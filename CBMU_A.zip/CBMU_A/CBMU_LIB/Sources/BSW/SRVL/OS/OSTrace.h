/*******************************************************************************
*
*  FILE
*     OSTrace.h
*
*  DESCRIPTION
*     the header file of OsTrace
*      
*       
*  COPYRIGHT
*     (c)Copyright 2008, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*    Gu Bin
*
*  VERSION
*    1.00
*
*******************************************************************************/

/*******************************************************************************
*                      Revision  History 
*                              
*   V1.00   18.11.2008  Gu Bin:  Initial version
*******************************************************************************/

#ifndef _OSTRACE_H_
#define _OSTRACE_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "OSTimer.h"
#include "OSTrace_Types.h"                        
/*******************************************************************************
* definition                                                 
*******************************************************************************/
#define OSTRACE_ETGROUP_NUM   2
#define TASKIdle              0   /* Do not modify it */
#define TASK10MS              1   /* Do not modify it */

#define OSTRACE_ETM_START     0U
#define OSTRACE_ETM_STOP      1U
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,OS_CODE) OSTrace_Init(void);
extern FUNC(void,OS_CODE) OSTrace_ExcTimeMeasure(uint8 groupNum,uint8 type);

#endif /* #ifndef _OSTRACE_H_ */