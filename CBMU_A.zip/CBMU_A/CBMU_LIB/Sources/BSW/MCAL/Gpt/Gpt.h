/*******************************************************************************
*
*  FILE
*     Gpt.h
*
*  DESCRIPTION
*     The Header file for Gpt   
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

#ifndef _GPT_H_
#define _GPT_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Gpt_Cfg.h"
#include "Mcu.h"
#include "Utility.h"

#if (GPT_SUPPORT_OSEK_OS == STD_ON)
  #include "osek.h"
#else
  #include "OSTimer_Cbk.h"
#endif

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* Vendor ID. */
#define GPT_VENDOR_ID         6666

/* Module ID  */
#define GPT_MODULE_ID         100

/* Version number of the module */
#define GPT_SW_MAJOR_VERSION    1
#define GPT_SW_MINOR_VERSION    0
#define GPT_SW_PATCH_VERSION    0


#define GPT_INSTATNCE_ID        1



#define GPT_CRGFLG      (*(volatile uint8*) 0x0037)
#define GPT_CRGINT      (*(volatile uint8*) 0x0038)
#define GPT_RTICTL      (*(volatile uint8*) 0x003B)

#define GPT_TIM_TSCR1   (*(volatile uint8*) 0x003D6)
#define GPT_TIM_PTPSR   (*(volatile uint8*) 0x003FE)

#define GPT_TIM_TCNT    (*(volatile uint16*) 0x03D4)

#define TIM_TSCR1_PRNT_MASK             8
#define TIM_TSCR1_TFFCA_MASK            16
#define TIM_TSCR1_TSFRZ_MASK            32
#define TIM_TSCR1_TSWAI_MASK            64
#define TIM_TSCR1_TEN_MASK              128
/*******************************************************************************
* Macros                                                                
*******************************************************************************/
/* Macro to calculate prescaler for binary Divider*/
#define GPT_RTICTL_PRESCALE_0(a)   (  ( 1UL << ( 9 + ( a ) ) ) )


/* Const used to calculate presclaer for Decimal Divider */
#define GPT_RTICTL_PRESCALE_1_HASH (  0x320A0351 )

/* Macro to calculate prescaler for Decimal Divider*/
#define GPT_RTICTL_PRESCALE_1(a)                                            \
(                                                                              \
   ( ( GPT_RTICTL_PRESCALE_1_HASH >> ( ( ( a ) % 3 ) * 3     ) ) & 0x07 ) * \
   ( ( GPT_RTICTL_PRESCALE_1_HASH >> ( ( ( a ) / 3 ) * 7 + 9 ) ) & 0x7f ) * \
   1000                                                                        \
)

/* Depend on slected divider, calculate the prescaler value */
#define _GPT_RTICTL_PRESCALE_GET(a,b) ( GPT_RTICTL_PRESCALE_ ## a  ( b ))
#define  GPT_RTICTL_PRESCALE_GET(a,b) (_GPT_RTICTL_PRESCALE_GET ( a, b ))


/* Pre Calculate prescaler setting according to NS  BEGIN */
#if ( GPT_RTICTL_RTDEC == 1 )
#define GPT_RTICTL_PRESCALE(NS)                                          \
(                                                                           \
   UTILITY_LOG10 ( ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) / 6400 ) * 3 + \
   (                                                                        \
      (                                                                     \
         (                                                                  \
            ( ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) / 6400 ) /         \
            (                                                               \
               (                                                            \
                  UTILITY_LOG10                                              \
                  (                                                         \
                     ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) / 6400      \
                  ) < 2 ? 1 : 10                                            \
               ) *                                                          \
               (                                                            \
                  UTILITY_LOG10                                              \
                  (                                                         \
                     ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) / 6400      \
                  ) < 1 ? 1 : 10                                            \
               )                                                            \
            )                                                               \
         ) / 5                                                              \
      ) == 0 ? 0 : 1                                                        \
   ) +                                                                      \
   (                                                                        \
      (                                                                     \
         (                                                                  \
            ( ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) / 6400 ) /         \
            (                                                               \
               (                                                            \
                  UTILITY_LOG10                                              \
                  (                                                         \
                     ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) / 6400      \
                  ) < 2 ? 1 : 10                                            \
               ) *                                                          \
               (                                                            \
                  UTILITY_LOG10                                              \
                  (                                                         \
                     ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) / 6400      \
                  ) < 1 ? 1 : 10                                            \
               )                                                            \
            )                                                               \
         ) / 2                                                              \
      ) == 0 ? 0 : 1                                                        \
   )                                                                        \
)
#else
#define GPT_RTICTL_PRESCALE(NS)                                    \
(                                                                     \
   ( ( ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) >> 14 ) > 0 )     ? \
   UTILITY_LOG2 ( ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) >> 14 ) : \
   1                                                                  \
)
#endif
/* Calculate prescaler setting according to NS  END */

/* Calculate Modulus Counter */
#define GPT_RTICTL_MODULUS(NS)               \
(                                               \
   ( ( ( NS ) / 1000 ) * MCU_OSC_FREQ_MHZ ) / \
   GPT_RTICTL_PRESCALE_GET                   \
   (                                            \
      GPT_RTICTL_RTDEC,                      \
      GPT_RTICTL_PRESCALE ( NS )             \
   )                                          - \
   1                                            \
)

/* RTI Initialization  */
#define Gpt_RtiInit(NS)               \
{                                              \
   GPT_RTICTL =                                    \
   (                                           \
      ( GPT_RTICTL_RTDEC           << 7 ) | \
      ( GPT_RTICTL_PRESCALE ( NS ) << 4 ) | \
      ( GPT_RTICTL_MODULUS  ( NS )      )   \
   );                                          \
   GPT_CRGINT |= 0x80;                             \
}


/* TIM initialization */
/* Use Precision prescaler */
#define Gpt_TimInit()                     \
{                                         \
  GPT_TIM_TSCR1 |= TIM_TSCR1_PRNT_MASK;   \
  GPT_TIM_PTPSR = GPT_TIM_TCNT_PRESCALER; \
  GPT_TIM_TSCR1 |= TIM_TSCR1_TSFRZ_MASK;  \
  GPT_TIM_TSCR1 |= TIM_TSCR1_TEN_MASK;    \
}

#define Gpt_GetCurrentCnt()  (GPT_TIM_TCNT)

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,GPT_CODE) Gpt_Init(void);
extern FUNC(void,GPT_CODE) Gpt_GetVersionInfo(Std_VersionInfoType* versioninfo);
extern FUNC(void,GPT_CODE) Gpt_RtiIrqHandler(void);


#define GPT_START_SEC_CODE_NEAR
#include "MemMap.h"

extern IRQFUNC(Gpt_RtiInterrupt);

#define GPT_STOP_SEC_CODE_NEAR
#include "MemMap.h"

#endif /* #ifndef _GPT_H_ */