/*
 * File: PtMon.h
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PtMon_h_
#define RTW_HEADER_PtMon_h_
#ifndef BMS_MON_COMMON_INCLUDES_
# define BMS_MON_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "SetErr.h"
#endif                                 /* BMS_MON_COMMON_INCLUDES_ */

#include "BMS_MON_types.h"

/* Child system includes */
#include "rt_sys_BMS_MON_3.h"

/* Block signals for system '<S87>/SRC_Check' */
typedef struct {
  uint8_T SRC_Def_Status;              /* '<S88>/SRC_Check' */
  uint8_T SRC_Tmp_Def_Flag;            /* '<S88>/SRC_Check' */
} rtB_SRC_Check_BMS_MON_l;

/* Block states (auto storage) for system '<S87>/SRC_Check' */
typedef struct {
  uint16_T local_Timer;                /* '<S88>/SRC_Check' */
  struct {
    uint_T is_Defect:3;                /* '<S88>/SRC_Check' */
    uint_T is_c48_BMS_MON:2;           /* '<S88>/SRC_Check' */
    uint_T is_active_c48_BMS_MON:1;    /* '<S88>/SRC_Check' */
  } bitsForTID0;
} rtDW_SRC_Check_BMS_MON_k;

/* Block signals for system '<S8>/discharge' */
typedef struct {
  uint8_T Merge;                       /* '<S102>/Merge' */
  rtB_SRC_Check_BMS_MON_l SRC_Check_k; /* '<S108>/SRC_Check' */
  rtB_SRC_Check_BMS_MON_l SRC_Check;   /* '<S99>/SRC_Check' */
} rtB_discharge_BMS_MON;

/* Block states (auto storage) for system '<S8>/discharge' */
typedef struct {
  boolean_T Dem_stClear;               /* '<S94>/CLT_BITEPOINTADAPT_POSN' */
  boolean_T Dem_stClear_g;             /* '<S93>/CLT_BITEPOINTADAPT_POSN' */
  rtDW_SRC_Check_BMS_MON_k SRC_Check_k;/* '<S108>/SRC_Check' */
  rtDW_SRC_Check_BMS_MON_k SRC_Check;  /* '<S99>/SRC_Check' */
} rtDW_discharge_BMS_MON;

/* Block signals for system '<S8>/sc charge' */
typedef struct {
  uint8_T Merge;                       /* '<S178>/Merge' */
  rtB_SRC_Check_BMS_MON_l SRC_Check_p; /* '<S184>/SRC_Check' */
  rtB_SRC_Check_BMS_MON_l SRC_Check;   /* '<S175>/SRC_Check' */
} rtB_sccharge_BMS_MON;

/* Block states (auto storage) for system '<S8>/sc charge' */
typedef struct {
  boolean_T Dem_stClear;               /* '<S170>/CLT_BITEPOINTADAPT_POSN' */
  boolean_T Dem_stClear_h;             /* '<S169>/CLT_BITEPOINTADAPT_POSN' */
  rtDW_SRC_Check_BMS_MON_k SRC_Check_p;/* '<S184>/SRC_Check' */
  rtDW_SRC_Check_BMS_MON_k SRC_Check;  /* '<S175>/SRC_Check' */
} rtDW_sccharge_BMS_MON;

/* Block signals for system '<S156>/SRC_Check' */
typedef struct {
  uint8_T SRC_Def_Status;              /* '<S157>/SRC_Check' */
  uint8_T SRC_Tmp_Def_Flag;            /* '<S157>/SRC_Check' */
} rtB_SRC_Check_BMS_MON_j;

/* Block states (auto storage) for system '<S156>/SRC_Check' */
typedef struct {
  uint16_T local_Timer;                /* '<S157>/SRC_Check' */
  struct {
    uint_T is_Defect:3;                /* '<S157>/SRC_Check' */
    uint_T is_c30_BMS_MON:2;           /* '<S157>/SRC_Check' */
    uint_T is_active_c30_BMS_MON:1;    /* '<S157>/SRC_Check' */
  } bitsForTID0;
} rtDW_SRC_Check_BMS_MON_kc;

extern void BMS_MON_SRC_Check_b_Init(rtB_SRC_Check_BMS_MON_l *localB,
  rtDW_SRC_Check_BMS_MON_k *localDW);
extern void BMS_MON_SRC_Check_f(boolean_T rtu_Clear_Def_Flag, t_Temp1
  rtu_Sig_Volt, t_Temp1 rtu_Par_SRC_H_Threshold, t_Temp1 rtu_Par_SRC_L_Threshold,
  uint16_T rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_l *localB, rtDW_SRC_Check_BMS_MON_k *
  localDW);
extern void BMS_MON_IfActionSubsystem_m(t_Temp1 rtu_In1, t_Temp1 *rty_Out1);
extern void BMS_IfAbnormalActionSubsystem_m(boolean_T rtu_In1, t_Temp1 rtu_In2,
  uint8_T rtu_In3, boolean_T *rty_Out1, t_Temp1 *rty_Out2, uint8_T *rty_Out3);
extern void BMS_MON_discharge_Init(rtB_discharge_BMS_MON *localB,
  rtDW_discharge_BMS_MON *localDW);
extern void BMS_MON_discharge_Start(rtB_discharge_BMS_MON *localB,
  rtDW_discharge_BMS_MON *localDW);
extern void BMS_MON_discharge(t_Temp1 rtu_CellTempMax, uint8_T *rty_CTMax_St,
  rtB_discharge_BMS_MON *localB, rtDW_discharge_BMS_MON *localDW);
extern void BMS_MON_sccharge_Init(rtB_sccharge_BMS_MON *localB,
  rtDW_sccharge_BMS_MON *localDW);
extern void BMS_MON_sccharge_Start(rtB_sccharge_BMS_MON *localB,
  rtDW_sccharge_BMS_MON *localDW);
extern void BMS_MON_sccharge(t_Temp1 rtu_CellTempMax, uint8_T *rty_CTMax_St,
  rtB_sccharge_BMS_MON *localB, rtDW_sccharge_BMS_MON *localDW);
extern void BMS_MON_SRC_Check_n_Init(rtB_SRC_Check_BMS_MON_j *localB,
  rtDW_SRC_Check_BMS_MON_kc *localDW);
extern void BMS_MON_SRC_Check_h(boolean_T rtu_Clear_Def_Flag, t_Temp1
  rtu_Sig_Volt, t_Temp1 rtu_Par_SRC_H_Threshold, t_Temp1 rtu_Par_SRC_L_Threshold,
  uint16_T rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_j *localB, rtDW_SRC_Check_BMS_MON_kc
  *localDW);
extern void BMS_MON_PtMon_Init(void);
extern void BMS_MON_PtMon_Start(void);
extern void BMS_MON_PtMon(void);

#endif                                 /* RTW_HEADER_PtMon_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
