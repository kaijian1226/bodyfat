#ifndef _SD2405_CFG_H_
#define _SD2405_CFG_H_

#define SD2405_MAXERRTIMES   			50U


#endif