/*******************************************************************************
*
*  FILE
*     Gpt.c
*
*  DESCRIPTION
*     The Driver for Gpt   
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Gpt.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/
/*******************************************************************************
* NAME:             Gpt_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize the Gpt  
*******************************************************************************/
FUNC(void,GPT_CODE) Gpt_Init(void) 
{
  Gpt_RtiInit(GPT_RTI_INT_PERIOD_NS);  
   
  Gpt_TimInit();
#if (GPT_SUPPORT_OSEK_OS == STD_ON)
  #if (GPT_SYSTEM_TIMER_USER_DEFINED == STD_ON)
      InitCounterSystemTimer(0);
  #endif
#endif     
}

/*******************************************************************************
* NAME:             Gpt_RtiIrqHandler
* CALLED BY:        Interrupt
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      interrupt handler   
*******************************************************************************/
FUNC(void,GPT_CODE) Gpt_RtiIrqHandler(void) 
{
  /* Clear RTI Interrupt Flag */
  GPT_CRGFLG = 0x80;
  
#if (GPT_SUPPORT_OSEK_OS == STD_ON)  //����
  #if (GPT_SYSTEM_TIMER_USER_DEFINED == STD_ON)
    CounterTriggerSystemTimer();
  #endif
#else
  OsTimer_Increment(GPT_RTI_INT_PERIOD);
#endif  
}

/****************************************************************************
* NAME:             Gpt_GetVersionInfo
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Std_VersionInfoType *versioninfo
* RETURN VALUES:    void
* DESCRIPTION:      Service to get version information     
****************************************************************************/
FUNC(void,GPT_CODE) Gpt_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
  versioninfo->vendorID = GPT_VENDOR_ID;
  versioninfo->moduleID = GPT_MODULE_ID;
  versioninfo->sw_major_version = GPT_SW_MAJOR_VERSION;
  versioninfo->sw_minor_version = GPT_SW_MINOR_VERSION;
  versioninfo->sw_patch_version = GPT_SW_PATCH_VERSION;
} 




/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

