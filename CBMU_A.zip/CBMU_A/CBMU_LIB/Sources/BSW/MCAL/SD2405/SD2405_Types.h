#ifndef __SD2405_TYPES_H__
#define __SD2405_TYPES_H__
/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Compiler.h"
#include "Platform_types.h" /*platform types from AUTOSAR*/

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
typedef  struct  
{
  uint8 second;
  uint8 minute;
  uint8 hour;
  uint8 week;
  uint8 day;
  uint8 month;
  uint8 year;
}SD2405_TD_TYPE;



#endif

