/*
 * File: IsoMon.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "IsoMon.h"

/* Include model header file for global data */
#include "BMS_MON.h"
#include "BMS_MON_private.h"

/* Named constants for Chart: '<S244>/SRC_Check' */
#define BMS_MON_IN_Defect_n            ((uint8_T)1U)
#define BMS_MON_IN_NO_ACTIVE_CHILD_bm  ((uint8_T)0U)
#define BMS_MON_IN_NO_Defect_i         ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Confimed_p ((uint8_T)1U)
#define BMS_MON_IN_SRC_High_Healing_i  ((uint8_T)3U)
#define BMS_MON_IN_SRC_Low_Confimed_n  ((uint8_T)4U)
#define BMS_MON_IN_SRC_Low_Debouncing_d ((uint8_T)5U)
#define BMS_MON_IN_SRC_Low_Healing_d   ((uint8_T)6U)
#define BMS_MO_IN_SRC_High_Debouncing_a ((uint8_T)2U)

/*
 * Initial conditions for atomic system:
 *    '<S243>/SRC_Check'
 *    '<S252>/SRC_Check'
 */
void BMS_MON_SRC_Check_f_Init(rtB_SRC_Check_BMS_MON_p *localB,
  rtDW_SRC_Check_BMS_MON_g *localDW)
{
  /* InitializeConditions for Chart: '<S244>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
  localDW->bitsForTID0.is_active_c56_BMS_MON = 0U;
  localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
  localB->SRC_Tmp_Def_Flag = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S243>/SRC_Check'
 *    '<S252>/SRC_Check'
 */
void BMS_MON_SRC_Check_d(boolean_T rtu_Clear_Def_Flag, uint16_T rtu_Sig_Volt,
  uint16_T rtu_Par_SRC_H_Threshold, uint16_T rtu_Par_SRC_L_Threshold, uint16_T
  rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_p *localB, rtDW_SRC_Check_BMS_MON_g *
  localDW)
{
  /* Chart: '<S244>/SRC_Check' */
  /* Gateway: Task_100ms/HVCU/HVCU_Mon/IsoMon/ISORES_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_100ms/HVCU/HVCU_Mon/IsoMon/ISORES_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c56_BMS_MON == 0U) {
    /* Entry: Task_100ms/HVCU/HVCU_Mon/IsoMon/ISORES_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c56_BMS_MON = 1U;

    /* Entry Internal: Task_100ms/HVCU/HVCU_Mon/IsoMon/ISORES_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S245>:9' */
    localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_NO_Defect_i;

    /* Entry 'NO_Defect': '<S245>:1' */
    localB->SRC_Def_Status = SRC_NON_DEF;
  } else if (localDW->bitsForTID0.is_c56_BMS_MON == BMS_MON_IN_Defect_n) {
    /* During 'Defect': '<S245>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S245>:22' */
      /* Exit Internal 'Defect': '<S245>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MO_IN_SRC_High_Debouncing_a:
        /* Exit 'SRC_High_Debouncing': '<S245>:4' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_d:
        /* Exit 'SRC_Low_Debouncing': '<S245>:3' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
        break;

       default:
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
        break;
      }

      localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_NO_Defect_i;

      /* Entry 'NO_Defect': '<S245>:1' */
      localB->SRC_Def_Status = SRC_NON_DEF;
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Confimed_p:
        /* During 'SRC_High_Confimed': '<S245>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S245>:13' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Healing_i;

          /* Entry 'SRC_High_Healing': '<S245>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MO_IN_SRC_High_Debouncing_a:
        /* During 'SRC_High_Debouncing': '<S245>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S245>:12' */
          /* Exit 'SRC_High_Debouncing': '<S245>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
          localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_NO_Defect_i;

          /* Entry 'NO_Defect': '<S245>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S245>:14' */
          /* Exit 'SRC_High_Debouncing': '<S245>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_p;

          /* Entry 'SRC_High_Confimed': '<S245>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Healing_i:
        /* During 'SRC_High_Healing': '<S245>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S245>:15' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
          localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_NO_Defect_i;

          /* Entry 'NO_Defect': '<S245>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S245>:17' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_p;

          /* Entry 'SRC_High_Confimed': '<S245>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Confimed_n:
        /* During 'SRC_Low_Confimed': '<S245>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S245>:18' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Healing_d;

          /* Entry 'SRC_Low_Healing': '<S245>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_d:
        /* During 'SRC_Low_Debouncing': '<S245>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S245>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S245>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
          localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_NO_Defect_i;

          /* Entry 'NO_Defect': '<S245>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S245>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S245>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_n;

          /* Entry 'SRC_Low_Confimed': '<S245>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S245>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S245>:20' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_bm;
          localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_NO_Defect_i;

          /* Entry 'NO_Defect': '<S245>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S245>:19' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_n;

          /* Entry 'SRC_Low_Confimed': '<S245>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    /* During 'NO_Defect': '<S245>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S245>:10' */
      localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_Defect_n;
      localDW->bitsForTID0.is_Defect = BMS_MO_IN_SRC_High_Debouncing_a;

      /* Entry 'SRC_High_Debouncing': '<S245>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
      localB->SRC_Tmp_Def_Flag = 1U;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S245>:11' */
        localDW->bitsForTID0.is_c56_BMS_MON = BMS_MON_IN_Defect_n;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Debouncing_d;

        /* Entry 'SRC_Low_Debouncing': '<S245>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
        localB->SRC_Tmp_Def_Flag = 1U;
      }
    }
  }

  /* End of Chart: '<S244>/SRC_Check' */
}

/*
 * Output and update for action system:
 *    '<S236>/If Abnormal Action Subsystem'
 *    '<S236>/If Normal Action Subsystem'
 */
void BM_IfAbnormalActionSubsystem_ml(boolean_T rtu_In1, uint16_T rtu_In2,
  uint8_T rtu_In3, boolean_T *rty_Out1, uint16_T *rty_Out2, uint8_T *rty_Out3)
{
  /* Inport: '<S239>/In1' */
  *rty_Out1 = rtu_In1;

  /* Inport: '<S239>/In2' */
  *rty_Out2 = rtu_In2;

  /* Inport: '<S239>/In3' */
  *rty_Out3 = rtu_In3;
}

/* Initial conditions for atomic system: '<S227>/IsoMon' */
void BMS_MON_IsoMon_Init(void)
{
  /* InitializeConditions for Atomic SubSystem: '<S243>/SRC_Check' */
  BMS_MON_SRC_Check_f_Init(&BMS_MON_B.SRC_Check_d, &BMS_MON_DWork.SRC_Check_d);

  /* End of InitializeConditions for SubSystem: '<S243>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S252>/SRC_Check' */
  BMS_MON_SRC_Check_f_Init(&BMS_MON_B.SRC_Check_dr, &BMS_MON_DWork.SRC_Check_dr);

  /* End of InitializeConditions for SubSystem: '<S252>/SRC_Check' */
}

/* Output and update for atomic system: '<S227>/IsoMon' */
void BMS_MON_IsoMon(void)
{
  boolean_T rtb_LogicalOperator1;
  uint8_T rtb_Switch;
  uint8_T rtb_Switch_bv;
  boolean_T rtb_Merge;
  uint16_T rtb_Merge1_l2;

  /* Outputs for Atomic SubSystem: '<S243>/SRC_Check' */

  /* Constant: '<S243>/Constant1' incorporates:
   *  Constant: '<S243>/Constant2'
   *  Constant: '<S243>/Constant3'
   *  Constant: '<S243>/Constant4'
   *  Constant: '<S243>/Constant5'
   *  Constant: '<S243>/Constant6'
   *  Constant: '<S243>/Constant7'
   *  Constant: '<S243>/Constant8'
   *  Inport: '<Root>/com_Resistance'
   */
  BMS_MON_SRC_Check_d(false, com_Resistance, IsoSigASRCHigh, IsoSigASRCLow,
                      BmsSigASRCHighPosDeb, BmsSigASRCHighNegDeb,
                      BmsSigASRCLowPosDeb, BmsSigASRCLowNegDeb, StepTim,
                      &BMS_MON_B.SRC_Check_d, &BMS_MON_DWork.SRC_Check_d);

  /* End of Outputs for SubSystem: '<S243>/SRC_Check' */

  /* Logic: '<S242>/Logical Operator1' incorporates:
   *  DataStoreRead: '<S242>/Data Store Read'
   *  Logic: '<S242>/Logical Operator4'
   */
  rtb_LogicalOperator1 = ((BMS_MON_B.SRC_Check_d.SRC_Tmp_Def_Flag != 0) &&
    (!BMS_MON_DWork.Dem_stClear_j));

  /* Switch: '<S238>/Switch2' incorporates:
   *  Constant: '<S238>/Constant4'
   *  DataStoreRead: '<S238>/Data Store Read1'
   *  Logic: '<S238>/Logical Operator3'
   */
  if (!BMS_MON_DWork.Dem_stClear_j) {
    rtb_Switch = BMS_MON_B.SRC_Check_d.SRC_Def_Status;
  } else {
    rtb_Switch = SRC_NON_DEF;
  }

  /* End of Switch: '<S238>/Switch2' */

  /* Switch: '<S238>/Switch' incorporates:
   *  Constant: '<S238>/Constant4'
   *  RelationalOperator: '<S238>/Relational Operator1'
   */
  if (rtb_Switch != SRC_NON_DEF) {
    rtb_Switch_bv = BMS_MON_B.SRC_Check_d.SRC_Def_Status;
  } else {
    rtb_Switch_bv = SRC_NON_DEF;
  }

  /* End of Switch: '<S238>/Switch' */

  /* Outputs for Atomic SubSystem: '<S252>/SRC_Check' */

  /* Constant: '<S252>/Constant1' incorporates:
   *  Constant: '<S252>/Constant2'
   *  Constant: '<S252>/Constant3'
   *  Constant: '<S252>/Constant4'
   *  Constant: '<S252>/Constant5'
   *  Constant: '<S252>/Constant6'
   *  Constant: '<S252>/Constant7'
   *  Constant: '<S252>/Constant8'
   *  Inport: '<Root>/com_Resistance'
   */
  BMS_MON_SRC_Check_d(false, com_Resistance, IsoSigASRCTooHigh, IsoSigASRCTooLow,
                      BmsSigASRCHighPosDeb, BmsSigASRCHighNegDeb,
                      BmsSigASRCLowPosDeb, BmsSigASRCLowNegDeb, StepTim,
                      &BMS_MON_B.SRC_Check_dr, &BMS_MON_DWork.SRC_Check_dr);

  /* End of Outputs for SubSystem: '<S252>/SRC_Check' */

  /* SwitchCase: '<S246>/Switch Case' incorporates:
   *  Constant: '<S246>/Constant1'
   *  Constant: '<S246>/Constant2'
   *  Constant: '<S246>/Constant4'
   */
  switch ((int32_T)BMS_MON_B.SRC_Check_dr.SRC_Def_Status) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S246>/Switch Case Action Subsystem' incorporates:
     *  ActionPort: '<S249>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_j);

    /* End of Outputs for SubSystem: '<S246>/Switch Case Action Subsystem' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S246>/Switch Case Action Subsystem1' incorporates:
     *  ActionPort: '<S250>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_j);

    /* End of Outputs for SubSystem: '<S246>/Switch Case Action Subsystem1' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S246>/Switch Case Action Subsystem2' incorporates:
     *  ActionPort: '<S251>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_j);

    /* End of Outputs for SubSystem: '<S246>/Switch Case Action Subsystem2' */
    break;
  }

  /* End of SwitchCase: '<S246>/Switch Case' */

  /* Switch: '<S237>/Switch2' incorporates:
   *  Constant: '<S237>/Constant4'
   *  DataStoreRead: '<S237>/Data Store Read1'
   *  Logic: '<S237>/Logical Operator3'
   */
  if (!BMS_MON_DWork.Dem_stClear_d) {
    rtb_Switch = BMS_MON_B.Merge_j;
  } else {
    rtb_Switch = SRC_NON_DEF;
  }

  /* End of Switch: '<S237>/Switch2' */

  /* Switch: '<S237>/Switch' incorporates:
   *  Constant: '<S237>/Constant4'
   *  RelationalOperator: '<S237>/Relational Operator1'
   */
  if (rtb_Switch != SRC_NON_DEF) {
    rtb_Switch = BMS_MON_B.Merge_j;
  } else {
    rtb_Switch = SRC_NON_DEF;
  }

  /* End of Switch: '<S237>/Switch' */

  /* If: '<S236>/If Abnormal' incorporates:
   *  DataStoreRead: '<S248>/Data Store Read'
   *  Inport: '<Root>/com_Resistance'
   *  Logic: '<S248>/Logical Operator1'
   *  Logic: '<S248>/Logical Operator4'
   */
  if (rtb_Switch != 0) {
    /* Outputs for IfAction SubSystem: '<S236>/If Abnormal Action Subsystem' incorporates:
     *  ActionPort: '<S239>/Action Port'
     */
    BM_IfAbnormalActionSubsystem_ml((BMS_MON_B.SRC_Check_dr.SRC_Tmp_Def_Flag !=
      0) && (!BMS_MON_DWork.Dem_stClear_d), com_Resistance, rtb_Switch,
      &rtb_Merge, &rtb_Merge1_l2, &BMS_MON_B.Merge2_p);

    /* End of Outputs for SubSystem: '<S236>/If Abnormal Action Subsystem' */
  } else {
    /* Outputs for IfAction SubSystem: '<S236>/If Normal Action Subsystem' incorporates:
     *  ActionPort: '<S240>/Action Port'
     */
    BM_IfAbnormalActionSubsystem_ml(rtb_LogicalOperator1, com_Resistance,
      rtb_Switch_bv, &rtb_Merge, &rtb_Merge1_l2, &BMS_MON_B.Merge2_p);

    /* End of Outputs for SubSystem: '<S236>/If Normal Action Subsystem' */
  }

  /* End of If: '<S236>/If Abnormal' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
