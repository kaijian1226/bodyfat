/*******************************************************************************
*
*  FILE
*     Adc.c
*
*  DESCRIPTION
*     Adc (Adc initialization) ��AD���ü��ɼ�
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.1
*
*******************************************************************************/

/*******************************************************************************
* Include files                                                        
*******************************************************************************/
#include "Adc.h"            
#include "Det.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define ADC_ERROR_VALUE   ((Adc_ResultType)(0xFFFF))
/*******************************************************************************
* macros                                                                  
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Adc_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize ADC0 and ADC1      
*******************************************************************************/
void ADC_CODE Adc_Init(void)  
{
  /*Wrap Around Channel Select*/
  /* ADC0:Wraparound to AN0 after Converting AN15 */
  ADC_ATD0CTL0 = 0x0f; 
  /* ADC1:Wraparound to AN0 after Converting AN7  */ 
  ADC_ATD1CTL0 = 0x07; 
        
  /*A/D Resolution=12bits,no External Trigger,No discharge before sampling*/

  /*ADC0: resolution is 12bits*/
  ADC_ATD0CTL1|=ATD0CTL1_SRES1_MASK;
  ADC_ATD0CTL1&=(~ATD0CTL1_SRES0_MASK);
  /*ADC1: resolution is 12bits */
  ADC_ATD1CTL1|=ATD1CTL1_SRES1_MASK;
  ADC_ATD1CTL1&=(~ATD1CTL1_SRES0_MASK);

  /*AFFC=1,ICLKSTP=0,ETRIGLE=0,ETRIGP=0,ETRIGE=0,ASCIE=0,ACMPIE=0.*/
  /*AFFC=1:Read access to the result register will cause the associated
  CCF[n] to clear automatically*/
  ADC_ATD0CTL2 = 0x40;
  ADC_ATD1CTL2 = 0x40;

  /*DJM=1,S8C=0,S4C=0,S2C=0,S1C=0,FIFO=0,FRZ[1:0]=10*/
  /*Right justified data in the result registers;
  The number of conversions per sequence is 16 ;
  Background debug freeze application:Finish current conversion, then freeze ;
  Conversion results are placed in the corresponding result register */          
  ADC_ATD0CTL3 = 0x82; 

  /*DJM=1,S8C=1,S4C=0,S2C=0,S1C=0,FIFO=0,FRZ[1:0]=10*/                         
  /*The number of conversions per sequence is 8*/
  ADC_ATD1CTL3 = 0xc2;

  /*ATDnCTL4= RESET => ATDCLK Frequence=BUS Frequence/12,Sample Time=4*ATD Clock Cycle*/

  /*SC=0,SCAN=1,MULI=1,CD=0,CC=0,CB=0,CA=0*/
  /*Scan Mode,Multi-Channel Sample ,First Channel is AN0*/
  ADC_ATD0CTL5 = 0x30;
  ADC_ATD1CTL5 = 0x30;
}

/*******************************************************************************
* NAME:             Adc_Read
* CALLED BY:        Application
* PRECONDITIONS:    Adc_Init
* INPUT PARAMETERS: Channel ID of ADC0 and ADC1
*                     0--15 for AN0--AN15 of ADC0
*                     15--23 for AN0--AN7 of ADC1    
* RETURN VALUES:    Value from Conversion Result Register of specified AD channel
* DESCRIPTION:      Read the value of AD Conversion Result Register    
*******************************************************************************/
#define ADC_START_SEC_CODE_NEAR
#include "MemMap.h"

//==========================================================================
//��������:Adc_ResultType ADC_CODE_NEAR Adc_Read(Adc_ChannelType channel_id)
//��������:��ȡͨ������ֵ
//�������:channel_id������ͨ��
//�������:����ֵ
//��������:
//==========================================================================
Adc_ResultType ADC_CODE_NEAR Adc_Read(Adc_ChannelType channel_id)
{
  Adc_ResultType result;
  uint8 offset;
  
  if(channel_id <= 15)
  {
    offset = channel_id;
    result = (Adc_ResultType)(*(uint16*)(ADC_ATD0DR0_ADDR + offset)); 
  }
  else if(channel_id <= 23)
  {
    offset = channel_id - 16;
    result = (Adc_ResultType)*(uint16*)(ADC_ATD1DR0_ADDR + offset); 
  }
  else
  {
#if(ADC_DEV_ERROR_DETECT == STD_ON)  
    Det_ReportError(ADC_MODULE_ID,ADC_INSTANCE_ID,ADC_API_INITCLK_ID,ADC_E_WRONG_PARAM);
#endif
    result = ADC_ERROR_VALUE;
  }

  return(result);
}
#define ADC_STOP_SEC_CODE_NEAR
#include "MemMap.h"

