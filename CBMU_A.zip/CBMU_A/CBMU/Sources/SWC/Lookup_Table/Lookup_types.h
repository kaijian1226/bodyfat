/*
 * File: Lookup_types.h
 *
 * Code generated for Simulink model 'Lookup'.
 *
 * Model version                  : 1.488
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Wed Jun 22 13:54:32 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Lookup_types_h_
#define RTW_HEADER_Lookup_types_h_
#include "rtwtypes.h"
#ifndef _DEFINED_TYPEDEF_FOR_t_Temp1_
#define _DEFINED_TYPEDEF_FOR_t_Temp1_

typedef uint8_T t_Temp1;
typedef cuint8_T ct_Temp1;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Voltage3_
#define _DEFINED_TYPEDEF_FOR_t_Voltage3_

typedef uint16_T t_Voltage3;
typedef cuint16_T ct_Voltage3;

#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_Lookup RT_MODEL_Lookup;

#endif                                 /* RTW_HEADER_Lookup_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
