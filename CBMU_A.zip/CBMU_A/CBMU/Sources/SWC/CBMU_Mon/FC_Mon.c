/*
 * File: FC_Mon.c
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:39:52 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "FC_Mon.h"

/* Include model header file for global data */
#include "CBMU_MON.h"
#include "CBMU_MON_private.h"

/* Named constants for Chart: '<S8>/Chart' */
#define CBMU_MON_IN_CCS_Normal         ((uint8_T)1U)
#define CBMU_MON_IN_CCS_Timeout        ((uint8_T)2U)
#define CBMU_MON_IN_CNT1               ((uint8_T)1U)
#define CBMU_MON_IN_CNT2               ((uint8_T)1U)
#define CBMU_MON_IN_CNT3               ((uint8_T)1U)
#define CBMU_MON_IN_CNT4               ((uint8_T)1U)
#define CBMU_MON_IN_CNT5               ((uint8_T)1U)
#define CBMU_MON_IN_ChargingStop       ((uint8_T)1U)
#define CBMU_MON_IN_Check              ((uint8_T)1U)
#define CBMU_MON_IN_Count              ((uint8_T)2U)
#define CBMU_MON_IN_Data_SOCFull       ((uint8_T)2U)
#define CBMU_MON_IN_END                ((uint8_T)1U)
#define CBMU_MON_IN_ERR1               ((uint8_T)2U)
#define CBMU_MON_IN_ERR2               ((uint8_T)2U)
#define CBMU_MON_IN_ERR3               ((uint8_T)2U)
#define CBMU_MON_IN_ERR4               ((uint8_T)1U)
#define CBMU_MON_IN_Err                ((uint8_T)3U)
#define CBMU_MON_IN_FC_Charging_Mon    ((uint8_T)3U)
#define CBMU_MON_IN_FC_Handing         ((uint8_T)4U)
#define CBMU_MON_IN_Heating            ((uint8_T)1U)
#define CBMU_MON_IN_NO_ACTIVE_CHILD_d  ((uint8_T)0U)
#define CBMU_MON_IN_Normal1            ((uint8_T)3U)
#define CBMU_MON_IN_Normal2            ((uint8_T)3U)
#define CBMU_MON_IN_Normal3            ((uint8_T)3U)
#define CBMU_MON_IN_Normal4            ((uint8_T)2U)
#define CBMU_MON_IN_Normal4_1          ((uint8_T)2U)
#define CBMU_MON_IN_Normal4_2          ((uint8_T)2U)
#define CBMU_MON_IN_PTCHeating         ((uint8_T)2U)
#define CBMU_MON_IN_PTCRelayCheck      ((uint8_T)3U)
#define CBMU_MON_IN_ParamSetting       ((uint8_T)5U)
#define CBMU_MON_IN_delay              ((uint8_T)1U)
#define CBMU_MON_IN_step0              ((uint8_T)2U)
#define CBMU_MON_IN_step01             ((uint8_T)3U)
#define CBMU_MON_IN_step02             ((uint8_T)1U)
#define CBMU_MON_IN_step03             ((uint8_T)4U)
#define CBMU_MON_IN_step04             ((uint8_T)2U)
#define CBMU_MON_IN_step05             ((uint8_T)3U)
#define CBMU_MON_IN_step06             ((uint8_T)4U)
#define CBMU_MON_IN_step07             ((uint8_T)5U)
#define CBMU_MON_IN_step08             ((uint8_T)6U)
#define CBMU_MON_IN_step09             ((uint8_T)1U)
#define CBMU_MON_IN_step10             ((uint8_T)2U)
#define CBMU_MON_IN_step12             ((uint8_T)1U)
#define CBMU_MON_IN_step13             ((uint8_T)2U)
#define CBMU_MON_IN_step14             ((uint8_T)3U)
#define CBMU_MON_IN_step15             ((uint8_T)4U)
#define CBMU_MON_IN_step16             ((uint8_T)5U)
#define CBMU_MON_IN_step17             ((uint8_T)6U)

/* Named constants for Chart: '<S12>/current' */
#define CBMU_MON_IN_CalcStart          ((uint8_T)1U)
#define CBMU_MON_IN_RelayOff           ((uint8_T)2U)
#define CBMU_MON_IN_RelayOn            ((uint8_T)3U)

/* Named constants for Chart: '<S13>/current' */
#define CBMU_MON_IN_Init               ((uint8_T)1U)
#define CBMU_MON_IN_LookUpCur          ((uint8_T)2U)

/* Forward declaration for local functions */
static void CBMU_MON_BSTCheck(void);
static void CBMU_MON_enter_atomic_step12(void);
static void CBMU_M_exit_internal_PTCHeating(void);
static void CBMU_MON_Heating(void);
static void C_exit_internal_FC_Charging_Mon(void);
static void CBMU_MON_FC_Charging_Mon(void);

/* Function for Chart: '<S8>/Chart' */
static void CBMU_MON_BSTCheck(void)
{
  /* Graphical Function 'BSTCheck': '<S9>:403' */
  /* Transition: '<S9>:420' */
  if (com_BCS_CurSOC >= 100) {
    /* Transition: '<S9>:423' */
    /* Transition: '<S9>:424' */
    com_BST_SetSOCReach = 1U;
    if (CBMU_MON_B.DataStoreRead7 != SRC_NON_DEF) {
      /* Transition: '<S9>:427' */
      /* Transition: '<S9>:428' */
      com_BST_ISOFault = 1U;
    } else {
      /* Transition: '<S9>:425' */
      /* Transition: '<S9>:426' */
    }

    if ((com_BSM_MaxCellTemp >= 94) || (CBMU_MON_B.DataStoreRead3 ==
         SRC_TOO_HIGH_DEF)) {
      /* Transition: '<S9>:431' */
      /* Transition: '<S9>:432' */
      com_BST_BatOverTempFault = 1U;
    } else {
      /* Transition: '<S9>:429' */
      /* Transition: '<S9>:430' */
    }

    if (!O_S_FCCC) {
      /* Transition: '<S9>:435' */
      /* Transition: '<S9>:436' */
      com_BST_ConnecterFault = 1U;
    } else {
      /* Transition: '<S9>:433' */
      /* Transition: '<S9>:434' */
    }

    /* Inport: '<Root>/com_CVMax' */
    if (uMax > 12386U) {
      /* Transition: '<S9>:439' */
      /*   !!!!!!��ѹ����3.78V[(com_BCS_CurSOC>=100)] */
      /* Transition: '<S9>:440' */
      com_BST_VoltError = 1U;

      /* {com_BST_SetPVReach = 1;com_BST_SetCVReach = 1;} */
    } else {
      /* Transition: '<S9>:437' */
      /* Transition: '<S9>:438' */
    }

    /* End of Inport: '<Root>/com_CVMax' */
  } else {
    /* Transition: '<S9>:421' */
  }
}

/* Function for Chart: '<S8>/Chart' */
static void CBMU_MON_enter_atomic_step12(void)
{
  /* Entry 'step12': '<S9>:400' */
  ioa_PTCRelayCtrl = (RELAY_OFF != 0);
  com_BEM_RcvChgerStateMsg = 0U;

  /* ���������� */
  com_BST_SetCVReach = 0U;
  com_BST_SetPVReach = 0U;
  com_BST_SetSOCReach = 0U;

  /* SOCû�дﵽ */
  com_BST_ConnecterFault = 0U;
  com_BST_CompOverTempFault = 0U;
  com_BST_ConnOverTempFault = 0U;
  com_BST_ISOFault = 0U;
  com_BST_OtherFault = 0U;
  com_BST_BatOverTempFault = 0U;
  com_BST_VoltError = 0U;
  com_BST_CurrentError = 0U;
  CBMU_MON_BSTCheck();
  com_BSTTxEna = true;

  /* ����BST���� */
  CBMU_MON_DWork.fc_ct = 0U;
  FC_MON_test = 12U;

  /* ioa_negativeRelayCtl = RELAY_OFF;//�¼̵��� �˴��ĸ���Ϊ���̵��� ����Ҫ��	 */
  com_BPSHighVoltSts = 0U;
  com_BCLTxEna = false;
  com_BCSTxEna = false;
  com_BSMTxEna = false;
}

/* Function for Chart: '<S8>/Chart' */
static void CBMU_M_exit_internal_PTCHeating(void)
{
  /* Exit Internal 'PTCHeating': '<S9>:646' */
  /* Exit Internal 'CHECK4': '<S9>:671' */
  /* Exit Internal 'CHECK4_3': '<S9>:684' */
  CBMU_MON_DWork.bitsForTID0.is_CHECK4_3 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_3 = 0U;

  /* Exit Internal 'CHECK4_2': '<S9>:678' */
  if (CBMU_MON_DWork.bitsForTID0.is_CHECK4_2 == CBMU_MON_IN_CNT5) {
    /* Exit 'CNT5': '<S9>:682' */
    CBMU_MON_DWork.cnt5 = 0U;
    CBMU_MON_DWork.bitsForTID0.is_CHECK4_2 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  } else {
    CBMU_MON_DWork.bitsForTID0.is_CHECK4_2 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  }

  CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_2 = 0U;

  /* Exit Internal 'CHECK4_1': '<S9>:672' */
  if (CBMU_MON_DWork.bitsForTID0.is_CHECK4_1 == CBMU_MON_IN_CNT4) {
    /* Exit 'CNT4': '<S9>:676' */
    CBMU_MON_DWork.cnt4 = 0UL;
    CBMU_MON_DWork.bitsForTID0.is_CHECK4_1 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  } else {
    CBMU_MON_DWork.bitsForTID0.is_CHECK4_1 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  }

  CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_1 = 0U;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK4 = 0U;

  /* Exit Internal 'CHECK3': '<S9>:705' */
  if (CBMU_MON_DWork.bitsForTID0.is_CHECK3 == CBMU_MON_IN_CNT3) {
    /* Exit 'CNT3': '<S9>:709' */
    CBMU_MON_DWork.cnt3 = 0U;
    CBMU_MON_DWork.bitsForTID0.is_CHECK3 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  } else {
    CBMU_MON_DWork.bitsForTID0.is_CHECK3 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  }

  CBMU_MON_DWork.bitsForTID0.is_active_CHECK3 = 0U;

  /* Exit Internal 'CHECK2': '<S9>:655' */
  if (CBMU_MON_DWork.bitsForTID0.is_CHECK2 == CBMU_MON_IN_CNT2) {
    /* Exit 'CNT2': '<S9>:660' */
    CBMU_MON_DWork.cnt2_p5 = 0U;
    CBMU_MON_DWork.bitsForTID0.is_CHECK2 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  } else {
    CBMU_MON_DWork.bitsForTID0.is_CHECK2 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  }

  CBMU_MON_DWork.bitsForTID0.is_active_CHECK2 = 0U;

  /* Exit Internal 'CHECK1': '<S9>:647' */
  if (CBMU_MON_DWork.bitsForTID0.is_CHECK1 == CBMU_MON_IN_CNT1) {
    /* Exit 'CNT1': '<S9>:652' */
    CBMU_MON_DWork.cnt1_l = 0U;
    CBMU_MON_DWork.bitsForTID0.is_CHECK1 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  } else {
    CBMU_MON_DWork.bitsForTID0.is_CHECK1 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  }

  CBMU_MON_DWork.bitsForTID0.is_active_CHECK1 = 0U;
}

/* Function for Chart: '<S8>/Chart' */
static void CBMU_MON_Heating(void)
{
  int16_T tmp;
  uint32_T qY;

  /* During 'Heating': '<S9>:632' */
  switch (CBMU_MON_DWork.bitsForTID0.is_Heating) {
   case CBMU_MON_IN_END:
    /* During 'END': '<S9>:644' */
    HeatingSt = 1U;
    ioa_PTCRelayCtrl = (RELAY_OFF != 0);
    break;

   case CBMU_MON_IN_PTCHeating:
    /* Inport: '<Root>/com_CTMin' */
    /* During 'PTCHeating': '<S9>:646' */
    if ((tMin >= 43) || (CBMU_MON_B.PTCerr1 == 1) || (CBMU_MON_B.PTCerr2 == 1) ||
        (CBMU_MON_B.PTCerr3 == 1) || (CBMU_MON_B.PTCerr4 == 1)) {
      /* Transition: '<S9>:640' */
      CBMU_M_exit_internal_PTCHeating();

      /* Exit 'PTCHeating': '<S9>:646' */
      /* ioa_PTCRelayCtl = RELAY_ON; */
      CBMU_MON_DWork.cnt = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_END;

      /* Entry 'END': '<S9>:644' */
      ioa_PTCRelayCtrl = (RELAY_OFF != 0);
    } else {
      qY = CBMU_MON_DWork.cnt + 10UL;
      if (qY < CBMU_MON_DWork.cnt) {
        qY = MAX_uint32_T;
      }

      CBMU_MON_DWork.cnt = qY;

      /* ��ʱ2Сʱ���Զ����� */
      /* During 'CHECK1': '<S9>:647' */
      switch (CBMU_MON_DWork.bitsForTID0.is_CHECK1) {
       case CBMU_MON_IN_CNT1:
        /* During 'CNT1': '<S9>:652' */
        if (CBMU_MON_B.DataStoreRead5 <= 32480U) {
          /* Transition: '<S9>:651' */
          /* Exit 'CNT1': '<S9>:652' */
          CBMU_MON_DWork.cnt1_l = 0U;
          CBMU_MON_DWork.bitsForTID0.is_CHECK1 = CBMU_MON_IN_Normal1;

          /* Entry 'Normal1': '<S9>:654' */
          CBMU_MON_B.PTCerr1 = 0U;
        } else if (CBMU_MON_DWork.cnt1_l > 20000U) {
          /* Transition: '<S9>:650' */
          /* Exit 'CNT1': '<S9>:652' */
          CBMU_MON_DWork.cnt1_l = 0U;
          CBMU_MON_DWork.bitsForTID0.is_CHECK1 = CBMU_MON_IN_ERR1;

          /* Entry 'ERR1': '<S9>:653' */
          CBMU_MON_B.PTCerr1 = 1U;

          /* PTC��· */
        } else {
          qY = CBMU_MON_DWork.cnt1_l + 10UL;
          if ((int32_T)qY > 65535L) {
            qY = 65535UL;
          }

          CBMU_MON_DWork.cnt1_l = (uint16_T)qY;
        }
        break;

       case CBMU_MON_IN_ERR1:
        /* During 'ERR1': '<S9>:653' */
        break;

       default:
        /* During 'Normal1': '<S9>:654' */
        if (CBMU_MON_B.DataStoreRead5 > 32480U) {
          /* Transition: '<S9>:649' */
          /* С��1A */
          CBMU_MON_DWork.bitsForTID0.is_CHECK1 = CBMU_MON_IN_CNT1;

          /* Entry 'CNT1': '<S9>:652' */
          CBMU_MON_DWork.cnt1_l = 0U;
        }
        break;
      }

      /* During 'CHECK2': '<S9>:655' */
      switch (CBMU_MON_DWork.bitsForTID0.is_CHECK2) {
       case CBMU_MON_IN_CNT2:
        /* During 'CNT2': '<S9>:660' */
        if (CBMU_MON_B.DataStoreRead5 >= 32128U) {
          /* Transition: '<S9>:659' */
          /* Exit 'CNT2': '<S9>:660' */
          CBMU_MON_DWork.cnt2_p5 = 0U;
          CBMU_MON_DWork.bitsForTID0.is_CHECK2 = CBMU_MON_IN_Normal2;

          /* Entry 'Normal2': '<S9>:662' */
          CBMU_MON_B.PTCerr2 = 0U;
        } else if (CBMU_MON_DWork.cnt2_p5 >= 200U) {
          /* Transition: '<S9>:658' */
          /* Exit 'CNT2': '<S9>:660' */
          CBMU_MON_DWork.cnt2_p5 = 0U;
          CBMU_MON_DWork.bitsForTID0.is_CHECK2 = CBMU_MON_IN_ERR2;

          /* Entry 'ERR2': '<S9>:661' */
          CBMU_MON_B.PTCerr2 = 1U;

          /* PTC��· */
        } else {
          qY = CBMU_MON_DWork.cnt2_p5 + 10UL;
          if ((int32_T)qY > 65535L) {
            qY = 65535UL;
          }

          CBMU_MON_DWork.cnt2_p5 = (uint16_T)qY;
        }
        break;

       case CBMU_MON_IN_ERR2:
        /* During 'ERR2': '<S9>:661' */
        break;

       default:
        /* During 'Normal2': '<S9>:662' */
        if (CBMU_MON_B.DataStoreRead5 < 32128U) {
          /* Transition: '<S9>:657' */
          /* ����12A */
          CBMU_MON_DWork.bitsForTID0.is_CHECK2 = CBMU_MON_IN_CNT2;

          /* Entry 'CNT2': '<S9>:660' */
          CBMU_MON_DWork.cnt2_p5 = 0U;
        }
        break;
      }

      /* During 'CHECK3': '<S9>:705' */
      switch (CBMU_MON_DWork.bitsForTID0.is_CHECK3) {
       case CBMU_MON_IN_CNT3:
        /* Inport: '<Root>/com_CVMin' */
        /* During 'CNT3': '<S9>:709' */
        if ((tMin > 20) && (uMin > 7864U)) {
          /* Transition: '<S9>:710' */
          /* �¶�>-20��;��ѹ>2.4V; */
          /* Exit 'CNT3': '<S9>:709' */
          CBMU_MON_DWork.cnt3 = 0U;
          CBMU_MON_DWork.bitsForTID0.is_CHECK3 = CBMU_MON_IN_Normal3;

          /* Entry 'Normal3': '<S9>:706' */
          CBMU_MON_B.PTCerr3 = 0U;
        } else if (CBMU_MON_DWork.cnt3 >= 10000U) {
          /* Transition: '<S9>:711' */
          /* Exit 'CNT3': '<S9>:709' */
          CBMU_MON_DWork.cnt3 = 0U;
          CBMU_MON_DWork.bitsForTID0.is_CHECK3 = CBMU_MON_IN_ERR3;

          /* Entry 'ERR3': '<S9>:708' */
          CBMU_MON_B.PTCerr3 = 1U;

          /* PTC������BMS���� */
        } else {
          qY = CBMU_MON_DWork.cnt3 + 10UL;
          if ((int32_T)qY > 65535L) {
            qY = 65535UL;
          }

          CBMU_MON_DWork.cnt3 = (uint16_T)qY;
        }
        break;

       case CBMU_MON_IN_ERR3:
        /* During 'ERR3': '<S9>:708' */
        break;

       default:
        /* Inport: '<Root>/com_CVMin' */
        /* During 'Normal3': '<S9>:706' */
        if ((tMin <= 20) || (uMin <= 7864U)) {
          /* Transition: '<S9>:707' */
          CBMU_MON_DWork.bitsForTID0.is_CHECK3 = CBMU_MON_IN_CNT3;

          /* Entry 'CNT3': '<S9>:709' */
          CBMU_MON_DWork.cnt3 = 0U;
        }
        break;
      }

      /* During 'CHECK4': '<S9>:671' */
      /* During 'CHECK4_1': '<S9>:672' */
      if (CBMU_MON_DWork.bitsForTID0.is_CHECK4_1 == CBMU_MON_IN_CNT4) {
        /* During 'CNT4': '<S9>:676' */
        if (tMin > CBMU_MON_DWork.tminback + 1) {
          /* Transition: '<S9>:675' */
          /* Exit 'CNT4': '<S9>:676' */
          CBMU_MON_DWork.cnt4 = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_CHECK4_1 = CBMU_MON_IN_Normal4_1;

          /* Entry 'Normal4_1': '<S9>:677' */
          CBMU_MON_DWork.tminback = tMin;
        } else {
          qY = CBMU_MON_DWork.cnt4 + 10UL;
          if (qY < CBMU_MON_DWork.cnt4) {
            qY = MAX_uint32_T;
          }

          CBMU_MON_DWork.cnt4 = qY;
        }
      } else {
        /* During 'Normal4_1': '<S9>:677' */
        tmp = tMin - CBMU_MON_DWork.tminback;
        if (tmp < 0) {
          tmp = -tmp;
        }

        if (tmp <= 1) {
          /* Transition: '<S9>:674' */
          CBMU_MON_DWork.bitsForTID0.is_CHECK4_1 = CBMU_MON_IN_CNT4;

          /* Entry 'CNT4': '<S9>:676' */
          CBMU_MON_DWork.cnt4 = 0UL;
        }
      }

      /* During 'CHECK4_2': '<S9>:678' */
      if (CBMU_MON_DWork.bitsForTID0.is_CHECK4_2 == CBMU_MON_IN_CNT5) {
        /* Inport: '<Root>/com_CTMax' */
        /* During 'CNT5': '<S9>:682' */
        if (tMax < 70) {
          /* Transition: '<S9>:681' */
          /* Exit 'CNT5': '<S9>:682' */
          CBMU_MON_DWork.cnt5 = 0U;
          CBMU_MON_DWork.bitsForTID0.is_CHECK4_2 = CBMU_MON_IN_Normal4_2;
        } else {
          qY = CBMU_MON_DWork.cnt5 + 10UL;
          if ((int32_T)qY > 65535L) {
            qY = 65535UL;
          }

          CBMU_MON_DWork.cnt5 = (uint16_T)qY;
        }
      } else {
        /* Inport: '<Root>/com_CTMax' */
        /* During 'Normal4_2': '<S9>:683' */
        if (tMax >= 70) {
          /* Transition: '<S9>:680' */
          CBMU_MON_DWork.bitsForTID0.is_CHECK4_2 = CBMU_MON_IN_CNT5;

          /* Entry 'CNT5': '<S9>:682' */
          CBMU_MON_DWork.cnt5 = 0U;
        }
      }

      /* During 'CHECK4_3': '<S9>:684' */
      if ((CBMU_MON_DWork.bitsForTID0.is_CHECK4_3 != CBMU_MON_IN_ERR4) &&
          ((CBMU_MON_DWork.cnt4 >= 900000UL) || (CBMU_MON_DWork.cnt5 >= 10000U) ||
           (CBMU_MON_DWork.cnt >= 7200000UL))) {
        /* During 'Normal4': '<S9>:688' */
        /* Transition: '<S9>:686' */
        CBMU_MON_DWork.bitsForTID0.is_CHECK4_3 = CBMU_MON_IN_ERR4;

        /* Entry 'ERR4': '<S9>:687' */
        CBMU_MON_B.PTCerr4 = 1U;

        /* PTC���ȹ��� */
      } else {
        /* During 'ERR4': '<S9>:687' */
      }
    }
    break;

   default:
    /* During 'PTCRelayCheck': '<S9>:645' */
    if (CBMU_MON_B.PTCStickyErr == 1) {
      /* Transition: '<S9>:730' */
      /* Exit Internal 'PTCRelayCheck': '<S9>:645' */
      if (CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck == CBMU_MON_IN_Count) {
        /* Exit 'Count': '<S9>:725' */
        CBMU_MON_DWork.cnt1_l = 0U;
        CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck =
          CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      } else {
        CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck =
          CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      }

      /* Exit 'PTCRelayCheck': '<S9>:645' */
      CBMU_MON_DWork.ONcnt = 0U;
      CBMU_MON_DWork.cnt1_l = 0U;
      CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_END;

      /* Entry 'END': '<S9>:644' */
      ioa_PTCRelayCtrl = (RELAY_OFF != 0);
    } else if ((CBMU_MON_DWork.ONcnt >= 2000U) && (CBMU_MON_B.PTCStickyErr == 0))
    {
      /* Inport: '<Root>/com_CTMin' */
      /* Transition: '<S9>:641' */
      if (tMin > 40) {
        /* Transition: '<S9>:638' */
        /* Exit Internal 'PTCRelayCheck': '<S9>:645' */
        if (CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck == CBMU_MON_IN_Count) {
          /* Exit 'Count': '<S9>:725' */
          CBMU_MON_DWork.cnt1_l = 0U;
          CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
        } else {
          CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
        }

        /* Exit 'PTCRelayCheck': '<S9>:645' */
        CBMU_MON_DWork.ONcnt = 0U;
        CBMU_MON_DWork.cnt1_l = 0U;
        CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_END;

        /* Entry 'END': '<S9>:644' */
        ioa_PTCRelayCtrl = (RELAY_OFF != 0);
      } else {
        /* Transition: '<S9>:734' */
        /* Exit Internal 'PTCRelayCheck': '<S9>:645' */
        if (CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck == CBMU_MON_IN_Count) {
          /* Exit 'Count': '<S9>:725' */
          CBMU_MON_DWork.cnt1_l = 0U;
          CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
        } else {
          CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
        }

        /* Exit 'PTCRelayCheck': '<S9>:645' */
        CBMU_MON_DWork.ONcnt = 0U;
        CBMU_MON_DWork.cnt1_l = 0U;
        CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_PTCHeating;

        /* Entry 'PTCHeating': '<S9>:646' */
        CBMU_MON_DWork.cnt = 0UL;
        HeatingSt = 2U;
        ioa_PTCRelayCtrl = (RELAY_ON != 0);

        /* Entry Internal 'PTCHeating': '<S9>:646' */
        CBMU_MON_DWork.bitsForTID0.is_active_CHECK1 = 1U;

        /* Entry Internal 'CHECK1': '<S9>:647' */
        /* Transition: '<S9>:648' */
        CBMU_MON_DWork.bitsForTID0.is_CHECK1 = CBMU_MON_IN_Normal1;

        /* Entry 'Normal1': '<S9>:654' */
        CBMU_MON_B.PTCerr1 = 0U;
        CBMU_MON_DWork.bitsForTID0.is_active_CHECK2 = 1U;

        /* Entry Internal 'CHECK2': '<S9>:655' */
        /* Transition: '<S9>:656' */
        CBMU_MON_DWork.bitsForTID0.is_CHECK2 = CBMU_MON_IN_Normal2;

        /* Entry 'Normal2': '<S9>:662' */
        CBMU_MON_B.PTCerr2 = 0U;
        CBMU_MON_DWork.bitsForTID0.is_active_CHECK3 = 1U;

        /* Entry Internal 'CHECK3': '<S9>:705' */
        /* Transition: '<S9>:712' */
        CBMU_MON_DWork.bitsForTID0.is_CHECK3 = CBMU_MON_IN_Normal3;

        /* Entry 'Normal3': '<S9>:706' */
        CBMU_MON_B.PTCerr3 = 0U;
        CBMU_MON_DWork.bitsForTID0.is_active_CHECK4 = 1U;

        /* Entry Internal 'CHECK4': '<S9>:671' */
        CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_1 = 1U;

        /* Entry Internal 'CHECK4_1': '<S9>:672' */
        /* Transition: '<S9>:673' */
        CBMU_MON_DWork.bitsForTID0.is_CHECK4_1 = CBMU_MON_IN_Normal4_1;

        /* Entry 'Normal4_1': '<S9>:677' */
        CBMU_MON_DWork.tminback = tMin;
        CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_2 = 1U;

        /* Entry Internal 'CHECK4_2': '<S9>:678' */
        /* Transition: '<S9>:679' */
        CBMU_MON_DWork.bitsForTID0.is_CHECK4_2 = CBMU_MON_IN_Normal4_2;
        CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_3 = 1U;

        /* Entry Internal 'CHECK4_3': '<S9>:684' */
        /* Transition: '<S9>:685' */
        CBMU_MON_DWork.bitsForTID0.is_CHECK4_3 = CBMU_MON_IN_Normal4;

        /* Entry 'Normal4': '<S9>:688' */
        CBMU_MON_B.PTCerr4 = 0U;
      }
    } else {
      qY = CBMU_MON_DWork.ONcnt + 10UL;
      if ((int32_T)qY > 65535L) {
        qY = 65535UL;
      }

      CBMU_MON_DWork.ONcnt = (uint16_T)qY;
      HeatingSt = 2U;
      switch (CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck) {
       case CBMU_MON_IN_Check:
        /* During 'Check': '<S9>:723' */
        if (CBMU_MON_B.DataStoreRead5 < 32512U) {
          /* Transition: '<S9>:726' */
          /* ���ڷŵ���� */
          CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck = CBMU_MON_IN_Count;

          /* Entry 'Count': '<S9>:725' */
          CBMU_MON_DWork.cnt1_l = 0U;
        }
        break;

       case CBMU_MON_IN_Count:
        /* During 'Count': '<S9>:725' */
        if (CBMU_MON_B.DataStoreRead5 >= 32512U) {
          /* Transition: '<S9>:727' */
          /* Exit 'Count': '<S9>:725' */
          CBMU_MON_DWork.cnt1_l = 0U;
          CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck = CBMU_MON_IN_Check;

          /* Entry 'Check': '<S9>:723' */
          CBMU_MON_B.PTCStickyErr = 0U;
        } else if (CBMU_MON_DWork.cnt1_l >= 500U) {
          /* Transition: '<S9>:729' */
          /* Exit 'Count': '<S9>:725' */
          CBMU_MON_DWork.cnt1_l = 0U;
          CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck = CBMU_MON_IN_Err;

          /* Entry 'Err': '<S9>:728' */
          CBMU_MON_B.PTCStickyErr = 1U;
        } else {
          qY = CBMU_MON_DWork.cnt1_l + 10UL;
          if ((int32_T)qY > 65535L) {
            qY = 65535UL;
          }

          CBMU_MON_DWork.cnt1_l = (uint16_T)qY;
        }
        break;

       default:
        /* During 'Err': '<S9>:728' */
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S8>/Chart' */
static void C_exit_internal_FC_Charging_Mon(void)
{
  /* Exit Internal 'FC_Charging_Mon': '<S9>:457' */
  /* Exit Internal 'CCS_Mon': '<S9>:474' */
  if (CBMU_MON_DWork.bitsForTID0.is_CCS_Mon == CBMU_MON_IN_CCS_Timeout) {
    /* Exit 'CCS_Timeout': '<S9>:451' */
    CBMU_MON_DWork.fc_ct = 0U;
    CBMU_MON_DWork.bitsForTID0.is_CCS_Mon = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  } else {
    CBMU_MON_DWork.bitsForTID0.is_CCS_Mon = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  }

  CBMU_MON_DWork.bitsForTID0.is_active_CCS_Mon = 0U;

  /* Exit Internal 'FC_Charging': '<S9>:448' */
  if (CBMU_MON_DWork.bitsForTID0.is_FC_Charging == CBMU_MON_IN_step10) {
    /* Exit Internal 'step10': '<S9>:453' */
    /* Exit Internal 'Heating': '<S9>:632' */
    switch (CBMU_MON_DWork.bitsForTID0.is_Heating) {
     case CBMU_MON_IN_PTCHeating:
      CBMU_M_exit_internal_PTCHeating();

      /* Exit 'PTCHeating': '<S9>:646' */
      /* ioa_PTCRelayCtl = RELAY_ON; */
      CBMU_MON_DWork.cnt = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;

     case CBMU_MON_IN_PTCRelayCheck:
      /* Exit Internal 'PTCRelayCheck': '<S9>:645' */
      if (CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck == CBMU_MON_IN_Count) {
        /* Exit 'Count': '<S9>:725' */
        CBMU_MON_DWork.cnt1_l = 0U;
        CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck =
          CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      } else {
        CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck =
          CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      }

      /* Exit 'PTCRelayCheck': '<S9>:645' */
      CBMU_MON_DWork.ONcnt = 0U;
      CBMU_MON_DWork.cnt1_l = 0U;
      CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;

     default:
      CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;
    }

    /* Exit 'Heating': '<S9>:632' */
    ioa_PTCRelayCtrl = (RELAY_OFF != 0);
    CBMU_MON_DWork.bitsForTID0.is_step10 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
    CBMU_MON_DWork.bitsForTID0.is_FC_Charging = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  } else {
    CBMU_MON_DWork.bitsForTID0.is_FC_Charging = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  }

  CBMU_MON_DWork.bitsForTID0.is_active_FC_Charging = 0U;
}

/* Function for Chart: '<S8>/Chart' */
static void CBMU_MON_FC_Charging_Mon(void)
{
  uint32_T tmp;
  int16_T tmp_0;
  uint16_T q0;
  int32_T tmp_1;
  int32_T tmp_2;
  int32_T tmp_3;
  uint16_T qY;
  int32_T tmp_4;

  /* Inport: '<Root>/BMS_FM2St' */
  /* During 'FC_Charging_Mon': '<S9>:457' */
  if ((CBMU_MON_B.DataStoreRead7 != SRC_NON_DEF) || (CBMU_MON_B.DataStoreRead3 ==
       SRC_TOO_HIGH_DEF) || (!O_S_FCCC) || CBMU_FM2St) {
    /* Transition: '<S9>:492' */
    C_exit_internal_FC_Charging_Mon();
    CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON = CBMU_MON_IN_ChargingStop;
    CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_step12;
    CBMU_MON_enter_atomic_step12();
  } else {
    /* During 'FC_Charging': '<S9>:448' */
    switch (CBMU_MON_DWork.bitsForTID0.is_FC_Charging) {
     case CBMU_MON_IN_step09:
      /* During 'step09': '<S9>:458' */
      FC_MON_test = 9U;
      com_BCL_ReqVolt = 4752U;

      /* f=0.1 VԤ���ѹ */
      com_BCL_ReqCurrent = 3800U;

      /* f=0.1 -400 AԤ����� */
      com_BCL_ChgMode = 2U;

      /*  ���ģʽ  2�������� */
      com_BCLTxEna = true;

      /* BCL���ķ���
         PackVolt 1/32V 0.1V */
      tmp_4 = CBMU_MON_B.DataStoreRead6 * 10L;
      if (tmp_4 > 65535L) {
        tmp_4 = 65535L;
      }

      com_BCS_MeasuredChgVolt = (uint16_T)tmp_4 >> 5;

      /* �����ĵ�ذ���ѹ
         PackCur 1/32 -1016 0.1 -400A */
      qY = 1016U - (CBMU_MON_B.DataStoreRead5 >> 5);
      if (qY > 1016U) {
        qY = 0U;
      }

      com_BCS_MeasuredChgCurrent = (qY + 400U) * 10U;

      /* Inport: '<Root>/com_CVMax' */
      /* �����ĳ�����
         SOC 0.4% 1%
         com_BCS_CurSOC = com_SOC;//��ǰ��SOC  ģ���������Ѿ�ת��
         0.305176  0.01V  ��ô������Ϊ�˷�ֹ������ʧ    */
      tmp_4 = uMax * 3L;
      if (tmp_4 > 65535L) {
        tmp_4 = 65535L;
      }

      /* Inport: '<Root>/com_CVMax' */
      tmp_1 = uMax * 5L;
      if (tmp_1 > 65535L) {
        tmp_1 = 65535L;
      }

      /* Inport: '<Root>/com_CVMax' */
      tmp_2 = uMax * 7L;
      if (tmp_2 > 65535L) {
        tmp_2 = 65535L;
      }

      /* Inport: '<Root>/com_CVMax' */
      tmp_3 = uMax * 6L;
      if (tmp_3 > 65535L) {
        tmp_3 = 65535L;
      }

      /* Inport: '<Root>/com_CVMax' */
      com_BCS_MaxCellVolt = (uint16_T)((((int16_T)(div_uus16_sat((uint16_T)tmp_4,
        100) + div_uus16_sat((uint16_T)tmp_1, 10000)) + (int16_T)div_s32(uMax,
        100000L)) + (int16_T)div_s32(tmp_2, 1000000L)) + (int16_T)div_s32(tmp_3,
        10000000L));

      /* com_BCS_MaxCellVolt = com_CVMax*305176/10000/1000; */
      com_BCS_MaxCVGroupNum = CBMU_MON_B.Divide;

      /* Inport: '<Root>/com_SOC' */
      /* ���о��ѹģ���Module Num */
      tmp_4 = (int32_T)(400 - (int16_T)(com_SOC * 205U >> 7)) * BMSCapacity;
      if (tmp_4 > 32767L) {
        tmp_4 = 32767L;
      }

      tmp_4 = div_s16_sat((int16_T)tmp_4, 100) * 60L;
      if (tmp_4 > 32767L) {
        tmp_4 = 32767L;
      } else {
        if (tmp_4 < -32768L) {
          tmp_4 = -32768L;
        }
      }

      tmp_0 = div_s16_sat((int16_T)tmp_4, 10) >> 2;
      if (tmp_0 < 0) {
        tmp_0 = 0;
      }

      com_BCS_ChgTimeRemain = (uint16_T)tmp_0;

      /*  Ԥ����ʣ��ʱ�䳬��600��600<= 600 min */
      com_BCSTxEna = true;

      /* Inport: '<Root>/com_CVMaxNum' */
      /* ����BCS */
      com_BSM_MaxCVCellNum = uMaxNum;

      /* Inport: '<Root>/com_CTMax' */
      /* ���о��ѹ��о�� */
      tmp_0 = tMax + 10;
      if (tmp_0 > 255) {
        tmp_0 = 255;
      }

      com_BSM_MaxCellTemp = (uint8_T)tmp_0;

      /* Inport: '<Root>/com_CTMaxNum' */
      /* -40 -50 deg//����¶� */
      com_BSM_MaxCTCellNum = tMaxNum;

      /* Inport: '<Root>/com_CTMin' */
      /* ����¶ȵ�о�� */
      tmp_0 = tMin + 10;
      if (tmp_0 > 255) {
        tmp_0 = 255;
      }

      com_BSM_MinCellTemp = (uint8_T)tmp_0;

      /* Inport: '<Root>/com_CTMinNum' */
      /* ��С��о�¶�-40 -50 deg */
      com_BSM_MinCTCellNum = tMinNum;

      /* ��С��о�¶ȵ�о�� */
      com_BSM_ChgTempSt = CBMU_MON_B.DataStoreRead3;

      /* ����¶�״̬0-normal  1-high 2-na */
      com_BSM_ChgCurrentSt = CBMU_MON_B.DataStoreRead2;

      /* ������״̬0-normal 1- high 2-na */
      com_BSM_ChgSOCSt = CBMU_MON_B.DataStoreRead4;

      /* SOC״̬0-normal 1-high 2-low */
      com_BSM_ChgCVSt = CBMU_MON_B.DataStoreRead1;

      /* ��о��ѹ״̬0-normal 1-high 2-low */
      com_BSM_ChgAllowed = 1U;

      /* �������enable   0-disable */
      com_BSM_ConnecterSt = 0U;

      /* ���������״̬connect   FCCC   0-normal 1-abnormal 2-na */
      com_BSM_ISOSt = 0U;

      /* ��Ե����״̬0-normal 1-abnormal 2-na */
      com_BSMTxEna = true;

      /* ����BSM����  */
      break;

     case CBMU_MON_IN_step10:
      /* During 'step10': '<S9>:453' */
      if (com_BCS_CurSOC >= 100) {
        /* Transition: '<S9>:494' */
        C_exit_internal_FC_Charging_Mon();
        CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON = CBMU_MON_IN_Data_SOCFull;

        /* Entry 'Data_SOCFull': '<S9>:393' */
        CBMU_MON_DWork.fc_ct = 0U;
      } else {
        FC_MON_test = 10U;

        /* com_BCL_ReqVolt = 38*12*11;/$f=0.1 VԤ���ѹ$/
           com_BCL_ReqCurrent = 3000;//f=0.1 -400 A remove 20151021 */
        com_BCL_ChgMode = 2U;

        /*      */
        com_BCLTxEna = true;

        /* PackVolt 1/32V 0.1V
           com_BCS_MeasuredChgVolt = com_PackVolt*10/32;
           PackCur 1/32 -1016 0.1 -400A
           com_BCS_MeasuredChgCurrent = ((1016-com_PackCur/32)+400)*10;
           SOC 0.4% 1%
           com_BCS_CurSOC = com_SOC;
           0.305176  0.01V
           com_BCS_MaxCellVolt = com_CVMax*3/100+com_CVMax*5/10000+com_CVMax*1/100000+com_CVMax*7/1000000+com_CVMax*6/10000000;//com_BCS_MaxCellVolt = com_CVMax*305176/10000/1000;
           com_BCS_MaxCVGroupNum = com_CVMaxGroupNum;//Module Num
           com_BCS_ChgTimeRemain =com_BRM_RatedCap*6/com_BCS_MeasuredChgCurrent*(100-com_BCS_CurSOC)/10;// 1440AH*(SOC/100)*60/(x*10A)    <= 600 min */
        com_BCSTxEna = true;

        /* com_BSM_MaxCVCellNum = com_CVMaxNum;
           com_BSM_MaxCellTemp = com_CTMax+10;//-40 -50 deg
           com_BSM_MaxCTCellNum = com_CTMaxNum;
           com_BSM_MinCellTemp = com_CTMin+10;//-40 -50 deg
           com_BSM_MinCTCellNum = com_CTMinNum; */
        com_BSM_ChgTempSt = CBMU_MON_B.DataStoreRead3;

        /* 0-normal  1-high 2-na */
        com_BSM_ChgCurrentSt = CBMU_MON_B.DataStoreRead2;

        /* 0-normal 1- high 2-na */
        com_BSM_ChgSOCSt = CBMU_MON_B.DataStoreRead4;

        /* 0-normal 1-high 2-low */
        com_BSM_ChgCVSt = CBMU_MON_B.DataStoreRead1;

        /* 0-normal 1-high 2-low */
        com_BSM_ChgAllowed = 1U;

        /* enable   0-disable */
        com_BSM_ConnecterSt = 0U;

        /* connect   FCCC   0-normal 1-abnormal 2-na */
        com_BSM_ISOSt = 0U;

        /* 0-normal 1-abnormal 2-na */
        com_BSMTxEna = true;
        CBMU_MON_Heating();
      }
      break;

     default:
      /* During 'step11': '<S9>:472' */
      FC_MON_test = 11U;
      com_BCL_ReqVolt = 5016U;

      /* f=0.1 VԤ���ѹ */
      com_BCL_ReqCurrent = 3940U;

      /* f=0.1 -400 A */
      com_BCL_ChgMode = 1U;
      com_BCLTxEna = true;

      /* PackVolt 1/32V 0.1V */
      tmp_4 = CBMU_MON_B.DataStoreRead6 * 10L;
      if (tmp_4 > 65535L) {
        tmp_4 = 65535L;
      }

      com_BCS_MeasuredChgVolt = (uint16_T)tmp_4 >> 5;

      /* PackCur 1/32 -1016 0.1 -400A */
      qY = 1016U - (CBMU_MON_B.DataStoreRead5 >> 5);
      if (qY > 1016U) {
        qY = 0U;
      }

      com_BCS_MeasuredChgCurrent = (qY + 400U) * 10U;

      /* Inport: '<Root>/com_CVMax' */
      /* SOC 0.4% 1%
         com_BCS_CurSOC = com_SOC;
         0.305176mV  0.01V */
      tmp_4 = uMax * 3L;
      if (tmp_4 > 65535L) {
        tmp_4 = 65535L;
      }

      /* Inport: '<Root>/com_CVMax' */
      tmp_1 = uMax * 5L;
      if (tmp_1 > 65535L) {
        tmp_1 = 65535L;
      }

      /* Inport: '<Root>/com_CVMax' */
      tmp_2 = uMax * 7L;
      if (tmp_2 > 65535L) {
        tmp_2 = 65535L;
      }

      /* Inport: '<Root>/com_CVMax' */
      tmp_3 = uMax * 6L;
      if (tmp_3 > 65535L) {
        tmp_3 = 65535L;
      }

      /* Inport: '<Root>/com_CVMax' */
      com_BCS_MaxCellVolt = (uint16_T)((((int16_T)(div_uus16_sat((uint16_T)tmp_4,
        100) + div_uus16_sat((uint16_T)tmp_1, 10000)) + (int16_T)div_s32(uMax,
        100000L)) + (int16_T)div_s32(tmp_2, 1000000L)) + (int16_T)div_s32(tmp_3,
        10000000L));

      /* com_BCS_M axCellVolt = com_CVMax*305176/10000/1000; */
      com_BCS_MaxCVGroupNum = CBMU_MON_B.Divide;

      /* Inport: '<Root>/com_SOC' */
      /* Module Num */
      tmp_4 = (int32_T)(400 - (int16_T)(com_SOC * 205U >> 7)) * BMSCapacity;
      if (tmp_4 > 32767L) {
        tmp_4 = 32767L;
      }

      tmp_4 = div_s16_sat((int16_T)tmp_4, 100) * 60L;
      if (tmp_4 > 32767L) {
        tmp_4 = 32767L;
      } else {
        if (tmp_4 < -32768L) {
          tmp_4 = -32768L;
        }
      }

      q0 = CBMU_MON_B.DataStoreRead5 >> 5;
      qY = q0 - 1016U;
      if (qY > q0) {
        qY = 0U;
      }

      com_BCS_ChgTimeRemain = div_usu16_sat((int16_T)tmp_4, qY) >> 2;

      /*  <= 600 min */
      com_BCSTxEna = true;

      /* Inport: '<Root>/com_CVMaxNum' */
      com_BSM_MaxCVCellNum = uMaxNum;

      /* Inport: '<Root>/com_CTMax' */
      tmp_0 = tMax + 10;
      if (tmp_0 > 255) {
        tmp_0 = 255;
      }

      com_BSM_MaxCellTemp = (uint8_T)tmp_0;

      /* Inport: '<Root>/com_CTMaxNum' */
      /* -40 -50 deg */
      com_BSM_MaxCTCellNum = tMaxNum;

      /* Inport: '<Root>/com_CTMin' */
      tmp_0 = tMin + 10;
      if (tmp_0 > 255) {
        tmp_0 = 255;
      }

      com_BSM_MinCellTemp = (uint8_T)tmp_0;

      /* Inport: '<Root>/com_CTMinNum' */
      /* -40 -50 deg */
      com_BSM_MinCTCellNum = tMinNum;
      com_BSM_ChgTempSt = CBMU_MON_B.DataStoreRead3;

      /* 0-normal  1-high 2-na */
      com_BSM_ChgCurrentSt = CBMU_MON_B.DataStoreRead2;

      /* 0-normal 1- high 2-na */
      com_BSM_ChgSOCSt = CBMU_MON_B.DataStoreRead4;

      /* 0-normal 1-high 2-low */
      com_BSM_ChgCVSt = CBMU_MON_B.DataStoreRead1;

      /* 0-normal 1-high 2-low */
      com_BSM_ChgAllowed = 1U;

      /* enable   0-disable */
      com_BSM_ConnecterSt = 0U;

      /* connect   FCCC   0-normal 1-abnormal 2-na */
      com_BSM_ISOSt = 0U;

      /* 0-normal 1-abnormal 2-na */
      com_BSMTxEna = true;
      break;
    }

    if (CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON == CBMU_MON_IN_FC_Charging_Mon)
    {
      /* During 'CCS_Mon': '<S9>:474' */
      if (CBMU_MON_DWork.bitsForTID0.is_CCS_Mon == CBMU_MON_IN_CCS_Normal) {
        /* During 'CCS_Normal': '<S9>:483' */
        if (CBMU_MON_B.bitsForTID0.DataStoreRead) {
          /* Transition: '<S9>:461' */
          CBMU_MON_DWork.bitsForTID0.is_CCS_Mon = CBMU_MON_IN_CCS_Timeout;

          /* Entry 'CCS_Timeout': '<S9>:451' */
          CBMU_MON_DWork.fc_ct = 0U;
        }
      } else {
        /* During 'CCS_Timeout': '<S9>:451' */
        if (CBMU_MON_DWork.fc_ct > 15000U) {
          /* Transition: '<S9>:485' */
          if (CBMU_MON_B.DataStoreRead5 > 32544U) {
            /* Transition: '<S9>:721' */
            /* ����1A */
            CBMU_MON_B.TimeOutErr = 1U;
            C_exit_internal_FC_Charging_Mon();
            CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON = CBMU_MON_IN_ChargingStop;
            CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_step13;

            /* Entry 'step13': '<S9>:398' */
            com_BEM_RcvChgerStateMsg = 1U;

            /* ��ʱ��һֱ���ñ��� */
            com_BEMTxEna = true;

            /* BEM���� */
            FC_MON_test = 13U;
            CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_m = (RELAY_OFF != 0);

            /* add 20150826  ��ü�һ����ʱ �˴��ĸ���Ϊ���̵��� ����Ҫ��	 */
            com_BPSHighVoltSts = 0U;
            ioa_PTCRelayCtrl = (RELAY_OFF != 0);
          } else {
            /* Transition: '<S9>:722' */
            C_exit_internal_FC_Charging_Mon();
            CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON = CBMU_MON_IN_ChargingStop;
            CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_step13;

            /* Entry 'step13': '<S9>:398' */
            com_BEM_RcvChgerStateMsg = 1U;

            /* ��ʱ��һֱ���ñ��� */
            com_BEMTxEna = true;

            /* BEM���� */
            FC_MON_test = 13U;
            CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_m = (RELAY_OFF != 0);

            /* add 20150826  ��ü�һ����ʱ �˴��ĸ���Ϊ���̵��� ����Ҫ��	 */
            com_BPSHighVoltSts = 0U;
            ioa_PTCRelayCtrl = (RELAY_OFF != 0);
          }
        } else if (!CBMU_MON_B.bitsForTID0.DataStoreRead) {
          /* Transition: '<S9>:396' */
          /* Exit 'CCS_Timeout': '<S9>:451' */
          CBMU_MON_DWork.fc_ct = 0U;
          CBMU_MON_DWork.bitsForTID0.is_CCS_Mon = CBMU_MON_IN_CCS_Normal;
        } else {
          tmp = CBMU_MON_DWork.fc_ct + 10UL;
          if ((int32_T)tmp > 65535L) {
            tmp = 65535UL;
          }

          CBMU_MON_DWork.fc_ct = (uint16_T)tmp;
        }
      }
    }
  }

  /* End of Inport: '<Root>/BMS_FM2St' */
}

/* Start for atomic system: '<S1>/FC_Mon' */
void CBMU_MON_FC_Mon_Start(void)
{
  /* Start for Enabled SubSystem: '<S3>/FcMon' */
  /* Start for SwitchCase: '<S10>/Switch Case' */
  CBMU_MON_DWork.SwitchCase_ActiveSubsystem = -1;

  /* Start for IfAction SubSystem: '<S10>/Switch Case Action Subsystem' */
  /* Start for SwitchCase: '<S12>/Switch Case' */
  CBMU_MON_DWork.SwitchCase_ActiveSubsystem_b = -1;

  /* InitializeConditions for IfAction SubSystem: '<S12>/Switch Case Action Subsystem2' */
  /* InitializeConditions for Memory: '<S15>/Memory' */
  CBMU_MON_DWork.Memory_PreviousInput_f = 5U;

  /* InitializeConditions for Chart: '<S15>/Chgcurrentcalc' */
  CBMU_MON_DWork.cnt1_f = 0U;
  CBMU_MON_DWork.cnt2_l = 0U;
  CBMU_MON_B.ChgCur = 0U;

  /* End of InitializeConditions for SubSystem: '<S12>/Switch Case Action Subsystem2' */
  /* End of Start for SubSystem: '<S10>/Switch Case Action Subsystem' */

  /* InitializeConditions for IfAction SubSystem: '<S10>/Switch Case Action Subsystem' */
  /* InitializeConditions for Chart: '<S12>/current' */
  CBMU_MON_DWork.bitsForTID0.is_active_c1_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c1_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.cnt_g = 0U;
  CBMU_MON_B.CalcStart = 0U;

  /* End of InitializeConditions for SubSystem: '<S10>/Switch Case Action Subsystem' */

  /* InitializeConditions for IfAction SubSystem: '<S10>/Switch Case Action Subsystem1' */
  /* InitializeConditions for Chart: '<S13>/current' */
  CBMU_MON_DWork.bitsForTID0.is_active_c24_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c24_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.cnt_lp = 0U;
  ChargeCUR = 0U;

  /* End of InitializeConditions for SubSystem: '<S10>/Switch Case Action Subsystem1' */
  /* End of Start for SubSystem: '<S3>/FcMon' */

  /* InitializeConditions for Enabled SubSystem: '<S3>/FcMon' */
  /* InitializeConditions for Chart: '<S8>/Chart' */
  CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_CCS_Mon = 0U;
  CBMU_MON_DWork.bitsForTID0.is_CCS_Mon = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_FC_Charging = 0U;
  CBMU_MON_DWork.bitsForTID0.is_FC_Charging = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_step10 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK1 = 0U;
  CBMU_MON_DWork.bitsForTID0.is_CHECK1 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK2 = 0U;
  CBMU_MON_DWork.bitsForTID0.is_CHECK2 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK3 = 0U;
  CBMU_MON_DWork.bitsForTID0.is_CHECK3 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK4 = 0U;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_1 = 0U;
  CBMU_MON_DWork.bitsForTID0.is_CHECK4_1 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_2 = 0U;
  CBMU_MON_DWork.bitsForTID0.is_CHECK4_2 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_CHECK4_3 = 0U;
  CBMU_MON_DWork.bitsForTID0.is_CHECK4_3 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_FC_Handing = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_ParamSetting = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_c9_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.fc_ct = 0U;
  CBMU_MON_DWork.cnt = 0UL;
  CBMU_MON_DWork.cnt1_l = 0U;
  CBMU_MON_DWork.cnt2_p5 = 0U;
  CBMU_MON_DWork.cnt3 = 0U;
  CBMU_MON_DWork.cnt4 = 0UL;
  CBMU_MON_DWork.tminback = 0U;
  CBMU_MON_DWork.ONcnt = 0U;
  CBMU_MON_DWork.cnt5 = 0U;
  com_BCL_ChgMode = 0U;
  com_BCL_ReqCurrent = 0U;
  com_BCL_ReqVolt = 0U;
  com_BCPTxEna = false;
  com_BCP_MaxAllowedTemp = 0U;
  com_BCP_MaxCellChgVolt = 0U;
  com_BCP_MaxChgCurrent = 0U;
  com_BCP_MaxPackChgVolt = 0U;
  com_BCP_NominalEnergy = 0U;
  com_BCS_ChgTimeRemain = 0U;
  com_BCS_CurSOC = 0U;
  com_BCS_MaxCVGroupNum = 0U;
  com_BCS_MaxCellVolt = 0U;
  com_BCS_MeasuredChgCurrent = 0U;
  com_BCS_MeasuredChgVolt = 0U;
  com_BEMTxEna = false;
  com_BEM_RcvChgerCMLMsg = 0U;
  com_BEM_RcvChgerReadyMsg = 0U;
  com_BEM_RcvChgerRecMsg_AA = 0U;
  com_BEM_RcvChgerStateMsg = 0U;
  com_BEM_RcvChgerStopMsg = 0U;
  com_BEM_RcvChgerTotalMsg = 0U;
  com_BRMTxEna = false;
  com_BRM_BatType = 0U;
  com_BRM_ProVersion = 0U;
  com_BRM_RatedCap = 0U;
  com_BRM_RatedVolt = 0U;
  com_BRM_SubProVersion = 0U;
  com_BROTxEna = false;
  com_BRO_BMSReady = 0U;
  com_BSDTxEna = false;
  com_BSD_EndSOC = 0U;
  com_BSD_MaxCellTemp = 0U;
  com_BSD_MaxCellVolt = 0U;
  com_BSD_MinCellTemp = 0U;
  com_BSD_MinCellVolt = 0U;
  com_BSM_ChgAllowed = 0U;
  com_BSM_ChgCVSt = 0U;
  com_BSM_ChgCurrentSt = 0U;
  com_BSM_ChgSOCSt = 0U;
  com_BSM_ChgTempSt = 0U;
  com_BSM_ConnecterSt = 0U;
  com_BSM_ISOSt = 0U;
  com_BSM_MaxCTCellNum = 0U;
  com_BSM_MaxCVCellNum = 0U;
  com_BSM_MaxCellTemp = 0U;
  com_BSM_MinCTCellNum = 0U;
  com_BSM_MinCellTemp = 0U;
  com_BSTTxEna = false;
  com_BST_BatOverTempFault = 0U;
  com_BST_CompOverTempFault = 0U;
  com_BST_ConnOverTempFault = 0U;
  com_BST_ConnecterFault = 0U;
  com_BST_CurrentError = 0U;
  com_BST_ISOFault = 0U;
  com_BST_OtherFault = 0U;
  com_BST_SetCVReach = 0U;
  com_BST_SetPVReach = 0U;
  com_BST_SetSOCReach = 0U;
  com_BST_VoltError = 0U;
  com_BCLTxEna = false;
  com_BCSTxEna = false;
  com_BSMTxEna = false;
  com_BPSHighVoltSts = 0U;
  CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_m = false;
  HeatingSt = 0U;
  ioa_PTCRelayCtrl = false;
  CBMU_MON_B.PTCerr1 = 0U;
  CBMU_MON_B.PTCerr2 = 0U;
  CBMU_MON_B.PTCerr3 = 0U;
  CBMU_MON_B.PTCerr4 = 0U;
  CBMU_MON_B.TimeOutErr = 0U;
  CBMU_MON_B.PTCStickyErr = 0U;

  /* End of InitializeConditions for SubSystem: '<S3>/FcMon' */
}

/* Output and update for atomic system: '<S1>/FC_Mon' */
void CBMU_MON_FC_Mon(void)
{
  uint16_T curvalue;
  boolean_T guard1 = false;
  int8_T rtPrevAction;
  int8_T rtAction;
  uint32_T tmp;
  int16_T tmp_0;
  int32_T tmp_1;
  int32_T tmp_2;
  int32_T tmp_3;
  int32_T tmp_4;

  /* Outputs for Enabled SubSystem: '<S3>/FcMon' incorporates:
   *  EnablePort: '<S8>/Enable'
   */
  /* RelationalOperator: '<S3>/Relational Operator2' incorporates:
   *  Constant: '<S3>/Constant2'
   */
  if (PwrMode == PWR_FC) {
    if (!CBMU_MON_DWork.bitsForTID0.FcMon_MODE) {
      CBMU_MON_DWork.bitsForTID0.FcMon_MODE = true;
    }

    /* Chart: '<S8>/Chart' incorporates:
     *  Inport: '<Root>/HeatingEnable'
     *  Inport: '<Root>/com_CML_MaxOutVolt'
     *  Inport: '<Root>/com_CRM_RecResult'
     *  Inport: '<Root>/com_CRO_ChgerReady'
     *  Inport: '<Root>/com_CTMax'
     *  Inport: '<Root>/com_CTMin'
     *  Inport: '<Root>/com_CVMax'
     *  Inport: '<Root>/com_CVMin'
     *  Inport: '<Root>/com_SOC'
     */
    /* Gateway: Task_10ms/FC_Mon/FcMon/Chart */
    /* During: Task_10ms/FC_Mon/FcMon/Chart */
    if (CBMU_MON_DWork.bitsForTID0.is_active_c9_CBMU_MON == 0U) {
      /* Entry: Task_10ms/FC_Mon/FcMon/Chart */
      CBMU_MON_DWork.bitsForTID0.is_active_c9_CBMU_MON = 1U;

      /* Entry Internal: Task_10ms/FC_Mon/FcMon/Chart */
      if (com_BCS_CurSOC <= 90) {
        /* Transition: '<S9>:505' */
        CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON = CBMU_MON_IN_FC_Handing;

        /* Entry Internal 'FC_Handing': '<S9>:502' */
        /* Transition: '<S9>:491' */
        CBMU_MON_DWork.bitsForTID0.is_FC_Handing = CBMU_MON_IN_delay;

        /* Entry 'delay': '<S9>:739' */
        CBMU_MON_DWork.fc_ct = 0U;
      }
    } else {
      switch (CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON) {
       case CBMU_MON_IN_ChargingStop:
        /* During 'ChargingStop': '<S9>:622' */
        switch (CBMU_MON_DWork.bitsForTID0.is_ChargingStop) {
         case CBMU_MON_IN_step12:
          /* During 'step12': '<S9>:400' */
          if ((!CBMU_MON_B.bitsForTID0.DataStoreRead1_d) &&
              (CBMU_MON_DWork.fc_ct > 15000U)) {
            /* Transition: '<S9>:500' */
            /* ���� ֹͣ������� */
            /* Exit 'step12': '<S9>:400' */
            CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_step15;

            /* Entry 'step15': '<S9>:495' */
            CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_m = (RELAY_OFF != 0);

            /* �¼̵��� �˴��ĸ���Ϊ���̵��� ����Ҫ�� */
            com_BEM_RcvChgerStopMsg = 0U;

            /* �洢��ǰ��Ϣ  û�г�ʱ */
            com_BSD_EndSOC = (uint8_T)(com_SOC * 205U >> 9);

            /* t_Soc1  1% */
            tmp_1 = uMin * 3L;
            if (tmp_1 > 65535L) {
              tmp_1 = 65535L;
            }

            tmp_2 = uMin * 5L;
            if (tmp_2 > 65535L) {
              tmp_2 = 65535L;
            }

            tmp_3 = uMin * 7L;
            if (tmp_3 > 65535L) {
              tmp_3 = 65535L;
            }

            tmp_4 = uMin * 6L;
            if (tmp_4 > 65535L) {
              tmp_4 = 65535L;
            }

            com_BSD_MinCellVolt = (uint16_T)((((int16_T)(div_uus16_sat((uint16_T)
              tmp_1, 100) + div_uus16_sat((uint16_T)tmp_2, 10000)) + (int16_T)
              div_s32(uMin, 100000L)) + (int16_T)div_s32(tmp_3, 1000000L)) +
              (int16_T)div_s32(tmp_4, 10000000L));

            /* 0.305176mV   0.01V */
            tmp_1 = uMax * 3L;
            if (tmp_1 > 65535L) {
              tmp_1 = 65535L;
            }

            tmp_2 = uMax * 5L;
            if (tmp_2 > 65535L) {
              tmp_2 = 65535L;
            }

            tmp_3 = uMax * 7L;
            if (tmp_3 > 65535L) {
              tmp_3 = 65535L;
            }

            tmp_4 = uMax * 6L;
            if (tmp_4 > 65535L) {
              tmp_4 = 65535L;
            }

            com_BSD_MaxCellVolt = (uint16_T)((((int16_T)(div_uus16_sat((uint16_T)
              tmp_1, 100) + div_uus16_sat((uint16_T)tmp_2, 10000)) + (int16_T)
              div_s32(uMax, 100000L)) + (int16_T)div_s32(tmp_3, 1000000L)) +
              (int16_T)div_s32(tmp_4, 10000000L));

            /* 0.305176mV   0.01V
               com_BSD_MinCellVolt = com_CVMin*305176/10000000;//0.305176mV   0.01V
               com_BSD_MaxCellVolt = com_CVMax*305176/10000000;//0.305176mV   0.01V */
            tmp_0 = tMin + 10;
            if (tmp_0 > 255) {
              tmp_0 = 255;
            }

            com_BSD_MinCellTemp = (uint8_T)tmp_0;

            /* -40 -50 */
            tmp_0 = tMax + 10;
            if (tmp_0 > 255) {
              tmp_0 = 255;
            }

            com_BSD_MaxCellTemp = (uint8_T)tmp_0;

            /* -40 -50 */
            com_BSDTxEna = true;

            /* BMS�Ա��γ��ͳ������ */
            CBMU_MON_DWork.fc_ct = 0U;
            FC_MON_test = 15U;
          } else if (CBMU_MON_DWork.fc_ct > 15000U) {
            /* Transition: '<S9>:496' */
            /* Exit 'step12': '<S9>:400' */
            CBMU_MON_DWork.fc_ct = 0U;
            CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_step14;

            /* Entry 'step14': '<S9>:454' */
            CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_m = (RELAY_OFF != 0);

            /* �¼̵��� �˴��ĸ���Ϊ���̵��� ����Ҫ�� */
            com_BEM_RcvChgerStopMsg = 1U;

            /* ֹͣ���Ľ��ճ�ʱ���� */
            com_BEMTxEna = true;

            /* ����BEM */
            FC_MON_test = 14U;
          } else {
            tmp = CBMU_MON_DWork.fc_ct + 10UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            CBMU_MON_DWork.fc_ct = (uint16_T)tmp;
            FC_MON_test = 12U;
            CBMU_MON_BSTCheck();
          }
          break;

         case CBMU_MON_IN_step13:
          /* During 'step13': '<S9>:398' */
          break;

         case CBMU_MON_IN_step14:
          /* During 'step14': '<S9>:454' */
          break;

         case CBMU_MON_IN_step15:
          /* During 'step15': '<S9>:495' */
          if (!CBMU_MON_B.bitsForTID0.DataStoreRead2_a) {
            /* Transition: '<S9>:499' */
            /* Exit 'step15': '<S9>:495' */
            CBMU_MON_DWork.fc_ct = 0U;
            CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_step17;

            /* Entry 'step17': '<S9>:498' */
            com_BEM_RcvChgerTotalMsg = 0U;

            /* �洢��ǰ��Ϣ  û�г�ʱ */
            FC_MON_test = 17U;
            CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_m = (RELAY_OFF != 0);

            /* �¼̵��� �˴��ĸ���Ϊ���̵��� ����Ҫ��	 */
            com_BPSHighVoltSts = 0U;
          } else if (CBMU_MON_DWork.fc_ct > 5000U) {
            /* Transition: '<S9>:490' */
            /* Exit 'step15': '<S9>:495' */
            CBMU_MON_DWork.fc_ct = 0U;
            CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_step16;

            /* Entry 'step16': '<S9>:488' */
            com_BEM_RcvChgerTotalMsg = 1U;

            /* ֹͣ���Ľ��ճ�ʱ���� */
            com_BEMTxEna = true;

            /* ����BEM */
            FC_MON_test = 16U;
          } else {
            tmp = CBMU_MON_DWork.fc_ct + 10UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            CBMU_MON_DWork.fc_ct = (uint16_T)tmp;
            FC_MON_test = 15U;
          }
          break;

         case CBMU_MON_IN_step16:
          /* During 'step16': '<S9>:488' */
          break;

         default:
          /* During 'step17': '<S9>:498' */
          break;
        }
        break;

       case CBMU_MON_IN_Data_SOCFull:
        /* During 'Data_SOCFull': '<S9>:393' */
        if (CBMU_MON_DWork.fc_ct > 5000U) {
          /* Transition: '<S9>:501' */
          /* Exit 'Data_SOCFull': '<S9>:393' */
          CBMU_MON_DWork.fc_ct = 0U;
          CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON = CBMU_MON_IN_ChargingStop;
          CBMU_MON_DWork.bitsForTID0.is_ChargingStop = CBMU_MON_IN_step12;
          CBMU_MON_enter_atomic_step12();
        } else if (com_BCS_CurSOC < 100) {
          /* Transition: '<S9>:493' */
          /* Exit 'Data_SOCFull': '<S9>:393' */
          CBMU_MON_DWork.fc_ct = 0U;
          CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON =
            CBMU_MON_IN_FC_Charging_Mon;
          CBMU_MON_DWork.bitsForTID0.is_active_FC_Charging = 1U;
          CBMU_MON_DWork.bitsForTID0.is_FC_Charging = CBMU_MON_IN_step10;

          /* Entry 'step10': '<S9>:453' */
          /* constant current 1C charge */
          FC_MON_test = 10U;

          /* Entry Internal 'step10': '<S9>:453' */
          /* Transition: '<S9>:689' */
          CBMU_MON_DWork.bitsForTID0.is_step10 = CBMU_MON_IN_Heating;

          /* Entry Internal 'Heating': '<S9>:632' */
          /* Transition: '<S9>:635' */
          HeatingSt = 0U;
          if (HeatingEnable == 0) {
            /* Transition: '<S9>:636' */
            CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_END;

            /* Entry 'END': '<S9>:644' */
            ioa_PTCRelayCtrl = (RELAY_OFF != 0);
          } else {
            /* Transition: '<S9>:637' */
            CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_PTCRelayCheck;

            /* Entry 'PTCRelayCheck': '<S9>:645' */
            CBMU_MON_DWork.ONcnt = 0U;

            /* Entry Internal 'PTCRelayCheck': '<S9>:645' */
            /* Transition: '<S9>:724' */
            CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck = CBMU_MON_IN_Check;

            /* Entry 'Check': '<S9>:723' */
            CBMU_MON_B.PTCStickyErr = 0U;
          }

          CBMU_MON_DWork.bitsForTID0.is_active_CCS_Mon = 1U;

          /* Entry Internal 'CCS_Mon': '<S9>:474' */
          /* Transition: '<S9>:460' */
          CBMU_MON_DWork.bitsForTID0.is_CCS_Mon = CBMU_MON_IN_CCS_Normal;
        } else {
          tmp = CBMU_MON_DWork.fc_ct + 10UL;
          if ((int32_T)tmp > 65535L) {
            tmp = 65535UL;
          }

          CBMU_MON_DWork.fc_ct = (uint16_T)tmp;
        }
        break;

       case CBMU_MON_IN_FC_Charging_Mon:
        CBMU_MON_FC_Charging_Mon();
        break;

       case CBMU_MON_IN_FC_Handing:
        /* During 'FC_Handing': '<S9>:502' */
        switch (CBMU_MON_DWork.bitsForTID0.is_FC_Handing) {
         case CBMU_MON_IN_delay:
          /* During 'delay': '<S9>:739' */
          if (CBMU_MON_DWork.fc_ct >= 15000U) {
            /* Transition: '<S9>:740' */
            /* Exit 'delay': '<S9>:739' */
            CBMU_MON_DWork.fc_ct = 0U;
            CBMU_MON_DWork.bitsForTID0.is_FC_Handing = CBMU_MON_IN_step0;

            /* Entry 'step0': '<S9>:479' */
            /* com_BCS_CurSOC = com_SOC;/$�ȿ���SOCֵ$/ */
            com_BRM_SubProVersion = 0U;

            /* �Ӱ汾��,��ǰ��V1.0 */
            com_BRM_ProVersion = 1U;

            /* ĸ�汾��,V1����˼ */
            com_BRM_BatType = 3U;

            /* �������  ������
               com_BRM_RatedCap = 1440;//����� ��Ҫ�޸�  144AH
               com_BRM_RatedVolt = 32*12*11;/$�ܵ�ѹΪV$/ */
            com_BRMTxEna = true;

            /* BMS-����ʶ����
               com_BEMTxEna = false;//�ص������� */
            FC_MON_test = 0U;

            /* ���� ���� */
          } else {
            tmp = CBMU_MON_DWork.fc_ct + 10UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            CBMU_MON_DWork.fc_ct = (uint16_T)tmp;
          }
          break;

         case CBMU_MON_IN_step0:
          /* During 'step0': '<S9>:479' */
          /* Transition: '<S9>:477' */
          CBMU_MON_DWork.bitsForTID0.is_FC_Handing = CBMU_MON_IN_step01;

          /* Entry 'step01': '<S9>:481' */
          CBMU_MON_DWork.fc_ct = 0U;
          FC_MON_test = 1U;
          break;

         case CBMU_MON_IN_step01:
          /* During 'step01': '<S9>:481' */
          if (CBMU_MON_DWork.fc_ct > 65000U) {
            /* Transition: '<S9>:478' */
            /* Exit 'step01': '<S9>:481' */
            CBMU_MON_DWork.fc_ct = 0U;
            CBMU_MON_DWork.bitsForTID0.is_FC_Handing = CBMU_MON_IN_step03;

            /* Entry 'step03': '<S9>:480' */
            com_BEM_RcvChgerRecMsg_AA = 1U;

            /* �����ĵ�һ���ź���Ϊ   AA���� PGN7680 */
            com_BEMTxEna = true;

            /* ����ʹ�� �跢����1 */
            com_BRMTxEna = false;

            /* BMS-����ʶ���� */
            FC_MON_test = 3U;
          } else if (com_CRM_RecResult == 0xAA) {
            /* Transition: '<S9>:487' */
            /* Exit 'step01': '<S9>:481' */
            CBMU_MON_DWork.bitsForTID0.is_FC_Handing =
              CBMU_MON_IN_NO_ACTIVE_CHILD_d;
            CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON = CBMU_MON_IN_ParamSetting;

            /* Entry Internal 'ParamSetting': '<S9>:628' */
            /* Transition: '<S9>:629' */
            CBMU_MON_DWork.bitsForTID0.is_ParamSetting = CBMU_MON_IN_step02;

            /* Entry 'step02': '<S9>:401' */
            CBMU_MON_DWork.fc_ct = 0U;
            FC_MON_test = 2U;
            com_BEM_RcvChgerRecMsg_AA = 0U;

            /* �����ٳ�ʱ OK��״̬
               com_BCP_MaxCellChgVolt = 380;//��о��ߵ�ѹ
               com_BCP_MaxChgCurrent = 3000;//f = 0.1 -400A �������� �涨�Ǹ�ֵ
               com_BCP_NominalEnergy = 663;/$kWH *0.1$/
               com_BCP_MaxPackChgVolt = 38*12*11;/$����ѹ 0.1 V$/
               com_BCP_MaxAllowedTemp = 95;//������¶�f=1 -50 deg
               com_BCP_PackSOC;//��ǰ��SOC  f=0.1 %
               com_BCP_PackVolt;//��ǰ���ܵ�ѹf=0.1 V */
            com_BCPTxEna = true;

            /* BCP����ʹ�� */
            com_BRMTxEna = false;
          } else {
            /* ������ ��ʱ60S */
            tmp = CBMU_MON_DWork.fc_ct + 10UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            CBMU_MON_DWork.fc_ct = (uint16_T)tmp;
            FC_MON_test = 1U;
          }
          break;

         default:
          /* During 'step03': '<S9>:480' */
          break;
        }
        break;

       default:
        /* During 'ParamSetting': '<S9>:628' */
        switch (CBMU_MON_DWork.bitsForTID0.is_ParamSetting) {
         case CBMU_MON_IN_step02:
          /* During 'step02': '<S9>:401' */
          if (!CBMU_MON_B.bitsForTID0.DataStoreRead3_m) {
            /* Transition: '<S9>:463' */
            /* //û�г�ʱ(com_CML_MaxOutVolt >= 1700) &&(com_CML_MinOutVolt <= 1200) &&(com_CML_MaxOutCurrent >= 3500) */
            if (com_CML_MaxOutVolt >= 3000U) {
              /* Transition: '<S9>:468' */
              /* [(com_CML_MaxOutVolt >= 5256) &&(com_CML_MinOutVolt <= 4030) &&(com_CML_MaxOutCurrent <= 2800)]//0.1 -400A ����������������� �涨�Ǹ�ֵ */
              /* Exit 'step02': '<S9>:401' */
              CBMU_MON_DWork.bitsForTID0.is_ParamSetting = CBMU_MON_IN_step04;

              /* Entry 'step04': '<S9>:465' */
              /* Relay ON for Charging preparation */
              com_BRO_BMSReady = (uint8_T)0xAA;

              /* ���ȷ��׼����� */
              com_BROTxEna = true;

              /* ���߳���BMS׼��OK */
              com_BCPTxEna = false;

              /* BCP */
              CBMU_MON_DWork.fc_ct = 0U;
              FC_MON_test = 4U;
            } else {
              /* Transition: '<S9>:452' */
              /* Exit 'step02': '<S9>:401' */
              CBMU_MON_DWork.fc_ct = 0U;
              CBMU_MON_DWork.bitsForTID0.is_ParamSetting = CBMU_MON_IN_step06;

              /* Entry 'step06': '<S9>:469' */
              com_BRO_BMSReady = (uint8_T)0x00;

              /* û�����Աߵ����� */
              com_BROTxEna = true;

              /* ʹ�ܷ���BRO */
              com_BCPTxEna = false;

              /* BCP */
              FC_MON_test = 6U;
            }
          } else if (CBMU_MON_DWork.fc_ct > 50000U) {
            /* Transition: '<S9>:467' */
            /* (com_CMLTimeoutFlag = true) */
            /* Exit 'step02': '<S9>:401' */
            CBMU_MON_DWork.fc_ct = 0U;
            CBMU_MON_DWork.bitsForTID0.is_ParamSetting = CBMU_MON_IN_step05;

            /* Entry 'step05': '<S9>:449' */
            com_BEM_RcvChgerCMLMsg = 1U;

            /* BEM��ʱ��־λ��1 */
            com_BEMTxEna = true;

            /* BEM����ʹ�� */
            FC_MON_test = 5U;
          } else {
            /* BMS-����ʶ���� */
            tmp = CBMU_MON_DWork.fc_ct + 10UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            CBMU_MON_DWork.fc_ct = (uint16_T)tmp;
            FC_MON_test = 2U;
          }
          break;

         case CBMU_MON_IN_step04:
          /* During 'step04': '<S9>:465' */
          if (com_CRO_ChgerReady == 0xAA) {
            /* Transition: '<S9>:402' */
            /* Exit 'step04': '<S9>:465' */
            CBMU_MON_DWork.fc_ct = 0U;
            CBMU_MON_DWork.bitsForTID0.is_ParamSetting = CBMU_MON_IN_step07;

            /* Entry 'step07': '<S9>:399' */
            /* Relay ON for Charging preparation */
            com_BEM_RcvChgerReadyMsg = 0U;

            /* �����ظ�OK */
            com_BROTxEna = false;

            /* ���߳���BMS׼��OK */
            FC_MON_test = 7U;
            CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_m = (RELAY_ON != 0);

            /* �����̵����պ�  �˴��ĸ���Ϊ���̵��� ����Ҫ��	 */
            com_BPSHighVoltSts = 1U;

            /* ��ѹ���ϵ�״̬ */
          } else if (CBMU_MON_DWork.fc_ct > 50000U) {
            /* Transition: '<S9>:471' */
            /* Exit 'step04': '<S9>:465' */
            CBMU_MON_DWork.fc_ct = 0U;
            CBMU_MON_DWork.bitsForTID0.is_ParamSetting = CBMU_MON_IN_step08;

            /* Entry 'step08': '<S9>:466' */
            com_BEM_RcvChgerReadyMsg = 1U;

            /* ��ʱ */
            com_BEMTxEna = true;
            com_BROTxEna = false;

            /* ���߳���BMS׼��OK */
            FC_MON_test = 8U;
          } else {
            tmp = CBMU_MON_DWork.fc_ct + 10UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            CBMU_MON_DWork.fc_ct = (uint16_T)tmp;
            FC_MON_test = 4U;
          }
          break;

         case CBMU_MON_IN_step05:
          /* During 'step05': '<S9>:449' */
          break;

         case CBMU_MON_IN_step06:
          /* During 'step06': '<S9>:469' */
          break;

         case CBMU_MON_IN_step07:
          /* During 'step07': '<S9>:399' */
          if (com_CRO_ChgerReady == 0xAA) {
            /* Transition: '<S9>:486' */
            CBMU_MON_DWork.bitsForTID0.is_ParamSetting =
              CBMU_MON_IN_NO_ACTIVE_CHILD_d;
            CBMU_MON_DWork.bitsForTID0.is_c9_CBMU_MON =
              CBMU_MON_IN_FC_Charging_Mon;

            /* Entry Internal 'FC_Charging_Mon': '<S9>:457' */
            CBMU_MON_DWork.bitsForTID0.is_active_FC_Charging = 1U;

            /* Entry Internal 'FC_Charging': '<S9>:448' */
            /* Transition: '<S9>:473' */
            CBMU_MON_DWork.bitsForTID0.is_FC_Charging = CBMU_MON_IN_step10;

            /* Entry 'step10': '<S9>:453' */
            /* constant current 1C charge */
            FC_MON_test = 10U;

            /* Entry Internal 'step10': '<S9>:453' */
            /* Transition: '<S9>:689' */
            CBMU_MON_DWork.bitsForTID0.is_step10 = CBMU_MON_IN_Heating;

            /* Entry Internal 'Heating': '<S9>:632' */
            /* Transition: '<S9>:635' */
            HeatingSt = 0U;
            if (HeatingEnable == 0) {
              /* Transition: '<S9>:636' */
              CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_END;

              /* Entry 'END': '<S9>:644' */
              ioa_PTCRelayCtrl = (RELAY_OFF != 0);
            } else {
              /* Transition: '<S9>:637' */
              CBMU_MON_DWork.bitsForTID0.is_Heating = CBMU_MON_IN_PTCRelayCheck;

              /* Entry 'PTCRelayCheck': '<S9>:645' */
              CBMU_MON_DWork.ONcnt = 0U;

              /* Entry Internal 'PTCRelayCheck': '<S9>:645' */
              /* Transition: '<S9>:724' */
              CBMU_MON_DWork.bitsForTID0.is_PTCRelayCheck = CBMU_MON_IN_Check;

              /* Entry 'Check': '<S9>:723' */
              CBMU_MON_B.PTCStickyErr = 0U;
            }

            CBMU_MON_DWork.bitsForTID0.is_active_CCS_Mon = 1U;

            /* Entry Internal 'CCS_Mon': '<S9>:474' */
            /* Transition: '<S9>:460' */
            CBMU_MON_DWork.bitsForTID0.is_CCS_Mon = CBMU_MON_IN_CCS_Normal;
          }
          break;

         default:
          /* During 'step08': '<S9>:466' */
          break;
        }
        break;
      }
    }

    /* End of Chart: '<S8>/Chart' */

    /* SwitchCase: '<S10>/Switch Case' incorporates:
     *  Constant: '<S11>/Constant'
     *  RelationalOperator: '<S11>/Compare'
     */
    rtPrevAction = CBMU_MON_DWork.SwitchCase_ActiveSubsystem;
    switch ((int32_T)(HeatingSt == 1)) {
     case 0L:
      rtAction = 0;
      break;

     case 1L:
      rtAction = 1;
      break;

     default:
      rtAction = 2;
      break;
    }

    CBMU_MON_DWork.SwitchCase_ActiveSubsystem = rtAction;
    if ((rtPrevAction != rtAction) && (rtPrevAction == 0)) {
      /* Disable for SwitchCase: '<S12>/Switch Case' */
      CBMU_MON_DWork.SwitchCase_ActiveSubsystem_b = -1;
    }

    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S10>/Switch Case Action Subsystem' incorporates:
         *  InitializeConditions for ActionPort: '<S12>/Action Port'
         */
        /* InitializeConditions for SwitchCase: '<S10>/Switch Case' incorporates:
         *  InitializeConditions for Chart: '<S12>/current'
         */
        CBMU_MON_DWork.bitsForTID0.is_active_c1_CBMU_MON = 0U;
        CBMU_MON_DWork.bitsForTID0.is_c1_CBMU_MON =
          CBMU_MON_IN_NO_ACTIVE_CHILD_d;
        CBMU_MON_DWork.cnt_g = 0U;
        CBMU_MON_B.CalcStart = 0U;

        /* End of InitializeConditions for SubSystem: '<S10>/Switch Case Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S10>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S12>/Action Port'
       */
      /* Chart: '<S12>/current' */
      /* Gateway: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
         Subsystem/current */
      /* During: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
         Subsystem/current */
      if (CBMU_MON_DWork.bitsForTID0.is_active_c1_CBMU_MON == 0U) {
        /* Entry: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
           Subsystem/current */
        CBMU_MON_DWork.bitsForTID0.is_active_c1_CBMU_MON = 1U;

        /* Entry Internal: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
           Subsystem/current */
        /* Transition: '<S16>:39' */
        CBMU_MON_DWork.bitsForTID0.is_c1_CBMU_MON = CBMU_MON_IN_RelayOff;

        /* Entry 'RelayOff': '<S16>:38' */
        CBMU_MON_B.CalcStart = 0U;
      } else {
        switch (CBMU_MON_DWork.bitsForTID0.is_c1_CBMU_MON) {
         case CBMU_MON_IN_CalcStart:
          /* During 'CalcStart': '<S16>:42' */
          CBMU_MON_B.CalcStart = 1U;
          break;

         case CBMU_MON_IN_RelayOff:
          /* During 'RelayOff': '<S16>:38' */
          if (ioa_PTCRelayCtrl) {
            /* Transition: '<S16>:41' */
            CBMU_MON_DWork.bitsForTID0.is_c1_CBMU_MON = CBMU_MON_IN_RelayOn;

            /* Entry 'RelayOn': '<S16>:40' */
            CBMU_MON_DWork.cnt_g = 0U;
          }
          break;

         default:
          /* During 'RelayOn': '<S16>:40' */
          if (CBMU_MON_DWork.cnt_g >= 8000U) {
            /* Transition: '<S16>:43' */
            /* Exit 'RelayOn': '<S16>:40' */
            CBMU_MON_DWork.cnt_g = 0U;
            CBMU_MON_DWork.bitsForTID0.is_c1_CBMU_MON = CBMU_MON_IN_CalcStart;
          } else {
            CBMU_MON_DWork.cnt_g += 10U;
          }
          break;
        }
      }

      /* End of Chart: '<S12>/current' */

      /* SwitchCase: '<S12>/Switch Case' incorporates:
       *  Constant: '<S14>/Constant'
       */
      rtPrevAction = CBMU_MON_DWork.SwitchCase_ActiveSubsystem_b;
      switch ((int32_T)CBMU_MON_B.CalcStart) {
       case 0L:
        rtAction = 0;
        break;

       case 1L:
        rtAction = 1;
        break;

       default:
        rtAction = 2;
        break;
      }

      CBMU_MON_DWork.SwitchCase_ActiveSubsystem_b = rtAction;
      switch (rtAction) {
       case 0:
        /* Outputs for IfAction SubSystem: '<S12>/Switch Case Action Subsystem1' incorporates:
         *  ActionPort: '<S14>/Action Port'
         */
        ChargeCUR = 50U;

        /* End of Outputs for SubSystem: '<S12>/Switch Case Action Subsystem1' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S12>/Switch Case Action Subsystem2' incorporates:
           *  InitializeConditions for ActionPort: '<S15>/Action Port'
           */
          /* InitializeConditions for SwitchCase: '<S12>/Switch Case' incorporates:
           *  InitializeConditions for Chart: '<S15>/Chgcurrentcalc'
           *  InitializeConditions for Memory: '<S15>/Memory'
           */
          CBMU_MON_DWork.Memory_PreviousInput_f = 5U;
          CBMU_MON_DWork.cnt1_f = 0U;
          CBMU_MON_DWork.cnt2_l = 0U;
          CBMU_MON_B.ChgCur = 0U;

          /* End of InitializeConditions for SubSystem: '<S12>/Switch Case Action Subsystem2' */
        }

        /* Outputs for IfAction SubSystem: '<S12>/Switch Case Action Subsystem2' incorporates:
         *  ActionPort: '<S15>/Action Port'
         */
        /* Chart: '<S15>/Chgcurrentcalc' incorporates:
         *  Memory: '<S15>/Memory'
         */
        /* Gateway: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
           Subsystem/Switch Case Action
           Subsystem2/Chgcurrentcalc */
        /* During: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
           Subsystem/Switch Case Action
           Subsystem2/Chgcurrentcalc */
        /* Entry Internal: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
           Subsystem/Switch Case Action
           Subsystem2/Chgcurrentcalc */
        /* Transition: '<S17>:73' */
        if (CBMU_MON_B.DataStoreRead5 >= 32512U) {
          /* Transition: '<S17>:75' */
          /* Transition: '<S17>:80' */
          curvalue = 0U;
          guard1 = true;
        } else {
          if (CBMU_MON_B.DataStoreRead5 < 32512U) {
            /* Transition: '<S17>:78' */
            /* Transition: '<S17>:81' */
            curvalue = 1016U - (CBMU_MON_B.DataStoreRead5 >> 5);
            guard1 = true;
          }
        }

        if (guard1) {
          if (curvalue >= 3U) {
            /* Transition: '<S17>:93' */
            /* Transition: '<S17>:101' */
            CBMU_MON_DWork.cnt1_f++;
            if (CBMU_MON_DWork.cnt1_f >= 500U) {
              /* Transition: '<S17>:105' */
              /* Transition: '<S17>:95' */
              CBMU_MON_DWork.cnt1_f = 0U;
              CBMU_MON_B.ChgCur = (CBMU_MON_DWork.Memory_PreviousInput_f +
                                   curvalue) - 2U;
            } else {
              /* Transition: '<S17>:124' */
              /* Transition: '<S17>:123' */
            }
          } else {
            /* Transition: '<S17>:97' */
            CBMU_MON_DWork.cnt1_f = 0U;
            if (curvalue <= 1U) {
              /* Transition: '<S17>:107' */
              /* Transition: '<S17>:109' */
              CBMU_MON_DWork.cnt2_l++;
              if ((CBMU_MON_DWork.cnt2_l >= 500U) &&
                  (CBMU_MON_DWork.Memory_PreviousInput_f >= 3U)) {
                /* Transition: '<S17>:114' */
                /* Transition: '<S17>:110' */
                CBMU_MON_DWork.cnt2_l = 0U;
                CBMU_MON_B.ChgCur = CBMU_MON_DWork.Memory_PreviousInput_f - 2U;
              } else {
                /* Transition: '<S17>:119' */
                /* Transition: '<S17>:121' */
              }
            } else {
              /* Transition: '<S17>:116' */
              CBMU_MON_DWork.cnt2_l = 0U;
              CBMU_MON_B.ChgCur = CBMU_MON_DWork.Memory_PreviousInput_f;

              /* Transition: '<S17>:120' */
              /* Transition: '<S17>:121' */
            }

            /* Transition: '<S17>:122' */
            /* Transition: '<S17>:123' */
          }
        }

        /* End of Chart: '<S15>/Chgcurrentcalc' */

        /* Saturate: '<S15>/Saturation' */
        if (CBMU_MON_B.ChgCur > 20U) {
          curvalue = 20U;
        } else if (CBMU_MON_B.ChgCur < 2U) {
          curvalue = 2U;
        } else {
          curvalue = CBMU_MON_B.ChgCur;
        }

        /* End of Saturate: '<S15>/Saturation' */

        /* Gain: '<S15>/Gain2' */
        ChargeCUR = 10U * curvalue;

        /* Update for Memory: '<S15>/Memory' */
        CBMU_MON_DWork.Memory_PreviousInput_f = curvalue;

        /* End of Outputs for SubSystem: '<S12>/Switch Case Action Subsystem2' */
        break;

       case 2:
        break;
      }

      /* End of SwitchCase: '<S12>/Switch Case' */
      /* End of Outputs for SubSystem: '<S10>/Switch Case Action Subsystem' */
      break;

     case 1:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S10>/Switch Case Action Subsystem1' incorporates:
         *  InitializeConditions for ActionPort: '<S13>/Action Port'
         */
        /* InitializeConditions for SwitchCase: '<S10>/Switch Case' incorporates:
         *  InitializeConditions for Chart: '<S13>/current'
         */
        CBMU_MON_DWork.bitsForTID0.is_active_c24_CBMU_MON = 0U;
        CBMU_MON_DWork.bitsForTID0.is_c24_CBMU_MON =
          CBMU_MON_IN_NO_ACTIVE_CHILD_d;
        CBMU_MON_DWork.cnt_lp = 0U;
        ChargeCUR = 0U;

        /* End of InitializeConditions for SubSystem: '<S10>/Switch Case Action Subsystem1' */
      }

      /* Outputs for IfAction SubSystem: '<S10>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S13>/Action Port'
       */
      /* Chart: '<S13>/current' incorporates:
       *  Constant: '<S13>/Constant'
       *  DataStoreRead: '<S13>/Data Store Read'
       */
      /* Gateway: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
         Subsystem1/current */
      /* During: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
         Subsystem1/current */
      if (CBMU_MON_DWork.bitsForTID0.is_active_c24_CBMU_MON == 0U) {
        /* Entry: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
           Subsystem1/current */
        CBMU_MON_DWork.bitsForTID0.is_active_c24_CBMU_MON = 1U;

        /* Entry Internal: Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action
           Subsystem1/current */
        /* Transition: '<S22>:51' */
        CBMU_MON_DWork.bitsForTID0.is_c24_CBMU_MON = CBMU_MON_IN_Init;

        /* Entry 'Init': '<S22>:40' */
        CBMU_MON_DWork.cnt_lp = 0U;
      } else if (CBMU_MON_DWork.bitsForTID0.is_c24_CBMU_MON == CBMU_MON_IN_Init)
      {
        /* During 'Init': '<S22>:40' */
        if (CBMU_MON_DWork.cnt_lp >= 30000U) {
          /* Transition: '<S22>:43' */
          /* Exit 'Init': '<S22>:40' */
          CBMU_MON_DWork.cnt_lp = 0U;
          CBMU_MON_DWork.bitsForTID0.is_c24_CBMU_MON = CBMU_MON_IN_LookUpCur;
        } else {
          CBMU_MON_DWork.cnt_lp += 10U;
          ChargeCUR = 50U;
        }
      } else {
        /* During 'LookUpCur': '<S22>:42' */
        ChargeCUR = LPC_CUR;
      }

      /* End of Chart: '<S13>/current' */
      /* End of Outputs for SubSystem: '<S10>/Switch Case Action Subsystem1' */
      break;

     case 2:
      break;
    }

    /* End of SwitchCase: '<S10>/Switch Case' */
  } else {
    if (CBMU_MON_DWork.bitsForTID0.FcMon_MODE) {
      /* Disable for SwitchCase: '<S10>/Switch Case' */
      if (CBMU_MON_DWork.SwitchCase_ActiveSubsystem == 0) {
        /* Disable for SwitchCase: '<S12>/Switch Case' */
        CBMU_MON_DWork.SwitchCase_ActiveSubsystem_b = -1;
      }

      CBMU_MON_DWork.SwitchCase_ActiveSubsystem = -1;

      /* End of Disable for SwitchCase: '<S10>/Switch Case' */
      CBMU_MON_DWork.bitsForTID0.FcMon_MODE = false;
    }
  }

  /* End of RelationalOperator: '<S3>/Relational Operator2' */
  /* End of Outputs for SubSystem: '<S3>/FcMon' */

  /* S-Function (sfun_SetErr): '<S3>/sfun_SetErr_SrcH1' incorporates:
   *  Constant: '<S3>/Constant1'
   */
  Dem_SetError( (uint16_T)86U, (uint8_T)CBMU_MON_B.PTCerr1);

  /* S-Function (sfun_SetErr): '<S3>/sfun_SetErr_SrcH2' incorporates:
   *  Constant: '<S3>/Constant3'
   */
  Dem_SetError( (uint16_T)87U, (uint8_T)CBMU_MON_B.PTCerr2);

  /* S-Function (sfun_SetErr): '<S3>/sfun_SetErr_SrcH3' incorporates:
   *  Constant: '<S3>/Constant4'
   */
  Dem_SetError( (uint16_T)88U, (uint8_T)CBMU_MON_B.PTCerr3);

  /* S-Function (sfun_SetErr): '<S3>/sfun_SetErr_SrcH4' incorporates:
   *  Constant: '<S3>/Constant5'
   */
  Dem_SetError( (uint16_T)89U, (uint8_T)CBMU_MON_B.PTCerr4);

  /* S-Function (sfun_SetErr): '<S3>/sfun_SetErr_SrcH5' incorporates:
   *  Constant: '<S3>/Constant6'
   */
  Dem_SetError( (uint16_T)65U, (uint8_T)CBMU_MON_B.TimeOutErr);

  /* S-Function (sfun_SetErr): '<S3>/sfun_SetErr_SrcH6' incorporates:
   *  Constant: '<S3>/Constant7'
   */
  Dem_SetError( (uint16_T)93U, (uint8_T)CBMU_MON_B.PTCStickyErr);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
