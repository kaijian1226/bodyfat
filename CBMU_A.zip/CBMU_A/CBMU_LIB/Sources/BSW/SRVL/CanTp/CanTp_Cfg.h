/*******************************************************************************
*
*  FILE
*     CanTp_Cfg.h
*
*  DESCRIPTION
*     The Configuration Header file for CanTp
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

#ifndef _CANTP_CFG_H_
#define _CANTP_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "CanIf.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* AUTOSAR COMPLIANT */
#define CANTP_DEV_ERROR_DETECT    STD_ON

/* The value should be corresponding to the CAN channel used 0-4 */
#define CANTP_CAN_CHANNEL_INDEX       0

/* Configure the TP handle and Data pointer */
#define CANTP_TX_HANDLE   CANIF_TX_CANTP_STATIC_MSG


/********************************************
* Timing Parameter , Unit: ms              
********************************************/
#define CANTP_TX_CALL_CYCLE                     10
#define CANTP_RX_CALL_CYCLE                     10

#define CANTP_CONFIRMATION_TO                   150

# if (CANTP_CONFIRMATION_TO == 0)
#  error "CANTP_CONFIRMATION_TO can not be zero !"
# endif

/* Tx CF interval */
#define CANTP_TX_CF_INTERVAL                    20   

/* Rx CF Timerout*/
#define CANTP_RX_CF_TO                          150 

/* Tx FC Timeout */
#define CANTP_TX_FC_TO                          150  

#define CANTP_ST_MIN                            20

/********************************************
* block size            
********************************************/
#define CANTP_BS_REQ                            8

/********************************************
* max wait frame allowed          
********************************************/
#define CANTP_MAX_WAIT_FRAME                    0xFF

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/


#endif /* #ifndef _CANTP_CFG_H_ */