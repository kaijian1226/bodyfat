/*
 * File: PtMon.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PtMon.h"

/* Include model header file for global data */
#include "BMS_MON.h"
#include "BMS_MON_private.h"

/* Named constants for Chart: '<S88>/SRC_Check' */
#define BMS_MON_IN_Defect_h            ((uint8_T)1U)
#define BMS_MON_IN_NO_ACTIVE_CHILD_b   ((uint8_T)0U)
#define BMS_MON_IN_NO_Defect_f         ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Confimed_h ((uint8_T)1U)
#define BMS_MON_IN_SRC_High_Healing_p  ((uint8_T)3U)
#define BMS_MON_IN_SRC_Low_Confimed_o  ((uint8_T)4U)
#define BMS_MON_IN_SRC_Low_Debouncing_f ((uint8_T)5U)
#define BMS_MON_IN_SRC_Low_Healing_o   ((uint8_T)6U)
#define BMS_MO_IN_SRC_High_Debouncing_e ((uint8_T)2U)

/* Named constants for Chart: '<S157>/SRC_Check' */
#define BMS_MON_IN_Defect_m            ((uint8_T)1U)
#define BMS_MON_IN_NO_ACTIVE_CHILD_h   ((uint8_T)0U)
#define BMS_MON_IN_NO_Defect_m         ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Confimed_d ((uint8_T)1U)
#define BMS_MON_IN_SRC_High_Healing_pl ((uint8_T)3U)
#define BMS_MON_IN_SRC_Low_Confimed_i  ((uint8_T)4U)
#define BMS_MON_IN_SRC_Low_Debouncing_l ((uint8_T)5U)
#define BMS_MON_IN_SRC_Low_Healing_a   ((uint8_T)6U)
#define BMS_MO_IN_SRC_High_Debouncing_n ((uint8_T)2U)

/*
 * Initial conditions for atomic system:
 *    '<S87>/SRC_Check'
 *    '<S99>/SRC_Check'
 *    '<S108>/SRC_Check'
 *    '<S175>/SRC_Check'
 *    '<S184>/SRC_Check'
 *    '<S137>/SRC_Check'
 *    '<S146>/SRC_Check'
 *    '<S118>/SRC_Check'
 *    '<S127>/SRC_Check'
 *    '<S194>/SRC_Check'
 *    ...
 */
void BMS_MON_SRC_Check_b_Init(rtB_SRC_Check_BMS_MON_l *localB,
  rtDW_SRC_Check_BMS_MON_k *localDW)
{
  /* InitializeConditions for Chart: '<S88>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_b;
  localDW->bitsForTID0.is_active_c48_BMS_MON = 0U;
  localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_NO_ACTIVE_CHILD_b;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
  localB->SRC_Tmp_Def_Flag = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S87>/SRC_Check'
 *    '<S99>/SRC_Check'
 *    '<S108>/SRC_Check'
 *    '<S175>/SRC_Check'
 *    '<S184>/SRC_Check'
 *    '<S137>/SRC_Check'
 *    '<S146>/SRC_Check'
 *    '<S118>/SRC_Check'
 *    '<S127>/SRC_Check'
 *    '<S194>/SRC_Check'
 *    ...
 */
void BMS_MON_SRC_Check_f(boolean_T rtu_Clear_Def_Flag, t_Temp1 rtu_Sig_Volt,
  t_Temp1 rtu_Par_SRC_H_Threshold, t_Temp1 rtu_Par_SRC_L_Threshold, uint16_T
  rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_l *localB, rtDW_SRC_Check_BMS_MON_k *
  localDW)
{
  /* Chart: '<S88>/SRC_Check' */
  /* Gateway: Task_100ms/BMU/BMU_Mon/PtMon/CTDiff_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_100ms/BMU/BMU_Mon/PtMon/CTDiff_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c48_BMS_MON == 0U) {
    /* Entry: Task_100ms/BMU/BMU_Mon/PtMon/CTDiff_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c48_BMS_MON = 1U;

    /* Entry Internal: Task_100ms/BMU/BMU_Mon/PtMon/CTDiff_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S89>:9' */
    localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_NO_Defect_f;

    /* Entry 'NO_Defect': '<S89>:1' */
    localB->SRC_Def_Status = SRC_NON_DEF;
  } else if (localDW->bitsForTID0.is_c48_BMS_MON == BMS_MON_IN_Defect_h) {
    /* During 'Defect': '<S89>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S89>:22' */
      /* Exit Internal 'Defect': '<S89>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MO_IN_SRC_High_Debouncing_e:
        /* Exit 'SRC_High_Debouncing': '<S89>:4' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_b;
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_f:
        /* Exit 'SRC_Low_Debouncing': '<S89>:3' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_b;
        break;

       default:
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_b;
        break;
      }

      localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_NO_Defect_f;

      /* Entry 'NO_Defect': '<S89>:1' */
      localB->SRC_Def_Status = SRC_NON_DEF;
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Confimed_h:
        /* During 'SRC_High_Confimed': '<S89>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S89>:13' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Healing_p;

          /* Entry 'SRC_High_Healing': '<S89>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MO_IN_SRC_High_Debouncing_e:
        /* During 'SRC_High_Debouncing': '<S89>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S89>:12' */
          /* Exit 'SRC_High_Debouncing': '<S89>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_b;
          localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_NO_Defect_f;

          /* Entry 'NO_Defect': '<S89>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S89>:14' */
          /* Exit 'SRC_High_Debouncing': '<S89>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_h;

          /* Entry 'SRC_High_Confimed': '<S89>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Healing_p:
        /* During 'SRC_High_Healing': '<S89>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S89>:15' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_b;
          localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_NO_Defect_f;

          /* Entry 'NO_Defect': '<S89>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S89>:17' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_h;

          /* Entry 'SRC_High_Confimed': '<S89>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Confimed_o:
        /* During 'SRC_Low_Confimed': '<S89>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S89>:18' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Healing_o;

          /* Entry 'SRC_Low_Healing': '<S89>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_f:
        /* During 'SRC_Low_Debouncing': '<S89>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S89>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S89>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_b;
          localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_NO_Defect_f;

          /* Entry 'NO_Defect': '<S89>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S89>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S89>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_o;

          /* Entry 'SRC_Low_Confimed': '<S89>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S89>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S89>:20' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_b;
          localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_NO_Defect_f;

          /* Entry 'NO_Defect': '<S89>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S89>:19' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_o;

          /* Entry 'SRC_Low_Confimed': '<S89>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    /* During 'NO_Defect': '<S89>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S89>:10' */
      localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_Defect_h;
      localDW->bitsForTID0.is_Defect = BMS_MO_IN_SRC_High_Debouncing_e;

      /* Entry 'SRC_High_Debouncing': '<S89>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
      localB->SRC_Tmp_Def_Flag = 1U;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S89>:11' */
        localDW->bitsForTID0.is_c48_BMS_MON = BMS_MON_IN_Defect_h;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Debouncing_f;

        /* Entry 'SRC_Low_Debouncing': '<S89>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
        localB->SRC_Tmp_Def_Flag = 1U;
      }
    }
  }

  /* End of Chart: '<S88>/SRC_Check' */
}

/*
 * Output and update for action system:
 *    '<S78>/If Action Subsystem'
 *    '<S78>/If Action Subsystem1'
 */
void BMS_MON_IfActionSubsystem_m(t_Temp1 rtu_In1, t_Temp1 *rty_Out1)
{
  /* Inport: '<S90>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S92>/If Abnormal Action Subsystem'
 *    '<S92>/If Normal Action Subsystem'
 *    '<S168>/If Abnormal Action Subsystem'
 *    '<S168>/If Normal Action Subsystem'
 *    '<S130>/If Abnormal Action Subsystem'
 *    '<S130>/If Normal Action Subsystem'
 *    '<S111>/If Abnormal Action Subsystem'
 *    '<S111>/If Normal Action Subsystem'
 *    '<S187>/If Abnormal Action Subsystem'
 *    '<S187>/If Normal Action Subsystem'
 *    ...
 */
void BMS_IfAbnormalActionSubsystem_m(boolean_T rtu_In1, t_Temp1 rtu_In2, uint8_T
  rtu_In3, boolean_T *rty_Out1, t_Temp1 *rty_Out2, uint8_T *rty_Out3)
{
  /* Inport: '<S95>/In1' */
  *rty_Out1 = rtu_In1;

  /* Inport: '<S95>/In2' */
  *rty_Out2 = rtu_In2;

  /* Inport: '<S95>/In3' */
  *rty_Out3 = rtu_In3;
}

/*
 * Initial conditions for action system:
 *    '<S8>/discharge'
 *    '<S8>/discharge1'
 */
void BMS_MON_discharge_Init(rtB_discharge_BMS_MON *localB,
  rtDW_discharge_BMS_MON *localDW)
{
  /* InitializeConditions for Atomic SubSystem: '<S99>/SRC_Check' */
  BMS_MON_SRC_Check_b_Init(&localB->SRC_Check, &localDW->SRC_Check);

  /* End of InitializeConditions for SubSystem: '<S99>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S108>/SRC_Check' */
  BMS_MON_SRC_Check_b_Init(&localB->SRC_Check_k, &localDW->SRC_Check_k);

  /* End of InitializeConditions for SubSystem: '<S108>/SRC_Check' */
}

/*
 * Start for action system:
 *    '<S8>/discharge'
 *    '<S8>/discharge1'
 */
void BMS_MON_discharge_Start(rtB_discharge_BMS_MON *localB,
  rtDW_discharge_BMS_MON *localDW)
{
  /* InitializeConditions for IfAction SubSystem: '<S8>/discharge' */
  BMS_MON_discharge_Init(localB, localDW);

  /* End of InitializeConditions for SubSystem: '<S8>/discharge' */
}

/*
 * Output and update for action system:
 *    '<S8>/discharge'
 *    '<S8>/discharge1'
 */
void BMS_MON_discharge(t_Temp1 rtu_CellTempMax, uint8_T *rty_CTMax_St,
  rtB_discharge_BMS_MON *localB, rtDW_discharge_BMS_MON *localDW)
{
  boolean_T rtb_LogicalOperator1_iv;
  uint8_T rtb_Switch_lv;
  uint8_T rtb_Switch_p2;
  boolean_T rtb_Merge_m;
  t_Temp1 rtb_Merge1_iz;

  /* Outputs for Atomic SubSystem: '<S99>/SRC_Check' */

  /* Constant: '<S99>/Constant1' incorporates:
   *  Constant: '<S99>/Constant2'
   *  Constant: '<S99>/Constant3'
   *  Constant: '<S99>/Constant4'
   *  Constant: '<S99>/Constant5'
   *  Constant: '<S99>/Constant6'
   *  Constant: '<S99>/Constant7'
   *  Constant: '<S99>/Constant8'
   */
  BMS_MON_SRC_Check_f(false, rtu_CellTempMax, DsgTempSigASRCHigh,
                      DsgTempSigASRCLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, &localB->SRC_Check,
                      &localDW->SRC_Check);

  /* End of Outputs for SubSystem: '<S99>/SRC_Check' */

  /* Logic: '<S98>/Logical Operator1' incorporates:
   *  DataStoreRead: '<S98>/Data Store Read'
   *  Logic: '<S98>/Logical Operator4'
   */
  rtb_LogicalOperator1_iv = ((localB->SRC_Check.SRC_Tmp_Def_Flag != 0) &&
    (!localDW->Dem_stClear));

  /* Switch: '<S94>/Switch2' incorporates:
   *  Constant: '<S94>/Constant4'
   *  DataStoreRead: '<S94>/Data Store Read1'
   *  Logic: '<S94>/Logical Operator3'
   */
  if (!localDW->Dem_stClear) {
    rtb_Switch_lv = localB->SRC_Check.SRC_Def_Status;
  } else {
    rtb_Switch_lv = SRC_NON_DEF;
  }

  /* End of Switch: '<S94>/Switch2' */

  /* Switch: '<S94>/Switch' incorporates:
   *  Constant: '<S94>/Constant4'
   *  RelationalOperator: '<S94>/Relational Operator1'
   */
  if (rtb_Switch_lv != SRC_NON_DEF) {
    rtb_Switch_p2 = localB->SRC_Check.SRC_Def_Status;
  } else {
    rtb_Switch_p2 = SRC_NON_DEF;
  }

  /* End of Switch: '<S94>/Switch' */

  /* Outputs for Atomic SubSystem: '<S108>/SRC_Check' */

  /* Constant: '<S108>/Constant1' incorporates:
   *  Constant: '<S108>/Constant2'
   *  Constant: '<S108>/Constant3'
   *  Constant: '<S108>/Constant4'
   *  Constant: '<S108>/Constant5'
   *  Constant: '<S108>/Constant6'
   *  Constant: '<S108>/Constant7'
   *  Constant: '<S108>/Constant8'
   */
  BMS_MON_SRC_Check_f(false, rtu_CellTempMax, DsgTempSigASRCTooHigh,
                      DsgTempSigASRCTooLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, &localB->SRC_Check_k,
                      &localDW->SRC_Check_k);

  /* End of Outputs for SubSystem: '<S108>/SRC_Check' */

  /* SwitchCase: '<S102>/Switch Case' incorporates:
   *  Constant: '<S102>/Constant1'
   *  Constant: '<S102>/Constant2'
   *  Constant: '<S102>/Constant4'
   */
  switch ((int32_T)localB->SRC_Check_k.SRC_Def_Status) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S102>/Switch Case Action Subsystem' incorporates:
     *  ActionPort: '<S105>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &localB->Merge);

    /* End of Outputs for SubSystem: '<S102>/Switch Case Action Subsystem' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S102>/Switch Case Action Subsystem1' incorporates:
     *  ActionPort: '<S106>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &localB->Merge);

    /* End of Outputs for SubSystem: '<S102>/Switch Case Action Subsystem1' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S102>/Switch Case Action Subsystem2' incorporates:
     *  ActionPort: '<S107>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &localB->Merge);

    /* End of Outputs for SubSystem: '<S102>/Switch Case Action Subsystem2' */
    break;
  }

  /* End of SwitchCase: '<S102>/Switch Case' */

  /* Switch: '<S93>/Switch2' incorporates:
   *  Constant: '<S93>/Constant4'
   *  DataStoreRead: '<S93>/Data Store Read1'
   *  Logic: '<S93>/Logical Operator3'
   */
  if (!localDW->Dem_stClear_g) {
    rtb_Switch_lv = localB->Merge;
  } else {
    rtb_Switch_lv = SRC_NON_DEF;
  }

  /* End of Switch: '<S93>/Switch2' */

  /* Switch: '<S93>/Switch' incorporates:
   *  Constant: '<S93>/Constant4'
   *  RelationalOperator: '<S93>/Relational Operator1'
   */
  if (rtb_Switch_lv != SRC_NON_DEF) {
    rtb_Switch_lv = localB->Merge;
  } else {
    rtb_Switch_lv = SRC_NON_DEF;
  }

  /* End of Switch: '<S93>/Switch' */

  /* If: '<S92>/If Abnormal' incorporates:
   *  DataStoreRead: '<S104>/Data Store Read'
   *  Logic: '<S104>/Logical Operator1'
   *  Logic: '<S104>/Logical Operator4'
   */
  if (rtb_Switch_lv != 0) {
    /* Outputs for IfAction SubSystem: '<S92>/If Abnormal Action Subsystem' incorporates:
     *  ActionPort: '<S95>/Action Port'
     */
    BMS_IfAbnormalActionSubsystem_m((localB->SRC_Check_k.SRC_Tmp_Def_Flag != 0) &&
      (!localDW->Dem_stClear_g), rtu_CellTempMax, rtb_Switch_lv, &rtb_Merge_m,
      &rtb_Merge1_iz, rty_CTMax_St);

    /* End of Outputs for SubSystem: '<S92>/If Abnormal Action Subsystem' */
  } else {
    /* Outputs for IfAction SubSystem: '<S92>/If Normal Action Subsystem' incorporates:
     *  ActionPort: '<S96>/Action Port'
     */
    BMS_IfAbnormalActionSubsystem_m(rtb_LogicalOperator1_iv, rtu_CellTempMax,
      rtb_Switch_p2, &rtb_Merge_m, &rtb_Merge1_iz, rty_CTMax_St);

    /* End of Outputs for SubSystem: '<S92>/If Normal Action Subsystem' */
  }

  /* End of If: '<S92>/If Abnormal' */
}

/*
 * Initial conditions for action system:
 *    '<S8>/sc charge'
 *    '<S8>/sc charge1'
 */
void BMS_MON_sccharge_Init(rtB_sccharge_BMS_MON *localB, rtDW_sccharge_BMS_MON
  *localDW)
{
  /* InitializeConditions for Atomic SubSystem: '<S175>/SRC_Check' */
  BMS_MON_SRC_Check_b_Init(&localB->SRC_Check, &localDW->SRC_Check);

  /* End of InitializeConditions for SubSystem: '<S175>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S184>/SRC_Check' */
  BMS_MON_SRC_Check_b_Init(&localB->SRC_Check_p, &localDW->SRC_Check_p);

  /* End of InitializeConditions for SubSystem: '<S184>/SRC_Check' */
}

/*
 * Start for action system:
 *    '<S8>/sc charge'
 *    '<S8>/sc charge1'
 */
void BMS_MON_sccharge_Start(rtB_sccharge_BMS_MON *localB, rtDW_sccharge_BMS_MON *
  localDW)
{
  /* InitializeConditions for IfAction SubSystem: '<S8>/sc charge' */
  BMS_MON_sccharge_Init(localB, localDW);

  /* End of InitializeConditions for SubSystem: '<S8>/sc charge' */
}

/*
 * Output and update for action system:
 *    '<S8>/sc charge'
 *    '<S8>/sc charge1'
 */
void BMS_MON_sccharge(t_Temp1 rtu_CellTempMax, uint8_T *rty_CTMax_St,
                      rtB_sccharge_BMS_MON *localB, rtDW_sccharge_BMS_MON
                      *localDW)
{
  boolean_T rtb_LogicalOperator1_a4;
  uint8_T rtb_Switch_j;
  uint8_T rtb_Switch_fm;
  boolean_T rtb_Merge_jo;
  t_Temp1 rtb_Merge1_of;

  /* Outputs for Atomic SubSystem: '<S175>/SRC_Check' */

  /* Constant: '<S175>/Constant1' incorporates:
   *  Constant: '<S175>/Constant2'
   *  Constant: '<S175>/Constant3'
   *  Constant: '<S175>/Constant4'
   *  Constant: '<S175>/Constant5'
   *  Constant: '<S175>/Constant6'
   *  Constant: '<S175>/Constant7'
   *  Constant: '<S175>/Constant8'
   */
  BMS_MON_SRC_Check_f(false, rtu_CellTempMax, ScTempSigASRCHigh,
                      ScTempSigASRCLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, &localB->SRC_Check,
                      &localDW->SRC_Check);

  /* End of Outputs for SubSystem: '<S175>/SRC_Check' */

  /* Logic: '<S174>/Logical Operator1' incorporates:
   *  DataStoreRead: '<S174>/Data Store Read'
   *  Logic: '<S174>/Logical Operator4'
   */
  rtb_LogicalOperator1_a4 = ((localB->SRC_Check.SRC_Tmp_Def_Flag != 0) &&
    (!localDW->Dem_stClear));

  /* Switch: '<S170>/Switch2' incorporates:
   *  Constant: '<S170>/Constant4'
   *  DataStoreRead: '<S170>/Data Store Read1'
   *  Logic: '<S170>/Logical Operator3'
   */
  if (!localDW->Dem_stClear) {
    rtb_Switch_j = localB->SRC_Check.SRC_Def_Status;
  } else {
    rtb_Switch_j = SRC_NON_DEF;
  }

  /* End of Switch: '<S170>/Switch2' */

  /* Switch: '<S170>/Switch' incorporates:
   *  Constant: '<S170>/Constant4'
   *  RelationalOperator: '<S170>/Relational Operator1'
   */
  if (rtb_Switch_j != SRC_NON_DEF) {
    rtb_Switch_fm = localB->SRC_Check.SRC_Def_Status;
  } else {
    rtb_Switch_fm = SRC_NON_DEF;
  }

  /* End of Switch: '<S170>/Switch' */

  /* Outputs for Atomic SubSystem: '<S184>/SRC_Check' */

  /* Constant: '<S184>/Constant1' incorporates:
   *  Constant: '<S184>/Constant2'
   *  Constant: '<S184>/Constant3'
   *  Constant: '<S184>/Constant4'
   *  Constant: '<S184>/Constant5'
   *  Constant: '<S184>/Constant6'
   *  Constant: '<S184>/Constant7'
   *  Constant: '<S184>/Constant8'
   */
  BMS_MON_SRC_Check_f(false, rtu_CellTempMax, ScTempSigASRCTooHigh,
                      ScTempSigASRCTooLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, &localB->SRC_Check_p,
                      &localDW->SRC_Check_p);

  /* End of Outputs for SubSystem: '<S184>/SRC_Check' */

  /* SwitchCase: '<S178>/Switch Case' incorporates:
   *  Constant: '<S178>/Constant1'
   *  Constant: '<S178>/Constant2'
   *  Constant: '<S178>/Constant4'
   */
  switch ((int32_T)localB->SRC_Check_p.SRC_Def_Status) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S178>/Switch Case Action Subsystem' incorporates:
     *  ActionPort: '<S181>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &localB->Merge);

    /* End of Outputs for SubSystem: '<S178>/Switch Case Action Subsystem' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S178>/Switch Case Action Subsystem1' incorporates:
     *  ActionPort: '<S182>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &localB->Merge);

    /* End of Outputs for SubSystem: '<S178>/Switch Case Action Subsystem1' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S178>/Switch Case Action Subsystem2' incorporates:
     *  ActionPort: '<S183>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &localB->Merge);

    /* End of Outputs for SubSystem: '<S178>/Switch Case Action Subsystem2' */
    break;
  }

  /* End of SwitchCase: '<S178>/Switch Case' */

  /* Switch: '<S169>/Switch2' incorporates:
   *  Constant: '<S169>/Constant4'
   *  DataStoreRead: '<S169>/Data Store Read1'
   *  Logic: '<S169>/Logical Operator3'
   */
  if (!localDW->Dem_stClear_h) {
    rtb_Switch_j = localB->Merge;
  } else {
    rtb_Switch_j = SRC_NON_DEF;
  }

  /* End of Switch: '<S169>/Switch2' */

  /* Switch: '<S169>/Switch' incorporates:
   *  Constant: '<S169>/Constant4'
   *  RelationalOperator: '<S169>/Relational Operator1'
   */
  if (rtb_Switch_j != SRC_NON_DEF) {
    rtb_Switch_j = localB->Merge;
  } else {
    rtb_Switch_j = SRC_NON_DEF;
  }

  /* End of Switch: '<S169>/Switch' */

  /* If: '<S168>/If Abnormal' incorporates:
   *  DataStoreRead: '<S180>/Data Store Read'
   *  Logic: '<S180>/Logical Operator1'
   *  Logic: '<S180>/Logical Operator4'
   */
  if (rtb_Switch_j != 0) {
    /* Outputs for IfAction SubSystem: '<S168>/If Abnormal Action Subsystem' incorporates:
     *  ActionPort: '<S171>/Action Port'
     */
    BMS_IfAbnormalActionSubsystem_m((localB->SRC_Check_p.SRC_Tmp_Def_Flag != 0) &&
      (!localDW->Dem_stClear_h), rtu_CellTempMax, rtb_Switch_j, &rtb_Merge_jo,
      &rtb_Merge1_of, rty_CTMax_St);

    /* End of Outputs for SubSystem: '<S168>/If Abnormal Action Subsystem' */
  } else {
    /* Outputs for IfAction SubSystem: '<S168>/If Normal Action Subsystem' incorporates:
     *  ActionPort: '<S172>/Action Port'
     */
    BMS_IfAbnormalActionSubsystem_m(rtb_LogicalOperator1_a4, rtu_CellTempMax,
      rtb_Switch_fm, &rtb_Merge_jo, &rtb_Merge1_of, rty_CTMax_St);

    /* End of Outputs for SubSystem: '<S168>/If Normal Action Subsystem' */
  }

  /* End of If: '<S168>/If Abnormal' */
}

/* Initial conditions for atomic system: '<S156>/SRC_Check' */
void BMS_MON_SRC_Check_n_Init(rtB_SRC_Check_BMS_MON_j *localB,
  rtDW_SRC_Check_BMS_MON_kc *localDW)
{
  /* InitializeConditions for Chart: '<S157>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h;
  localDW->bitsForTID0.is_active_c30_BMS_MON = 0U;
  localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_NO_ACTIVE_CHILD_h;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
  localB->SRC_Tmp_Def_Flag = 0U;
}

/* Output and update for atomic system: '<S156>/SRC_Check' */
void BMS_MON_SRC_Check_h(boolean_T rtu_Clear_Def_Flag, t_Temp1 rtu_Sig_Volt,
  t_Temp1 rtu_Par_SRC_H_Threshold, t_Temp1 rtu_Par_SRC_L_Threshold, uint16_T
  rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_j *localB, rtDW_SRC_Check_BMS_MON_kc
  *localDW)
{
  /* Chart: '<S157>/SRC_Check' */
  /* Gateway: Task_100ms/BMU/BMU_Mon/PtMon/fc charge1/CTMax_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_100ms/BMU/BMU_Mon/PtMon/fc charge1/CTMax_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c30_BMS_MON == 0U) {
    /* Entry: Task_100ms/BMU/BMU_Mon/PtMon/fc charge1/CTMax_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c30_BMS_MON = 1U;

    /* Entry Internal: Task_100ms/BMU/BMU_Mon/PtMon/fc charge1/CTMax_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S158>:9' */
    localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_NO_Defect_m;

    /* Entry 'NO_Defect': '<S158>:1' */
    localB->SRC_Def_Status = SRC_NON_DEF;
  } else if (localDW->bitsForTID0.is_c30_BMS_MON == BMS_MON_IN_Defect_m) {
    /* During 'Defect': '<S158>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S158>:22' */
      /* Exit Internal 'Defect': '<S158>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MO_IN_SRC_High_Debouncing_n:
        /* Exit 'SRC_High_Debouncing': '<S158>:4' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h;
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_l:
        /* Exit 'SRC_Low_Debouncing': '<S158>:3' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h;
        break;

       default:
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h;
        break;
      }

      localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_NO_Defect_m;

      /* Entry 'NO_Defect': '<S158>:1' */
      localB->SRC_Def_Status = SRC_NON_DEF;
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Confimed_d:
        /* During 'SRC_High_Confimed': '<S158>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S158>:13' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Healing_pl;

          /* Entry 'SRC_High_Healing': '<S158>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MO_IN_SRC_High_Debouncing_n:
        /* During 'SRC_High_Debouncing': '<S158>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S158>:12' */
          /* Exit 'SRC_High_Debouncing': '<S158>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h;
          localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_NO_Defect_m;

          /* Entry 'NO_Defect': '<S158>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S158>:14' */
          /* Exit 'SRC_High_Debouncing': '<S158>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_d;

          /* Entry 'SRC_High_Confimed': '<S158>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Healing_pl:
        /* During 'SRC_High_Healing': '<S158>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S158>:15' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h;
          localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_NO_Defect_m;

          /* Entry 'NO_Defect': '<S158>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S158>:17' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_d;

          /* Entry 'SRC_High_Confimed': '<S158>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Confimed_i:
        /* During 'SRC_Low_Confimed': '<S158>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S158>:18' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Healing_a;

          /* Entry 'SRC_Low_Healing': '<S158>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_l:
        /* During 'SRC_Low_Debouncing': '<S158>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S158>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S158>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h;
          localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_NO_Defect_m;

          /* Entry 'NO_Defect': '<S158>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S158>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S158>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_i;

          /* Entry 'SRC_Low_Confimed': '<S158>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S158>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S158>:20' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h;
          localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_NO_Defect_m;

          /* Entry 'NO_Defect': '<S158>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S158>:19' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_i;

          /* Entry 'SRC_Low_Confimed': '<S158>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    /* During 'NO_Defect': '<S158>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S158>:10' */
      localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_Defect_m;
      localDW->bitsForTID0.is_Defect = BMS_MO_IN_SRC_High_Debouncing_n;

      /* Entry 'SRC_High_Debouncing': '<S158>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
      localB->SRC_Tmp_Def_Flag = 1U;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S158>:11' */
        localDW->bitsForTID0.is_c30_BMS_MON = BMS_MON_IN_Defect_m;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Debouncing_l;

        /* Entry 'SRC_Low_Debouncing': '<S158>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
        localB->SRC_Tmp_Def_Flag = 1U;
      }
    }
  }

  /* End of Chart: '<S157>/SRC_Check' */
}

/* Initial conditions for atomic system: '<S4>/PtMon' */
void BMS_MON_PtMon_Init(void)
{
  /* InitializeConditions for Atomic SubSystem: '<S87>/SRC_Check' */
  BMS_MON_SRC_Check_b_Init(&BMS_MON_B.SRC_Check_f, &BMS_MON_DWork.SRC_Check_f);

  /* End of InitializeConditions for SubSystem: '<S87>/SRC_Check' */
}

/* Start for atomic system: '<S4>/PtMon' */
void BMS_MON_PtMon_Start(void)
{
  /* Start for IfAction SubSystem: '<S8>/discharge' */
  BMS_MON_discharge_Start(&BMS_MON_B.discharge, &BMS_MON_DWork.discharge);

  /* End of Start for SubSystem: '<S8>/discharge' */

  /* Start for IfAction SubSystem: '<S8>/sc charge' */
  BMS_MON_sccharge_Start(&BMS_MON_B.sccharge, &BMS_MON_DWork.sccharge);

  /* End of Start for SubSystem: '<S8>/sc charge' */

  /* InitializeConditions for IfAction SubSystem: '<S8>/fc charge' */

  /* InitializeConditions for Atomic SubSystem: '<S137>/SRC_Check' */
  BMS_MON_SRC_Check_b_Init(&BMS_MON_B.SRC_Check_n, &BMS_MON_DWork.SRC_Check_n);

  /* End of InitializeConditions for SubSystem: '<S137>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S146>/SRC_Check' */
  BMS_MON_SRC_Check_b_Init(&BMS_MON_B.SRC_Check_e, &BMS_MON_DWork.SRC_Check_e);

  /* End of InitializeConditions for SubSystem: '<S146>/SRC_Check' */

  /* End of InitializeConditions for SubSystem: '<S8>/fc charge' */

  /* Start for IfAction SubSystem: '<S8>/discharge1' */
  BMS_MON_discharge_Start(&BMS_MON_B.discharge1, &BMS_MON_DWork.discharge1);

  /* End of Start for SubSystem: '<S8>/discharge1' */

  /* Start for IfAction SubSystem: '<S8>/sc charge1' */
  BMS_MON_sccharge_Start(&BMS_MON_B.sccharge1, &BMS_MON_DWork.sccharge1);

  /* End of Start for SubSystem: '<S8>/sc charge1' */

  /* Start for IfAction SubSystem: '<S8>/fc charge1' */
  /* Start for DataStoreMemory: '<S156>/Data Store Memory5' */
  FcTempTooLow = 40U;

  /* End of Start for SubSystem: '<S8>/fc charge1' */

  /* InitializeConditions for IfAction SubSystem: '<S8>/fc charge1' */

  /* InitializeConditions for Atomic SubSystem: '<S156>/SRC_Check' */
  BMS_MON_SRC_Check_n_Init(&BMS_MON_B.SRC_Check_hc, &BMS_MON_DWork.SRC_Check_hc);

  /* End of InitializeConditions for SubSystem: '<S156>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S165>/SRC_Check' */
  BMS_MON_SRC_Check_b_Init(&BMS_MON_B.SRC_Check_j, &BMS_MON_DWork.SRC_Check_j);

  /* End of InitializeConditions for SubSystem: '<S165>/SRC_Check' */

  /* End of InitializeConditions for SubSystem: '<S8>/fc charge1' */
}

/* Output and update for atomic system: '<S4>/PtMon' */
void BMS_MON_PtMon(void)
{
  boolean_T rtb_LogicalOperator1;
  uint8_T rtb_Switch;
  t_Temp1 rtb_Merge;
  boolean_T rtb_Merge_i;
  t_Temp1 rtb_Merge1_j;

  /* If: '<S78>/If' incorporates:
   *  Constant: '<S78>/Constant'
   *  Inport: '<Root>/com_CellTempMax'
   *  Inport: '<Root>/com_CellTempMin'
   *  RelationalOperator: '<S78>/Relational Operator'
   *  Sum: '<S78>/Add'
   */
  if (SWC_CellTempMax >= SWC_CellTempMin) {
    /* Outputs for IfAction SubSystem: '<S78>/If Action Subsystem' incorporates:
     *  ActionPort: '<S90>/Action Port'
     */
    BMS_MON_IfActionSubsystem_m((uint8_T)((SWC_CellTempMax - SWC_CellTempMin) +
      40), &rtb_Merge);

    /* End of Outputs for SubSystem: '<S78>/If Action Subsystem' */
  } else {
    /* Outputs for IfAction SubSystem: '<S78>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S91>/Action Port'
     */
    BMS_MON_IfActionSubsystem_m(40U, &rtb_Merge);

    /* End of Outputs for SubSystem: '<S78>/If Action Subsystem1' */
  }

  /* End of If: '<S78>/If' */

  /* Outputs for Atomic SubSystem: '<S87>/SRC_Check' */

  /* Constant: '<S87>/Constant1' incorporates:
   *  Constant: '<S87>/Constant2'
   *  Constant: '<S87>/Constant3'
   *  Constant: '<S87>/Constant4'
   *  Constant: '<S87>/Constant5'
   *  Constant: '<S87>/Constant6'
   *  Constant: '<S87>/Constant7'
   *  Constant: '<S87>/Constant8'
   */
  BMS_MON_SRC_Check_f(false, rtb_Merge, DiffTempSigASRCHigh, DiffTempSigASRCLow,
                      BmsSigASRCHighPosDeb, BmsSigASRCHighNegDeb,
                      BmsSigASRCLowPosDeb, BmsSigASRCLowNegDeb, StepTim,
                      &BMS_MON_B.SRC_Check_f, &BMS_MON_DWork.SRC_Check_f);

  /* End of Outputs for SubSystem: '<S87>/SRC_Check' */

  /* Switch: '<S77>/Switch2' incorporates:
   *  Constant: '<S77>/Constant4'
   *  DataStoreRead: '<S77>/Data Store Read1'
   *  Logic: '<S77>/Logical Operator3'
   */
  if (!BMS_MON_DWork.Dem_stClear_kf) {
    rtb_Merge1_j = BMS_MON_B.SRC_Check_f.SRC_Def_Status;
  } else {
    rtb_Merge1_j = SRC_NON_DEF;
  }

  /* End of Switch: '<S77>/Switch2' */

  /* Switch: '<S77>/Switch' incorporates:
   *  Constant: '<S77>/Constant4'
   *  RelationalOperator: '<S77>/Relational Operator1'
   */
  if (rtb_Merge1_j != SRC_NON_DEF) {
    BMS_MON_B.Switch = BMS_MON_B.SRC_Check_f.SRC_Def_Status;
  } else {
    BMS_MON_B.Switch = SRC_NON_DEF;
  }

  /* End of Switch: '<S77>/Switch' */

  /* Constant: '<S8>/Constant10' */
  BMS_MON_B.Merge1 = SRC_NON_DEF;

  /* Constant: '<S8>/Constant12' */
  BMS_MON_B.Merge_o = SRC_NON_DEF;

  /* Constant: '<S8>/Constant3' */
  BMS_MON_B.Merge3 = SRC_NON_DEF;

  /* Constant: '<S8>/Constant5' */
  BMS_MON_B.Merge4_i = SRC_NON_DEF;

  /* Constant: '<S8>/Constant7' */
  BMS_MON_B.Merge5_b = SRC_NON_DEF;

  /* Constant: '<S8>/Constant9' */
  BMS_MON_B.Merge2_h = SRC_NON_DEF;

  /* SwitchCase: '<S8>/Switch Case' incorporates:
   *  Constant: '<S137>/Constant1'
   *  Constant: '<S137>/Constant2'
   *  Constant: '<S137>/Constant3'
   *  Constant: '<S137>/Constant4'
   *  Constant: '<S137>/Constant5'
   *  Constant: '<S137>/Constant6'
   *  Constant: '<S137>/Constant7'
   *  Constant: '<S137>/Constant8'
   *  Constant: '<S146>/Constant1'
   *  Constant: '<S146>/Constant2'
   *  Constant: '<S146>/Constant3'
   *  Constant: '<S146>/Constant4'
   *  Constant: '<S146>/Constant5'
   *  Constant: '<S146>/Constant6'
   *  Constant: '<S146>/Constant7'
   *  Constant: '<S146>/Constant8'
   *  Inport: '<Root>/PackCurMode'
   *  Inport: '<Root>/com_CellTempMax'
   */
  switch ((int32_T)PackCurMode) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S8>/discharge' incorporates:
     *  ActionPort: '<S79>/Action Port'
     */
    BMS_MON_discharge(SWC_CellTempMax, &BMS_MON_B.Merge_o, &BMS_MON_B.discharge,
                      &BMS_MON_DWork.discharge);

    /* End of Outputs for SubSystem: '<S8>/discharge' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S8>/sc charge' incorporates:
     *  ActionPort: '<S83>/Action Port'
     */
    BMS_MON_sccharge(SWC_CellTempMax, &BMS_MON_B.Merge1, &BMS_MON_B.sccharge,
                     &BMS_MON_DWork.sccharge);

    /* End of Outputs for SubSystem: '<S8>/sc charge' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S8>/fc charge' incorporates:
     *  ActionPort: '<S81>/Action Port'
     */

    /* Outputs for Atomic SubSystem: '<S137>/SRC_Check' */
    BMS_MON_SRC_Check_f(false, SWC_CellTempMax, FcTempSigASRCHigh,
                        FcTempSigASRCLow, BmsSigASRCHighPosDeb,
                        BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                        BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_n,
                        &BMS_MON_DWork.SRC_Check_n);

    /* End of Outputs for SubSystem: '<S137>/SRC_Check' */

    /* Logic: '<S136>/Logical Operator1' incorporates:
     *  Constant: '<S137>/Constant1'
     *  Constant: '<S137>/Constant2'
     *  Constant: '<S137>/Constant3'
     *  Constant: '<S137>/Constant4'
     *  Constant: '<S137>/Constant5'
     *  Constant: '<S137>/Constant6'
     *  Constant: '<S137>/Constant7'
     *  Constant: '<S137>/Constant8'
     *  DataStoreRead: '<S136>/Data Store Read'
     *  Inport: '<Root>/com_CellTempMax'
     *  Logic: '<S136>/Logical Operator4'
     */
    rtb_LogicalOperator1 = ((BMS_MON_B.SRC_Check_n.SRC_Tmp_Def_Flag != 0) &&
      (!BMS_MON_DWork.Dem_stClear_m));

    /* Switch: '<S132>/Switch2' incorporates:
     *  Constant: '<S132>/Constant4'
     *  DataStoreRead: '<S132>/Data Store Read1'
     *  Logic: '<S132>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_m) {
      rtb_Merge1_j = BMS_MON_B.SRC_Check_n.SRC_Def_Status;
    } else {
      rtb_Merge1_j = SRC_NON_DEF;
    }

    /* End of Switch: '<S132>/Switch2' */

    /* Switch: '<S132>/Switch' incorporates:
     *  Constant: '<S132>/Constant4'
     *  RelationalOperator: '<S132>/Relational Operator1'
     */
    if (rtb_Merge1_j != SRC_NON_DEF) {
      rtb_Merge = BMS_MON_B.SRC_Check_n.SRC_Def_Status;
    } else {
      rtb_Merge = SRC_NON_DEF;
    }

    /* End of Switch: '<S132>/Switch' */

    /* Outputs for Atomic SubSystem: '<S146>/SRC_Check' */
    BMS_MON_SRC_Check_f(false, SWC_CellTempMax, FcTempSigASRCTooHigh,
                        FcTempSigASRCTooLow, BmsSigASRCHighPosDeb,
                        BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                        BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_e,
                        &BMS_MON_DWork.SRC_Check_e);

    /* End of Outputs for SubSystem: '<S146>/SRC_Check' */

    /* SwitchCase: '<S140>/Switch Case' incorporates:
     *  Constant: '<S140>/Constant1'
     *  Constant: '<S140>/Constant2'
     *  Constant: '<S140>/Constant4'
     *  Constant: '<S146>/Constant1'
     *  Constant: '<S146>/Constant2'
     *  Constant: '<S146>/Constant3'
     *  Constant: '<S146>/Constant4'
     *  Constant: '<S146>/Constant5'
     *  Constant: '<S146>/Constant6'
     *  Constant: '<S146>/Constant7'
     *  Constant: '<S146>/Constant8'
     *  Inport: '<Root>/com_CellTempMax'
     */
    switch ((int32_T)BMS_MON_B.SRC_Check_e.SRC_Def_Status) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S140>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S143>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_lz);

      /* End of Outputs for SubSystem: '<S140>/Switch Case Action Subsystem' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S140>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S144>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_lz);

      /* End of Outputs for SubSystem: '<S140>/Switch Case Action Subsystem1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S140>/Switch Case Action Subsystem2' incorporates:
       *  ActionPort: '<S145>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_lz);

      /* End of Outputs for SubSystem: '<S140>/Switch Case Action Subsystem2' */
      break;
    }

    /* End of SwitchCase: '<S140>/Switch Case' */

    /* Switch: '<S131>/Switch2' incorporates:
     *  Constant: '<S131>/Constant4'
     *  DataStoreRead: '<S131>/Data Store Read1'
     *  Logic: '<S131>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_dy) {
      rtb_Merge1_j = BMS_MON_B.Merge_lz;
    } else {
      rtb_Merge1_j = SRC_NON_DEF;
    }

    /* End of Switch: '<S131>/Switch2' */

    /* Switch: '<S131>/Switch' incorporates:
     *  Constant: '<S131>/Constant4'
     *  RelationalOperator: '<S131>/Relational Operator1'
     */
    if (rtb_Merge1_j != SRC_NON_DEF) {
      rtb_Switch = BMS_MON_B.Merge_lz;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S131>/Switch' */

    /* If: '<S130>/If Abnormal' incorporates:
     *  DataStoreRead: '<S142>/Data Store Read'
     *  Inport: '<Root>/com_CellTempMax'
     *  Logic: '<S142>/Logical Operator1'
     *  Logic: '<S142>/Logical Operator4'
     */
    if (rtb_Switch != 0) {
      /* Outputs for IfAction SubSystem: '<S130>/If Abnormal Action Subsystem' incorporates:
       *  ActionPort: '<S133>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_m((BMS_MON_B.SRC_Check_e.SRC_Tmp_Def_Flag !=
        0) && (!BMS_MON_DWork.Dem_stClear_dy), SWC_CellTempMax, rtb_Switch,
        &rtb_Merge_i, &rtb_Merge1_j, &BMS_MON_B.Merge2_h);

      /* End of Outputs for SubSystem: '<S130>/If Abnormal Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S130>/If Normal Action Subsystem' incorporates:
       *  ActionPort: '<S134>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_m(rtb_LogicalOperator1, SWC_CellTempMax,
        rtb_Merge, &rtb_Merge_i, &rtb_Merge1_j, &BMS_MON_B.Merge2_h);

      /* End of Outputs for SubSystem: '<S130>/If Normal Action Subsystem' */
    }

    /* End of If: '<S130>/If Abnormal' */
    /* End of Outputs for SubSystem: '<S8>/fc charge' */
    break;
  }

  /* End of SwitchCase: '<S8>/Switch Case' */

  /* SwitchCase: '<S8>/Switch Case1' incorporates:
   *  Constant: '<S156>/Constant1'
   *  Constant: '<S156>/Constant2'
   *  Constant: '<S156>/Constant4'
   *  Constant: '<S156>/Constant5'
   *  Constant: '<S156>/Constant6'
   *  Constant: '<S156>/Constant7'
   *  Constant: '<S156>/Constant8'
   *  Constant: '<S165>/Constant1'
   *  Constant: '<S165>/Constant2'
   *  Constant: '<S165>/Constant3'
   *  Constant: '<S165>/Constant4'
   *  Constant: '<S165>/Constant5'
   *  Constant: '<S165>/Constant6'
   *  Constant: '<S165>/Constant7'
   *  Constant: '<S165>/Constant8'
   *  DataStoreRead: '<S156>/Data Store Read'
   *  Inport: '<Root>/PackCurMode'
   *  Inport: '<Root>/com_CellTempMin'
   */
  switch ((int32_T)PackCurMode) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S8>/discharge1' incorporates:
     *  ActionPort: '<S80>/Action Port'
     */
    BMS_MON_discharge(SWC_CellTempMin, &BMS_MON_B.Merge3, &BMS_MON_B.discharge1,
                      &BMS_MON_DWork.discharge1);

    /* End of Outputs for SubSystem: '<S8>/discharge1' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S8>/sc charge1' incorporates:
     *  ActionPort: '<S84>/Action Port'
     */
    BMS_MON_sccharge(SWC_CellTempMin, &BMS_MON_B.Merge4_i, &BMS_MON_B.sccharge1,
                     &BMS_MON_DWork.sccharge1);

    /* End of Outputs for SubSystem: '<S8>/sc charge1' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S8>/fc charge1' incorporates:
     *  ActionPort: '<S82>/Action Port'
     */

    /* Outputs for Atomic SubSystem: '<S156>/SRC_Check' */
    BMS_MON_SRC_Check_h(false, SWC_CellTempMin, FcTempSigASRCHigh, FcTempTooLow,
                        BmsSigASRCHighPosDeb, BmsSigASRCHighNegDeb,
                        BmsSigASRCLowPosDeb, BmsSigASRCLowNegDeb, StepTim,
                        &BMS_MON_B.SRC_Check_hc, &BMS_MON_DWork.SRC_Check_hc);

    /* End of Outputs for SubSystem: '<S156>/SRC_Check' */

    /* Outputs for Atomic SubSystem: '<S165>/SRC_Check' */
    BMS_MON_SRC_Check_f(false, SWC_CellTempMin, FcTempSigASRCTooHigh,
                        FcTempSigASRCTooLow, BmsSigASRCHighPosDeb,
                        BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                        BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_j,
                        &BMS_MON_DWork.SRC_Check_j);

    /* End of Outputs for SubSystem: '<S165>/SRC_Check' */

    /* SwitchCase: '<S159>/Switch Case' incorporates:
     *  Constant: '<S156>/Constant1'
     *  Constant: '<S156>/Constant2'
     *  Constant: '<S156>/Constant4'
     *  Constant: '<S156>/Constant5'
     *  Constant: '<S156>/Constant6'
     *  Constant: '<S156>/Constant7'
     *  Constant: '<S156>/Constant8'
     *  Constant: '<S159>/Constant1'
     *  Constant: '<S159>/Constant2'
     *  Constant: '<S159>/Constant4'
     *  Constant: '<S165>/Constant1'
     *  Constant: '<S165>/Constant2'
     *  Constant: '<S165>/Constant3'
     *  Constant: '<S165>/Constant4'
     *  Constant: '<S165>/Constant5'
     *  Constant: '<S165>/Constant6'
     *  Constant: '<S165>/Constant7'
     *  Constant: '<S165>/Constant8'
     *  DataStoreRead: '<S156>/Data Store Read'
     *  Inport: '<Root>/com_CellTempMin'
     */
    switch ((int32_T)BMS_MON_B.SRC_Check_j.SRC_Def_Status) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S159>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S162>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_l);

      /* End of Outputs for SubSystem: '<S159>/Switch Case Action Subsystem' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S159>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S163>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_l);

      /* End of Outputs for SubSystem: '<S159>/Switch Case Action Subsystem1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S159>/Switch Case Action Subsystem2' incorporates:
       *  ActionPort: '<S164>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_l);

      /* End of Outputs for SubSystem: '<S159>/Switch Case Action Subsystem2' */
      break;
    }

    /* End of SwitchCase: '<S159>/Switch Case' */

    /* Switch: '<S150>/Switch2' incorporates:
     *  Constant: '<S150>/Constant4'
     *  DataStoreRead: '<S150>/Data Store Read1'
     *  Logic: '<S150>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_nq) {
      rtb_Merge1_j = BMS_MON_B.Merge_l;
    } else {
      rtb_Merge1_j = SRC_NON_DEF;
    }

    /* End of Switch: '<S150>/Switch2' */

    /* Switch: '<S150>/Switch' incorporates:
     *  Constant: '<S150>/Constant4'
     *  RelationalOperator: '<S150>/Relational Operator1'
     */
    if (rtb_Merge1_j != SRC_NON_DEF) {
      rtb_Merge = BMS_MON_B.Merge_l;
    } else {
      rtb_Merge = SRC_NON_DEF;
    }

    /* End of Switch: '<S150>/Switch' */

    /* If: '<S149>/If Abnormal' incorporates:
     *  DataStoreRead: '<S151>/Data Store Read1'
     *  DataStoreRead: '<S155>/Data Store Read'
     *  DataStoreRead: '<S161>/Data Store Read'
     *  Inport: '<Root>/com_CellTempMin'
     *  Logic: '<S151>/Logical Operator3'
     *  Logic: '<S155>/Logical Operator1'
     *  Logic: '<S155>/Logical Operator4'
     *  Logic: '<S161>/Logical Operator1'
     *  Logic: '<S161>/Logical Operator4'
     *  Switch: '<S151>/Switch2'
     */
    if (rtb_Merge != 0) {
      /* Outputs for IfAction SubSystem: '<S149>/If Abnormal Action Subsystem' incorporates:
       *  ActionPort: '<S152>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_m((BMS_MON_B.SRC_Check_j.SRC_Tmp_Def_Flag !=
        0) && (!BMS_MON_DWork.Dem_stClear_nq), SWC_CellTempMin, rtb_Merge,
        &rtb_LogicalOperator1, &rtb_Switch, &BMS_MON_B.Merge5_b);

      /* End of Outputs for SubSystem: '<S149>/If Abnormal Action Subsystem' */
    } else {
      if (!BMS_MON_DWork.Dem_stClear_p) {
        /* Switch: '<S151>/Switch2' */
        rtb_Merge1_j = BMS_MON_B.SRC_Check_hc.SRC_Def_Status;
      } else {
        /* Switch: '<S151>/Switch2' incorporates:
         *  Constant: '<S151>/Constant4'
         */
        rtb_Merge1_j = SRC_NON_DEF;
      }

      /* Switch: '<S151>/Switch' incorporates:
       *  Constant: '<S151>/Constant4'
       *  RelationalOperator: '<S151>/Relational Operator1'
       */
      if (rtb_Merge1_j != SRC_NON_DEF) {
        rtb_Merge1_j = BMS_MON_B.SRC_Check_hc.SRC_Def_Status;
      } else {
        rtb_Merge1_j = SRC_NON_DEF;
      }

      /* End of Switch: '<S151>/Switch' */

      /* Outputs for IfAction SubSystem: '<S149>/If Normal Action Subsystem' incorporates:
       *  ActionPort: '<S153>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_m((BMS_MON_B.SRC_Check_hc.SRC_Tmp_Def_Flag
        != 0) && (!BMS_MON_DWork.Dem_stClear_p), SWC_CellTempMin, rtb_Merge1_j,
        &rtb_LogicalOperator1, &rtb_Switch, &BMS_MON_B.Merge5_b);

      /* End of Outputs for SubSystem: '<S149>/If Normal Action Subsystem' */
    }

    /* End of If: '<S149>/If Abnormal' */
    /* End of Outputs for SubSystem: '<S8>/fc charge1' */
    break;
  }

  /* End of SwitchCase: '<S8>/Switch Case1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
