/*
 * File: PvMon.h
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PvMon_h_
#define RTW_HEADER_PvMon_h_
#ifndef BMS_MON_COMMON_INCLUDES_
# define BMS_MON_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "SetErr.h"
#endif                                 /* BMS_MON_COMMON_INCLUDES_ */

#include "BMS_MON_types.h"

/* Child system includes */
#include "rt_sys_BMS_MON_3.h"

/* Block signals for system '<S322>/SRC_Check' */
typedef struct {
  uint8_T SRC_Def_Status;              /* '<S323>/SRC_Check' */
  uint8_T SRC_Tmp_Def_Flag;            /* '<S323>/SRC_Check' */
} rtB_SRC_Check_BMS_MON_m;

/* Block states (auto storage) for system '<S322>/SRC_Check' */
typedef struct {
  uint16_T local_Timer;                /* '<S323>/SRC_Check' */
  struct {
    uint_T is_Defect:3;                /* '<S323>/SRC_Check' */
    uint_T is_c31_BMS_MON:2;           /* '<S323>/SRC_Check' */
    uint_T is_active_c31_BMS_MON:1;    /* '<S323>/SRC_Check' */
  } bitsForTID0;
} rtDW_SRC_Check_BMS_MON_c;

/* Block signals for system '<S331>/SRC_Check' */
typedef struct {
  uint8_T SRC_Def_Status;              /* '<S332>/SRC_Check' */
  uint8_T SRC_Tmp_Def_Flag;            /* '<S332>/SRC_Check' */
} rtB_SRC_Check_BMS_MON_g;

/* Block states (auto storage) for system '<S331>/SRC_Check' */
typedef struct {
  uint16_T local_Timer;                /* '<S332>/SRC_Check' */
  struct {
    uint_T is_Defect:3;                /* '<S332>/SRC_Check' */
    uint_T is_c53_BMS_MON:2;           /* '<S332>/SRC_Check' */
    uint_T is_active_c53_BMS_MON:1;    /* '<S332>/SRC_Check' */
  } bitsForTID0;
} rtDW_SRC_Check_BMS_MON_f;

extern void BMS_MON_SRC_Check_m_Init(rtB_SRC_Check_BMS_MON_m *localB,
  rtDW_SRC_Check_BMS_MON_c *localDW);
extern void BMS_MON_SRC_Check_fe(boolean_T rtu_Clear_Def_Flag, t_Voltage4
  rtu_Sig_Volt, t_Voltage4 rtu_Par_SRC_H_Threshold, t_Voltage4
  rtu_Par_SRC_L_Threshold, uint16_T rtu_Par_SRC_H_PosDeb, uint16_T
  rtu_Par_SRC_H_NegDeb, uint16_T rtu_Par_SRC_L_PosDeb, uint16_T
  rtu_Par_SRC_L_NegDeb, uint8_T rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_m
  *localB, rtDW_SRC_Check_BMS_MON_c *localDW);
extern void BMS_IfAbnormalActionSubsystem_d(boolean_T rtu_In1, t_Voltage4
  rtu_In2, uint8_T rtu_In3, boolean_T *rty_Out1, t_Voltage4 *rty_Out2, uint8_T
  *rty_Out3);
extern void BMS_MON_SRC_Check_j_Init(rtB_SRC_Check_BMS_MON_g *localB,
  rtDW_SRC_Check_BMS_MON_f *localDW);
extern void BMS_MON_SRC_Check_i(boolean_T rtu_Clear_Def_Flag, t_Voltage4
  rtu_Sig_Volt, t_Voltage4 rtu_Par_SRC_H_Threshold, t_Voltage4
  rtu_Par_SRC_L_Threshold, uint16_T rtu_Par_SRC_H_PosDeb, uint16_T
  rtu_Par_SRC_H_NegDeb, uint16_T rtu_Par_SRC_L_PosDeb, uint16_T
  rtu_Par_SRC_L_NegDeb, uint8_T rtu_Par_SampleTime, t_Voltage4
  rtu_Par_SRC_H_HealThreshold, t_Voltage4 rtu_Par_SRC_L_HealThreshold,
  rtB_SRC_Check_BMS_MON_g *localB, rtDW_SRC_Check_BMS_MON_f *localDW);
extern void BMS_MON_PvMon_Init(void);
extern void BMS_MON_PvMon(void);

#endif                                 /* RTW_HEADER_PvMon_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
