/*******************************************************************************
*
*  FILE
*     Xcp_Cfg.h
*
*  DESCRIPTION
*     The Configuration Header file for Xcp Module 
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

#ifndef _XCP_CFG_H_
#define _XCP_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Can_Cfg.h"
#include "Xcp_CanIf_Cfg.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* Following is constant used for configuration, must not modified */
/* Byte order */
#define XCP_BYTE_ORDER_INTEL                      0
#define XCP_BYTE_ORDER_MOTOROLA                   1

/* XCP sizes */
#define XCP_SIZE_BYTE                             1
#define XCP_SIZE_WORD                             2
#define XCP_SIZE_DWORD                            4
#define XCP_SIZE_QWORD                            8

/* XCP checksum types */
#define XCP_CHECKSUM_TYPE_ADD_11                  0x01
#define XCP_CHECKSUM_TYPE_ADD_12                  0x02
#define XCP_CHECKSUM_TYPE_ADD_14                  0x03
#define XCP_CHECKSUM_TYPE_ADD_22                  0x04
#define XCP_CHECKSUM_TYPE_ADD_24                  0x05
#define XCP_CHECKSUM_TYPE_ADD_44                  0x06
#define XCP_CHECKSUM_TYPE_USER_DEFINED            0xFF

/* Configuration Start */
#define XCP_DEV_ERROR_DETECT                      STD_ON

#define XCP_BYTE_ORDER                            XCP_BYTE_ORDER_MOTOROLA

/* maximum block size (number of consecutive CMD packets) */
#define XCP_MAX_BS                                20

/* minimum separation time between the packets of a block transfer from
 the master device to the slave device in units of 100 microseconds. */
#define XCP_MIN_ST                                5

/*********************************************
*  standard XCP features 
**********************************************/

/* protected resources */
#define XCP_RESOURCE_PROTECTION_CAL_PAG           STD_OFF
#define XCP_RESOURCE_PROTECTION_DAQ               STD_OFF

/* maximum size of seed in bytes */
#define XCP_MAX_SEED_SIZE                         4

/* maximum size of key in bytes */
#define XCP_MAX_KEY_SIZE                          4

/* maximum blocksize for checksum calculation */
#define XCP_MAX_CHECKSUM_BLOCKSIZE                0x4000

/* number of segments for online calibration and page switching */
#define XCP_MAX_SEGMENT                           1

/*********************************************
*  synchronous data acquisition features
**********************************************/

/* granularity of ODT entries for DAQ */
#define XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ        XCP_SIZE_BYTE

/* maximum size of ODT entries for DAQ */
#define XCP_MAX_ODT_ENTRY_SIZE_DAQ                XCP_SIZE_DWORD

/* number of available event channels */
#define XCP_MAX_EVENT_CHANNEL                     1
        
/* buffer size for dynamic DAQ lists in bytes */
#define XCP_DAQ_BUFFER_SIZE                       0x1000

/*********************************************
*  configuration checks
**********************************************/

#if (CAN_RX_PROCESSING != CAN_POLLING)
  #error "Only Rx Polling is supported in XCP"
#endif

#if (CAN_TX_PROCESSING != CAN_INTERRUPT)
  #error "Only Tx Interrupt is supported in XCP"
#endif


/* check of XCP_BYTE_ORDER */
#if ((XCP_BYTE_ORDER == XCP_BYTE_ORDER_INTEL) || (XCP_BYTE_ORDER == XCP_BYTE_ORDER_MOTOROLA))
  /* XCP_BYTE_ORDER is valid */
#else
  #error "XCP configuration error: XCP_BYTE_ORDER is invalid."
#endif


/* check of XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ */
#if ((XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ == XCP_SIZE_BYTE) || \
     (XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ == XCP_SIZE_WORD) || \
     (XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ == XCP_SIZE_DWORD))
  /* XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ is valid */
#else
  #error "XCP configuration error: XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ is invalid."
#endif


/*********************************************
*  Constant
**********************************************/
/* defines for DAQ list configuration */
#define XCP_MIN_DAQ                           0
#define XCP_MAX_DAQ                           0
#define XCP_NO_OF_ODTS                        0
#define XCP_NO_OF_ODT_ENTRIES                 0


/* define for number of pages in all segments */
/* support Page switch, so the page number is 2 */
#define XCP_MAX_PAGES                         2


/* protocol layer version (1.0) */
#define XCP_PROTOCOL_LAYER_VERSION            0x01

/*********************************************
*  symbolic definitions of bit mask coded parameters
**********************************************/

/* RESOURCE parameter in CONNECT and GET_SEED */
#define XCP_RESOURCE_CAL_PAG                      0x01
#define XCP_RESOURCE_DAQ                          0x04
#define XCP_RESOURCE_STIM                         0x08
#define XCP_RESOURCE_PGM                          0x10

/* COMM_MODE_BASIC parameter in CONNECT */
#define XCP_COMM_MODE_BASIC_BYTE_ORDER            0x01
#define XCP_COMM_MODE_BASIC_ADRR_GRANULARITY_0    0x02
#define XCP_COMM_MODE_BASIC_ADRR_GRANULARITY_1    0x04
#define XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE      0x40
#define XCP_COMM_MODE_BASIC_OPTIONAL              0x80

/* COMM_MODE_OPTIONAL parameter in GET_COMM_MODE_INFO */
#define XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE  0x01
#define XCP_COMM_MODE_OPTIONAL_INTERLEAVED_MODE   0x02

/* COMM_MODE_PGM parameter in PROGRAM_START */
#define XCP_COMM_MODE_PGM_MASTER_BLOCK_MODE       0x01
#define XCP_COMM_MODE_PGM_INTERLEAVED_MODE        0x02
#define XCP_COMM_MODE_PGM_SLAVE_BLOCK_MODE        0x40

/* Current Resource Protection Status parameter in GET_STATUS and UNLOCK */
#define XCP_PROTECTION_STATUS_CAL_PAG             0x01
#define XCP_PROTECTION_STATUS_DAQ                 0x04
#define XCP_PROTECTION_STATUS_STIM                0x08
#define XCP_PROTECTION_STATUS_PGM                 0x10

/* Mode parameter in SET_REQUEST */
#define XCP_REQUEST_STORE_CAL                     0x01
#define XCP_REQUEST_STORE_DAQ                     0x04
#define XCP_REQUEST_CLEAR_DAQ                     0x08

/* Current Session Status parameter in GET_STATUS */
#define XCP_SESSION_STATUS_DISCONNECTED           0x00  /* internal */
#define XCP_SESSION_STATUS_STORE_CAL_REQUEST      0x01
#define XCP_SESSION_STATUS_STORE_DAQ_REQUEST      0x04
#define XCP_SESSION_STATUS_CLEAR_DAQ_REQUEST      0x08
#define XCP_SESSION_STATUS_CONNECTED              0x10  /* internal */
#define XCP_SESSION_STATUS_CONNECTED_USER         0x20  /* internal */
#define XCP_SESSION_STATUS_DAQ_RUNNING            0x40
#define XCP_SESSION_STATUS_RESUME                 0x80

/* DAQ_KEY_BYTE parameter in GET_DAQ_PROCESSOR_INFO */
#define XCP_DAQ_KEY_OPTIMISATION_TYPE_0           0x01
#define XCP_DAQ_KEY_OPTIMISATION_TYPE_1           0x02
#define XCP_DAQ_KEY_OPTIMISATION_TYPE_2           0x04
#define XCP_DAQ_KEY_OPTIMISATION_TYPE_3           0x08
#define XCP_DAQ_KEY_ADDRESS_EXTENSION_ODT         0x10
#define XCP_DAQ_KEY_ADDRESS_EXTENSION_DAQ         0x20
#define XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_0   0x40
#define XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_1   0x80

/* DAQ_PROPERTIES parameter in GET_DAQ_PROCESSOR_INFO */
#define XCP_DAQ_PROPERTY_CONFIG_TYPE              0x01
#define XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED      0x02
#define XCP_DAQ_PROPERTY_RESUME_SUPPORTED         0x04
#define XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED       0x08
#define XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED      0x10
#define XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED        0x20
#define XCP_DAQ_PROPERTY_OVERLOAD_MSB             0x40
#define XCP_DAQ_PROPERTY_OVERLOAD_EVENT           0x80

/* Mode parameter in SET_DAQ_LIST_MODE / GET_DAQ_LIST_MODE */
#define XCP_DAQ_LIST_MODE_SELECTED                0x01
#define XCP_DAQ_LIST_MODE_DIRECTION               0x02
#define XCP_DAQ_LIST_MODE_CONFIGURED              0x04  /* internal */
#define XCP_DAQ_LIST_MODE_OVERLOAD                0x08  /* internal */
#define XCP_DAQ_LIST_MODE_TIMESTAMP               0x10
#define XCP_DAQ_LIST_MODE_PID_OFF                 0x20
#define XCP_DAQ_LIST_MODE_RUNNING                 0x40
#define XCP_DAQ_LIST_MODE_RESUME                  0x80

/* DAQ_LIST_PROPERTIES parameter in GET_DAQ_LIST_INFO */
#define XCP_DAQ_LIST_PROPERTY_PREDEFINED          0x01
#define XCP_DAQ_LIST_PROPERTY_EVENT_FIXED         0x02
#define XCP_DAQ_LIST_PROPERTY_DAQ                 0x04
#define XCP_DAQ_LIST_PROPERTY_STIM                0x08

/* DAQ_EVENT_PROPERTIES parameter in GET_DAQ_EVENT_INFO */
#define XCP_EVENT_PROPERTY_DAQ                    0x04
#define XCP_EVENT_PROPERTY_STIM                   0x08

/* TIMESTAMP_MODE parameter in GET_DAQ_RESOLUTION_INFO */
#define XCP_TIMESTAMP_MODE_SIZE_0                 0x01
#define XCP_TIMESTAMP_MODE_SIZE_1                 0x02
#define XCP_TIMESTAMP_MODE_SIZE_2                 0x04
#define XCP_TIMESTAMP_MODE_TIMESTAMP_FIXED        0x08
#define XCP_TIMESTAMP_MODE_UNIT_0                 0x10
#define XCP_TIMESTAMP_MODE_UNIT_1                 0x20
#define XCP_TIMESTAMP_MODE_UNIT_2                 0x40
#define XCP_TIMESTAMP_MODE_UNIT_3                 0x80

/* PAG_PROPERTIES parameter in GET_PAG_PROCESSOR_INFO */
#define XCP_PAG_PROPERTY_FREEZE_SUPPORTED         0x01

/* Mode parameter in SET_SEGMENT_MODE / GET_SEGMENT_MODE */
#define XCP_SEGMENT_MODE_FREEZE                   0x01

/* PAGE_PROPERTIES parameter in GET_PAGE_INFO */
#define XCP_PAGE_PROPERTY_ECU_ACCESS_WITHOUT_XCP        0x01
#define XCP_PAGE_PROPERTY_ECU_ACCESS_WITH_XCP           0x02
#define XCP_PAGE_PROPERTY_XCP_READ_ACCESS_WITHOUT_ECU   0x04
#define XCP_PAGE_PROPERTY_XCP_READ_ACCESS_WITH_ECU      0x08
#define XCP_PAGE_PROPERTY_XCP_WRITE_ACCESS_WITHOUT_ECU  0x10
#define XCP_PAGE_PROPERTY_XCP_WRITE_ACCESS_WITH_ECU     0x20

/* Mode parameter in SET_CAL_PAGE */
#define XCP_PAGE_MODE_ECU                         0x01
#define XCP_PAGE_MODE_XCP                         0x02
#define XCP_PAGE_MODE_ALL                         0x80




/* RESOURCE parameter */
#define _XCP_RESOURCE_CAL_PAG                   XCP_RESOURCE_CAL_PAG
#define _XCP_RESOURCE_DAQ                       XCP_RESOURCE_DAQ
#define _XCP_RESOURCE_STIM                      0
#define _XCP_RESOURCE_PGM                       0

#define XCP_RESOURCE (_XCP_RESOURCE_CAL_PAG | \
                      _XCP_RESOURCE_DAQ     | \
                      _XCP_RESOURCE_STIM    | \
                      _XCP_RESOURCE_PGM)

/* COMM_MODE_BASIC parameter */
#if (XCP_BYTE_ORDER == XCP_BYTE_ORDER_MOTOROLA)
  #define _XCP_COMM_MODE_BASIC_BYTE_ORDER         XCP_COMM_MODE_BASIC_BYTE_ORDER
#else
  #define _XCP_COMM_MODE_BASIC_BYTE_ORDER         0
#endif
#define _XCP_COMM_MODE_BASIC_ADDR_GRANULARITY_0   0 /* address granularity is always BYTE */
#define _XCP_COMM_MODE_BASIC_ADDR_GRANULARITY_1   0

#define _XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE   XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE


#define _XCP_COMM_MODE_BASIC_OPTIONAL           XCP_COMM_MODE_BASIC_OPTIONAL

#define XCP_COMM_MODE_BASIC  (_XCP_COMM_MODE_BASIC_BYTE_ORDER         | \
                              _XCP_COMM_MODE_BASIC_ADDR_GRANULARITY_0 | \
                              _XCP_COMM_MODE_BASIC_ADDR_GRANULARITY_1 | \
                              _XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE   | \
                              _XCP_COMM_MODE_BASIC_OPTIONAL)

/* COMM_MODE_OPTIONAL parameter */

#define _XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE
#define _XCP_COMM_MODE_OPTIONAL_INTERLEAVED_MODE    0
#define XCP_COMM_MODE_OPTIONAL (_XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE |\
                                _XCP_COMM_MODE_OPTIONAL_INTERLEAVED_MODE)

/* Current Resource Protection Status parameter */
#if (XCP_RESOURCE_PROTECTION_CAL_PAG == STD_ON)
  #define _XCP_RESOURCE_PROTECTION_CAL_PAG          XCP_PROTECTION_STATUS_CAL_PAG
#else
  #define _XCP_RESOURCE_PROTECTION_CAL_PAG          0
#endif
#if (XCP_RESOURCE_PROTECTION_DAQ == STD_ON)
  #define _XCP_RESOURCE_PROTECTION_DAQ              XCP_PROTECTION_STATUS_DAQ
#else
  #define _XCP_RESOURCE_PROTECTION_DAQ              0
#endif

#define _XCP_RESOURCE_PROTECTION_STIM             0
#define _XCP_RESOURCE_PROTECTION_PGM              0


#define XCP_RESOURCE_PROTECTION_DEFAULT  (_XCP_RESOURCE_PROTECTION_CAL_PAG  | \
                                          _XCP_RESOURCE_PROTECTION_DAQ      | \
                                          _XCP_RESOURCE_PROTECTION_STIM     | \
                                          _XCP_RESOURCE_PROTECTION_PGM)

/* DAQ_KEY_BYTE parameter */
#define _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_0  0 /* IDENTIFICATION_FIELD_TYPE_ABSOLUTE */
#define _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_1  0
#define _XCP_DAQ_KEY_OPTIMISATION_TYPE_0          0 /* OPTIMIZATION_TYPE_DEFAULT */
#define _XCP_DAQ_KEY_OPTIMISATION_TYPE_1          0
#define _XCP_DAQ_KEY_OPTIMISATION_TYPE_2          0
#define _XCP_DAQ_KEY_OPTIMISATION_TYPE_3          0
#define _XCP_DAQ_KEY_ADDRESS_EXTENSION_ODT        0 /* ADDRESS_EXTENSION_FREE */
#define _XCP_DAQ_KEY_ADDRESS_EXTENSION_DAQ        0
#define _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE    XCP_IDENTIFICATION_FIELD_TYPE
#define XCP_DAQ_KEY_BYTE (_XCP_DAQ_KEY_OPTIMISATION_TYPE_0          |\
                          _XCP_DAQ_KEY_OPTIMISATION_TYPE_1          |\
                          _XCP_DAQ_KEY_OPTIMISATION_TYPE_2          |\
                          _XCP_DAQ_KEY_OPTIMISATION_TYPE_3          |\
                          _XCP_DAQ_KEY_ADDRESS_EXTENSION_ODT        |\
                          _XCP_DAQ_KEY_ADDRESS_EXTENSION_DAQ        |\
                          _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_0  |\
                          _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_1)

/* DAQ_PROPERTIES parameter */

#define _XCP_DAQ_PROPERTY_CONFIG_TYPE_0         XCP_DAQ_PROPERTY_CONFIG_TYPE



#define _XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED   0


#define _XCP_DAQ_PROPERTY_RESUME_SUPPORTED      0

#define _XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED    0


#define _XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED   0


#define _XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED     0


#define _XCP_DAQ_PROPERTY_OVERLOAD_MSB          0
#define _XCP_DAQ_PROPERTY_OVERLOAD_EVENT        0

#define XCP_DAQ_PROPERTIES_0 (_XCP_DAQ_PROPERTY_CONFIG_TYPE_0       | \
                              _XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED | \
                              _XCP_DAQ_PROPERTY_RESUME_SUPPORTED    | \
                              _XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED  | \
                              _XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED | \
                              _XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED   | \
                              _XCP_DAQ_PROPERTY_OVERLOAD_MSB        | \
                              _XCP_DAQ_PROPERTY_OVERLOAD_EVENT)


/* DAQ list properties */
#define XCP_DAQ_LIST_PROPERTIES_PREDEFINED       (XCP_DAQ_LIST_PROPERTY_PREDEFINED  | \
                                                  XCP_DAQ_LIST_PROPERTY_DAQ         | \
                                                  XCP_DAQ_LIST_PROPERTY_STIM)

#define XCP_DAQ_LIST_PROPERTIES_CONFIGURABLE     (XCP_DAQ_LIST_PROPERTY_DAQ         | \
                                                  XCP_DAQ_LIST_PROPERTY_STIM)

/* event channel properties */
#define XCP_EVENT_CHANNEL_PROPERTIES             (XCP_EVENT_PROPERTY_DAQ  | \
                                                  XCP_EVENT_PROPERTY_STIM)
                                                  

/*********************************************
*  Transport Layer
**********************************************/                                                  
#define XCP_TRANSPORT_LAYER_VERSION           XCP_TRANSPORT_LAYER_VERSION_CAN
#define XCP_MAX_CTO                           XCP_CAN_MAX_CTO
#define XCP_MAX_DTO                           XCP_CAN_MAX_DTO

#define XCP_DAQ_LST_BUFFER_NEAR               STD_OFF

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/


#endif /* #ifndef _XCP_CFG_H_ */
