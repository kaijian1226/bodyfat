/*******************************************************************************
*
*  FILE
*     CanTp.h
*
*  DESCRIPTION
*     The Header file for CanTp
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

#ifndef _CANTP_H_
#define _CANTP_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "CanTp_cfg.h" 
#include "CanTp_Types.h"
#include "CanTp_Cbk.h"
#include "CanIf.h"
#include "Dcm_Cbk.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Vendor ID. */
#define CANTP_VENDOR_ID           6666

/* Module ID  */
#define CANTP_MODULE_ID             35

/* Version number of the module */
#define CANTP_SW_MAJOR_VERSION    1
#define CANTP_SW_MINOR_VERSION    0
#define CANTP_SW_PATCH_VERSION    0


#define CANTP_INSTATNCE_ID          0

#define CANTP_API_TX_INIT           0
#define CANTP_API_RX_INIT           1
#define CANTP_API_INIT              2
#define CANTP_API_RX_IND            3
#define CANTP_API_MAIN_FUNCTION     4
#define CANTP_API_TX_COPY           5
#define CANTP_API_RX_STATE          6
#define CANTP_API_TX_CONFIRM        7
#define CANTP_API_TX                8

#define CANTP_E_OK                                    0x00
#define CANTP_E_RX_WRONG_SN_RECEIVED                  0x01
#define CANTP_E_RX_DATA_LENGTH_TOO_BIG                0x02
#define CANTP_E_RX_CF_TO                              0x03
#define CANTP_E_RX_CONFIRM_TO                         0x04
#define CANTP_E_RX_UNKNOWN_PCI_TYPE                   0x05
#define CANTP_E_RX_FF_SF_AGAIN_RECEIVED               0x06
#define CANTP_E_RX_DATA_BUFFER_NOT_VALID              0x07
#define CANTP_E_RX_WF_MAX_OVRRUN                      0x08
#define CANTP_E_RX_DATA_LENGTH_TOO_SMALL              0x09                                                                                                  
#define CANTP_E_RX_STATES                             0x0A
#define CANTP_E_RX_NOT_IN_WAIT_CF_STATE               0x0B
#define CANTP_E_RX_CHANNEL_STATE                      0x0C
#define CANTP_E_RX_INCONSISTENT_FLOW_STATUS           0x0D


#define CANTP_E_TX_CONFIRM_TO                         0x20
#define CANTP_E_TX_FC_TO                              0x21
#define CANTP_E_TX_FC_OVRRUN                          0x22
#define CANTP_E_TX_WRONG_FRAME_AT_PRETRANSMIT         0x23
#define CANTP_E_TX_DATA_LENGTH_TOO_HIGH               0x24
#define CANTP_E_TX_STATES                             0x25
#define CANTP_E_TX_NOT_IN_WAIT_FC_STATE               0x26
#define CANTP_E_TX_FLAG_INCONSISTENT                  0x27
#define CANTP_E_TX_FC_UNKNOWN_FS                      0x28
#define CANTP_E_TX_DATA_LENGTH_ZERO                   0X29


#define CANTP_E_NO_DYN_OBJ                            0x50
#define CANTP_E_CHANNEL_NOT_IN_USE                    0x51

/**********************************************
* CANTP offsets in CAN-frame
**********************************************/

#define CANTP_FRAME_LENGTH             8 

#define CANTP_PCI_OFFSET               0
#define CANTP_DL_OFFSET                1
#define CANTP_FF_OFFSET                2
#define CANTP_SF_OFFSET                1
#define CANTP_CF_OFFSET                1
#define CANTP_STMIN_OFFSET             2
#define CANTP_BS_OFFSET                1

/**********************************************
* PCI codes and protocol lengths
**********************************************/
#define CANTP_PCI_TYPE_SF               0x00
#define CANTP_PCI_TYPE_FF               0x10
#define CANTP_PCI_TYPE_CF               0x20
#define CANTP_PCI_TYPE_FC               0x30

#define CANTP_PCI_FC_CTS                0x30
#define CANTP_PCI_FC_WAIT               0x31
#define CANTP_PCI_FC_OVRRUN             0x32
                                      
#define CANTP_PCI_SN_MASK               0x0F


/**********************************************
* Other Parameter 
**********************************************/
#define CANTP_CHANNEL_FREE              0xFF

#define CANTP_CHANNEL_TX                0x00
#define CANTP_CHANNEL_RX                0x80

/* Flow Control Status */
#define CANTP_FC_CTS                    0x00
#define CANTP_FC_WAIT                   0x01
#define CANTP_FC_SUPPRESS               0x02
#define CANTP_FC_OVRFLOW                0x03

/* Timer value in counter units */
#define CANTP_TX_CONFIRM_TO_CNT        (CanTp_TimerType)((CANTP_CONFIRMATION_TO/CANTP_TX_CALL_CYCLE)+1)
#define CANTP_RX_CONFIRM_TO_CNT        (CanTp_TimerType)((CANTP_CONFIRMATION_TO/CANTP_RX_CALL_CYCLE)+1)
#define CANTP_TX_GET_ST_DEFAULT_CNT    ((CanTp_TimerType)((CANTP_TX_CF_INTERVAL+(CANTP_TX_CALL_CYCLE-1))/CANTP_TX_CALL_CYCLE))

#define CANTP_CF_TO_CNT   ((CanTp_TimerType)((CANTP_RX_CF_TO/CANTP_RX_CALL_CYCLE) + 1) )
#define CANTP_FC_TO_CNT   ((CanTp_TimerType)((CANTP_TX_FC_TO/CANTP_TX_CALL_CYCLE) + 1) ) 

/* the Minimum Length for First Frame */
#define CANTP_FF_MIN_DL   (CANTP_FRAME_LENGTH - CANTP_SF_OFFSET + 1)
#define CANTP_FF_OWN_DL   (CANTP_FRAME_LENGTH - CANTP_FF_OFFSET)
#define CANTP_SF_MAX_DL   (CANTP_FRAME_LENGTH - CANTP_SF_OFFSET)
#define CANTP_CF_DL       (CANTP_FRAME_LENGTH - CANTP_CF_OFFSET) 

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern VAR(CanTp_RxInfoType,CANTP_VAR) canTp_RxConfig;

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,CANTP_CODE) CanTp_Init(void);
extern FUNC(Std_ReturnType,CANTP_CODE) CanTp_Transmit(uint8* pdata, uint16 count);
extern FUNC(void,CANTP_CODE) CanTp_MainFunction(void);  
extern FUNC(void,CANTP_CODE) CanTp_RxInit(void); 
extern FUNC(void,CANTP_CODE) CanTp_GetVersionInfo(Std_VersionInfoType* versioninfo);                                                                                                                                                      

#endif /* #ifndef _CANTP_H_ */

