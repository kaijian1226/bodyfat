#ifndef _VARIANT_CFG_H_
#define _VARIANT_CFG_H_

#include "Std_Types.h"



/********** add by zuo , 2013-6-8 *********/
//Plus Relay delay count

// BMU Balance Commond
#define BAL_DELAYCOUNT_2MIN    12000  //12000 * 10ms =2 min 

#define BAL_CURRENT_1A         0x32
#define BAL_CURRENT_2A         0x64
#define BAL_CURRENT_3A         0x96
#define BAL_CURRENT_4A         0xC8
#define BAL_CURRENT_5A         0xFA

#define BALANCE_DISABLE     0
#define BALANCE_ENABLE      1
#define BALANC_EERROR       2
#define BALANCE_NA          3

// High Voltage Lock Switch Count ,add 2013-6-9




// used for relay sticky sensor
#define IO_PORTC  (*(volatile uint8*) 0x00000004)
#define IO_DDRC   (*(volatile uint8*) 0x00000006)

#define IOC_PORTT (*(volatile uint8*) 0x00000240)
#define IOC_DDRT  (*(volatile uint8*) 0x00000242)


extern uint8 ect_IcNotFirst;
extern uint8 ect_CrashOccur ;
extern uint16 ect_IcCountOld ;
extern uint16 ect_IcPeriod  ;
extern uint8  ect_count;
extern uint8  ect_AirbagNormal ;


/*****************************************/

#endif 