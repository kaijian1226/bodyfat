/*******************************************************************************
*
*  FILE
*     CanIf_Types.h
*
*  DESCRIPTION
*     CAN Interface data type  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION          
*    1.1.0
*
*******************************************************************************/
#ifndef _CANIF_TYPES_H_
#define _CANIF_TYPES_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Can.h"

/*******************************************************************************
* Type Definition                                                                
*******************************************************************************/

typedef void   (*CanIf_IndicationFctType)   (PduIdType CanRxPduId, const PduInfoType* PduInfoPtr) ;
typedef void   (*CanIf_ConfirmFctType) (PduIdType CanTxPduId);

typedef enum
{
  CANIF_CS_UNINIT       = 0,
  CANIF_CS_SLEEP        = 1,
  CANIF_CS_STARTED      = 2,
  CANIF_CS_STOPPED      = 3,
}CanIf_ControllerModeType;

typedef enum
{
  CANIF_SET_OFFLINE     = 0,
  CANIF_SET_ONLINE      = 1,
  CANIF_SET_RX_OFFLINE  = 2,
  CANIF_SET_RX_ONLINE   = 3,
  CANIF_SET_TX_OFFLINE  = 4,
  CANIF_SET_TX_OFFLINE_ACTIVE = 5,
  CANIF_SET_TX_ONLINE   = 6,
}CanIf_PduSetModeType;

typedef struct
{
  Can_IdType CanId;
  Can_CntrlType CntrlId;
  CanIf_ConfirmFctType ConfirmFct;
}CanIf_StaticPduTxCfgType;

typedef struct
{
  Can_CntrlType CntrlId;
  Can_IdRngType idRng;
  CanIf_ConfirmFctType ConfirmFct;
}CanIf_DynamicPduTxCfgType;

typedef struct
{
  Can_IdType CanId;
  CanIf_IndicationFctType IndicationFct;
  uint8 SwFltIndex;
}CanIf_PduRxCfgType;

typedef struct
{
  Can_IdType FltCode;
  Can_IdType FltMask;
}CanIf_SwFltType;

typedef struct
{
  PduIdType PduId;
  Can_IdType CanId;
  Can_DlcType CanDlc;
  uint8 Data[8]; 
}CanIf_TxBufferType;

typedef struct
{
  uint8 Size;
  uint8 MaxUsedSize;
  uint8 Rp;
  uint8 Wp;
}CanIf_TxBufferStatusType;


/*******************************************************************************
* Define                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/



#endif /* #ifndef _CAN_TYPES_H_ */