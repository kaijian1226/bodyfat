/*******************************************************************************
*
*  FILE
*     Com_Types.h
*
*  DESCRIPTION
*     The Data Type Header file for COM module  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    0.01
*
*******************************************************************************/

#ifndef _COM_TYPES_H_
#define _COM_TYPES_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
typedef struct
{
  uint8 Enable :1;
  uint8 State  :7;
  uint16 Timer; 
}Com_PduTxStructType;

typedef struct
{
  uint8 Enable :1;
  uint8 State  :7;
  uint16 Timer;
}Com_PduRxStructType;


typedef struct
{
  uint8 TransType;
  uint16 TransRate;
  uint8* DataPtr;
  uint16 DataLen;//add by xyl    
  uint8 TpType;//add by xyl    
  PduIdType CanIfIndex;//add by xyl    
}Com_PduTxConfigType; 

typedef struct
{
  uint8 TransType;
  uint16 TimeOut;  
}Com_PduRxConfigType; 


/*******************************************************************************
* Macros                                                                
*******************************************************************************/
#define COM_TT_ASYN             0
#define COM_TT_CYCLIC           1
#define COM_TT_J1939TP_CYCLIC   2
#define COM_TT_J1939TP_ASYN     3

#define COM_TP_TYPE_NO          0
#define COM_TP_TYPE_CANTP       1
#define COM_TP_TYPE_J1939TP     2

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/



#endif /* #ifndef _COM_TYPES_H_ */