/*******************************************************************************
*
*  FILE
*     Can_Reg.h
*
*  DESCRIPTION
*     The Header file for CAN driver register  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/
#ifndef _CAN_REG_H_
#define _CAN_REG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Can_Cfg.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define CAN_CNTRL_BASIS_ADR(controller)       ((Can_CtrlRegType *)(Can_InitBasisAdr_C[controller]))

#define CAN_RX_MAILBOX_BASIS_ADR(controller)   ((Can_MsgObjType *)&(CAN_CNTRL_BASIS_ADR(controller) -> CanRxBuf))
#define CAN_TX_MAILBOX_BASIS_ADR(controller)   ((Can_MsgObjType *)&(CAN_CNTRL_BASIS_ADR(controller) -> CanTxBuf))

#define CTL0                                (CAN_CNTRL_BASIS_ADR(controller) -> CanCTL0)
#define CTL1                                (CAN_CNTRL_BASIS_ADR(controller) -> CanCTL1)
#define CBTR0                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCBTR0)
#define CBTR1                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCBTR1)
#define CRFLG                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCRFLG)
#define CRIER                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCRIER)
#define CANTFLG                             (CAN_CNTRL_BASIS_ADR(controller) -> CanCTFLG)
#define CTIER                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCTIER)
#define CTARQ                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCTARQ)
#define CTAAK                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCTAAK)
#define CTBSEL                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCTBSEL)
#define CIDAC                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAC)
#define CMISC                               (CAN_CNTRL_BASIS_ADR(controller) -> CanCMISC)
#define CRXERR                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCRXERR)
#define CTXERR                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCTXERR)
#define CIDAR0                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAR0)
#define CIDAR1                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAR1)
#define CIDAR2                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAR2)
#define CIDAR3                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAR3)
#define CIDMR0                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDMR0)
#define CIDMR1                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDMR1)
#define CIDMR2                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDMR2)
#define CIDMR3                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDMR3)
#define CIDAR4                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAR4)
#define CIDAR5                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAR5)
#define CIDAR6                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAR6)
#define CIDAR7                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDAR7)
#define CIDMR4                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDMR4)
#define CIDMR5                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDMR5)
#define CIDMR6                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDMR6)
#define CIDMR7                              (CAN_CNTRL_BASIS_ADR(controller) -> CanCIDMR7)


/* Bitmask of CAN-Register CTL0:                                                         */
# define  CAN_INITRQ       ((uint8)0x01)    /* initialized mode request                     */ 
# define  CAN_SLPRQ        ((uint8)0x02)    /* Sleep request, go to internal sleep mode     */
# define  CAN_WUPE         ((uint8)0x04)    /* wakeup enable                                */
# define  CAN_TIMER        ((uint8)0x08)    /* timer enable                                 */
# define  CAN_SYNCH        ((uint8)0x10)    /* synchronized status                          */
# define  CAN_CSWAI        ((uint8)0x20)    /* CAn stops in waitmode                        */
# define  CAN_RXACT        ((uint8)0x40)    /* receiver active                              */
# define  CAN_RXFRM        ((uint8)0x80)    /* received frame flag                          */

/* Bitmask of CAN-Register CTL1:                                                         */
# define  CAN_INITAK       ((uint8)0x01)    /* initialized mode ack                         */ 
# define  CAN_SLPAK        ((uint8)0x02)    /* Sleep mode acknowledge                       */
# define  CAN_WUPM         ((uint8)0x04)    /* wakeup mode                                  */
# define  CAN_LISTEN       ((uint8)0x10)    /* listen only                                  */
# define  CAN_LOOPB        ((uint8)0x20)    /* loopback mode                                */
# define  CAN_CLKSRC       ((uint8)0x40)    /* clocksource                                  */
# define  CAN_CANE         ((uint8)0x80)    /* CAN enabled                                  */

/* Bitmasks of CAN receiver flag Register CRFLG:                                         */
# define  CAN_WUPIF        ((uint8)0x80)    /* Wake-up interrupt flag                       */
# define  CAN_CSCIF        ((uint8)0x40)    /* CAN status change interruptflag              */
# define  CAN_RSTAT0       ((uint8)0x20)    /*  00 - RxOK 01 Rx-Warning                     */
# define  CAN_RSTAT1       ((uint8)0x10)    /*  02 - RxErr 03 BufOff                        */
# define  CAN_TSTAT0       ((uint8)0x08)    /*  00 - TxOK 01 Tx-Warning                     */
# define  CAN_TSTAT1       ((uint8)0x04)    /*  02 - TxErr 03 BufOff                        */
# define  CAN_OVRIF        ((uint8)0x02)    /* Overrun interrupt flag                       */
# define  CAN_RXF          ((uint8)0x01)    /* Receive buffer full                          */

/* Bitmasks of CAN receiver interrupt enable Register CRIER:                             */
# define  CAN_WUPIE        ((uint8)0x80)    /* Wake-up interrupt flag                       */
# define  CAN_CSCIE        ((uint8)0x40)    /* Receiver warning interrupt flag              */
# define  CAN_RSTAT0E      ((uint8)0x20)    /* Transmitter warning interrupt flag           */
# define  CAN_RSTAT1E      ((uint8)0x10)    /* Receiver error passive interrupt flag        */
# define  CAN_TSTAT0E      ((uint8)0x08)    /* Transmitter error passive interrupt flag     */
# define  CAN_TSTAT1E      ((uint8)0x04)    /* Bus off interrupt flag                       */
# define  CAN_OVRIE        ((uint8)0x02)    /* Overrun interrupt flag                       */
# define  CAN_RXE          ((uint8)0x01)    /* Receive buffer full                          */
# define  CAN_BOFFIF       ((uint8)(CAN_TSTAT1 | CAN_TSTAT0))

/* Bitmasks of CAN transmitter abort request register CTARQ:                             */
# define  CAN_ABTRQ2       ((uint8)0x04)
# define  CAN_ABTRQ1       ((uint8)0x02)
# define  CAN_ABTRQ0       ((uint8)0x01)

/* Bitmasks of CAN miscellaneous Register CMISC:                                         */
# define CAN_BOHOLD        ((uint8)0x01)

# define  CRIER_RX_MASK      ((uint8)0x01)
# define  CRIER_ERROR_MASK   ((uint8)0x7E)
# define  CRIER_WAKEUP_MASK  ((uint8)0x80)

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/





#endif /* _CAN_REG_H_ */