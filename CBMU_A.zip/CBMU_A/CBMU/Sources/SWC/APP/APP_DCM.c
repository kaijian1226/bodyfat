#include "VFB.h"


/***** LID Define: Data Identifier*****/
#define MBB1CELLMINVLOT       0xB001
#define MBB1CELLMAXVLOT       0xB002
#define MBB1CELLMINTEMP       0xB006
#define MBB1CELLMAXTEMP       0xB007

#define MBB2CELLMINVLOT       0xB009
#define MBB2CELLMAXVLOT       0xB00A
#define MBB2CELLMINTEMP       0xB00E
#define MBB2CELLMAXTEMP       0xB00F

#define MBB3CELLMINVLOT       0xB011
#define MBB3CELLMAXVLOT       0xB012
#define MBB3CELLMINTEMP       0xB016
#define MBB3CELLMAXTEMP       0xB017

#define MBB4CELLMINVLOT       0xB019
#define MBB4CELLMAXVLOT       0xB01A
#define MBB4CELLMINTEMP       0xB01E
#define MBB4CELLMAXTEMP       0xB01F
                
#define MBB5CELLMINVLOT       0xB021
#define MBB5CELLMAXVLOT       0xB022
#define MBB5CELLMINTEMP       0xB026
#define MBB5CELLMAXTEMP       0xB027

#define MBB6CELLMINVLOT       0xB029
#define MBB6CELLMAXVLOT       0xB02A
#define MBB6CELLMINTEMP       0xB02E
#define MBB6CELLMAXTEMP       0xB02F

#define BATTPACKBUSVOLT       0xB041
#define BATTPACKBATVOLT       0xB042
#define BATTPACKCURR1         0xB043
#define BATTPACKCURR2         0xB044
#define HVBATTISORES          0xB045
#define HVBATTSOC             0xB046
#define BMSFAULTLEVEL         0xB047
#define BMSBASICSTATUS        0xB048
#define BMSCOMMUNICATESTATUS  0xB04B
#define BATTMAXCELLTEMP       0xB056
#define BATTMINCELLTEMP       0xB057
#define BATTMAXCELLVOLT       0xB058
#define BATTMINCELLVOLT       0xB059

 /***** PID No *****/
#define PID_ECUPARTNUM         0xF187
#define PID_DFSWNUM            0xF189
#define PID_VIN                0xF190
#define PID_ECUHW_NUM          0xF191
#define PID_ECU_APPSWNUM       0xF1A0
#define PID_ECU_CALIBRATESWNUM 0xF1A1
#define PID_SUPPLIER_ID        0xF18A



#define DCM_CELL_VOLT_MUL  25
#define DCM_CELL_VOLT_DIV  82

#define DCM_CELL_TEMP_MUL   2
#define DCM_CELL_TEMP_DIV   1

#define DCM_PACK_VOLT_MUL   1
#define DCM_PACK_VOLT_DIV   8  // 1/32*4

#define DCM_PACK_CURR_MUL   5
#define DCM_PACK_CURR_DIV   4
#define DCM_PACK_CURR_OFFSET   -640

#define DCM_PACK_SOC_MUL    4
#define DCM_PACK_SOC_DIV    1

#define DCM_BPVPMAX_VOLT_MUL  125
#define DCM_BPVPMAX_VOLT_DIV  8

#define DCM_BPVPMIN_VOLT_MUL  20
#define DCM_BPVPMIN_VOLT_DIV  1

#define DCM_RESMAXLIMIT       8190

/* BMS Basic Ststus */
#define BMSPWRUP       0
#define DRIVEREADY     1
#define DRIVEPRECHRG   2
#define DRIVEMODE      3

#define ONBOARDCHRGREADY   4   //Slow charge
#define OFFBOARDCHRGREADY  5   //Fast charge
#define ONBOARDCHRGMODE    6
#define OFFBOARDCHRGMODE   7

#define OFFBOARDCHRGDONE   9
#define ONBOARDCHRGDONE    0x0A
#define ONBOARDPRECHRG     0x0C

#define COLLISIONMODE      0x0D
#define BALANCEING         0x0E
#define BMSFAULT           0x0F

#define PM_VEH_MODE       0
#define RLY_ST_CLOSE  1
#define PM_SC_MODE        1
#define SC_ST_CHARGING  1
#define SC_ST_FINISHED  3
#define SC_ST_ERR       2
#define PM_FC_MODE        2
#define PM_NA_MODE        3


const uint8 Dcm_AppSwVersion[12]= {68,70,95,66,77,83,32,67,72,73,78,65};   /* DF_BMS CHINA */
const uint8 Dcm_SerialNum[12]= {56,56,56,56,56,56,56,56,56,56,56,56};      /* ���кţ�888888888888*/
const uint8 Dcm_BootSwVersion[12]= {49,46,48,48,48,48,48,48,48,48,48,48};  /* 1.0000000000*/
const uint8 Dcm_BSWVersion[6]={86,48,49,46,48,55};                         /*���綨�������汾��,V01.07*/
const uint8 Dcm_BSWDate[6]={49,48,48,56,51,49};                            /*��������:10-08-31*/
const uint8 Dcm_BSWPartNumber[14]={'Z',1,1,0,0,3,0,'J','-','H',0,1,0,0} ;    /*ECU Part Number*/
/* Z = 0x5A, J = 0x4A, '-' =0xC4 */
const uint8 Dcm_BSW_VIN[17]={'z'} ;                                  /*VIN:����ʶ�����*/

const uint8 Dcm_BSW_HardwareNumber[5]={49,48,48,56,51};              /*ECU Hardware Number*/
const uint8 Dcm_BSW_AppSwNumber[5]={49,48,48,56,51};                 /*ECU Application Software Number*/
const uint8 Dcm_BSW_CalibrationSwNumber[5]={49,48,48,56,51};         /*ECU Calibration Software Number*/
const uint8 Dcm_BSW_SupplierID = 0x03;                               /*BMS Supplier ID 0x03,1 byte*/

uint8 VehPowerMode;

uint8 Dcm_ApplGetBMSSts(void);

uint8 App_DCM_Handle( uint16 id,uint8* ptr,uint8 max_length)
 {
  uint8 comSts;
  
  uint8 *ptr_old = ptr;
  uint8 length, i;
  
  *((uint16*)ptr_old)++ = id ;
  switch (id)
  {
  	/* cell Moudle 1 */
  	/*No. B001 */
    case MBB1CELLMINVLOT:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_CellVoltMin[0]*DCM_CELL_VOLT_MUL/DCM_CELL_VOLT_DIV);
      length = 2;
    }
    break;
    
    /*No. B002 */
    case MBB1CELLMAXVLOT:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_CellVoltMax[0]*DCM_CELL_VOLT_MUL/DCM_CELL_VOLT_DIV);
      length = 2;
    }
    break;
    
    /*No. B006 */
    case MBB1CELLMINTEMP:
    {
      *ptr_old = (uint8)((uint16)com_CellTempMin[0]*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
    
    case MBB1CELLMAXTEMP:
    {
      *ptr_old = (uint8)((uint16)com_CellTempMax[0]*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
    
     /* cell Moudle 2 */
    case MBB2CELLMINVLOT:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_CellVoltMin[1]*DCM_CELL_VOLT_MUL/DCM_CELL_VOLT_DIV);
      length = 2;
    }
    break;
    
    case MBB2CELLMAXVLOT:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_CellVoltMax[1]*DCM_CELL_VOLT_MUL/DCM_CELL_VOLT_DIV);
      length = 2;
    }
    break;
    
    case MBB2CELLMINTEMP:
    {
      *ptr_old = (uint8)((uint16)com_CellTempMin[1]*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
    
    case MBB2CELLMAXTEMP:
    {
      *ptr_old = (uint8)((uint16)com_CellTempMax[1]*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
   
    /* cell Moudle 3 */ 
    case MBB3CELLMINVLOT:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_CellVoltMin[2]*DCM_CELL_VOLT_MUL/DCM_CELL_VOLT_DIV);
      length = 2;
    }
    break;
    
    case MBB3CELLMAXVLOT:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_CellVoltMax[2]*DCM_CELL_VOLT_MUL/DCM_CELL_VOLT_DIV);
      length = 2;
    }
    break;
    
    case MBB3CELLMINTEMP:
    {
      *ptr_old = (uint8)((uint16)com_CellTempMin[2]*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
    
    case MBB3CELLMAXTEMP:
    {
      *ptr_old = (uint8)((uint16)com_CellTempMax[2]*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
    
     /* cell Moudle 4 */
    case MBB4CELLMINVLOT:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_CellVoltMin[3]*DCM_CELL_VOLT_MUL/DCM_CELL_VOLT_DIV);
      length = 2;
    }
    break;
    
    case MBB4CELLMAXVLOT:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_CellVoltMax[3]*DCM_CELL_VOLT_MUL/DCM_CELL_VOLT_DIV);
      length = 2;
    }
    break;
    
    case MBB4CELLMINTEMP:
    {
      *ptr_old = (uint8)((uint16)com_CellTempMin[2]*DCM_CELL_TEMP_MUL) ;
      length = 1;
    }
    break;
    
    case MBB4CELLMAXTEMP:
    {
      *ptr_old = (uint8)((uint16)com_CellTempMax[2]*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
    
    /* No.B021 -- cell Moudle 5 */
    case MBB5CELLMINVLOT:
    {
      *(uint16*)ptr_old = 0xFEFE;
      length = 2;
    }
    break;
    /* No.B022 */
    case MBB5CELLMAXVLOT:
    {
      *(uint16*)ptr_old = 0xFEFE;
      length = 2;
    }
    break;
    
    /* No.B026 */
    case MBB5CELLMINTEMP:
    {
      *ptr_old = 0xFE ;
      length = 1;
    }
    break;
    
    case MBB5CELLMAXTEMP:
    {
      *ptr_old = 0xFE;
      length = 1;
    }
    break;
    
    /* No.B029 -- cell Moudle 6 */
    case MBB6CELLMINVLOT:
    {
      *(uint16*)ptr_old = 0xFEFE;
      length = 2;
    }
    break;
    
    case MBB6CELLMAXVLOT:
    {
      *(uint16*)ptr_old = 0xFEFE;
      length = 2;
    }
    break;
    
    case MBB6CELLMINTEMP:
    {
      *ptr_old = 0xFE ;
      length = 1;
    }
    break;
    
    case MBB6CELLMAXTEMP:
    {
      *ptr_old = 0xFE;
      length = 1;
    }
    break;


    /*No.B041 Battery Pack Bus Voltage */
    case BATTPACKBUSVOLT:
    {
      *(uint16*)ptr_old = com_BattVolt*DCM_PACK_VOLT_MUL/DCM_PACK_VOLT_DIV ;
      length = 2;
    }
    break;
    
    /*No.B042 Battery Pack Bat Voltage */
    case BATTPACKBATVOLT:
    {
      *(uint16*)ptr_old = com_BattVolt*DCM_PACK_VOLT_MUL/DCM_PACK_VOLT_DIV;
      length = 2;
    }
    break;
    
    /* No.B043 -- Battery Pack Current1 */
    case BATTPACKCURR1:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_BattCurr*DCM_PACK_CURR_MUL/DCM_PACK_CURR_DIV + DCM_PACK_CURR_OFFSET);
      length = 2;
    }
    break;
    
    /* No.B044 -- Battery Pack Current2 */
    case BATTPACKCURR2:
    {
      *(uint16*)ptr_old = (uint16)((uint32)com_BattCurr*DCM_PACK_CURR_MUL/DCM_PACK_CURR_DIV + DCM_PACK_CURR_OFFSET);
      length = 2;
    }
    break;
   
    /* No.B045 -- HV Battery Isolation */
    case HVBATTISORES:
    {
      if(com_Resistance > DCM_RESMAXLIMIT)
        {
          *(uint16*)ptr_old = DCM_RESMAXLIMIT*2;
        }
      else
        {
          *(uint16*)ptr_old = com_Resistance*2;
        }
      length = 2;
    }
    break;
    
    /* No.B046 -- HV Battery SOC */
    case HVBATTSOC:
    {
      *(uint16*)ptr_old = (uint16)com_SOC*DCM_PACK_SOC_MUL;
      length = 2;
    }
    break;
    
    /* No.B047 -- BMS Fault Level */
    case BMSFAULTLEVEL:
    {
      *ptr_old = BMS_FaultState;
      length = 1;
    }
    break;
    
    
    /* No.B048 -- BMS Basic Status */
    case BMSBASICSTATUS:
    {
      *ptr_old = Dcm_ApplGetBMSSts();
      length = 1 ;
    }
    break;
    
    /*NO.B04B -- BMS Coumunication Status */
    case BMSCOMMUNICATESTATUS:
    {
       comSts = 0 ;
      /*BMS Vehicle Bus Wakeup*/ 
      if( (com_VehBusRxEna == 1)&&(com_VehBusTxEna == 1) )
        {
          comSts = 1 ;
        } 
      else
        {
          comSts = 0 ;
        }
      /*BMS Onboard Charger Wakeup*/  
      if( (com_SlowChrgrRxEna == 1)&&(com_SlowChrgrTxEna == 1) )
        {
          comSts |= 0x02 ;
        } 
      else
        {
          comSts &= ~0x02 ;
        }
      /*BMS Offboard Charger Wakeup*/ 
      if( (com_FastChrgrRxEna == 1)&&(com_FastChrgrTxEna == 1) )
        {
          comSts |= 0x04 ;
        } 
      else
        {
          comSts &= ~0x04 ;
        }
      
      *ptr_old = comSts ;
      length = 1;
    }
    break;
    
    /* No.B056 -- Battery Max Cell Tempature */
    case BATTMAXCELLTEMP:
    {
      *ptr_old = (uint8)((uint16)com_BPTP1MaxCellTemp*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
   
    /* No.B057 -- Battery Min Cell Tempature */ 
    case BATTMINCELLTEMP:
    {
      *ptr_old = (uint8)((uint16)com_BPTP1MinCellTemp*DCM_CELL_TEMP_MUL);
      length = 1;
    }
    break;
   
   /* No.B058 -- Battery Max Cell Voltage */
    case BATTMAXCELLVOLT:
    {
      *(uint16*)ptr_old = (uint16)com_BPVP1MaxCellVolt*DCM_BPVPMAX_VOLT_MUL/DCM_BPVPMAX_VOLT_DIV;
      length = 2;
    }
    break;
   
    /* No.B059 -- Battery Min Cell Voltage */ 
    case BATTMINCELLVOLT:
    {
      *(uint16*)ptr_old = (uint16)com_BPVP1MinCellVolt*DCM_BPVPMIN_VOLT_MUL/DCM_BPVPMIN_VOLT_DIV;
      length = 2;
    }
    break;
    
    
    
  /***PID****/    
    case PID_ECUPARTNUM:
    {
    	for(i=0; i<14; i++){
    		ptr_old[i] = Dcm_BSWPartNumber[i];
    	}
      length = 14;
    }
    break;
    
    case PID_DFSWNUM:
    {
    	for(i=0; i<6; i++){
    		ptr_old[i] = Dcm_BSWVersion[i];//���綨�������汾��
    	}
      length = 6;
    }
    break;
    
    
    case PID_VIN:
    {
    	for(i=0; i<17; i++){
    		ptr_old[i] = Dcm_BSW_VIN[i];//����ʶ�����
    	}
    	length = 17;
    }
    break;
    
    case PID_ECUHW_NUM:
    {
    	for(i=0; i<5; i++){
    		ptr_old[i] = Dcm_BSW_HardwareNumber[i];
    	}
      length = 5;
    }
    break;
    
    case PID_ECU_APPSWNUM:
    {
    	for(i=0; i<5; i++){
    		ptr_old[i] = Dcm_BSW_AppSwNumber[i];
    	}
      length = 5;
    }
    break;
    
    case PID_ECU_CALIBRATESWNUM:
    {
    	for(i=0; i<5; i++){
    		ptr_old[i] = Dcm_BSW_CalibrationSwNumber[i];
    	}
      length = 5;
    }
    break;
    
    case PID_SUPPLIER_ID :
    {
    	ptr_old[0] = Dcm_BSW_SupplierID;
      length = 1;
    }
    break;
        
    default: 
    {
      length = 0;
    }
    break;
   }
   
   if(length)
    {
      return (length+2);
    }else
    {
      return (0);
    }
 }


uint8 Dcm_ApplGetBMSSts(void)
{
     uint8 uSts ;
    if( VehPowerMode == PM_VEH_MODE )
        {
          if(com_BPSHighVoltSts == RLY_ST_CLOSE )
            {
              uSts = DRIVEREADY ;
              if( com_BattCurr < 0x7EE0 ) // < -1A 
                {
                  uSts = DRIVEMODE ;
                }
            } 
           else uSts = BMSFAULT ; 
        }
     else if( VehPowerMode == PM_SC_MODE  )
      {
        if(com_BPSHighVoltSts == RLY_ST_CLOSE )
          {
             uSts = ONBOARDCHRGREADY ;
             if( com_BPC2ChrgSts == SC_ST_CHARGING ) uSts = ONBOARDCHRGMODE ;
          } 
         else if ( com_BPC2ChrgSts == SC_ST_FINISHED ) uSts = ONBOARDCHRGDONE ;
         else if ( com_BPC2ChrgSts == SC_ST_ERR ) uSts = BMSFAULT ;
      }
     else if( VehPowerMode == PM_FC_MODE  ) 
      {
        if(com_BPSHighVoltSts == RLY_ST_CLOSE )
          {
             uSts = OFFBOARDCHRGREADY ;
          }
      }
     else if( VehPowerMode == PM_NA_MODE )  uSts = BMSFAULT ;
    return uSts ; 
}

