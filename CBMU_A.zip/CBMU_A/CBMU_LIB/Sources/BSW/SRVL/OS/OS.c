/*******************************************************************************
*
*  FILE
*     OS.c
*
*  DESCRIPTION
*     
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.00
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include <MC9S12XEP100.h>     /* derivative information */
#include "OSTrace.h"


/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
VAR(boolean, OS_VAR) os_Alarm10ms;
VAR(uint16, OS_VAR)  os_Alarm10msStart;
/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/

/*******************************************************************************
* Extern function declaration                                                
*******************************************************************************/
extern void TASK_10MS(void);
extern void TASK_Idle(void);
extern void TASK_Init(void);
/*******************************************************************************
* Global Functions Body                                   
*******************************************************************************/

/****************************************************************************
* NAME:             main
* CALLED BY:        _Startup in Start12.c
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    None
* DESCRIPTION:      main loop of program                       
****************************************************************************/
FUNC(void, OS_CODE) main(void)  
{

  /* local variable definition */

  uint8 IntOldState;
  
  //CRGFLG_ILAF = 1;        // 2014-01-23, lzy, Clear  ilegal Address flag

  (void)TASK_Init();
  OsTimer_Init();
  OSTrace_Init();

  os_Alarm10msStart = OsTimer_GetMSecondsTick() - 10; //��ʼ�Ķ�ʱ��ʱ��
  Mcu_EnableAllInterrupt();

  /* Loop */
  for (;;)
  {

    SuspendAllInterrupts(); //��ͣ�ж�


    if (os_Alarm10ms == FALSE)
    {
      os_Alarm10ms = OsTimer_CheckTimeOut(os_Alarm10msStart,OsTimer_GetMSecondsTick(),10);//10msʱ���Ƿ�
      if (os_Alarm10ms == TRUE)
      {
        os_Alarm10msStart = OsTimer_GetMSecondsTick(); 
      }
    }


    ResumeAllInterrupts();//�ָ��ж�


    if (os_Alarm10ms == TRUE)
    {
      OSTrace_ExcTimeMeasure(TASK10MS,OSTRACE_ETM_START);
      TASK_10MS();
      OSTrace_ExcTimeMeasure(TASK10MS,OSTRACE_ETM_STOP);
      os_Alarm10ms = FALSE;
    }
    else
    {
      OSTrace_ExcTimeMeasure(TASKIdle,OSTRACE_ETM_START);
      TASK_Idle();
      OSTrace_ExcTimeMeasure(TASKIdle,OSTRACE_ETM_STOP);
    }
  }
}
