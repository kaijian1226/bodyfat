/*******************************************************************************
*
*  FILE
*     OSTimer.c
*
*  DESCRIPTION
*     OsTimer management and update
*      
*       
*  COPYRIGHT
*     (c)Copyright 2008, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*    Gu Bin
*
*  VERSION                 
*    1.00
*
*******************************************************************************/

/*******************************************************************************
*                      Revision  History 
*                              
*   V1.00   18.11.2008  Gu Bin:  Initial version
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "OSTimer.h"
#include "Gpt.h"
#include "Det.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
*  local variables definition                                               
*******************************************************************************/
_STATIC_  VAR(osTimer_MSecondType, OS_VAR) osTimer_MSec; 

_STATIC_  VAR(osTimer_SecondType, OS_VAR) osTimer_Sec;
  
_STATIC_  VAR(osTime_MSecTickType, OS_VAR) osTime_MSecTick;    
/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/****************************************************************************
* NAME:             OsTimer_Init
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    None
* DESCRIPTION:      OsTimer initialization       
****************************************************************************/
#define OS_START_SEC_CODE_NEAR
#include "MemMap.h"

FUNC(void, OS_CODE_NEAR) OsTimer_Init(void)
{
  osTimer_MSec     = 0;
  osTimer_Sec      = 0;
  osTime_MSecTick  = 0;
}

/****************************************************************************
* NAME:             OsTimer_Increment
* CALLED BY:        ISR
* PRECONDITIONS:    
* INPUT PARAMETERS: msec -  millisecond to increase
* RETURN VALUES:    None
* DESCRIPTION:      Increase the Timer      
****************************************************************************/
FUNC(void, OS_CODE_NEAR) OsTimer_Increment(uint16 msec)   //1S��ʱ
{  
  osTimer_MSec += msec;
  if (osTimer_MSec >= 1000U)
  {
    osTimer_Sec += 1;
    osTimer_MSec -= 1000U;
  }
  /* Tick used for alarm function*/
  osTime_MSecTick += msec;

  /* keep the Stop watch high word updated */
  /* OsTimer_GetStopWatch(); */
}

/****************************************************************************
* NAME:             OsTimer_GetSeconds
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    the current seconds that MCU runs
* DESCRIPTION:      Get current Seconds        
****************************************************************************/
FUNC(osTimer_SecondType, OS_CODE_NEAR) OsTimer_GetSeconds(void)
{
  osTimer_SecondType value;
  
  SuspendAllInterrupts();
  value = osTimer_Sec;
  ResumeAllInterrupts();
  return value;
}

/****************************************************************************
* NAME:             OsTimer_GetMSeconds
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    the current milli seconds
* DESCRIPTION:      Get current milli Seconds        
****************************************************************************/
FUNC(osTimer_MSecondType, OS_CODE_NEAR) OsTimer_GetMSeconds(void)
{
  osTimer_MSecondType value;
  
  SuspendAllInterrupts();
  value = osTimer_MSec;
  ResumeAllInterrupts();
  return value;
}

/****************************************************************************
* NAME:             OsTimer_GetMSecondsTick
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    the current time tick
* DESCRIPTION:      Get current time tick (Unit: ms )        
****************************************************************************/
FUNC(osTime_MSecTickType, OS_CODE_NEAR) OsTimer_GetMSecondsTick(void)
{
  osTime_MSecTickType value;
  
  SuspendAllInterrupts();
  value = osTime_MSecTick;
  ResumeAllInterrupts();
  return value;
}

/****************************************************************************
* NAME:             OsTimer_CheckTimeOut
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: timeStart - start tick
*                   timeNow   - current tick
*                   timeOut   - expired tick
* RETURN VALUES:    whether timer is expired 
* DESCRIPTION:      check if specified time is expired        
****************************************************************************/
FUNC(boolean, OS_CODE_NEAR) OsTimer_CheckTimeOut(osTime_MSecTickType timeStart,osTime_MSecTickType timeNow,osTime_MSecTickType timeOut)
{  
  osTime_MSecTickType timerActivateVal;  
  timerActivateVal =  timeOut + timeStart;

  if (timerActivateVal > timeStart)
  {
    if ((timeNow >= timerActivateVal) || (timeNow < timeStart))
    {
      return TRUE;
    }
  } 
  else if ((timeNow >= timerActivateVal) && (timeNow < timeStart))
  {
    return TRUE;
  }
  return FALSE;
}

/****************************************************************************
* NAME:             OsTimer_GetStopWatch
* CALLED BY:        OsTrace and Ostimer function
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    current time tick (uint: us)
* DESCRIPTION:      get current time tick from MCU's timer register
*                   (Timer hardware must be configured properly )
****************************************************************************/
FUNC(OsTimer_StopWatchTickType, OS_CODE_NEAR) OsTimer_GetStopWatch(void)
{
  #if (OSTIMER_STOPWATCH_32BITS == STD_ON)
    /* Store the top 16 bits of the timer */
    static volatile OsTimer_StopWatchTickType timerHighWord = (OsTimer_StopWatchTickType)0U;

    /* Store the bottom 16 bits, to tell if the 16-bit timer wrapped */
    static volatile OsTimer_StopWatchTickType timerLastValue = (OsTimer_StopWatchTickType)0U;

    /* Get the current value of the 16-bit hardware timer, the access of TCNT only cost 
    1 clock cycle, so unnecessary worry about inconsistency */
    OsTimer_StopWatchTickType curValue = (OsTimer_StopWatchTickType)(Gpt_GetCurrentCnt());

    /* If the 16-bit timer has wrapped, increment the high word.
    * Assumes the timer has only wrapped once since the last call to
    * GETSTOPWATCH().*/
    if (curValue < timerLastValue) 
    {
      timerHighWord += (OsTimer_StopWatchTickType)0x00010000U;
    }

    timerLastValue = curValue;

    /* Return (32-bit) value of the stopwatch counter */
    return timerHighWord | curValue; 
  #else /* #if (OSTIMER_STOPWATCH_32BITS == OSTIMER_ON) */ 

    /* Get the current value of the 16-bit hardware timer, the access of TCNT only cost 
    1 clock cycle, so unnecessary worry about inconsistency */
    OsTimer_StopWatchTickType curValue = (OsTimer_StopWatchTickType)(Gpt_GetCurrentCnt());

    return curValue; 
  #endif  
}

#define OS_STOP_SEC_CODE_NEAR
#include "MemMap.h"
