/*******************************************************************************
*
*  FILE
*     TLE8104_Cfg.h
*
*  DESCRIPTION
*     The Header file for TLE8104 Configuration  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

#ifndef _TLE8104_CFG_H_
#define _TLE8104_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Mcu.h"
#include "Dio.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

#define TLE8104_MODULE_NUM        3U

#define TLE8104_CH_NUM            4U

/*
#define TLE8104_M0_RESET_PORT     DIO_PORTD
#define TLE8104_M1_RESET_PORT     DIO_PORTB
#define TLE8104_M2_RESET_PORT     DIO_PTS

#define TLE8104_M0_RESET_DDR      DIO_DDRD
#define TLE8104_M1_RESET_DDR      DIO_DDRB
#define TLE8104_M2_RESET_DDR      DIO_DDRS

#define TLE8104_M0_RESET_MASK      0x01
#define TLE8104_M1_RESET_MASK      0x80
#define TLE8104_M2_RESET_MASK      0x08
*/

#define TLE8104_M0_FAULT_PORT     DIO_PTT
#define TLE8104_M1_FAULT_PORT     DIO_PTT
#define TLE8104_M2_FAULT_PORT     DIO_PTS

#define TLE8104_M0_FAULT_DDR      DIO_DDRT
#define TLE8104_M1_FAULT_DDR      DIO_DDRT
#define TLE8104_M2_FAULT_DDR      DIO_DDRT

#define TLE8104_M0_FAULT_MASK      0x40
#define TLE8104_M1_FAULT_MASK      0x80
#define TLE8104_M2_FAULT_MASK      0x10





#define TLE8104_M0C0_PORT         DIO_PORTB
#define TLE8104_M0C1_PORT         DIO_PORTB
#define TLE8104_M0C2_PORT         DIO_PORTB
#define TLE8104_M0C3_PORT         DIO_PORTB

#define TLE8104_M0C0_DDR         DIO_DDRB
#define TLE8104_M0C1_DDR         DIO_DDRB
#define TLE8104_M0C2_DDR         DIO_DDRB
#define TLE8104_M0C3_DDR         DIO_DDRB

#define TLE8104_M0C0_MASK         0x4
#define TLE8104_M0C1_MASK         0x2
#define TLE8104_M0C2_MASK         0x8
#define TLE8104_M0C3_MASK         0x10

#define TLE8104_M0C0_NMASK         (~TLE8104_M0C0_MASK)
#define TLE8104_M0C1_NMASK         (~TLE8104_M0C1_MASK)
#define TLE8104_M0C2_NMASK         (~TLE8104_M0C2_MASK)
#define TLE8104_M0C3_NMASK         (~TLE8104_M0C3_MASK)


#define TLE8104_M1C0_PORT         DIO_PORTA
#define TLE8104_M1C1_PORT         DIO_PORTA
#define TLE8104_M1C2_PORT         DIO_PORTA
#define TLE8104_M1C3_PORT         DIO_PORTA

#define TLE8104_M1C0_DDR         DIO_DDRA
#define TLE8104_M1C1_DDR         DIO_DDRA
#define TLE8104_M1C2_DDR         DIO_DDRA
#define TLE8104_M1C3_DDR         DIO_DDRA

#define TLE8104_M1C0_MASK         0x20
#define TLE8104_M1C1_MASK         0x40
#define TLE8104_M1C2_MASK         0x80
#define TLE8104_M1C3_MASK         0x10

#define TLE8104_M1C0_NMASK         (~TLE8104_M1C0_MASK)
#define TLE8104_M1C1_NMASK         (~TLE8104_M1C1_MASK)
#define TLE8104_M1C2_NMASK         (~TLE8104_M1C2_MASK)
#define TLE8104_M1C3_NMASK         (~TLE8104_M1C3_MASK)


#define TLE8104_M2C0_PORT         DIO_PORTA
#define TLE8104_M2C1_PORT         DIO_PORTA
#define TLE8104_M2C2_PORT         DIO_PORTA
#define TLE8104_M2C3_PORT         DIO_PORTA

#define TLE8104_M2C0_DDR         DIO_DDRA
#define TLE8104_M2C1_DDR         DIO_DDRA
#define TLE8104_M2C2_DDR         DIO_DDRA
#define TLE8104_M2C3_DDR         DIO_DDRA

#define TLE8104_M2C0_MASK         0x1
#define TLE8104_M2C1_MASK         0x4
#define TLE8104_M2C2_MASK         0x8
#define TLE8104_M2C3_MASK         0x2

#define TLE8104_M2C0_NMASK         (~TLE8104_M2C0_MASK)
#define TLE8104_M2C1_NMASK         (~TLE8104_M2C1_MASK)
#define TLE8104_M2C2_NMASK         (~TLE8104_M2C2_MASK)
#define TLE8104_M2C3_NMASK         (~TLE8104_M2C3_MASK)


#define TLE8104_SPI_ERR_LIMIT     100U
#define TLE8104_SPI_OK_LIMIT     100U
#define TLE8104_INIT_MAX_TIME     200U

#define TLE8104_DEFAULT_CMD       0xF //ShutDown
/*******************************************************************************
* Macros                                                                
*******************************************************************************/
#define TLE8104_ACTIVATE_M0C0()  (TLE8104_M0C0_PORT |= TLE8104_M0C0_MASK)
#define TLE8104_ACTIVATE_M0C1()  (TLE8104_M0C1_PORT |= TLE8104_M0C1_MASK)
#define TLE8104_ACTIVATE_M0C2()  (TLE8104_M0C2_PORT |= TLE8104_M0C2_MASK)
#define TLE8104_ACTIVATE_M0C3()  (TLE8104_M0C3_PORT |= TLE8104_M0C3_MASK)

#define TLE8104_ACTIVATE_M1C0()  (TLE8104_M1C0_PORT |= TLE8104_M1C0_MASK)
#define TLE8104_ACTIVATE_M1C1()  (TLE8104_M1C1_PORT |= TLE8104_M1C1_MASK)
#define TLE8104_ACTIVATE_M1C2()  (TLE8104_M1C2_PORT |= TLE8104_M1C2_MASK)
#define TLE8104_ACTIVATE_M1C3()  (TLE8104_M1C3_PORT |= TLE8104_M1C3_MASK)

#define TLE8104_ACTIVATE_M2C0()  (TLE8104_M2C0_PORT |= TLE8104_M2C0_MASK)
#define TLE8104_ACTIVATE_M2C1()  (TLE8104_M2C1_PORT |= TLE8104_M2C1_MASK)
#define TLE8104_ACTIVATE_M2C2()  (TLE8104_M2C2_PORT |= TLE8104_M2C2_MASK)
#define TLE8104_ACTIVATE_M2C3()  (TLE8104_M2C3_PORT |= TLE8104_M2C3_MASK)

#define TLE8104_DEACTIVATE_M0C0()  (TLE8104_M0C0_PORT &= TLE8104_M0C0_NMASK)
#define TLE8104_DEACTIVATE_M0C1()  (TLE8104_M0C1_PORT &= TLE8104_M0C1_NMASK)
#define TLE8104_DEACTIVATE_M0C2()  (TLE8104_M0C2_PORT &= TLE8104_M0C2_NMASK)
#define TLE8104_DEACTIVATE_M0C3()  (TLE8104_M0C3_PORT &= TLE8104_M0C3_NMASK)

#define TLE8104_DEACTIVATE_M1C0()  (TLE8104_M1C0_PORT &= TLE8104_M1C0_NMASK)
#define TLE8104_DEACTIVATE_M1C1()  (TLE8104_M1C1_PORT &= TLE8104_M1C1_NMASK)
#define TLE8104_DEACTIVATE_M1C2()  (TLE8104_M1C2_PORT &= TLE8104_M1C2_NMASK)
#define TLE8104_DEACTIVATE_M1C3()  (TLE8104_M1C3_PORT &= TLE8104_M1C3_NMASK)

#define TLE8104_DEACTIVATE_M2C0()  (TLE8104_M2C0_PORT &= TLE8104_M2C0_NMASK)
#define TLE8104_DEACTIVATE_M2C1()  (TLE8104_M2C1_PORT &= TLE8104_M2C1_NMASK)
#define TLE8104_DEACTIVATE_M2C2()  (TLE8104_M2C2_PORT &= TLE8104_M2C2_NMASK)
#define TLE8104_DEACTIVATE_M2C3()  (TLE8104_M2C3_PORT &= TLE8104_M2C3_NMASK)


#define TLE8104_PORT_INIT()\
{ TLE8104_DEACTIVATE_M0C0();\
  TLE8104_DEACTIVATE_M0C1();\
  TLE8104_DEACTIVATE_M0C2();\
  TLE8104_DEACTIVATE_M0C3();\
  TLE8104_DEACTIVATE_M1C0();\
  TLE8104_DEACTIVATE_M1C1();\
  TLE8104_DEACTIVATE_M1C2();\
  TLE8104_DEACTIVATE_M1C3();\
  TLE8104_DEACTIVATE_M2C0();\
  TLE8104_DEACTIVATE_M2C1();\
  TLE8104_DEACTIVATE_M2C2();\
  TLE8104_DEACTIVATE_M2C3();\
  TLE8104_M0C0_DDR |= TLE8104_M0C0_MASK;\
  TLE8104_M0C1_DDR |= TLE8104_M0C1_MASK;\
  TLE8104_M0C2_DDR |= TLE8104_M0C2_MASK;\
  TLE8104_M0C3_DDR |= TLE8104_M0C3_MASK;\
  TLE8104_M1C0_DDR |= TLE8104_M1C0_MASK;\
  TLE8104_M1C1_DDR |= TLE8104_M1C1_MASK;\
  TLE8104_M1C2_DDR |= TLE8104_M1C2_MASK;\
  TLE8104_M1C3_DDR |= TLE8104_M1C3_MASK;\
  TLE8104_M2C0_DDR |= TLE8104_M2C0_MASK;\
  TLE8104_M2C1_DDR |= TLE8104_M2C1_MASK;\
  TLE8104_M2C2_DDR |= TLE8104_M2C2_MASK;\
  TLE8104_M2C3_DDR |= TLE8104_M2C3_MASK;}

/*
  TLE8104_M0C1_DDR |= TLE8104_M0C1_MASK;\
  TLE8104_M0C2_DDR |= TLE8104_M0C2_MASK;\
  TLE8104_M0C3_DDR |= TLE8104_M0C3_MASK;\
  TLE8104_M1C0_DDR |= TLE8104_M1C0_MASK;\
  TLE8104_M1C1_DDR |= TLE8104_M1C1_MASK;\
  TLE8104_M1C2_DDR |= TLE8104_M1C2_MASK;\
  TLE8104_M1C3_DDR |= TLE8104_M1C3_MASK;\
  TLE8104_M2C0_DDR |= TLE8104_M2C0_MASK;\
  TLE8104_M2C1_DDR |= TLE8104_M2C1_MASK;\
  TLE8104_M2C2_DDR |= TLE8104_M2C2_MASK;\
  TLE8104_M2C3_DDR |= TLE8104_M2C3_MASK; 
*/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

#endif /* _TLE8104_CFG_H_ */