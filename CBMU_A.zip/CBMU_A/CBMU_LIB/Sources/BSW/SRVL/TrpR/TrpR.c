#include "TrpR.h"

#define TRIP_RECORD_STRT_ADDRESS   0x13F200UL
#define TRIP_RECORD_SIZE           0xDF0U

#pragma DATA_SEG CHKSUM
uint32 trpr_tripRcdChksum;
#pragma DATA_SEG DEFAULT;

#pragma DATA_SEG TRIP_RECORD

VehPowerDownDataStr TRPR_VAR_FAR trpr_PwrDwnData[100];
ChrgPowerDownDataStr TRPR_VAR_FAR trpr_SlwChrgDwnData[20];
ChrgPowerDownDataStr TRPR_VAR_FAR trpr_FstChrgDwnData[2];

uint8 TRPR_VAR_FAR trpr_PwrDwnDataIdx;
uint8 TRPR_VAR_FAR trpr_SlwChrgDwnDataIdx;
uint8 TRPR_VAR_FAR trpr_FstChrgDwnDataIdx;

#pragma DATA_SEG DEFAULT

/* when it's true, the trip record is valid, otherwise invalid */
boolean trpr_tripRcdDataValid;

boolean trpr_status;

_STATIC_ uint32 TRPR_CODE TrpR_ChksumCal(void);


void TRPR_CODE TrpR_Init(void)
{
  if (eep_Status == E_OK)
  {
    if (TrpR_ChksumCal() != trpr_tripRcdChksum)
    {
      trpr_PwrDwnDataIdx = 0;
      trpr_SlwChrgDwnDataIdx = 0;
      trpr_FstChrgDwnDataIdx = 0; 
      trpr_status = E_NOT_OK; 
    }else
    {
      trpr_tripRcdDataValid = TRUE;
      trpr_status = E_OK;
    }
  }else
  {
    trpr_PwrDwnDataIdx = 0;
    trpr_SlwChrgDwnDataIdx = 0;
    trpr_FstChrgDwnDataIdx = 0; 
    trpr_status = E_NOT_OK;     
  }  
}


void TRPR_CODE TrpR_DataSave(void)
{
  trpr_tripRcdChksum = TrpR_ChksumCal(); 
}

_STATIC_ uint32 TRPR_CODE TrpR_ChksumCal(void)
{
  uint16 index;
  uint32 chksum;
  uint8 * __far dataPtr;

  chksum = 0;
  dataPtr = (uint8 * __far)(TRIP_RECORD_STRT_ADDRESS); 
  for(index =0; index<TRIP_RECORD_SIZE; index++)
  {
    chksum += *dataPtr;
  }  
  
  return chksum;

}