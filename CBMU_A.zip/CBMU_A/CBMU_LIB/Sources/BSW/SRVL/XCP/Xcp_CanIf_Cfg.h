/*******************************************************************************
*
*  FILE
*     Xcp_CanIf_Cfg.h
*
*  DESCRIPTION
*     Configuration Header File of Can Interface for Xcp Module 
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

#ifndef _XCP_CANIF_CFG_H_
#define _XCP_CANIF_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "CanIf.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* size of CTO packets, bytes */
#define XCP_CAN_MAX_CTO                         8

/* size of DTO packets, bytes */
#define XCP_CAN_MAX_DTO                         8

/* CAN ID of CMD CTO packets */
/* Maybe not used, if Rx Indication is specfic for CMD_CTO */
#define XCP_CAN_ID_CMD_CTO                      0x18FFFEFF

/* CAN ID of RES/ERR/EV/SERV CTO packets */
#define XCP_CAN_ID_RES_CTO                      0x18FFFFFF

/* size of send FIFO for DAQ DTOs , number of DAQ DTO packets */
#define XCP_CAN_FIFO_SIZE_DAQ_DTO               20

/* CAN transport layer version */
#define XCP_TRANSPORT_LAYER_VERSION_CAN         0x01  /* version 1.0 */ 


extern const uint8 Xcp_TxHandle_C;

//#define XCP_TX_HANDLE                          5// CANIF_TX_XCP_STATIC_MSG
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/



#endif /* #ifndef _XCP_CANIF_CFG_H_ */