function CodeDefine() { 
this.def = new Array();
this.def["BINARYSEARCH_U16"] = {file: "soc_logic_c.html",line:50,type:"fcn"};
this.def["BINARYSEARCH_U8"] = {file: "soc_logic_c.html",line:82,type:"fcn"};
this.def["INTERPOLATE_S16_U8"] = {file: "soc_logic_c.html",line:114,type:"fcn"};
this.def["INTERPOLATE_S16_U16"] = {file: "soc_logic_c.html",line:144,type:"fcn"};
this.def["Look2D_S16_U16_U8"] = {file: "soc_logic_c.html",line:174,type:"fcn"};
this.def["mul_wide_s32"] = {file: "soc_logic_c.html",line:218,type:"fcn"};
this.def["mul_s32_s32_s32_sr28_zero"] = {file: "soc_logic_c.html",line:265,type:"fcn"};
this.def["mul_s32_s32_s32_sr14_zero"] = {file: "soc_logic_c.html",line:275,type:"fcn"};
this.def["div_repeat_s16s32"] = {file: "soc_logic_c.html",line:285,type:"fcn"};
this.def["div_nzp_repeat_u32"] = {file: "soc_logic_c.html",line:305,type:"fcn"};
this.def["mul_s32_s32_s32_sr35"] = {file: "soc_logic_c.html",line:327,type:"fcn"};
this.def["mul_s32_s32_s32_sr10"] = {file: "soc_logic_c.html",line:335,type:"fcn"};
this.def["div_s16s32_floor"] = {file: "soc_logic_c.html",line:344,type:"fcn"};
this.def["look1_is16lu16n16ts16D_c5pSCY2v"] = {file: "soc_logic_c.html",line:377,type:"fcn"};
this.def["look1_iu8lu16n16ts16Ds_FbqVATJM"] = {file: "soc_logic_c.html",line:446,type:"fcn"};
this.def["look1_is32lu16n16ts16D_UEUZuoen"] = {file: "soc_logic_c.html",line:516,type:"fcn"};
this.def["soc_logic_step"] = {file: "soc_logic_c.html",line:587,type:"fcn"};
this.def["soc_logic_initialize"] = {file: "soc_logic_c.html",line:760,type:"fcn"};
this.def["t_Percent2"] = {file: "soc_logic_types_h.html",line:41,type:"type"};
this.def["t_Voltage1"] = {file: "soc_logic_types_h.html",line:53,type:"type"};
this.def["t_Temp1"] = {file: "soc_logic_types_h.html",line:65,type:"type"};
this.def["Boolean"] = {file: "soc_logic_types_h.html",line:72,type:"type"};
this.def["t_Current1"] = {file: "soc_logic_types_h.html",line:84,type:"type"};
this.def["t_Capacity1"] = {file: "soc_logic_types_h.html",line:96,type:"type"};
this.def["t_Percent1"] = {file: "soc_logic_types_h.html",line:108,type:"type"};
this.def["t_Capacity3"] = {file: "soc_logic_types_h.html",line:120,type:"type"};
this.def["t_Time"] = {file: "soc_logic_types_h.html",line:132,type:"type"};
this.def["t_Factor1"] = {file: "soc_logic_types_h.html",line:144,type:"type"};
this.def["SOC_ST"] = {file: "soc_logic_Data_c.html",line:38,type:"var"};
this.def["soc_fac_ChargeDiffCurv"] = {file: "soc_logic_Data_c.html",line:39,type:"var"};
this.def["soc_fac_CurrentCurv"] = {file: "soc_logic_Data_c.html",line:42,type:"var"};
this.def["soc_fac_DisChargeDiffCurv"] = {file: "soc_logic_Data_c.html",line:45,type:"var"};
this.def["soc_fac_SocCurv"] = {file: "soc_logic_Data_c.html",line:48,type:"var"};
this.def["soc_fac_TempCurv"] = {file: "soc_logic_Data_c.html",line:51,type:"var"};
this.def["soc_i_CurrentCurvX"] = {file: "soc_logic_Data_c.html",line:54,type:"var"};
this.def["soc_ocv_TBL"] = {file: "soc_logic_Data_c.html",line:57,type:"var"};
this.def["soc_percent_MAP"] = {file: "soc_logic_Data_c.html",line:62,type:"var"};
this.def["soc_r_SocCurvX"] = {file: "soc_logic_Data_c.html",line:74,type:"var"};
this.def["soc_soc_ChargeDiffCurvX"] = {file: "soc_logic_Data_c.html",line:77,type:"var"};
this.def["soc_soc_DisChargeDiffCurvX"] = {file: "soc_logic_Data_c.html",line:80,type:"var"};
this.def["soc_t_TempCurvX"] = {file: "soc_logic_Data_c.html",line:83,type:"var"};
this.def["soc_temp_TBL"] = {file: "soc_logic_Data_c.html",line:86,type:"var"};
this.def["soc_capacity"] = {file: "soc_logic_Data_c.html",line:91,type:"var"};
this.def["soc_capacityChargeCorrect"] = {file: "soc_logic_Data_c.html",line:92,type:"var"};
this.def["soc_capacityCharging"] = {file: "soc_logic_Data_c.html",line:93,type:"var"};
this.def["soc_fullCapacity"] = {file: "soc_logic_Data_c.html",line:94,type:"var"};
this.def["soc_ocvCapacity"] = {file: "soc_logic_Data_c.html",line:95,type:"var"};
this.def["soc_ocvPercent"] = {file: "soc_logic_Data_c.html",line:96,type:"var"};
this.def["soc_percent"] = {file: "soc_logic_Data_c.html",line:97,type:"var"};
this.def["int8_T"] = {file: "rtwtypes_h.html",line:56,type:"type"};
this.def["uint8_T"] = {file: "rtwtypes_h.html",line:57,type:"type"};
this.def["int16_T"] = {file: "rtwtypes_h.html",line:58,type:"type"};
this.def["uint16_T"] = {file: "rtwtypes_h.html",line:59,type:"type"};
this.def["int32_T"] = {file: "rtwtypes_h.html",line:60,type:"type"};
this.def["uint32_T"] = {file: "rtwtypes_h.html",line:61,type:"type"};
this.def["boolean_T"] = {file: "rtwtypes_h.html",line:67,type:"type"};
this.def["int_T"] = {file: "rtwtypes_h.html",line:68,type:"type"};
this.def["uint_T"] = {file: "rtwtypes_h.html",line:69,type:"type"};
this.def["ulong_T"] = {file: "rtwtypes_h.html",line:70,type:"type"};
this.def["char_T"] = {file: "rtwtypes_h.html",line:71,type:"type"};
this.def["uchar_T"] = {file: "rtwtypes_h.html",line:72,type:"type"};
this.def["byte_T"] = {file: "rtwtypes_h.html",line:73,type:"type"};
this.def["pointer_T"] = {file: "rtwtypes_h.html",line:91,type:"type"};
}
CodeDefine.instance = new CodeDefine();
var testHarnessInfo = {OwnerFileName: "", HarnessOwner: "", HarnessName: "", IsTestHarness: "0"};
function Html2SrcLink() {
	this.html2SrcPath = new Array;
	this.html2Root = new Array;
	this.html2SrcPath["soc_logic_c.html"] = "../soc_logic.c";
	this.html2Root["soc_logic_c.html"] = "soc_logic_c.html";
	this.html2SrcPath["soc_logic_h.html"] = "../soc_logic.h";
	this.html2Root["soc_logic_h.html"] = "soc_logic_h.html";
	this.html2SrcPath["soc_logic_private_h.html"] = "../soc_logic_private.h";
	this.html2Root["soc_logic_private_h.html"] = "soc_logic_private_h.html";
	this.html2SrcPath["soc_logic_types_h.html"] = "../soc_logic_types.h";
	this.html2Root["soc_logic_types_h.html"] = "soc_logic_types_h.html";
	this.html2SrcPath["soc_logic_Data_c.html"] = "../soc_logic_Data.c";
	this.html2Root["soc_logic_Data_c.html"] = "soc_logic_Data_c.html";
	this.html2SrcPath["soc_logic_Data_h.html"] = "../soc_logic_Data.h";
	this.html2Root["soc_logic_Data_h.html"] = "soc_logic_Data_h.html";
	this.html2SrcPath["rtwtypes_h.html"] = "../rtwtypes.h";
	this.html2Root["rtwtypes_h.html"] = "rtwtypes_h.html";
	this.html2SrcPath["rtmodel_h.html"] = "../rtmodel.h";
	this.html2Root["rtmodel_h.html"] = "rtmodel_h.html";
	this.getLink2Src = function (htmlFileName) {
		 if (this.html2SrcPath[htmlFileName])
			 return this.html2SrcPath[htmlFileName];
		 else
			 return null;
	}
	this.getLinkFromRoot = function (htmlFileName) {
		 if (this.html2Root[htmlFileName])
			 return this.html2Root[htmlFileName];
		 else
			 return null;
	}
}
Html2SrcLink.instance = new Html2SrcLink();
var fileList = [
"soc_logic_c.html","soc_logic_h.html","soc_logic_private_h.html","soc_logic_types_h.html","soc_logic_Data_c.html","soc_logic_Data_h.html","rtwtypes_h.html","rtmodel_h.html"];
