/*******************************************************************************
*
*  FILE
*     Xcp_CanIf_Types.h
*
*  DESCRIPTION
*     Data Type Header File of Can Interface for Xcp Module 
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

#ifndef _XCP_CANIF_TYPES_H_
#define _XCP_CANIF_TYPES_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* structure of a CAN message */
typedef struct
{
  uint8 length;
  uint8  data[8];
}Xcp_CanMsgType;


/* structure of a buffer status for a CAN message buffer */
typedef struct
{
  uint8 size;
  uint8 rp;
  uint8 wp;
} Xcp_CanBufferStatusType;


/* structure of an XCP CMD CTO packet for CAN transport layer specific commands */
typedef union
{
  uint8 pid;
  uint8 data[1];

  /*********************************************************************
  * command TRANSPORT_LAYER_CMD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF2
  * 1             BYTE    sub command code
  * 2...          BYTE    parameters
  **********************************************************************/
  struct
  {
    uint8 pid;
    uint8 sub_pid;
    uint8 data[1];
  } transport_layer_cmd;

  /*********************************************************************
  * command GET_SLAVE_ID
  * position:     type:   description:
  * 0             BYTE    command code = 0xF2
  * 1             BYTE    sub command code = 0xFF
  * 2             BYTE    0x58 (ASCII = X)
  * 3             BYTE    0x43 (ASCII = C)
  * 4             BYTE    0x50 (ASCII = P)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   sub_code;
    uint8   x;
    uint8   c;
    uint8   p;
    uint8   mode;
  } get_slave_id;

  /*********************************************************************
  * command GET_DAQ_ID
  * position:     type:   description:
  * 0             BYTE    command code = 0xF2
  * 1             BYTE    sub command code = 0xFE
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   sub_code;
    uint16  daq;
  } get_daq_id;

  /*********************************************************************
  * command SET_DAQ_ID
  * position:     type:   description:
  * 0             BYTE    command code = 0xF2
  * 1             BYTE    sub command code = 0xFD
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4..7          DWORD   CAN identifier of DTO dedicated to list number
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   sub_code;
    uint16  daq;
    uint32  can_id;
  } set_daq_id;
} Xcp_CanCmdCtoType;


/* structure of an XCP RES CTO packet for CAN transport layer specific commands */
typedef union
{
  uint8 pid;
  uint8 data[1];

  /*********************************************************************
  * error message
  * negative response:
  * position:       type:   description:
  * 0               BYTE    packet ID : 0xFE
  * 1               BYTE    error code
  * 2..             BYTE    additional information
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   code;
    uint8   info[1];
  } error;

  /*********************************************************************
  * event message
  * position:     type:   description:
  * 0             BYTE    packet ID : 0xFD
  * 1             BYTE    event code
  * 2..           BYTE    additional information
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   code;
    uint8   info[1];
  } event;

  /*********************************************************************
  * command GET_SLAVE_ID
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID : 0xFF
  * 1             BYTE    0x58 (ASCII = X)
  * 2             BYTE    0x43 (ASCII = C)
  * 3             BYTE    0x50 (ASCII = P)
  * 4..7          DWORD   CAN identifier for CMD/STIM
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   x;
    uint8   c;
    uint8   p;
    uint32  can_id;
  } get_slave_id;

  /*********************************************************************
  * command GET_DAQ_ID
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID : 0xFF
  * 1             BYTE    CAN_ID_FIXED
  * 2,3           WORD    reserved
  * 4..7          DWORD   CAN identifier of DTO dedicated to list number
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   can_id_fixed;
    uint16  reserved;
    uint32  can_id;
  } get_daq_id;

  /*********************************************************************
  * command SET_DAQ_ID
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID : 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_daq_id;
} Xcp_CanResCTOType;

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/



#endif /* #ifndef _XCP_CANIF_TYPES_H_ */