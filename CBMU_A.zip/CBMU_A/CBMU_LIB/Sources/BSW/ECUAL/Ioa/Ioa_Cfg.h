/*******************************************************************************
*
*  FILE
*     Ioa_Cfg.h
*
*  DESCRIPTION
*     The Configuration Header file for IO abstraction
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR           
*    
*
*  VERSION           
*    0.01
*
*******************************************************************************/

#ifndef _IOA_CFG_H_
#define _IOA_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* Mapping to Frequency Input Sensor */


/* Mapping Sensor to HW (AD) */

#define IOA_AD_12VOUT_CH              13U
#define IOA_AD_CHRG_CH                6U
#define IOA_AD_BATT_VOLT_CH           14U
#define IOA_AD_VCC_CH                 7U
#define IOA_AD_SUPPLY_5V_CH           15U
#define IOA_AD_T15_CH                 16U
#define IOA_AD_GAS_CH                 18U
#define IOA_AD_GAS_PRESS_CH           19U

#define IOA_AD_12V_GAIN                  11U
#define IOA_AD_5V_GAIN                   2U

/* 2013-09-18, Add channel for C Sample */
#define IOA_AD_FC12V_CH             17U
#define IOA_AD_HVIL_CH              21U
#define IOA_AD_FCCC_CH              22U
#define IOA_AD_SCCC_CH              23U

                                                 
/* Mapping Sensor to HW (Switch) */
#define IOA_DI_OC_IN1_CH                    1U
#define IOA_DI_OC_IN1_PORT                  DIO_PORTK_DI
#define IOA_DI_OC_IN1_DIR                   DIO_PORTK_DIR

#define IOA_DI_OC_IN2_CH                    0U
#define IOA_DI_OC_IN2_PORT                  DIO_PORTK_DI
#define IOA_DI_OC_IN2_DIR                   DIO_PORTK_DIR


/* Mapping Vlv Feed Back to HW  */
#define IOA_DI_RELAY1_FDBK_CH               0U
#define IOA_DI_RELAY1_FDBK_PORT             DIO_PORTC_DI
#define IOA_DI_RELAY1_FDBK_DIR              DIO_PORTC_DIR

#define IOA_DI_RELAY2_FDBK_CH               1U
#define IOA_DI_RELAY2_FDBK_PORT             DIO_PORTC_DI
#define IOA_DI_RELAY2_FDBK_DIR              DIO_PORTC_DIR



/* Power Supply Control  */
#define IOA_DO_5V_CTL_CH                    4
#define IOA_DO_5V_CTL_PORT                  DIO_PORTD_DO
#define IOA_DO_5V_CTL_DIR                   DIO_PORTD_DIR

#define IOA_DO_12V_CTL_CH                   7
#define IOA_DO_12V_CTL_PORT                 DIO_PORTD_DO
#define IOA_DO_12V_CTL_DIR                  DIO_PORTD_DIR

#define IOA_DO_PWR_CTL_CH                   6
#define IOA_DO_PWR_CTL_PORT                 DIO_PORTD_DO
#define IOA_DO_PWR_CTL_DIR                  DIO_PORTD_DIR

#define IOA_DO_PING_SPLY_CTL_CH                    7
#define IOA_DO_PING_SPLY_CTL_PORT                  DIO_PORTP_DO
#define IOA_DO_PING_SPLY_CTL_DIR                   DIO_PORTP_DIR

#define IOA_DO_FC_SPLY_CTL_CH                    6
#define IOA_DO_FC_SPLY_CTL_PORT                  DIO_PORTP_DO
#define IOA_DO_FC_SPLY_CTL_DIR                   DIO_PORTP_DIR

#define IOA_DO_VEH_SPLY_CTL_CH                    5
#define IOA_DO_VEH_SPLY_CTL_PORT                  DIO_PORTP_DO
#define IOA_DO_VEH_SPLY_CTL_DIR                   DIO_PORTP_DIR

/* Lamp Control  */

#define IOA_DO_RED_LMP_CTL_CH               2
#define IOA_DO_RED_LMP_CTL_PORT             DIO_PORTC_DO
#define IOA_DO_RED_LMP_CTL_DIR              DIO_PORTC_DIR

#define IOA_DO_GR_LMP_CTL_CH                3
#define IOA_DO_GR_LMP_CTL_PORT              DIO_PORTC_DO
#define IOA_DO_GR_LMP_CTL_DIR               DIO_PORTC_DIR

/* Sync */
#define IOA_DO_SYNC_CTL_CH                0
#define IOA_DO_SYNC_CTL_PORT              DIO_PORTT_DO
#define IOA_DO_SYNC_CTL_DIR               DIO_PORTT_DIR

#define IOA_T15_ON_THRESHOLD           6888U
#define IOA_T15_OFF_THRESHOLD          1888U

#define IOA_T15_ON_CNT      3U
#define IOA_T15_OFF_CNT     3U


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/



#endif /* #ifndef _IOA_CFG_H_ */