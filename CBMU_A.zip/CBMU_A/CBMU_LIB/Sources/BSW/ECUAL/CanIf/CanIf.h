/*******************************************************************************
*
*  FILE                     
*     CanIf.h
*                     
*  DESCRIPTION             
*     Can interface header file 
*      
*                         
*  COPYRIGHT        
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

#ifndef _CANIF_H_
#define _CANIF_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "CanIf_Cfg.h"
#include "CanIf_Types.h"
#include "CanIf_Cbk.h"
#include "Can.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* Used for DET , Module and API ID */
/* Vendor ID. */
#define CANIF_VENDOR_ID           6666

/* Module ID  */
#define CANIF_MODULE_ID             60

/* Version number of the module */
#define CANIF_SW_MAJOR_VERSION    1
#define CANIF_SW_MINOR_VERSION    0
#define CANIF_SW_PATCH_VERSION    0

#define CANIF_INSTATNCE_ID              1

#define CANIF_API_TRANSMIT_ID           0
#define CANIF_API_DYNSETSTDID_ID        1
#define CANIF_API_CANCELTRANSMIT_ID     2
#define CANIF_API_SETCTLMODE            3
#define CANIF_API_GETCTLMODE            4

#define CANIF_E_PARAM_CONTROLLERID  15
#define CANIF_E_UNINIT              30
#define CANIF_E_POINTER             20
#define CANIF_E_PARAM_TXOBJ         21


#define CANIF_E_HANDLE_TOO_LARGE    0

#define CANIF_TXDYNOBJ_NA           ((PduIdType)0xFFFFFFFFU)

#define CANIF_IDTYPE_EXT            ((uint32)(0x00180000UL))
#define CANIF_IDTYPE_STD            ((uint32)(0x00000000UL)) 
                                     
/* status of transmit objects */
#define CANIF_BUFFER_FREE           ((uint8)0xFFU)   /* mark a transmit object is free */
#define CANIF_BUFFER_CANCEL         ((uint8)0xFEU)   /* mark a transmit object as canceled */                                     

#define CANIF_INVALID_SW_FILTER               0xFF

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

#define MK_EXTID(id)            ((uint32)((((uint32)(id) << 3) & (uint32)0xFFE00000) | (((uint32)(id) << 1) &  (uint32)0x0007FFFE) | (uint32)0x00180000))
#define MK_STDID(id)            ((uint32)(((uint32)(id)) << 21))

#define GET_ACT_EXTID(id)        ((uint32)(((id & 0xFFE00000) >> 3) | ((id & 0x0007FFFE) >> 1)))  
#define GET_ACT_STDID(id)        ((uint16)(id & 0xFFE00000) >> 21)

#define MK_TX_DLC(dlc)          ((uint8)((dlc) & 0x0F))

/* macros to fill struct elements RngMask and RngCode   */
#define MK_RX_RANGE_MASK(i)   (MK_EXTID(i) & (~0x00180000))
#define MK_RX_RANGE_CODE(i)   (MK_EXTID(i))

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
#if (CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS != 0)
  extern CONST(CanIf_StaticPduTxCfgType,TYPEDEF) CanIf_StaticPduTxCfg_C[CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS];
#endif

#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS != 0)
  extern CONST(CanIf_DynamicPduTxCfgType,TYPEDEF) CanIf_DynamicPduTxCfg_C[CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS];
#endif

#if (CANIF_INIT_NUMBER_OF_CANRXPDUIDS != 0)                           
  extern CONST(CanIf_PduRxCfgType,TYPEDEF) CanIf_PduRxCfg_C[CANIF_INIT_NUMBER_OF_CANRXPDUIDS];
  extern CONST(PduIdType,CANIF_CONST)   CanIf_RxStrtIdx_C[CAN_USED_NUM_OF_CHANNEL+1];
#endif /* #if (CANIF_INIT_NUMBER_OF_CANRXPDUIDS != 0)  */

#if (CANIF_INIT_NUMBER_OF_SW_FILTER != 0)  
  extern CONST(CanIf_SwFltType,CANIF_CONST) CanIf_SwFlt_C[CANIF_INIT_NUMBER_OF_SW_FILTER];
#endif

extern CONST(boolean,CANIF_CONST)CanIf_IdChkOrNot_C[CAN_USED_NUM_OF_CHANNEL];
extern CONST(Can_IdRngType,CANIF_CONST)CanIf_CntrlIdType_C[CAN_USED_NUM_OF_CHANNEL];

extern VAR(boolean, CANIF_VAR) canif_RxFlag;
extern VAR(boolean, CANIF_VAR) canif_TxFlag;
/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

extern uint8 CanErrorChannel;
extern FUNC(void,CANIF_CODE) CanIf_Init(void);

#if (CANIF_INIT_NUMBER_OF_CANTXPDUIDS != 0)
  extern FUNC(Std_ReturnType,CANIF_CODE) CanIf_Transmit(PduIdType CanTxPduId,const PduInfoType* PduInfoPtr);
  extern FUNC(void,CANIF_CODE) CanIf_CancelTransmit(PduIdType CanTxPduId);
  extern FUNC(void,CANIF_CODE) CanIf_ClearTxBuffer(Can_CntrlType controller);
#endif

#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS == 0)
  extern FUNC(void,CANIF_CODE) CanIf_SetDynamicTxId(PduIdType CanTxPduId, Can_IdType id);
#endif 

extern FUNC(Std_ReturnType,CANIF_CODE) CanIf_SetPduMode(Can_CntrlType controller, CanIf_PduSetModeType PduModeRequest);
extern FUNC(void,CANIF_CODE) CanIf_GetVersionInfo(Std_VersionInfoType* versioninfo);

/* Used for future extension */
extern FUNC(Std_ReturnType,CANIF_CODE) CanIf_GetControllerMode(Can_CntrlType ControllerId,CanIf_ControllerModeType* ControllerModePtr);
extern FUNC(Std_ReturnType,CANIF_CODE) CanIf_SetControllerMode(Can_CntrlType ControllerId,CanIf_ControllerModeType ControllerMode);

extern FUNC(Can_IdType,CANIF_CODE) CanIf_GetRxCanId(Can_CntrlType controller);

#endif /* #ifndef _CANIF_H_ */
