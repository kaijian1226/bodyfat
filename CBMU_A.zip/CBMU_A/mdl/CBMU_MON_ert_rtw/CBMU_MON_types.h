/*
 * File: CBMU_MON_types.h
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_CBMU_MON_types_h_
#define RTW_HEADER_CBMU_MON_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_t_Voltage1_
#define DEFINED_TYPEDEF_FOR_t_Voltage1_

typedef uint16_T t_Voltage1;
typedef cuint16_T ct_Voltage1;

#endif

#ifndef DEFINED_TYPEDEF_FOR_t_Temp1_
#define DEFINED_TYPEDEF_FOR_t_Temp1_

typedef uint8_T t_Temp1;
typedef cuint8_T ct_Temp1;

#endif

#ifndef DEFINED_TYPEDEF_FOR_t_Soc1_
#define DEFINED_TYPEDEF_FOR_t_Soc1_

typedef uint8_T t_Soc1;
typedef cuint8_T ct_Soc1;

#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_CBMU_MON RT_MODEL_CBMU_MON;

#endif                                 /* RTW_HEADER_CBMU_MON_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
