/*******************************************************************************
*
*  FILE
*     Can.h
*
*  DESCRIPTION
*     Can Driver header file
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/

#ifndef _CAN_H_
#define _CAN_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Can_Cfg.h"               /* dependend configuration of the driver.*/
                                   /* configuration file.                   */

#include "Can_Reg.h"               /* CAN driver header                     */
#include "Can_Types.h"
#include "Mcu.h"


/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Vendor ID. */
#define CAN_VENDOR_ID           6666

/* Module ID  */
#define CAN_MODULE_ID           80

/* Version number of the module */
#define CAN_SW_MAJOR_VERSION    1
#define CAN_SW_MINOR_VERSION    0
#define CAN_SW_PATCH_VERSION    0

#define CAN_INSTATNCE_ID              1

#define CAN_API_TRANSMIT_ID           0
#define CAN_API_INITCONTRLER_ID       1
#define CAN_API_INIT_ID               2
#define CAN_API_WRITE_ID              6
#define CAN_API_DISGLBINT_ID          3


#define CAN_E_PARAM_POINTER       0x01
#define CAN_E_PARAM_HANDLE        0x02
#define CAN_E_PARAM_DLC           0x03
#define CAN_E_PARAM_CONTROLLER    0x04
#define CAN_E_UNINIT              0x05
#define CAN_E_TRANSITION          0x06
#define CAN_E_DATALOST            0x07
#define CAN_E_TXBUSY              0x08
#define CAN_E_INT_TOO_OFTEN       0x09

#define CAN_NO_TX_HW_HDL            ((uint8)0xFFU) 


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

#define Can_TxIsHWObjFree(controller)   (((CANTFLG & (0x01)) != 0) ? TRUE : FALSE)

#define CanIdDWord(rxStruct)              ((uint32)*((uint32*)((rxStruct) -> pChipMsgObj)))

#define CanRxActualExtId(rxStruct)        ((uint32)(((CanIdDWord(rxStruct) & 0xFFE00000) >> 3) | ((CanIdDWord(rxStruct) & 0x0007FFFE) >> 1)))
#define CanRxActualStdId(rxStruct)        ((uint16)(CanHiIdWord(rxStruct) & 0xFFE0) >> 5)

#define CanRxActualDLC(rxStruct)          ((*(uint8*)((uint8*)(rxStruct) -> pChipMsgObj + 0xC)) & 0x0F)

#define CanHiIdByte(rxStruct)             ((uint8)*((uint8*)((rxStruct) -> pChipMsgObj)))
#define CanMidHiIdByte(rxStruct)          ((uint8)*((uint8*)(((rxStruct) -> pChipMsgObj) + 1)))
#define CanMidLoIdByte(rxStruct)          ((uint8)*((uint8*)(((rxStruct) -> pChipMsgObj) + 2)))
#define CanLoIdByte(rxStruct)             ((uint8)*((uint8*)(((rxStruct) -> pChipMsgObj) + 3)))


#define CanRxActualIdExtHi(rxStruct)      ((uint8)  (CanHiIdByte(rxStruct) >> 3))
#define CanRxActualIdExtMidHi(rxStruct)   ((uint8)(((CanHiIdWord(rxStruct) & 0x07E0) >> 3) | ((CanHiIdWord(rxStruct) & 0x0007) >> 1)))
#define CanRxActualIdExtMidLo(rxStruct)   ((uint8) ((CanMidHiIdByte(rxStruct) << 7)        | (CanMidLoIdByte(rxStruct) >> 1)))
#define CanRxActualIdExtLo(rxStruct)      ((uint8) ((CanMidLoIdByte(rxStruct) << 7)        | (CanLoIdByte(rxStruct) >> 1)))


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern VAR(Can_RxInfoType,CAN_VAR) can_RxInfo[CAN_USED_NUM_OF_CHANNEL];
/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,CAN_CODE) Can_InitController(Can_CntrlType controller);
extern FUNC(void,CAN_CODE) Can_Init(void);
extern FUNC(Can_ReturnType,CAN_CODE) Can_Write(Can_HwHandleType Hth,const Can_PduType* PduInfo);
extern FUNC(Can_ReturnType,CAN_CODE) Can_SetControllerMode(Can_CntrlType controller, Can_StateTransitionType Transition);
extern FUNC(Std_ReturnType,CAN_CODE) Can_CancelTransmit(Can_CntrlType controller);
extern FUNC(void,CAN_CODE) Can_GetVersionInfo(Std_VersionInfoType* versioninfo);

#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"

extern FUNC(void,CAN_CODE_NEAR) Can_DisableControllerInterrupts(Can_CntrlType controller);
extern FUNC(void,CAN_CODE_NEAR) Can_EnableControllerInterrupts(Can_CntrlType controller);

#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"

#if (CAN_TX_PROCESSING == CAN_INTERRUPT)
  #define Can_MainFunction_Write()
#else
  extern FUNC(void,CAN_CODE) Can_MainFunction_Write(void);
#endif

#if (CAN_RX_PROCESSING == CAN_INTERRUPT)
  #define Can_MainFunction_Read()
#else
  extern FUNC(void,CAN_CODE) Can_MainFunction_Read(void);
#endif

#if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT)
  #define Can_MainFunction_BusOff()
#else
  extern FUNC(void,CAN_CODE) Can_MainFunction_BusOff(void);
#endif

#if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT)
  #define Can_MainFunction_WakeUp()
#else
  extern FUNC(void,CAN_CODE) Can_MainFunction_WakeUp(void);
#endif

extern FUNC(void,CAN_CODE) Can_BusOffRecovery(Can_CntrlType controller);

#if (CAN_TX_PROCESSING == CAN_INTERRUPT)
extern FUNC(void,CAN_CODE) Can_TxIrqHandler(Can_CntrlType controller);
#endif

#if (CAN_RX_PROCESSING == CAN_INTERRUPT)
extern FUNC(void,CAN_CODE) Can_RxIrqHandler(Can_CntrlType controller);
#endif

#if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT)
extern FUNC(void,CAN_CODE) Can_ErrorIrqHandler(Can_CntrlType controller);
#endif

#if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT)
extern FUNC(void,CAN_CODE) Can_WakeUpIrqHandler(Can_CntrlType controller);
#endif


#endif /* #ifndef _CAN_H_ */


