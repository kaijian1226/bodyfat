#include "SetErr.h"
extern uint8 Dem_SetError(uint16 errIndex , uint8 errsStatus)
{
	
}


extern uint8 Dem_GetError(uint8 EventId)
{
	
}