/*******************************************************************************
*
*  FILE
*     Wdg.h
*
*  DESCRIPTION
*      Wdg module header file 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.1
*
*******************************************************************************/

#ifndef _WDG_H_
#define _WDG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Wdg_Cfg.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Vendor ID. */
#define WDG_VENDOR_ID           6666

/* Module ID */
#define WDG_MODULE_ID           102

/* Version number of the module */
#define WDG_SW_MAJOR_VERSION    1
#define WDG_SW_MINOR_VERSION    0
#define WDG_SW_PATCH_VERSION    0


/* Registers */
#define WDG_COPCTL           (*(volatile uint8*) 0x0000003C)
#define WDG_ARMCOP           (*(volatile uint8*) 0x0000003F) 

#if (WDG_RTI_STOP_IN_DEBUG_MODE == STD_ON)
  #define WDG_SETTING                   (0x40|WDG_TRIGGER_PERIOD)
#else
  #define WDG_SETTING                   (WDG_TRIGGER_PERIOD)
#endif                                     
/*******************************************************************************
* Macros                                                                
*******************************************************************************/


#define  Wdg_Init()                 {WDG_COPCTL=WDG_SETTING;}
#define  Wdg_Trigger()              {WDG_ARMCOP=0x55; WDG_ARMCOP=0xAA;}
/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/ 

#endif/* #ifndef _WDG_H_ */


