/*******************************************************************************
*
*  FILE
*     Can.c
*
*  DESCRIPTION
*     The CAN Driver   CAN�����ײ����ü��������ú���
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Can.h"
#include "CanIf_Cbk.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* parameter for HWLOOPTimer */
#define CAN_INIT_REQ_LOOP_TIMER         ((uint8)0x01)
#define CAN_SLEEP_LOOP_TIMER            ((uint8)0x02)
#define CAN_WKUP_LOOP_TIMER             ((uint8)0x03)
#define CAN_EXIT_LOOP_TIMER             ((uint8)0x04)

/* CAN Driver States */
#define CAN_UNINIT                      ((uint8)0x00)
#define CAN_READY                       ((uint8)0x01)

/* CAN Controller States */
#define CAN_C_UNINIT                    ((uint8)0x00)
#define CAN_C_STOPPED                   ((uint8)0x01)
#define CAN_C_STARTED                   ((uint8)0x02)
#define CAN_C_SLEEP                     ((uint8)0x03)

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
VAR(Can_RxInfoType,CAN_VAR) can_RxInfo[CAN_USED_NUM_OF_CHANNEL];

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
/* Driver State machine*/
_STATIC_ VAR(uint8,CAN_VAR) can_DrvState;
/* CAN Controller States machine*/
_STATIC_ VAR(uint8,CAN_VAR) can_CntrlState[CAN_USED_NUM_OF_CHANNEL];

_STATIC_ VAR(uint16,CAN_VAR) can_loopInitReqTimer;
_STATIC_ VAR(uint16,CAN_VAR) can_loopSleepTimer;
_STATIC_ VAR(uint16,CAN_VAR) can_loopWkUpTimer;
_STATIC_ VAR(uint16,CAN_VAR) can_loopExitInitTimer; 

_STATIC_ VAR(uint8,CAN_VAR) can_loopInitReqAbortCnt;
_STATIC_ VAR(uint8,CAN_VAR) can_loopSleepAbortCnt;
_STATIC_ VAR(uint8,CAN_VAR) can_loopWkUpAbortCnt;
_STATIC_ VAR(uint8,CAN_VAR) can_loopExitInitAbortCnt;

/* CanIf_Transmit needs to know if the Tx Irq is disabled */
_STATIC_ VAR(uint16,CAN_VAR) can_CanIrqDisabled[CAN_USED_NUM_OF_CHANNEL];

_STATIC_ VAR(Can_IrqRegType,CAN_VAR) can_CanIrqOldStatus[CAN_USED_NUM_OF_CHANNEL];

_STATIC_ VAR(uint8,CAN_VAR) can_ControllerIntCnt[CAN_USED_NUM_OF_CHANNEL];



 #if ((CAN_TX_PROCESSING == CAN_POLLING) || (CAN_RX_PROCESSING == CAN_POLLING) || \
     (CAN_WAKEUP_PROCESSING == CAN_POLLING) || (CAN_BUSOFF_PROCESSING == CAN_POLLING))

  _STATIC_ VAR(boolean,CAN_VAR) can_PollingTaskActive[CAN_USED_NUM_OF_CHANNEL];

#endif  

#if (CAN_TX_PROCESSING == CAN_POLLING) 
   _STATIC_ VAR(boolean,CAN_VAR) can_TxActive[CAN_USED_NUM_OF_CHANNEL];
#endif
/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ FUNC(void,CAN_CODE)   Can_HwLoopTimerStart(uint8 source);
_STATIC_ FUNC(uint16,CAN_CODE) Can_HwLoopTimerLoop (uint8 source);
_STATIC_ FUNC(void,CAN_CODE)   Can_HwLoopTimerEnd (uint8 source);
_STATIC_ FUNC(void,CAN_CODE)   Can_Read(Can_CntrlType controller);

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Can_RxIrqHandler
* CALLED BY:        Can_RxInterruptx
* PRECONDITIONS:    Rx interrupt enabled
* INPUT PARAMETERS: CAN channel on which the interrupt was fired
* RETURN VALUES:    Void
* DESCRIPTION:      call indication function or range pre-copy functions  
*******************************************************************************/
#if (CAN_RX_PROCESSING == CAN_INTERRUPT)
FUNC(void,CAN_CODE) Can_RxIrqHandler(Can_CntrlType controller)  //�ó���Ϊ��ѵ��ʽ,û���õ��ж�
{
  Can_Read(controller);    
}
#endif /* #if (CAN_RX_PROCESSING == CAN_INTERRUPT) */

/*******************************************************************************
* NAME:             Can_TxIrqHandler
* CALLED BY:        Can_TxInterruptx
* PRECONDITIONS:    Tx interrupt enabled
* INPUT PARAMETERS: CAN channel on which the interrupt was fired
* RETURN VALUES:    Void
* DESCRIPTION:      simply call confirmation function
*******************************************************************************/
#if (CAN_TX_PROCESSING == CAN_INTERRUPT)
FUNC(void,CAN_CODE) Can_TxIrqHandler(Can_CntrlType controller)
{   
   CTIER &= (uint8)(~CANTFLG) & (0x07); /* deactivate Tx interrupt */
   CanIf_TxConfirmation(controller);

}
#endif /* #if (CAN_TX_PROCESSING == CAN_INTERRUPT) */

/*******************************************************************************
* NAME:             Can_ErrorIrqHandler
* CALLED BY:        Can_ErrorInterruptx
* PRECONDITIONS:    Error interrupt enabled
* INPUT PARAMETERS: CAN channel on which the interrupt was fired
* RETURN VALUES:    Void
* DESCRIPTION:      check bus status register, call application specific bus 
*                   off function
*******************************************************************************/
FUNC(void,CAN_CODE) Can_ErrorIrqHandler(Can_CntrlType controller)
{
  /* check for status register (bus error)--*/
  if( ((CRFLG & CAN_BOFFIF) == CAN_BOFFIF) && ((CRFLG & CAN_CSCIF) == CAN_CSCIF) )
  {
    CanIf_ControllerBusOff(controller);           
  }
  CRFLG = (CAN_OVRIF | CAN_CSCIF); /* clear overrunflag and status changed */
}

/*******************************************************************************
* NAME:             Can_WakeUpIrqHandler
* CALLED BY:        Can_WakeupInterruptx
* PRECONDITIONS:    Wakeup interrupt enabled
* INPUT PARAMETERS: CAN channel on which the interrupt was fired
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,CAN_CODE) Can_WakeUpIrqHandler(Can_CntrlType controller)
{
  (void)Can_SetControllerMode(controller,CAN_T_WAKEUP);
  CRFLG = CAN_WUPIF; /* acknowledge wakeup flag */
  CanIf_ControllerWakeup(controller);  
}

/*******************************************************************************
* NAME:             Can_Write
* CALLED BY:        CanIf_Transmit
* PRECONDITIONS:    Can driver must be initialized
* INPUT PARAMETERS: Can_CntrlType controller
*                   const Can_PduType* PduInfo: Pdu Information to be sent
* RETURN VALUES:    CAN_OK
*                   CAN_NOT_OK
*                   CAN_BUSY                        
* DESCRIPTION:      If the CAN driver is not ready for send, the application
*                   decide, whether the transmit request is repeated or not.
*******************************************************************************/
FUNC(Can_ReturnType,CAN_CODE) Can_Write(Can_CntrlType controller,const Can_PduType* PduInfo)   
{
  sint8_least index;
  uint8*   CanMemCopySrcPtr;
  
#if(CAN_DEV_ERROR_DETECT == STD_ON)  
  if (controller >= CAN_USED_NUM_OF_CHANNEL)
  {
    Det_ReportError(CAN_MODULE_ID,controller,CAN_API_WRITE_ID,CAN_E_PARAM_CONTROLLER); 
    return (CAN_NOT_OK);
  }    
#endif /* #if(CAN_DEV_ERROR_DETECT == STD_ON) */

  /* check if HW is busy*/
  if (Can_TxIsHWObjFree(controller) == FALSE)
  {
    return (CAN_BUSY);
  }
    
  /* Select the free Tx Buffer */
  CTBSEL = 0x01;


  /* set id and dlc  */
  CAN_TX_MAILBOX_BASIS_ADR(controller) -> Id   = PduInfo -> id;
  CAN_TX_MAILBOX_BASIS_ADR(controller) -> Dlc = PduInfo -> length;
  
  /* copy data  */
  if (PduInfo -> length != 0)
  {
    CanMemCopySrcPtr = PduInfo -> sdu;  

    if ( CanMemCopySrcPtr != NULL_PTR )   /* copy if buffer exists */
    {
      uint8* pDestData;
      uint8* pSrcData;

      pDestData = (uint8*)&(CAN_TX_MAILBOX_BASIS_ADR(controller) -> DataFld[0]);
      pSrcData  = (uint8*)CanMemCopySrcPtr;
      for(index = (PduInfo -> length - 1); index >= 0; index--)
      {
        pDestData[index] = pSrcData[index];
      }
    }
  }

  /* Start Transmission */
  CANTFLG = CTBSEL; /* transmit message    */

#if (CAN_TX_PROCESSING == CAN_INTERRUPT)
  /* in case of disabled Tx Irq the request needs to be stored in the old status variable */
  if(can_CanIrqDisabled[controller] == TRUE)
  {
    can_CanIrqOldStatus[controller].oldCanCTIER |= CTBSEL; /* enable Tx interrupt */
  }
  else
  {
    CTIER |= CTBSEL; /* enable All Tx interrupt */
  }
#else
   can_TxActive[controller] = TRUE; 
#endif
 
  return (CAN_OK);   

}

/*******************************************************************************
* NAME:             Can_MainFunction_Read
* CALLED BY:        Application
* PRECONDITIONS:    - Can driver must be initialized
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      - cyclic Task,
*                   - polling Rx BasicCAN objects
*******************************************************************************/
#if (CAN_RX_PROCESSING == CAN_POLLING) 
FUNC(void,CAN_CODE) Can_MainFunction_Read(void)
{
  Can_CntrlType controller;
  
  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)
  {
    if (can_PollingTaskActive[controller] == FALSE)
    {      
      can_PollingTaskActive[controller] = TRUE;
      
      /* check for dedicated indication pending */
      if(CAN_RXF == (CRFLG & CAN_RXF)) /* something received? */
      {
        Can_DisableControllerInterrupts(controller);
        Can_Read(controller);
        Can_EnableControllerInterrupts(controller);
      }
      
      can_PollingTaskActive[controller] = FALSE;
    }
  }
} 
#endif /* #if (CAN_RX_PROCESSING == CAN_POLLING)   */

/*******************************************************************************
* NAME:             Can_MainFunction_Write
* CALLED BY:        Application
* PRECONDITIONS:    - Can driver must be initialized
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      - cyclic Task,
*                   - polling Tx objects
*******************************************************************************/
#if (CAN_TX_PROCESSING == CAN_POLLING) //$$$��ѵ�ķ�ʽ����
FUNC(void,CAN_CODE) Can_MainFunction_Write(void)
{
  uint8_least controller;

  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)   //����3��CANͨ��
  {
    
    if (can_PollingTaskActive[controller] == FALSE)
    {
      can_PollingTaskActive[controller] = TRUE;
             
      /*  polling Tx objects */
      if ((Can_TxIsHWObjFree(controller) == TRUE)&&(can_TxActive[controller] == TRUE))
      {
        Can_DisableControllerInterrupts(controller);
        can_TxActive[controller] = FALSE;
        /* do tx confirmation */
        CanIf_TxConfirmation(controller);
        Can_EnableControllerInterrupts(controller);
      }

      can_PollingTaskActive[controller] = FALSE; 
    }
  }
}
#endif /* #if (CAN_TX_PROCESSING == CAN_POLLING) */

/*******************************************************************************
* NAME:             Can_MainFunction_Wakeup
* CALLED BY:        Application
* PRECONDITIONS:    - Can driver must be initialized
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      polling the wakeup event
*******************************************************************************/
#if (CAN_WAKEUP_PROCESSING == CAN_POLLING)
FUNC(void,CAN_CODE) Can_MainFunction_WakeUp(void)
{
  

  uint8_least controller;

  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)
  {
    
    if (can_PollingTaskActive[controller] == FALSE)
    {
      can_PollingTaskActive[controller] = TRUE;
             
      if((CRFLG & CAN_WUPIF) == CAN_WUPIF)
      {
        Can_WakeUpIrqHandler(controller);    
      }

      can_PollingTaskActive[controller] = FALSE; 
    }
  }
}
#endif /* #if (CAN_WAKEUP_PROCESSING == CAN_POLLING) */

/*******************************************************************************
* NAME:             Can_MainFunction_BusOff
* CALLED BY:        Application
* PRECONDITIONS:    - Can driver must be initialized
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      polling the bus off event 
*******************************************************************************/
#if (CAN_BUSOFF_PROCESSING == CAN_POLLING)
FUNC(void,CAN_CODE) Can_MainFunction_BusOff(void)
{
  uint8_least controller;

  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)
  {
    
    if (can_PollingTaskActive[controller] == FALSE)
    {
      can_PollingTaskActive[controller] = TRUE;          
      Can_ErrorIrqHandler(controller);
      can_PollingTaskActive[controller] = FALSE; 
    }
  }
}
#endif /* #if (CAN_BUSOFF_PROCESSING == CAN_POLLING) */
 

/*******************************************************************************
* NAME:             Can_DisableControllerInterrupts
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      disables CAN interrupts and stores old interrupt status
*******************************************************************************/
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"

FUNC(void,CAN_CODE_NEAR) Can_DisableControllerInterrupts(Can_CntrlType controller)
{
  
  Can_IrqRegType localInterruptOldFlag;
  /* local variable must reside on stack or registerbank, switched */
  /* in interrupt level                                            */
  /* disable global interrupt                                      */
  
  #if(CAN_DEV_ERROR_DETECT == STD_ON) 
 
  if (controller >= CAN_USED_NUM_OF_CHANNEL)
  {
    Det_ReportError(CAN_MODULE_ID,controller,CAN_API_WRITE_ID,CAN_E_PARAM_CONTROLLER); 
  }
    
  #endif /* #if(CAN_DEV_ERROR_DETECT == STD_ON) */
    

  SuspendAllInterrupts();
  
  if (can_ControllerIntCnt[controller] == (sint16)0)  /* if 0 then save old interrupt status */
  {        
    localInterruptOldFlag.oldCanCRIER = CRIER;
    localInterruptOldFlag.oldCanCTIER = CTIER;
    CRIER = (uint8)0;
    CTIER = (uint8)0;
    can_CanIrqDisabled[controller] = TRUE;
    can_CanIrqOldStatus[controller] = localInterruptOldFlag;            /*lint !e530 */
  }
  can_ControllerIntCnt[controller]++;               /* common for all platforms */
  ResumeAllInterrupts();

}

#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h" 
/*******************************************************************************
* NAME:             Can_EnableControllerInterrupts
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      restores the old interrupt status of the CAN interrupt
*******************************************************************************/
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"

FUNC(void,CAN_CODE_NEAR) Can_EnableControllerInterrupts(Can_CntrlType controller)
{
  
  
  #if(CAN_DEV_ERROR_DETECT == STD_ON) 
 
  if (controller >= CAN_USED_NUM_OF_CHANNEL)
  {
    Det_ReportError(CAN_MODULE_ID,controller,CAN_API_WRITE_ID,CAN_E_PARAM_CONTROLLER); 
  }
    
  #endif /* #if(CAN_DEV_ERROR_DETECT == STD_ON) */

  SuspendAllInterrupts();
  /* restore CAN interrupt */
  can_ControllerIntCnt[controller]--;

  if (can_ControllerIntCnt[controller] == 0)         /* restore interrupt if canGlobalInterruptCounter=0 */
  {      
    CRIER = can_CanIrqOldStatus[controller].oldCanCRIER;
    CTIER = can_CanIrqOldStatus[controller].oldCanCTIER;
    can_CanIrqDisabled[controller] = FALSE;
  }
  ResumeAllInterrupts();
}

#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"

/*******************************************************************************
* NAME:             Can_InitController
* CALLED BY:        CanIf_Init
* PRECONDITIONS:    
* INPUT PARAMETERS: Can_CntrlType controller
* RETURN VALUES:    void
* DESCRIPTION:      initialization of chip-hardware
*******************************************************************************/
FUNC(void,CAN_CODE) Can_InitController(Can_CntrlType controller)
{

  uint8 tmpCRIER;

#if(CAN_DEV_ERROR_DETECT == STD_ON) 
  if (controller >= CAN_USED_NUM_OF_CHANNEL)
  {
    Det_ReportError(CAN_MODULE_ID,CAN_INSTATNCE_ID,CAN_API_TRANSMIT_ID,CAN_E_PARAM_CONTROLLER);      
  }
#endif /* #if(CAN_DEV_ERROR_DETECT == STD_ON) */

  
  /* Request CAN to stop mode */
  if (Can_SetControllerMode(controller,CAN_T_STOP) != CAN_OK)
  {
    return;
  } 
  
  CTL1  = Can_InitObject_C[controller].CanInitCTL1;
  CBTR0 = Can_InitObject_C[controller].CanInitCBTR0;     /* set baudrate */
  CBTR1 = Can_InitObject_C[controller].CanInitCBTR1;
  CIDAC = Can_InitObject_C[controller].CanInitCIDAC;     /* set filter mode */
  
  /* set acceptance filter registers */
  CIDAR0 = Can_InitObject_C[controller].CanInitCIDAR0;
  CIDAR1 = Can_InitObject_C[controller].CanInitCIDAR1;
  CIDAR2 = Can_InitObject_C[controller].CanInitCIDAR2;
  CIDAR3 = Can_InitObject_C[controller].CanInitCIDAR3;
  CIDMR0 = Can_InitObject_C[controller].CanInitCIDMR0;
  CIDMR1 = Can_InitObject_C[controller].CanInitCIDMR1;
  CIDMR2 = Can_InitObject_C[controller].CanInitCIDMR2;
  CIDMR3 = Can_InitObject_C[controller].CanInitCIDMR3;
  CIDAR4 = Can_InitObject_C[controller].CanInitCIDAR4;
  CIDAR5 = Can_InitObject_C[controller].CanInitCIDAR5;
  CIDAR6 = Can_InitObject_C[controller].CanInitCIDAR6;
  CIDAR7 = Can_InitObject_C[controller].CanInitCIDAR7;
  CIDMR4 = Can_InitObject_C[controller].CanInitCIDMR4;
  CIDMR5 = Can_InitObject_C[controller].CanInitCIDMR5;
  CIDMR6 = Can_InitObject_C[controller].CanInitCIDMR6;
  CIDMR7 = Can_InitObject_C[controller].CanInitCIDMR7;
  
  /* disable CAN interrupts? */
  if(can_CanIrqDisabled[controller] == TRUE) 
  {
    /* disable all Tx interrupts */
    can_CanIrqOldStatus[controller].oldCanCTIER = (uint8)0x00; 
  }
  else
  {
    /* disable all Tx interrupts */
    CTIER = (uint8)0x00; 
  }
 
  (void)Can_SetControllerMode(controller,CAN_T_START);  

  tmpCRIER = (uint8)0x00;

#if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT)  
  /* at least we want BusOff notification */
  tmpCRIER |= (uint8)(CAN_CSCIE | CAN_TSTAT1E); 
#else
  tmpCRIER |= (uint8)CAN_TSTAT1E;
#endif  

#if (CAN_RX_PROCESSING == CAN_INTERRUPT)
  tmpCRIER |= CAN_RXE; /* enable Rx interrupt */
#endif

#if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT)
  tmpCRIER |= CAN_WUPIE; /* enable wakeup interrupt */    
#endif
  
  if(can_CanIrqDisabled[controller] == TRUE) /* disable CAN interrupts? */
  {
    can_CanIrqOldStatus[controller].oldCanCRIER = tmpCRIER;
  }
  else
  {
    CRIER = tmpCRIER;
  }
} 

/*******************************************************************************
* NAME:             Can_Init
* CALLED BY:        Application
* PRECONDITIONS:    this function must be called by the application before
*                   any other CAN driver function 
*                   Interrupts must be disabled
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      Initialization of the CAN driver status and global variables
*******************************************************************************/
FUNC(void,CAN_CODE) Can_Init(void)
{ 
  Can_CntrlType controller;
  
#if(CAN_DEV_ERROR_DETECT == STD_ON) 
  if (can_DrvState != CAN_UNINIT)
  {
    Det_ReportError(CAN_MODULE_ID,CAN_INSTATNCE_ID,CAN_API_INIT_ID,CAN_E_TRANSITION);      
  }

  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)
  {    
    if (can_CntrlState[controller] != CAN_C_UNINIT)
    {
      Det_ReportError(CAN_MODULE_ID,CAN_INSTATNCE_ID,CAN_API_INIT_ID,CAN_E_TRANSITION);      
    } 
  }
#endif /* #if(CAN_DEV_ERROR_DETECT == STD_ON) */

  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)
  {
    can_CanIrqDisabled[controller] = FALSE;
    can_ControllerIntCnt[controller] = 0; 
    
#if ((CAN_TX_PROCESSING == CAN_POLLING) || (CAN_RX_PROCESSING == CAN_POLLING) ||   \
     (CAN_WAKEUP_PROCESSING == CAN_POLLING) || (CAN_BUSOFF_PROCESSING == CAN_POLLING))
    
    can_PollingTaskActive[controller] = FALSE;
    
#endif
    
    /* Initialize can_RxInfo */
    can_RxInfo[controller].pChipMsgObj = (volatile uint8 *)CAN_RX_MAILBOX_BASIS_ADR(controller);
    can_RxInfo[controller].pChipData = (volatile uint8 *)&(CAN_RX_MAILBOX_BASIS_ADR(controller) -> DataFld[0]);
   
    can_CntrlState[controller] = CAN_C_STOPPED;
  }
  
  can_DrvState = CAN_READY;
}
/*******************************************************************************
* NAME:             Can_SetControllerMode
* CALLED BY:        
* PRECONDITIONS:    Wakeup interrupt enabled
* INPUT PARAMETERS: Can_CntrlType controller
*                   Can_StateTransitionType Transition: Transition type
* RETURN VALUES:    CAN_OK, if success
*                   CAN_NOT_OK, if function failed
*                   CAN_WAKEUP, if wakeup
* DESCRIPTION:      
*******************************************************************************/
FUNC(Can_ReturnType,CAN_CODE) Can_SetControllerMode(Can_CntrlType controller, Can_StateTransitionType Transition)
{
  Can_ReturnType canReturnCode;
  switch (Transition)
  {
/* Can start */ 
    case (CAN_T_START): 
    {
       /* leave init mode */
      CTL0 &= (uint8)~CAN_INITRQ;
      CTL0 = (uint8)(Can_InitObject_C[controller].CanInitCTL0 & ((uint8)~CAN_INITRQ));
      
      Can_HwLoopTimerStart(CAN_EXIT_LOOP_TIMER);
      while(((CTL1 & CAN_INITAK) == CAN_INITAK) && Can_HwLoopTimerLoop(CAN_EXIT_LOOP_TIMER))
      {
        ; /* wait until init mode is left */
      }
      Can_HwLoopTimerEnd(CAN_EXIT_LOOP_TIMER);

      
      if (CAN_INITAK != (CTL1 & CAN_INITAK))
      {
        can_CntrlState[controller] = CAN_C_STARTED;
        canReturnCode = CAN_OK;
      }else
      {
        canReturnCode = CAN_NOT_OK;
      }   
    }
    break;

/* Can stop */   
    case (CAN_T_STOP):
    {
        /* request init mode */
      CTL0 = CAN_INITRQ;
      Can_HwLoopTimerStart(CAN_INIT_REQ_LOOP_TIMER);
      while( ((CTL1 & CAN_INITAK) != CAN_INITAK) && Can_HwLoopTimerLoop(CAN_INIT_REQ_LOOP_TIMER) )
      { 
        ; /* wait while not in initmode */
      } 
      Can_HwLoopTimerEnd(CAN_INIT_REQ_LOOP_TIMER);

      if(CAN_INITAK == (CTL1 & CAN_INITAK))
      {
        canReturnCode = CAN_OK;
        can_CntrlState[controller] = CAN_C_STOPPED;
      }
      else
      {
        canReturnCode = CAN_NOT_OK;
      }
    }
    break;

/* Can sleep */        
    case (CAN_T_SLEEP):
    {
      
      CTL0 |= CAN_SLPRQ;    /* set sleep request bit */
      Can_HwLoopTimerStart(CAN_SLEEP_LOOP_TIMER);
      while(((CTL0 & CAN_SLPRQ) == CAN_SLPRQ) && ((CTL1 & CAN_SLPAK) != CAN_SLPAK) && Can_HwLoopTimerLoop(CAN_SLEEP_LOOP_TIMER))
      {
        ; /* wait until CAN controller sets the sleep acknowledge flag */
      } 
      Can_HwLoopTimerEnd(CAN_SLEEP_LOOP_TIMER);
    
      if(CAN_SLPAK == (CTL1 & CAN_SLPAK)) /* check if sleep request was successful */
      {
        can_CntrlState[controller] = CAN_C_SLEEP;
        canReturnCode = CAN_OK;
      }
      else
      {
        canReturnCode = CAN_NOT_OK;
      }   
    }
    break;

/* Can wakeup */    
    case (CAN_T_WAKEUP):
    {
      CTL0 &= (uint8)~CAN_SLPRQ; /* clear sleep request */

      Can_HwLoopTimerStart(CAN_WKUP_LOOP_TIMER);
      while(((CTL1 & CAN_SLPAK) == CAN_SLPAK) && Can_HwLoopTimerLoop(CAN_WKUP_LOOP_TIMER))
      { 
        ; /* wait until CAN controller is awake */
      } 
      Can_HwLoopTimerEnd(CAN_WKUP_LOOP_TIMER);

      if(CAN_SLPAK == (CTL1 & CAN_SLPAK))
      {
        canReturnCode = CAN_NOT_OK; /* CAN controller still sleeping */
      }
      else
      {
        can_CntrlState[controller] = CAN_C_STOPPED;
        canReturnCode = CAN_WAKEUP;
      }
    }
    break;
    
    default: 
    {
      canReturnCode = CAN_NOT_OK;
    }
    break;
  }
  return canReturnCode;

}
/*******************************************************************************
* NAME:             Can_CancelTransmit
* CALLED BY:        
* PRECONDITIONS:    
* INPUT PARAMETERS: Can_CntrlType controller
* RETURN VALUES:    Can_HwHandleType
* DESCRIPTION:      
*******************************************************************************/
FUNC(Std_ReturnType,CAN_CODE) Can_CancelTransmit(Can_CntrlType controller)
{
  if (Can_TxIsHWObjFree(0) == FALSE) 
  {
    CTARQ = 0x01;
    return E_OK;
  }else
  {
    return E_NOT_OK;
  }
}

/****************************************************************************
* NAME:             Can_GetVersionInfo
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Std_VersionInfoType *versioninfo
* RETURN VALUES:    void
* DESCRIPTION:      Service to get version information     
****************************************************************************/
FUNC(void,CAN_CODE) Can_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
  versioninfo->vendorID = CAN_VENDOR_ID;
  versioninfo->moduleID = CAN_MODULE_ID;
  versioninfo->sw_major_version = CAN_SW_MAJOR_VERSION;
  versioninfo->sw_minor_version = CAN_SW_MINOR_VERSION;
  versioninfo->sw_patch_version = CAN_SW_PATCH_VERSION;
} 

/*******************************************************************************
* NAME:             Can_BusOffRecovery
* CALLED BY:        
* PRECONDITIONS:    
* INPUT PARAMETERS: Can_CntrlType controller
* RETURN VALUES:    void 
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,CAN_CODE) Can_BusOffRecovery(Can_CntrlType controller)
{
  CMISC |= CAN_BOHOLD;    
}
/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Can_Read
* CALLED BY:        Can_MainFunction_Read() or Rx Interrupt
* PRECONDITIONS:    - Can driver must be initialized
* INPUT PARAMETERS: uint16 controller: internal can channel number
* RETURN VALUES:    void
* DESCRIPTION:      
*******************************************************************************/
_STATIC_ FUNC(void,CAN_CODE) Can_Read(Can_CntrlType controller)
{
  Can_RxInfoType    *pCanRxInfoStruct; 
  Can_IdType        canId;
  Can_DlcType       canDlc;
  uint8*            dataPtr;
  
  pCanRxInfoStruct =  &can_RxInfo[controller];
  canId = CanIdDWord(pCanRxInfoStruct);
  canDlc = CanRxActualDLC(pCanRxInfoStruct); 
  dataPtr = pCanRxInfoStruct->pChipData;
  
  CanIf_RxIndication(controller,canId,canDlc,dataPtr);
  CRFLG = CAN_RXF; /* clear receive pending flag */  
}

/*******************************************************************************
* NAME:             Can_HwLoopTimerStart
* CALLED BY:        Can_SetControllerMode
* PRECONDITIONS:
* INPUT PARAMETERS: uint8 source: src timer required
* RETURN VALUES:    Void
* DESCRIPTION:      Start Timer of Hw loop 
*******************************************************************************/
_STATIC_ FUNC(void,CAN_CODE) Can_HwLoopTimerStart(uint8 source)
{
  switch (source)
  {
    case CAN_INIT_REQ_LOOP_TIMER:
    {
      can_loopInitReqTimer = CAN_INIT_REQ_TO_LOOP; 
    }
    break;
    
    case CAN_SLEEP_LOOP_TIMER:
    {
      can_loopSleepTimer = CAN_SLEEP_TO_LOOP; 
    }
    break;
    
    case CAN_WKUP_LOOP_TIMER:
    {
      can_loopWkUpTimer = CAN_WKUP_TO_LOOP;
    }
    break;

    case CAN_EXIT_LOOP_TIMER:
    {
        can_loopExitInitTimer =  CAN_EXIT_INIT_TO_LOOP;
    }
    break;

    default:
    break;
   }
}

/*******************************************************************************
* NAME:             Can_HwLoopTimerLoop
* CALLED BY:        Can_SetControllerMode
* PRECONDITIONS:
* INPUT PARAMETERS: uint8 source: src timer required
* RETURN VALUES:    Void
* DESCRIPTION:      tick the timer 
*******************************************************************************/
_STATIC_ FUNC(uint16,CAN_CODE) Can_HwLoopTimerLoop (uint8 source)
{
  switch (source)
  {
    case CAN_INIT_REQ_LOOP_TIMER:
    {
      can_loopInitReqTimer--;
      return (can_loopInitReqTimer); 
    }
    break;
    
    case CAN_SLEEP_LOOP_TIMER:
    {
      can_loopSleepTimer--;
      return (can_loopSleepTimer);
    }
    break;
    
    case CAN_WKUP_LOOP_TIMER:
    {
      can_loopWkUpTimer--;
      return ((can_loopWkUpTimer));
    }
    break;
    
    case CAN_EXIT_LOOP_TIMER:
    {
      can_loopExitInitTimer--;
      return ((can_loopExitInitTimer));
    }
    break;
    
    default:
    break;
   }
}

/*******************************************************************************
* NAME:             Can_HwLoopTimerEnd
* CALLED BY:        Can_SetControllerMode
* PRECONDITIONS:
* INPUT PARAMETERS: uint8 source: src timer required
* RETURN VALUES:    Void
* DESCRIPTION:      check the timer, if expired add the cnt
*******************************************************************************/
_STATIC_ FUNC(void,CAN_CODE) Can_HwLoopTimerEnd (uint8 source)
{
  switch (source)
  {
    case CAN_INIT_REQ_LOOP_TIMER:
    {
      if (can_loopInitReqTimer == 0)
      {
        can_loopInitReqAbortCnt++;
      }
    }
    break;
    
    case CAN_SLEEP_LOOP_TIMER:
    {
      if (can_loopSleepTimer == 0)
      {
        can_loopSleepAbortCnt++;
      }
    }
    break;
    
    case CAN_WKUP_LOOP_TIMER:
    {
      if (can_loopWkUpTimer == 0)
      {
        can_loopWkUpAbortCnt++;
      }
    }
    break;
    
    case CAN_EXIT_LOOP_TIMER:
    {
      if (can_loopExitInitTimer==0)
      {
        can_loopExitInitAbortCnt++;
      }
    }
    break;
    
    default:
    break;
   }
}











