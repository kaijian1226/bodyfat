/*
 * File: PvMon.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PvMon.h"

/* Include model header file for global data */
#include "BMS_MON.h"
#include "BMS_MON_private.h"

/* Named constants for Chart: '<S323>/SRC_Check' */
#define BMS_MON_IN_Defect_f            ((uint8_T)1U)
#define BMS_MON_IN_NO_ACTIVE_CHILD_j   ((uint8_T)0U)
#define BMS_MON_IN_NO_Defect_j         ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Confimed_i ((uint8_T)1U)
#define BMS_MON_IN_SRC_High_Healing_g  ((uint8_T)3U)
#define BMS_MON_IN_SRC_Low_Confimed_p  ((uint8_T)4U)
#define BMS_MON_IN_SRC_Low_Debouncing_o ((uint8_T)5U)
#define BMS_MON_IN_SRC_Low_Healing_ak  ((uint8_T)6U)
#define BMS_MO_IN_SRC_High_Debouncing_d ((uint8_T)2U)

/* Named constants for Chart: '<S332>/SRC_Check' */
#define BMS_MON_IN_Defect_d            ((uint8_T)1U)
#define BMS_MON_IN_NO_ACTIVE_CHILD_l   ((uint8_T)0U)
#define BMS_MON_IN_NO_Defect_n         ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Confimed_iq ((uint8_T)1U)
#define BMS_MON_IN_SRC_High_Healing_j  ((uint8_T)3U)
#define BMS_MON_IN_SRC_Low_Confimed_ib ((uint8_T)4U)
#define BMS_MON_IN_SRC_Low_Debouncing_b ((uint8_T)5U)
#define BMS_MON_IN_SRC_Low_Healing_as  ((uint8_T)6U)
#define BMS_MO_IN_SRC_High_Debouncing_m ((uint8_T)2U)

/* Initial conditions for atomic system: '<S322>/SRC_Check' */
void BMS_MON_SRC_Check_m_Init(rtB_SRC_Check_BMS_MON_m *localB,
  rtDW_SRC_Check_BMS_MON_c *localDW)
{
  /* InitializeConditions for Chart: '<S323>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_j;
  localDW->bitsForTID0.is_active_c31_BMS_MON = 0U;
  localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_NO_ACTIVE_CHILD_j;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
  localB->SRC_Tmp_Def_Flag = 0U;
}

/* Output and update for atomic system: '<S322>/SRC_Check' */
void BMS_MON_SRC_Check_fe(boolean_T rtu_Clear_Def_Flag, t_Voltage4 rtu_Sig_Volt,
  t_Voltage4 rtu_Par_SRC_H_Threshold, t_Voltage4 rtu_Par_SRC_L_Threshold,
  uint16_T rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_m *localB, rtDW_SRC_Check_BMS_MON_c *
  localDW)
{
  /* Chart: '<S323>/SRC_Check' */
  /* Gateway: Task_100ms/HVCU/HVCU_Mon/PvMon/PV_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_100ms/HVCU/HVCU_Mon/PvMon/PV_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c31_BMS_MON == 0U) {
    /* Entry: Task_100ms/HVCU/HVCU_Mon/PvMon/PV_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c31_BMS_MON = 1U;

    /* Entry Internal: Task_100ms/HVCU/HVCU_Mon/PvMon/PV_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S324>:9' */
    localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_NO_Defect_j;

    /* Entry 'NO_Defect': '<S324>:1' */
    localB->SRC_Def_Status = SRC_NON_DEF;
  } else if (localDW->bitsForTID0.is_c31_BMS_MON == BMS_MON_IN_Defect_f) {
    /* During 'Defect': '<S324>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S324>:22' */
      /* Exit Internal 'Defect': '<S324>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MO_IN_SRC_High_Debouncing_d:
        /* Exit 'SRC_High_Debouncing': '<S324>:4' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_j;
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_o:
        /* Exit 'SRC_Low_Debouncing': '<S324>:3' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_j;
        break;

       default:
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_j;
        break;
      }

      localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_NO_Defect_j;

      /* Entry 'NO_Defect': '<S324>:1' */
      localB->SRC_Def_Status = SRC_NON_DEF;
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Confimed_i:
        /* During 'SRC_High_Confimed': '<S324>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S324>:13' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Healing_g;

          /* Entry 'SRC_High_Healing': '<S324>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MO_IN_SRC_High_Debouncing_d:
        /* During 'SRC_High_Debouncing': '<S324>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S324>:12' */
          /* Exit 'SRC_High_Debouncing': '<S324>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_j;
          localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_NO_Defect_j;

          /* Entry 'NO_Defect': '<S324>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S324>:14' */
          /* Exit 'SRC_High_Debouncing': '<S324>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_i;

          /* Entry 'SRC_High_Confimed': '<S324>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Healing_g:
        /* During 'SRC_High_Healing': '<S324>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S324>:15' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_j;
          localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_NO_Defect_j;

          /* Entry 'NO_Defect': '<S324>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S324>:17' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_i;

          /* Entry 'SRC_High_Confimed': '<S324>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Confimed_p:
        /* During 'SRC_Low_Confimed': '<S324>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S324>:18' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Healing_ak;

          /* Entry 'SRC_Low_Healing': '<S324>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_o:
        /* During 'SRC_Low_Debouncing': '<S324>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S324>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S324>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_j;
          localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_NO_Defect_j;

          /* Entry 'NO_Defect': '<S324>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S324>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S324>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_p;

          /* Entry 'SRC_Low_Confimed': '<S324>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S324>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S324>:20' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_j;
          localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_NO_Defect_j;

          /* Entry 'NO_Defect': '<S324>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S324>:19' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_p;

          /* Entry 'SRC_Low_Confimed': '<S324>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    /* During 'NO_Defect': '<S324>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S324>:10' */
      localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_Defect_f;
      localDW->bitsForTID0.is_Defect = BMS_MO_IN_SRC_High_Debouncing_d;

      /* Entry 'SRC_High_Debouncing': '<S324>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
      localB->SRC_Tmp_Def_Flag = 1U;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S324>:11' */
        localDW->bitsForTID0.is_c31_BMS_MON = BMS_MON_IN_Defect_f;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Debouncing_o;

        /* Entry 'SRC_Low_Debouncing': '<S324>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
        localB->SRC_Tmp_Def_Flag = 1U;
      }
    }
  }

  /* End of Chart: '<S323>/SRC_Check' */
}

/*
 * Output and update for action system:
 *    '<S315>/If Abnormal Action Subsystem'
 *    '<S315>/If Normal Action Subsystem'
 */
void BMS_IfAbnormalActionSubsystem_d(boolean_T rtu_In1, t_Voltage4 rtu_In2,
  uint8_T rtu_In3, boolean_T *rty_Out1, t_Voltage4 *rty_Out2, uint8_T *rty_Out3)
{
  /* Inport: '<S318>/In1' */
  *rty_Out1 = rtu_In1;

  /* Inport: '<S318>/In2' */
  *rty_Out2 = rtu_In2;

  /* Inport: '<S318>/In3' */
  *rty_Out3 = rtu_In3;
}

/* Initial conditions for atomic system: '<S331>/SRC_Check' */
void BMS_MON_SRC_Check_j_Init(rtB_SRC_Check_BMS_MON_g *localB,
  rtDW_SRC_Check_BMS_MON_f *localDW)
{
  /* InitializeConditions for Chart: '<S332>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_l;
  localDW->bitsForTID0.is_active_c53_BMS_MON = 0U;
  localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_NO_ACTIVE_CHILD_l;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
  localB->SRC_Tmp_Def_Flag = 0U;
}

/* Output and update for atomic system: '<S331>/SRC_Check' */
void BMS_MON_SRC_Check_i(boolean_T rtu_Clear_Def_Flag, t_Voltage4 rtu_Sig_Volt,
  t_Voltage4 rtu_Par_SRC_H_Threshold, t_Voltage4 rtu_Par_SRC_L_Threshold,
  uint16_T rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, t_Voltage4 rtu_Par_SRC_H_HealThreshold, t_Voltage4
  rtu_Par_SRC_L_HealThreshold, rtB_SRC_Check_BMS_MON_g *localB,
  rtDW_SRC_Check_BMS_MON_f *localDW)
{
  /* Chart: '<S332>/SRC_Check' */
  /* Gateway: Task_100ms/HVCU/HVCU_Mon/PvMon/PV_SRC_Check2/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_100ms/HVCU/HVCU_Mon/PvMon/PV_SRC_Check2/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c53_BMS_MON == 0U) {
    /* Entry: Task_100ms/HVCU/HVCU_Mon/PvMon/PV_SRC_Check2/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c53_BMS_MON = 1U;

    /* Entry Internal: Task_100ms/HVCU/HVCU_Mon/PvMon/PV_SRC_Check2/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S333>:9' */
    localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_NO_Defect_n;

    /* Entry 'NO_Defect': '<S333>:1' */
    localB->SRC_Def_Status = SRC_NON_DEF;
  } else if (localDW->bitsForTID0.is_c53_BMS_MON == BMS_MON_IN_Defect_d) {
    /* During 'Defect': '<S333>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S333>:22' */
      /* Exit Internal 'Defect': '<S333>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MO_IN_SRC_High_Debouncing_m:
        /* Exit 'SRC_High_Debouncing': '<S333>:4' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_l;
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_b:
        /* Exit 'SRC_Low_Debouncing': '<S333>:3' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_l;
        break;

       default:
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_l;
        break;
      }

      localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_NO_Defect_n;

      /* Entry 'NO_Defect': '<S333>:1' */
      localB->SRC_Def_Status = SRC_NON_DEF;
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Confimed_iq:
        /* During 'SRC_High_Confimed': '<S333>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_HealThreshold) {
          /* Transition: '<S333>:13' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Healing_j;

          /* Entry 'SRC_High_Healing': '<S333>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MO_IN_SRC_High_Debouncing_m:
        /* During 'SRC_High_Debouncing': '<S333>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_HealThreshold) {
          /* Transition: '<S333>:12' */
          /* Exit 'SRC_High_Debouncing': '<S333>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_l;
          localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_NO_Defect_n;

          /* Entry 'NO_Defect': '<S333>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S333>:14' */
          /* Exit 'SRC_High_Debouncing': '<S333>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_iq;

          /* Entry 'SRC_High_Confimed': '<S333>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Healing_j:
        /* During 'SRC_High_Healing': '<S333>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S333>:15' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_l;
          localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_NO_Defect_n;

          /* Entry 'NO_Defect': '<S333>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S333>:17' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_iq;

          /* Entry 'SRC_High_Confimed': '<S333>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Confimed_ib:
        /* During 'SRC_Low_Confimed': '<S333>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_HealThreshold) {
          /* Transition: '<S333>:18' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Healing_as;

          /* Entry 'SRC_Low_Healing': '<S333>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_b:
        /* During 'SRC_Low_Debouncing': '<S333>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_HealThreshold) {
          /* Transition: '<S333>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S333>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_l;
          localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_NO_Defect_n;

          /* Entry 'NO_Defect': '<S333>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S333>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S333>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_ib;

          /* Entry 'SRC_Low_Confimed': '<S333>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S333>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S333>:20' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_l;
          localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_NO_Defect_n;

          /* Entry 'NO_Defect': '<S333>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S333>:19' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_ib;

          /* Entry 'SRC_Low_Confimed': '<S333>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    /* During 'NO_Defect': '<S333>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S333>:10' */
      localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_Defect_d;
      localDW->bitsForTID0.is_Defect = BMS_MO_IN_SRC_High_Debouncing_m;

      /* Entry 'SRC_High_Debouncing': '<S333>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
      localB->SRC_Tmp_Def_Flag = 1U;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S333>:11' */
        localDW->bitsForTID0.is_c53_BMS_MON = BMS_MON_IN_Defect_d;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Debouncing_b;

        /* Entry 'SRC_Low_Debouncing': '<S333>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
        localB->SRC_Tmp_Def_Flag = 1U;
      }
    }
  }

  /* End of Chart: '<S332>/SRC_Check' */
}

/* Initial conditions for atomic system: '<S227>/PvMon' */
void BMS_MON_PvMon_Init(void)
{
  /* InitializeConditions for Atomic SubSystem: '<S322>/SRC_Check' */
  BMS_MON_SRC_Check_m_Init(&BMS_MON_B.SRC_Check_fe, &BMS_MON_DWork.SRC_Check_fe);

  /* End of InitializeConditions for SubSystem: '<S322>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S331>/SRC_Check' */
  BMS_MON_SRC_Check_j_Init(&BMS_MON_B.SRC_Check_iq, &BMS_MON_DWork.SRC_Check_iq);

  /* End of InitializeConditions for SubSystem: '<S331>/SRC_Check' */
}

/* Output and update for atomic system: '<S227>/PvMon' */
void BMS_MON_PvMon(void)
{
  uint8_T rtb_Switch;
  boolean_T rtb_Merge;
  t_Voltage4 rtb_Merge1_dq;

  /* Outputs for Atomic SubSystem: '<S322>/SRC_Check' */

  /* Constant: '<S322>/Constant1' incorporates:
   *  Constant: '<S322>/Constant2'
   *  Constant: '<S322>/Constant3'
   *  Constant: '<S322>/Constant4'
   *  Constant: '<S322>/Constant5'
   *  Constant: '<S322>/Constant6'
   *  Constant: '<S322>/Constant7'
   *  Constant: '<S322>/Constant8'
   *  Inport: '<Root>/com_BattVolt'
   */
  BMS_MON_SRC_Check_fe(false, com_BattVolt, PackVoltSigASRCHigh,
                       PackVoltSigASRCLow, BmsSigASRCHighPosDeb,
                       BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                       BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_fe,
                       &BMS_MON_DWork.SRC_Check_fe);

  /* End of Outputs for SubSystem: '<S322>/SRC_Check' */

  /* Outputs for Atomic SubSystem: '<S331>/SRC_Check' */

  /* Constant: '<S331>/Constant1' incorporates:
   *  Constant: '<S331>/Constant10'
   *  Constant: '<S331>/Constant2'
   *  Constant: '<S331>/Constant3'
   *  Constant: '<S331>/Constant4'
   *  Constant: '<S331>/Constant5'
   *  Constant: '<S331>/Constant6'
   *  Constant: '<S331>/Constant7'
   *  Constant: '<S331>/Constant8'
   *  Constant: '<S331>/Constant9'
   *  Inport: '<Root>/com_BattVolt'
   */
  BMS_MON_SRC_Check_i(false, com_BattVolt, PackVoltSigASRCTooHigh,
                      PackVoltSigASRCTooLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, PackVoltSigASRCTooHighHeal,
                      PackVoltSigASRCTooLowHeal, &BMS_MON_B.SRC_Check_iq,
                      &BMS_MON_DWork.SRC_Check_iq);

  /* End of Outputs for SubSystem: '<S331>/SRC_Check' */

  /* SwitchCase: '<S325>/Switch Case' incorporates:
   *  Constant: '<S325>/Constant1'
   *  Constant: '<S325>/Constant2'
   *  Constant: '<S325>/Constant4'
   */
  switch ((int32_T)BMS_MON_B.SRC_Check_iq.SRC_Def_Status) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S325>/Switch Case Action Subsystem' incorporates:
     *  ActionPort: '<S328>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_m);

    /* End of Outputs for SubSystem: '<S325>/Switch Case Action Subsystem' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S325>/Switch Case Action Subsystem1' incorporates:
     *  ActionPort: '<S329>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_m);

    /* End of Outputs for SubSystem: '<S325>/Switch Case Action Subsystem1' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S325>/Switch Case Action Subsystem2' incorporates:
     *  ActionPort: '<S330>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_m);

    /* End of Outputs for SubSystem: '<S325>/Switch Case Action Subsystem2' */
    break;
  }

  /* End of SwitchCase: '<S325>/Switch Case' */

  /* Switch: '<S316>/Switch2' incorporates:
   *  Constant: '<S316>/Constant4'
   *  DataStoreRead: '<S316>/Data Store Read1'
   *  Logic: '<S316>/Logical Operator3'
   */
  if (!(BMS_MON_DWork.Dem_stClear_n != 0)) {
    rtb_Switch = BMS_MON_B.Merge_m;
  } else {
    rtb_Switch = SRC_NON_DEF;
  }

  /* End of Switch: '<S316>/Switch2' */

  /* Switch: '<S316>/Switch' incorporates:
   *  Constant: '<S316>/Constant4'
   *  RelationalOperator: '<S316>/Relational Operator1'
   */
  if (rtb_Switch != SRC_NON_DEF) {
    rtb_Switch = BMS_MON_B.Merge_m;
  } else {
    rtb_Switch = SRC_NON_DEF;
  }

  /* End of Switch: '<S316>/Switch' */

  /* If: '<S315>/If Abnormal' incorporates:
   *  DataStoreRead: '<S317>/Data Store Read1'
   *  DataStoreRead: '<S321>/Data Store Read'
   *  DataStoreRead: '<S327>/Data Store Read'
   *  Inport: '<Root>/com_BattVolt'
   *  Logic: '<S317>/Logical Operator3'
   *  Logic: '<S321>/Logical Operator1'
   *  Logic: '<S321>/Logical Operator4'
   *  Logic: '<S327>/Logical Operator1'
   *  Logic: '<S327>/Logical Operator4'
   *  Switch: '<S317>/Switch2'
   */
  if (rtb_Switch != 0) {
    /* Outputs for IfAction SubSystem: '<S315>/If Abnormal Action Subsystem' incorporates:
     *  ActionPort: '<S318>/Action Port'
     */
    BMS_IfAbnormalActionSubsystem_d((BMS_MON_B.SRC_Check_iq.SRC_Tmp_Def_Flag !=
      0) && (!(BMS_MON_DWork.Dem_stClear_n != 0)), com_BattVolt, rtb_Switch,
      &rtb_Merge, &rtb_Merge1_dq, &Pv_St);

    /* End of Outputs for SubSystem: '<S315>/If Abnormal Action Subsystem' */
  } else {
    if (!(BMS_MON_DWork.Dem_stClear_k != 0)) {
      /* Switch: '<S317>/Switch2' */
      rtb_Switch = BMS_MON_B.SRC_Check_fe.SRC_Def_Status;
    } else {
      /* Switch: '<S317>/Switch2' incorporates:
       *  Constant: '<S317>/Constant4'
       */
      rtb_Switch = SRC_NON_DEF;
    }

    /* Switch: '<S317>/Switch' incorporates:
     *  Constant: '<S317>/Constant4'
     *  RelationalOperator: '<S317>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch = BMS_MON_B.SRC_Check_fe.SRC_Def_Status;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S317>/Switch' */

    /* Outputs for IfAction SubSystem: '<S315>/If Normal Action Subsystem' incorporates:
     *  ActionPort: '<S319>/Action Port'
     */
    BMS_IfAbnormalActionSubsystem_d((BMS_MON_B.SRC_Check_fe.SRC_Tmp_Def_Flag !=
      0) && (!(BMS_MON_DWork.Dem_stClear_k != 0)), com_BattVolt, rtb_Switch,
      &rtb_Merge, &rtb_Merge1_dq, &Pv_St);

    /* End of Outputs for SubSystem: '<S315>/If Normal Action Subsystem' */
  }

  /* End of If: '<S315>/If Abnormal' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
