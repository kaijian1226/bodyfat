/*******************************************************************************
*
*  FILE
*     Xcp_CanIf.c
*
*  DESCRIPTION
*    Source Code Of CAN interface for Xcp module   
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "CanIf.h"
#include "Xcp.h"


/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ VAR(boolean,XCP_VAR) xcp_CanMsgRxFlag;
_STATIC_ VAR(uint8,XCP_VAR) xcp_CanData[8];



_STATIC_ VAR(Xcp_CanMsgType,XCP_VAR) xcp_CanDaqDtoBuffer[XCP_CAN_FIFO_SIZE_DAQ_DTO];
_STATIC_ VAR(Xcp_CanMsgType,XCP_VAR) xcp_CanResCtoBuffer;


_STATIC_ VAR(Xcp_CanBufferStatusType,XCP_VAR) xcp_CanResCtoBufferSt;
_STATIC_ VAR(Xcp_CanBufferStatusType,XCP_VAR) xcp_CanDaqDtoBufferSt;

_STATIC_ VAR(PduInfoType,XCP_VAR) xcp_CanIfPduInfo;


/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_CanIfSend(void);
_STATIC_ FUNC(Std_ReturnType,XCP_CODE) Xcp_CanIfSendCanMsg(uint8* XCP_VAR data, uint8 length);

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Xcp_CanIfInit
* CALLED BY:        Xcp_Init
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      initializes the CAN transport layer of the  XCP   
*******************************************************************************/
FUNC(void,XCP_CODE) Xcp_CanIfInit(void)
{

  xcp_CanMsgRxFlag = FALSE;
  /* initialize all buffer statuses */

  xcp_CanResCtoBufferSt.size = 0;

  xcp_CanDaqDtoBufferSt.size = 0;
  xcp_CanDaqDtoBufferSt.rp = 0;
  xcp_CanDaqDtoBufferSt.wp = 0;
}

/*******************************************************************************
* NAME:             Xcp_CanIfRxIndication  - Call back Function
* CALLED BY:        CanIf
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Rx Indication   
*******************************************************************************/
FUNC(void,TYPEDEF) Xcp_CanIfRxIndication(PduIdType CanRxPduId, const PduInfoType* PduInfoPtr)
{
  xcp_CanMsgRxFlag = TRUE;
  
  /* copy databytes from the CAN buffer */
  MemCpy2((void*)xcp_CanData,(void*)PduInfoPtr->SduDataPtr,PduInfoPtr->SduLength);  
}

/*******************************************************************************
* NAME:             Xcp_CanIfTxConfirmation  - Call back Function
* CALLED BY:        CanIf
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Tx    
*******************************************************************************/
FUNC(void,XCP_CODE) Xcp_CanIfTxConfirmation(PduIdType CanTxPduId)
{
  Xcp_CanIfSend(); 
}

/*******************************************************************************
* NAME:             Xcp_CanIfGetReceivePtr
* CALLED BY:        Xcp_Background
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    uint8* : pointer to received data buffer
* DESCRIPTION:      poll the CAN for a new message    
*******************************************************************************/
FUNC(uint8*,XCP_CODE) Xcp_CanIfGetReceivePtr(void)
{
  /* poll for a new CAN message */
  if (xcp_CanMsgRxFlag == TRUE)
  {
    xcp_CanMsgRxFlag = FALSE;
    
    /* a new CAN message has been received, check for valid XCP packet */
    return (xcp_CanData);
  }
  else
  {
    /* no CAN message received, return NULL */
    return (NULL_PTR);
  }
}

/*******************************************************************************
* NAME:             Xcp_CanIfGetResCtoPtr
* CALLED BY:        Xcp_CmdProcessor,Xcp_BlockUpload
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    uint8* : pointer to RES/ERR/EV/SERV CTO or NULL
* DESCRIPTION:      returns a pointer to the buffer for RES/ERR/EV/SERV CTO packets   
*******************************************************************************/
FUNC(uint8*,XCP_CODE) Xcp_CanIfGetResCtoPtr(void)
{
  /* if RES/ERR/EV/SERV CTO buffer is empty, return pointer else NULL */
  if (xcp_CanResCtoBufferSt.size == 0)
  {
    return (xcp_CanResCtoBuffer.data);
  }
  else
  {
    return (NULL_PTR);
  }
}

/*******************************************************************************
* NAME:             Xcp_CanIfSendResCto
* CALLED BY:        Xcp_CmdProcessor, Xcp_BlockUpload
* PRECONDITIONS:
* INPUT PARAMETERS: uint8 length: length of RES/ERR/EV/SERV CTO packet
* RETURN VALUES:    Void
* DESCRIPTION:      sends a RES/ERR/EV/SERV CTO packet.  
*******************************************************************************/
FUNC(void,XCP_CODE) Xcp_CanIfSendResCto(uint8 length)
{
  SuspendAllInterrupts();

  /* try to send RES/ERR/EV/SERV CTO packet */
  if (Xcp_CanIfSendCanMsg(xcp_CanResCtoBuffer.data, length) != E_OK)
  {
    /* sending was not successful, RES/ERR/EV/SERV CTO packet will be kept in the buffer */
    xcp_CanResCtoBuffer.length = length;
    xcp_CanResCtoBufferSt.size = 1;
  }

  ResumeAllInterrupts();
}

/*******************************************************************************
* NAME:             Xcp_CanIfGetDaqDtoPtr
* CALLED BY:        Xcp_Service
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      returns a pointer to the next free space in the send buffer
*                    (FIFO) for DAQ DTO packets 
*******************************************************************************/
FUNC(uint8* XCP_VAR,XCP_CODE) Xcp_CanIfGetDaqDtoPtr(void)
{
  /* if DAQ DTO buffer is not full, return pointer else NULL */
  if (xcp_CanDaqDtoBufferSt.size < XCP_CAN_FIFO_SIZE_DAQ_DTO)
  {
    return (xcp_CanDaqDtoBuffer[xcp_CanDaqDtoBufferSt.wp].data);
  }
  else
  {
    return (NULL_PTR);
  }
}

/*******************************************************************************
* NAME:             Xcp_CanIfSendDaqDto
* CALLED BY:        Xcp_Service
* PRECONDITIONS:
* INPUT PARAMETERS: uint16 length : length of DAQ DTO
* RETURN VALUES:    Void
* DESCRIPTION:      sends a DAQ DTO.
*******************************************************************************/
FUNC(void,XCP_CODE) Xcp_CanIfSendDaqDto(uint16 length)
{
  /* flag if sending of DAQ packet was successful (default: not successful) */
  boolean send_flag;
  
  send_flag = FALSE;  

  /* send DAQ DTO only, if no former DAQ DTO packet is pending */
  if (xcp_CanDaqDtoBufferSt.size == 0)
  {
    /* try to send DAQ DTO packet */
    if (Xcp_CanIfSendCanMsg( xcp_CanDaqDtoBuffer[xcp_CanDaqDtoBufferSt.wp].data, (uint8)length) == E_OK)
    {
      send_flag = TRUE;
    }
  }

  /* if DAQ DTO packet should not be sent or sending was not successful, DAQ DTO packet will be kept in the buffer */
  if (send_flag == FALSE)
  {
    xcp_CanDaqDtoBuffer[xcp_CanDaqDtoBufferSt.wp].length = length;
    xcp_CanDaqDtoBufferSt.size++;
    xcp_CanDaqDtoBufferSt.wp++;

    /* check for DAQ DTO buffer wraparound */
    if (xcp_CanDaqDtoBufferSt.wp == XCP_CAN_FIFO_SIZE_DAQ_DTO)
    {
      xcp_CanDaqDtoBufferSt.wp = 0;
    }
  }
}

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Xcp_CanIfSend
* CALLED BY:        Xcp_CanIfTxConfirmation
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      sending RES/ERR/EV/SERV CTO and DAQ DTO packets,  
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_CanIfSend(void)
{
  SuspendAllInterrupts();

  /* check, if RES/ERR/EV/SERV CTO packet or a DAQ DTO packet is pending */
  if (xcp_CanResCtoBufferSt.size > 0)
  {
    /* try to send RES/ERR/EV/SERV CTO packet */
    if (Xcp_CanIfSendCanMsg( xcp_CanResCtoBuffer.data, (uint8)xcp_CanResCtoBuffer.length) == E_OK)
    {
      /* sending was successful, remove RES/ERR/EV/SERV CTO packet from the buffer */
      xcp_CanResCtoBufferSt.size = 0;
    }
  }
  else if (xcp_CanDaqDtoBufferSt.size > 0)
  {
    /* try to send DAQ DTO packet */
    if (Xcp_CanIfSendCanMsg( xcp_CanDaqDtoBuffer[xcp_CanDaqDtoBufferSt.rp].data, (uint8)xcp_CanDaqDtoBuffer[xcp_CanDaqDtoBufferSt.rp].length) == E_OK)
    {
      /* sending was successful, remove DAQ DTO packet from the buffer */
      xcp_CanDaqDtoBufferSt.size--;
      xcp_CanDaqDtoBufferSt.rp++;

      /* check for DAQ DTO buffer wraparound */
      if (xcp_CanDaqDtoBufferSt.rp == XCP_CAN_FIFO_SIZE_DAQ_DTO)
      {
        xcp_CanDaqDtoBufferSt.rp = 0;
      }

    }
  }
  ResumeAllInterrupts();
}

/*******************************************************************************
* NAME:             Xcp_CanIfSendCanMsg
* CALLED BY:        Xcp_CanIf
* PRECONDITIONS:
* INPUT PARAMETERS: uint8* data
*                   uint8 length
* RETURN VALUES:    E_OK
*                   E_NOT_OK
* DESCRIPTION:      sends a CAN message.  
*******************************************************************************/
_STATIC_ FUNC(Std_ReturnType,XCP_CODE) Xcp_CanIfSendCanMsg(uint8* XCP_VAR data, uint8 length)
{
  Std_ReturnType rc;
  uint8_least idx;

  xcp_CanIfPduInfo.SduDataPtr = data;
  xcp_CanIfPduInfo.SduLength = length;
  rc = CanIf_Transmit(Xcp_TxHandle_C,&xcp_CanIfPduInfo);
  
  if (rc == E_OK)
  {
    return (E_OK);
  } 
  else
  {
    return (E_NOT_OK);
  }

}



