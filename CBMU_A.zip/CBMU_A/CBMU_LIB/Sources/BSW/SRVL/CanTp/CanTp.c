/*******************************************************************************
*
*  FILE
*     CanTp.c
*
*  DESCRIPTION
*     Source Code For Can Transport Protocol  	δʹ��
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "CanTp.h"
#include "Det.h"


/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/* CAN Interface*/
#define CANTP_FRAME_DATA_PTR    (CanTpPduInfoPtr->SduDataPtr)

#define CANTP_GET_PCI_TYPE      (*(volatile uint8*)(CANTP_PCI_OFFSET  + CANTP_FRAME_DATA_PTR) & 0xF0)
#define CANTP_GET_PCI           (*(volatile uint8*)(CANTP_PCI_OFFSET  + CANTP_FRAME_DATA_PTR))


#define CANTP_GET_SF_DL         (*(volatile uint8*)(CANTP_PCI_OFFSET  + CANTP_FRAME_DATA_PTR))
#define CANTP_GET_FF_DL         ((((uint16)(*(volatile uint8*)(CANTP_PCI_OFFSET  + CANTP_FRAME_DATA_PTR) & 0x0F))<<8) | \
                                  (*(volatile uint8*)(CANTP_DL_OFFSET  + CANTP_FRAME_DATA_PTR)))   

#define CANTP_GET_FF_DATA_PTR   ((volatile uint8*)(CANTP_FF_OFFSET  + CANTP_FRAME_DATA_PTR))

#define CANTP_GET_SF_DATA_PTR   ((volatile uint8*)(CANTP_SF_OFFSET  + CANTP_FRAME_DATA_PTR))

#define CANTP_GET_FF_DATA(idx)  (*(volatile uint8*)(CANTP_FF_OFFSET  + CANTP_FRAME_DATA_PTR + idx))

#define CANTP_GET_SF_DATA(idx)  (*(volatile uint8*)(CANTP_SF_OFFSET  + CANTP_FRAME_DATA_PTR + idx))

#define CANTP_GET_CF_DATA(idx)  (*((volatile uint8*)(CANTP_CF_OFFSET  + CANTP_FRAME_DATA_PTR) + idx))

#define CANTP_GET_SN            ((*(volatile uint8*)(CANTP_PCI_OFFSET  + CANTP_FRAME_DATA_PTR)) & CANTP_PCI_SN_MASK)

#define CANTP_GET_BS            (*(volatile uint8*)(CANTP_FRAME_DATA_PTR  + CANTP_BS_OFFSET))

#define CANTP_GET_STMIN         (*(volatile uint8*)(CANTP_FRAME_DATA_PTR  + CANTP_STMIN_OFFSET))
/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
VAR(CanTp_RxInfoType,CANTP_VAR) canTp_RxConfig; 

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ VAR(CanTp_TxStatusType,CANTP_VAR) canTp_TxState;
_STATIC_ VAR(CanTp_RxStatusType,CANTP_VAR) canTp_RxState;

_STATIC_ VAR(CanTp_TxInfoType,CANTP_VAR) canTp_TxConfig;

_STATIC_ VAR(uint8,CANTP_VAR) canTp_TxChannel; 

_STATIC_ VAR(boolean,CANTP_VAR) canTp_BusyFlag;

_STATIC_ VAR(PduInfoType,CANTP_VAR) canTp_PduInfo;

_STATIC_ VAR(uint8, CANTP_VAR) canTp_Pdudata[8];
/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ FUNC(Std_ReturnType,CANTP_CODE) CanTp_TxCopyToMsgBuffer(void); 
_STATIC_ FUNC(void,CANTP_CODE) CanTp_TxState(void);
_STATIC_ FUNC(void,CANTP_CODE) CanTp_RxState(void);
_STATIC_ FUNC(void,CANTP_CODE) CanTp_TxInit(void);

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             CanTp_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize CanTp   
*******************************************************************************/
FUNC(void,CANTP_CODE) CanTp_Init(void)
{
 
  canTp_TxChannel   = CANTP_CHANNEL_FREE; /* Free Transmit queue */

  canTp_RxState.State = RX_STATE_IDLE;
  canTp_TxState.State = TX_STATE_IDLE;

  canTp_BusyFlag = FALSE;  

  CanTp_RxInit();
  CanTp_TxInit(); 
  
  canTp_PduInfo.SduLength = CANTP_FRAME_LENGTH;
  canTp_PduInfo.SduDataPtr = &canTp_Pdudata;
}

/*******************************************************************************
* NAME:             CanTp_RxIndication
* CALLED BY:        CAN Interface (Call back Function) 
* PRECONDITIONS:
* INPUT PARAMETERS: PduIdType CanRxPduId
*                   const PduInfoType* PduInfoPtr
* RETURN VALUES:    void
* DESCRIPTION:      Receive the Can Data
*******************************************************************************/
FUNC(void,CANTP_CODE) CanTp_RxIndication(PduIdType CanTpRxPduId, const PduInfoType* CanTpPduInfoPtr)
{
  uint16_least idx;
  uint8 stMin;
  uint8  dlc;
  uint8  pciType;


  /* Dlc Check  */
  dlc = (uint8)CanTpPduInfoPtr->SduLength;
  
  if (dlc != CANTP_FRAME_LENGTH)
  {
    return;
  }
 
  pciType  = CANTP_GET_PCI_TYPE;

  /* Check PCI Type*/
  switch (pciType)  
  {
    /****************************************************************
    *  SF and FF processing BEGIN
    ****************************************************************/
    case CANTP_PCI_TYPE_FF:
    case CANTP_PCI_TYPE_SF:
    {
      /* Check if the Channel is not Idle */   
      if (canTp_RxState.State != RX_STATE_IDLE)
      {
        if (canTp_RxState.State == RX_STATE_APP_INFORMED)
        {
          /* Do not proceed this frame*/
          return;
        }
        else
        {
          CanTp_RxInit();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
          Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_FF_SF_AGAIN_RECEIVED);
#endif
        }
      }

      /* Receive the frame*/
      canTp_RxState.State = RX_STATE_CAN_FRAME_RECEIVED; 

      /* set DataIndex to zero */
      canTp_RxConfig.DataIndex = 0;

      /****************************************************************
      *  FF processing BEGIN
      ****************************************************************/      
      if (pciType == CANTP_PCI_TYPE_FF)
      {
        /* Store length for app usage */
        canTp_RxConfig.DataLength  = CANTP_GET_FF_DL;
        
        /* Check dataLength: the minimum length of a First Frame is seven (normal fixed) */
        if (canTp_RxConfig.DataLength >= CANTP_FF_MIN_DL)
        { 
          /* Preselect ApplGetBufferStatus to the default */
          canTp_RxConfig.ApplGetBufferStatus = CANTP_FC_CTS;
          
          canTp_RxConfig.DataBuffPtr = Dcm_ProvideRxBuffer(canTp_RxConfig.DataLength);

          /* Check if the Application Data Ptr is NULL */
          if(canTp_RxConfig.DataBuffPtr != NULL_PTR)
          { 
            /* COPY DATA */
            for (idx = 0; idx < 6; idx++)
            {
              *(canTp_RxConfig.DataBuffPtr + idx) = CANTP_GET_FF_DATA(idx);  
            }

            /*Set rx index to next free data element*/
            canTp_RxConfig.DataIndex = CANTP_FF_OWN_DL;    
            
            /* Await CF with SN 1 next */
            canTp_RxConfig.SeqNrm = 1;        

            canTp_RxState.Timer  = CANTP_RX_CONFIRM_TO_CNT;
            canTp_RxState.State = RX_STATE_WAIT_FC_CONFIRM;
            
            /* set transmission request */
            canTp_RxState.Queued = 1;

            CanTp_RxState();
          }
          else
          {
            /* if Null Ptr, Cancel reception */
            canTp_RxState.State = RX_STATE_IDLE;
          }
        }/* if (canTp_RxConfig.DataLength >= CANTP_FF_MIN_DL) */
        else
        {
          canTp_RxState.State = RX_STATE_APP_INFORMED;
          CanTp_RxInit();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
          Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_DATA_LENGTH_TOO_SMALL);
#endif            
        }          
      }
      /****************************************************************
      *  FF processing END
      ****************************************************************/

      /****************************************************************
      *  SF processing BEGIN
      ****************************************************************/
      else if (pciType == CANTP_PCI_TYPE_SF)       
      {
        /* Get the data Length*/
        canTp_RxConfig.DataLength = CANTP_GET_SF_DL; 
        
        /* Is maximum length of a SingleFrame exeeded ? */              
        if ((canTp_RxConfig.DataLength <= CANTP_SF_MAX_DL) && (canTp_RxConfig.DataLength  != 0))
        { 
          canTp_RxConfig.ApplGetBufferStatus = CANTP_FC_CTS;

          canTp_RxConfig.DataBuffPtr = Dcm_ProvideRxBuffer(canTp_RxConfig.DataLength);
          
          /* Check if data buffer is valid */   
          if (canTp_RxConfig.DataBuffPtr != NULL_PTR)
          {            
            /* COPY DATA */
            for (idx = 0; idx < canTp_RxConfig.DataLength; idx++)
            {
              *(canTp_RxConfig.DataBuffPtr + idx) = CANTP_GET_SF_DATA(idx);
            }
            canTp_RxState.State = RX_STATE_APP_INFORMED;
            /* Callback - ApplIndication a SingleFrame is completely received */
            Dcm_RxIndication(NETWORK_OK);
          }
          else
          {
            /* invalid data buffer */
            canTp_RxState.State = RX_STATE_APP_INFORMED;
            CanTp_RxInit();
            
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_DATA_BUFFER_NOT_VALID);
#endif                 
          }
        }
        else
        {
          canTp_RxState.State = RX_STATE_APP_INFORMED;              
          CanTp_RxInit();
                      
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
          Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_DATA_LENGTH_TOO_BIG);
#endif               
        }
        return;
      }
      /****************************************************************
      *  SF processing END
      ****************************************************************/        
      else
      {         
        /* unknown frame */
        canTp_RxState.State = RX_STATE_APP_INFORMED;
        CanTp_RxInit();
        
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
        Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_UNKNOWN_PCI_TYPE);
#endif                      
      }
 
    }
    break;
    /****************************************************************
    *  SF and FF processing END
    ****************************************************************/
 
    
    /****************************************************************
    *  CF processing BEGIN
    ****************************************************************/
    case CANTP_PCI_TYPE_CF:
    {
      /* check if a connection is established on this channel and a CF is allowed */ 
      if((canTp_RxState.State == RX_STATE_WAIT_CF) || (canTp_RxState.State == RX_STATE_WAIT_FC_CONFIRM))
      {        
        /* If Flow Control Confirmation is still waiting, */
        if(canTp_RxState.State == RX_STATE_WAIT_FC_CONFIRM)
        {
          if(canTp_RxState.Queued == 0)
          {
            /* Emulate Isr-Confirm on state RX_STATE_WAIT_FC_CONFIRM because this event might have happened 
            but is only scheduled later in processor */
            
            /* suppress real confirmation */ 
            CanIf_CancelTransmit (CANTP_TX_HANDLE); 
            
            /* Call confirmation function to simulate expected WaitForFCConfIsr event */
            CanTp_TxConfirmation(CANTP_TX_HANDLE);

            /* state State should now be in state RX_STATE_WAIT_CF */
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            if (canTp_RxState.State != RX_STATE_WAIT_CF)
            {
              Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_NOT_IN_WAIT_CF_STATE);
              return;
            }
#endif
          }
          else 
          {
            /* Ignore frame and wait for correct frame because FC is not sent */
            return; 
          }
        }
        
        /* A connection is established, CF is allowed */
        
        /* Check if it's the Last CF? */
        if ((canTp_RxConfig.DataIndex + CANTP_CF_DL) >= canTp_RxConfig.DataLength)
        { 
          
          /* Check if it's Wrong SN ?*/
          if (CANTP_GET_SN != (uint8)(canTp_RxConfig.SeqNrm))
          { 
            /* Stop receiving  */
            CanTp_RxInit();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_WRONG_SN_RECEIVED);
#endif                  
          }
          else
          {
            /* COPY DATA */     
            for (idx = 0; idx < (canTp_RxConfig.DataLength - canTp_RxConfig.DataIndex); idx++)
            {
              *(canTp_RxConfig.DataBuffPtr + canTp_RxConfig.DataIndex + idx) = CANTP_GET_CF_DATA(idx);
            }
            /* Stop waiting for CF/FC */
            canTp_RxState.State = RX_STATE_APP_INFORMED; 
            /* Stop Timeout Counter */
            canTp_RxState.Timer  = 0; 
            /* Callback - ApplIndication a MultipleFrame is completely received */  
            Dcm_RxIndication(NETWORK_OK);
          }
        }
        /*Wait for next CF*/
        else 
        { 
          /*Wrong SN received?*/
          if ( CANTP_GET_SN != (uint8)(canTp_RxConfig.SeqNrm) )
          { /* Stop receiving immediately! */
            CanTp_RxInit();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_WRONG_SN_RECEIVED);
#endif               
            /*Possible tx of error frame here?*/
          }
          else
          {
           /* COPY DATA */     
            for (idx = 0; idx < CANTP_CF_DL; idx++)
            {
              *(canTp_RxConfig.DataBuffPtr + canTp_RxConfig.DataIndex + idx) = CANTP_GET_CF_DATA(idx);
            }     
            /*Set rx index to next free data element*/
            canTp_RxConfig.DataIndex += CANTP_CF_DL;   
            
            /*Calculate next expected SN now (not neccessary if last CF was received)*/
            /*SN is calculated modulo 15 , SN increment*/
            canTp_RxConfig.SeqNrm += 1; 
            canTp_RxConfig.SeqNrm &= 0x0F;
            
            /* No special check for channels without FlowControl */
            /* If BS == 0 - no FlowControl frames shall be sent */
            if(canTp_RxState.BSCounter != 0) 
            {
              canTp_RxState.BSCounter--;
              /* Check if a FC is requested (BS==0?) */
              if(canTp_RxState.BSCounter == 0)
              { /*Yes, FC is requested!*/
                canTp_RxState.State = RX_STATE_WAIT_FC_CONFIRM;
                canTp_RxState.Timer = CANTP_RX_CONFIRM_TO_CNT;                      
                /* set transmission request */
                canTp_RxState.Queued = 1;
                CanTp_RxState();

                return;
              }
            }
            canTp_RxState.Timer = CANTP_CF_TO_CNT;
            canTp_RxState.State = RX_STATE_WAIT_CF;
          }
        }
        return;
      }
    }
    break;
    /****************************************************************
    *  CF processing END
    ****************************************************************/
           
    /****************************************************************
    *  FC processing BEGIN
    ****************************************************************/
    case CANTP_PCI_TYPE_FC:
    {
    /* Is waiting for FC ? */
      if ( (canTp_TxState.State == TX_STATE_WAIT_FC) 
        || (canTp_TxState.State == TX_STATE_WAIT_FOR_FF_CONFIRM)
        || (canTp_TxState.State == TX_STATE_WAIT_FOR_CF_CONFIRM))
      {
        /* Check if previous frame is sent or not */
        if(canTp_TxState.Queued == 0) 
        {
          if((canTp_TxState.State == TX_STATE_WAIT_FOR_FF_CONFIRM) ||
            ((canTp_TxState.State == TX_STATE_WAIT_FOR_CF_CONFIRM) && (canTp_TxState.BSCounter == 1)))
          {

            /* Emulate Confirm on state RX_STATE_WAIT_FC_CONFIRM 
            because this event might have happened but is only scheduled later in processor */
            
             /* suppress scheduled event */
            CanIf_CancelTransmit(CANTP_TX_HANDLE);
            /* call driver routine now */
            CanTp_TxConfirmation(CANTP_TX_HANDLE); 

            /* state State should be now in TX_STATE_WAIT_FC state */
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            if (canTp_TxState.State != TX_STATE_WAIT_FC)
            {
              Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_TX_NOT_IN_WAIT_FC_STATE);
              return;
            }
#endif
          }
        }
        else
        { 
          /* ignore FC while confirmation is Queued, that meaning not sent yet */
          return;
        }

        if (canTp_TxState.State == TX_STATE_WAIT_FC) 
        {
          /**** FlowStatus *******************************************************/
          switch (CANTP_GET_PCI)
          {
            case CANTP_PCI_FC_CTS:
            {
              if (canTp_TxState.firstFC == 0)  
              {
                /* Set flag with the first received FC */
                canTp_TxState.firstFC = 1; 
                canTp_TxConfig.BlockSize = CANTP_GET_BS;                      
                
                stMin = CANTP_GET_STMIN;

                if (stMin < (CANTP_TX_GET_ST_DEFAULT_CNT * CANTP_TX_CALL_CYCLE))
                { 
                  /* Requested STmin to low for internal possible values, use minimum value */
                  canTp_TxConfig.STMin = (uint8)CANTP_TX_GET_ST_DEFAULT_CNT;
                }
                else
                { /* Selected call cycle is rounded up to next possible call value */
                  if ((stMin & 0x80) != 0)
                  {
                    if ((stMin > 0xF0) && (stMin <= 0xF9))
                    {
                      canTp_TxConfig.STMin = (uint8)CANTP_TX_GET_ST_DEFAULT_CNT;
                    }
                    else
                    {
                      canTp_TxConfig.STMin = (uint8)( ((127/*maxSTminTime*/ + (CANTP_TX_CALL_CYCLE-1)) / CANTP_TX_CALL_CYCLE) + 1);
                    }
                  }
                  else
                  {
                    canTp_TxConfig.STMin = (uint8)(((stMin + (CANTP_TX_CALL_CYCLE-1)) / CANTP_TX_CALL_CYCLE) + 1);

                  }
                }
              }
              /* load BlockSize into Counter */
              canTp_TxState.BSCounter = (canTp_TxConfig.BlockSize); 
              canTp_TxState.Timer = canTp_TxConfig.STMin;
              canTp_TxState.State = TX_STATE_WAIT_FOR_TX_CF;
            }
            break;

            case CANTP_PCI_FC_WAIT:
            {           
              /* WaitFrame received, set timer again */
              canTp_TxState.Timer = CANTP_FC_TO_CNT;
            }
            break;
            
            case CANTP_PCI_FC_OVRRUN:
            {
              /* Receiver reported an Overrun - terminate channel */
              CanTp_TxInit();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
              Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_TX_FC_OVRRUN);
#endif
            }
            break;
            
            default:
            {
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
              Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_TX_FC_UNKNOWN_FS);
#endif
            }
            break;
          }

        }
        return;
             
      }
    }
    break;
    /****************************************************************
    *  FC processing END
    ****************************************************************/

    default:
    {
 #if (CANTP_DEV_ERROR_DETECT == STD_ON)
      Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_IND,CANTP_E_RX_UNKNOWN_PCI_TYPE);
#endif   
    }
    break;
  }
  return;                
}

/*******************************************************************************
* NAME:             CanTp_TxConfirmation
* CALLED BY:        Can interface (Call Back Function)
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Inform Application that Transmit is successful
*******************************************************************************/
FUNC(void,CANTP_CODE) CanTp_TxConfirmation(PduIdType CanTxPduId)
{
    
  /* Do Tx confirmation  */
  if (canTp_TxChannel  == CANTP_CHANNEL_TX)
  {
    
    switch(canTp_TxState.State)
    {
        /*-----------------------------------------------------------------------------
        | SingleFrame
        -----------------------------------------------------------------------------*/
      case TX_STATE_WAIT_FOR_SF_CONFIRM: 
        /* Same as "TX_STATE_WAIT_FOR_LAST_CF_CONFIRM" */
        /*-----------------------------------------------------------------------------
        | LastConsecutiveFrame
        -----------------------------------------------------------------------------*/
      case TX_STATE_WAIT_FOR_LAST_CF_CONFIRM:
      { 
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
      if ((canTp_TxState.Queued != 0)||(canTp_TxState.ReTx != 0))
      {
        Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_TX_CONFIRM,CANTP_E_TX_FLAG_INCONSISTENT);
        return;
      }
#endif                       
        /* Callback - */
        Dcm_TxConfirmation(NETWORK_OK);
        /* Reset tpChannel after callback to get access to the connection */

        /* static tpChannels and MinTimer feature is in-active */
        /* or dynamic and not locked tpChannel */
        canTp_TxState.Timer      = 0;
        canTp_TxState.State     = TX_STATE_IDLE;

        }
        break;
        /*-----------------------------------------------------------------------------
        | FirstFrame
        -----------------------------------------------------------------------------*/
      case TX_STATE_WAIT_FOR_FF_CONFIRM:
        {
          canTp_TxState.Timer = CANTP_FC_TO_CNT;
          canTp_TxState.State = TX_STATE_WAIT_FC;
          canTp_TxState.firstFC = 0; /* Calculate BS/STmin only out of the first received FC */
        }
        /* Callback - */
        break;
        /*-----------------------------------------------------------------------------
        | ConsecutiveFrame
        -----------------------------------------------------------------------------*/
      case TX_STATE_WAIT_FOR_CF_CONFIRM:
        /* Callback - */
        
        /* No special check for channels without FlowControl */
        /* If BS == 0 - no FlowControl frames shall be await */
        if(canTp_TxState.BSCounter != 0)
        {     
          canTp_TxState.BSCounter--;
          if(canTp_TxState.BSCounter == 0)
          { /*Check for FC of counterpart now */
            canTp_TxState.Timer = CANTP_FC_TO_CNT;
            canTp_TxState.State = TX_STATE_WAIT_FC;
            break;
          }
        }
        {
          canTp_TxState.Timer = canTp_TxConfig.STMin;
          canTp_TxState.State = TX_STATE_WAIT_FOR_TX_CF;
        }
        break;
      default: 
        /* default case - leave function without any changes to internal states */
        return;
    }  /* end of switch state */
    
    /* Set TransmitObject free */
    canTp_TxChannel = CANTP_CHANNEL_FREE;
  }
  /* Do Tx confirmation stuff END */
  
  /* Do Rx related Tx confirmation stuff BEGIN */
  else
  {
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
    if (canTp_TxChannel != CANTP_CHANNEL_RX)
    {
      Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_TX_CONFIRM,CANTP_E_RX_CHANNEL_STATE);
      return;
    }
#endif 
    
    switch(canTp_RxState.State)
    {
      case RX_STATE_WAIT_FC_CONFIRM:
        if (canTp_RxConfig.ApplGetBufferStatus == CANTP_FC_WAIT)
        {
          canTp_RxState.WFTCounter--;                /* decr. wait frame counter */
          /* Wait for next FC wait transmission */
          canTp_RxState.Timer  = (CanTp_TimerType)((CANTP_FC_TO_CNT << 2) / 5);
          canTp_RxState.State = RX_STATE_WAIT_FC_WAIT;
        }
        else

        { /* Wait for next CF */
          canTp_RxState.Timer  = CANTP_CF_TO_CNT;
          canTp_RxState.State = RX_STATE_WAIT_CF;
          canTp_RxState.WFTCounter = CANTP_MAX_WAIT_FRAME;    /* re-init wait frame counter */

        }
      break;

      case RX_STATE_WAIT_FC_OVRFLOW_CONFIRM:
        /* Stop receiving frames on this tpChannel */
        canTp_RxState.Timer  = 0;
        canTp_RxState.State = RX_STATE_IDLE;
      break;

      default:
      return;
    }
    /* Set TransmitObject free */
    canTp_TxChannel     =  CANTP_CHANNEL_FREE;
  }
   /* Do Rx related Tx confirmation stuff END */
}

/*******************************************************************************
* NAME:             CanTp_Transmit
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: uint8* pdata, pointer to transmit data
*                   uint16 count, number of data bytes
* RETURN VALUES:    E_OK
*                   E_NOT_OK
* DESCRIPTION:      Transmit data in buffer
*******************************************************************************/
FUNC(Std_ReturnType,CANTP_CODE) CanTp_Transmit(uint8* pdata, uint16 count)
{
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
  if (count > 0xfff)
  {
    Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_TX,CANTP_E_TX_DATA_LENGTH_TOO_HIGH);
    return (E_NOT_OK);
  }

  if (count == 0)
  {
    Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_TX,CANTP_E_TX_DATA_LENGTH_ZERO);
    return E_NOT_OK;
  }
#endif
 
  /* check and modify state and timer */
  SuspendAllInterrupts();
    
  /* Check if channel is free */
  if(canTp_TxState.State != TX_STATE_IDLE)
  { 
    ResumeAllInterrupts();
    return E_NOT_OK;
  }
 
  if (count <= CANTP_SF_MAX_DL) 
  { 
    canTp_TxState.State = TX_STATE_WAIT_FOR_SF_CONFIRM;
  }
  else 
  {
    canTp_TxState.State = TX_STATE_WAIT_FOR_FF_CONFIRM;
  }  
  
  canTp_TxState.Timer = CANTP_TX_CONFIRM_TO_CNT;   

  /* store parameters */
  canTp_TxConfig.DataBuffPtr = pdata;
  canTp_TxConfig.DataIndex     = 0;
  canTp_TxConfig.DataLength    = count;
  
  /* start transmission */
  /* set transmission request */
  canTp_TxState.Queued = 1; 

  ResumeAllInterrupts();  
  return E_OK;
}

/*******************************************************************************
* NAME:             CanTp_MainFunction
* CALLED BY:        Idle Task or period task
* PRECONDITIONS:    Must not called in Interrupt Context
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Call Rx and Tx task in correct order. (Rx First)
*******************************************************************************/
FUNC(void,CANTP_CODE) CanTp_MainFunction(void)
{
  /* Check if the Rx State is not in Idle*/
  if (canTp_RxState.Timer != 0)
  {    
    SuspendAllInterrupts();

    if(canTp_RxState.Timer != 0)
    {
      /* Decrement the Timer */
      canTp_RxState.Timer--;

      /* Value of timer must be zero to reach this point*/
      if(canTp_RxState.Timer == 0)
      { 
        switch(canTp_RxState.State)
        {
          case RX_STATE_WAIT_CF:
          { 
            CanTp_RxInit();               
            ResumeAllInterrupts();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_MAIN_FUNCTION,CANTP_E_RX_CF_TO);
#endif   
          }
          break;
          
          case RX_STATE_WAIT_FC_CONFIRM:
          case RX_STATE_WAIT_FC_OVRFLOW_CONFIRM:
          {
            CanTp_RxInit(); 
            ResumeAllInterrupts();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_MAIN_FUNCTION,CANTP_E_RX_CONFIRM_TO);
#endif            
          }
          break;

          case RX_STATE_WAIT_FC_WAIT:
          {
            if(canTp_RxState.WFTCounter == 0)
            { /* WFTmax wait frames are transmitted now */
              CanTp_RxInit();   /* and go to idle state       */
              ResumeAllInterrupts();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
              Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_MAIN_FUNCTION,CANTP_E_RX_WF_MAX_OVRRUN);
#endif               
            }
            else
            { /* Force sending next FC with status wait */
              canTp_RxState.Timer  = CANTP_RX_CONFIRM_TO_CNT;
              canTp_RxState.State = RX_STATE_WAIT_FC_CONFIRM;
              canTp_RxState.Queued = 1; /* set transmission request */
              ResumeAllInterrupts();
              CanTp_RxState();
            }
          }
          break;

          default:
          {
            ResumeAllInterrupts();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_MAIN_FUNCTION,CANTP_E_RX_STATES);
#endif 
          }
          break;
        }
      }
      else
      {
        ResumeAllInterrupts();
        /* Do only while timer is active */
        CanTp_RxState();
      }
    } /* RxTimer */
    else 
    {
      ResumeAllInterrupts();
    }
  } 

  /* Check if the Tx State is not in Idle*/
  if (canTp_TxState.Timer != 0)
  { 
    SuspendAllInterrupts();  
        
    if(canTp_TxState.Timer != 0)
    {
      canTp_TxState.Timer--;
      
      if(canTp_TxState.Timer == 0)
      {     
        switch(canTp_TxState.State)
        {
          /* FC Timeout occured!*/
          case TX_STATE_WAIT_FC:    
          {
            CanTp_TxInit();          
            ResumeAllInterrupts();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_MAIN_FUNCTION,CANTP_E_TX_FC_TO);
#endif              
          }
          break;
          
          case TX_STATE_WAIT_FOR_TX_CF:            
          {
              /* Assemble CF now*/
            /* Calculate next SN - SN is calculated modulo 15*/
            canTp_TxConfig.SeqNrm += 1;
            canTp_TxConfig.SeqNrm &= 0x0F;
            
            /* Last message? */
            if((canTp_TxConfig.DataIndex + CANTP_CF_DL) >= canTp_TxConfig.DataLength)
            {                
              canTp_TxState.State = TX_STATE_WAIT_FOR_LAST_CF_CONFIRM;
            }                
            /*No, wait for next CF*/  
            else               
            {
              canTp_TxState.State = TX_STATE_WAIT_FOR_CF_CONFIRM;
            }
            canTp_TxState.Timer = CANTP_TX_CONFIRM_TO_CNT;
            
            /* Transmit the CANframe */
            canTp_TxState.Queued = 1;
            
            ResumeAllInterrupts();
            /* Try first transmission now */
            CanTp_TxState();
          }
          break;
          
          case TX_STATE_WAIT_FOR_SF_CONFIRM:
          case TX_STATE_WAIT_FOR_FF_CONFIRM:               
          case TX_STATE_WAIT_FOR_CF_CONFIRM:               
          case TX_STATE_WAIT_FOR_LAST_CF_CONFIRM:
          {
            /* Timeout, apparently no access to bus*/
            CanTp_TxInit();
            ResumeAllInterrupts();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
    Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_MAIN_FUNCTION,CANTP_E_TX_CONFIRM_TO);
#endif 
          }
          break;
            
          default: 
          {
            ResumeAllInterrupts();
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_MAIN_FUNCTION,CANTP_E_TX_STATES);
#endif            
          }
          break;
        } 
      } 
      else
      {
        ResumeAllInterrupts();
        /* Try to transmit if timer is not zero */
        CanTp_TxState();
      }
    } 
    else
    {
      ResumeAllInterrupts();
    }
  }
}


/*******************************************************************************
* NAME:             CanTp_RxInit
* CALLED BY:        Internal function
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize the receive channel    
*******************************************************************************/
FUNC(void,CANTP_CODE) CanTp_RxInit(void)
{
  SuspendAllInterrupts();
  
  if ((canTp_RxState.State > RX_STATE_APP_INFORMED) && \
      (canTp_RxState.State != RX_STATE_ERROR))
  {
    canTp_RxState.State   = RX_STATE_ERROR;
    Dcm_RxIndication(NETWORK_ABORT);
  }
  canTp_RxState.Timer                    = 0;
  canTp_RxState.State                   = RX_STATE_IDLE;
  canTp_RxState.Queued                   = 0;
  canTp_RxState.ReTx               = 0;
  canTp_RxConfig.SeqNrm      = 0;
  canTp_RxConfig.ApplGetBufferStatus = CANTP_FC_CTS;

  if (canTp_TxChannel == CANTP_CHANNEL_RX)
  {
    CanIf_CancelTransmit(CANTP_TX_HANDLE);
    /* Set TransmitObject free */
    canTp_TxChannel   =  CANTP_CHANNEL_FREE;
  }
  ResumeAllInterrupts();
}

/****************************************************************************
* NAME:             CanTp_GetVersionInfo
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Std_VersionInfoType *versioninfo
* RETURN VALUES:    void
* DESCRIPTION:      Service to get version information     
****************************************************************************/
FUNC(void,CANTP_CODE) CanTp_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
  versioninfo->vendorID = CANTP_VENDOR_ID;
  versioninfo->moduleID = CANTP_MODULE_ID;
  versioninfo->sw_major_version = CANTP_SW_MAJOR_VERSION;
  versioninfo->sw_minor_version = CANTP_SW_MINOR_VERSION;
  versioninfo->sw_patch_version = CANTP_SW_PATCH_VERSION;
}

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             CanTp_TxInit
* CALLED BY:        Internal function
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize the transmit channel    
*******************************************************************************/
_STATIC_ FUNC(void,CANTP_CODE) CanTp_TxInit(void)
{
  SuspendAllInterrupts();

  /* Error Indication */
  if ((canTp_TxState.State != TX_STATE_IDLE) && \
     (canTp_TxState.State != TX_STATE_ERROR)) /* ! (TX_STATE_IDLE ) */
  {
    canTp_TxState.State = TX_STATE_ERROR; 
    Dcm_TxConfirmation(NETWORK_ABORT);
    canTp_TxState.State = TX_STATE_IDLE;
  }
  
  canTp_TxState.Timer                  = 0;
  canTp_TxState.Queued                 = 0;
  canTp_TxState.ReTx             = 0;

  if (canTp_TxChannel == CANTP_CHANNEL_TX)
  {
    CanIf_CancelTransmit(CANTP_TX_HANDLE);
    /* Set TransmitObject free */
    canTp_TxChannel = CANTP_CHANNEL_FREE;
  }
  ResumeAllInterrupts();
}



/*******************************************************************************
* NAME:             CanTp_TxState
* CALLED BY:        CanTp_MainFunction
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Transmit a CAN frame   
*******************************************************************************/
_STATIC_ FUNC(void,CANTP_CODE) CanTp_TxState(void)
{
  Std_ReturnType rc;

  if(canTp_BusyFlag == FALSE)
  {
    canTp_BusyFlag = TRUE;

    if (canTp_TxState.ReTx != 0)
    {
      Can_DisableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);

      if (canTp_TxState.ReTx != 0)
      {
        canTp_TxState.ReTx = 0;
        
        Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
        
        rc = CanIf_Transmit(CANTP_TX_HANDLE,&canTp_PduInfo);
        
        if (rc == E_NOT_OK)
        {
          canTp_TxState.ReTx = 1;  
        }
      }
      else
      {
        Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
      }            
    } 
    else         
    {
      if (canTp_TxState.Queued != 0)
      {
        Can_DisableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);

        if(canTp_TxState.Queued != 0)
        {          
          if (canTp_TxChannel == CANTP_CHANNEL_FREE) 
          { 
            canTp_TxChannel = CANTP_CHANNEL_TX;

            canTp_TxState.Queued = 0;
            
            /* Copy Data to message Buffer */
            rc = CanTp_TxCopyToMsgBuffer();
            
            if (rc == E_OK)
            {
              rc = CanIf_Transmit(CANTP_TX_HANDLE,&canTp_PduInfo);
              Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
              if (rc == E_NOT_OK)
              {
                 canTp_TxState.ReTx = 1;              
              }
            } 
            else
            {
              if ((canTp_TxState.State == TX_STATE_WAIT_FOR_CF_CONFIRM)     || 
                  (canTp_TxState.State == TX_STATE_WAIT_FOR_LAST_CF_CONFIRM) ||
                  (canTp_TxState.State == TX_STATE_WAIT_FOR_FF_CONFIRM))
              {
                if(canTp_TxState.State == TX_STATE_WAIT_FOR_FF_CONFIRM) 
                {
                  canTp_TxConfig.DataIndex = 0;
                }
                else
                {
                  canTp_TxConfig.DataIndex -= CANTP_CF_DL;
                }
              }
              /* A buffer underrun has happened - restore transmit path and set queue flag again */
              canTp_TxChannel = CANTP_CHANNEL_FREE;
              canTp_TxState.Queued = 1;
              Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
            }
          }
        }
        else
        {
          Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
        } /* if (canTp_TxChannel == CANTP_CHANNEL_FREE) */
      }/* if (canTp_TxState.Queued != 0) */
    }/* if (canTp_TxState.ReTx != 0) */
    canTp_BusyFlag = FALSE;
  } /* if(canTp_BusyFlag == FALSE) */
}

/*******************************************************************************
* NAME:             CanTp_RxState
* CALLED BY:        CanTp_MainFunction
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Transmit a CAN frame   
*******************************************************************************/
_STATIC_ FUNC(void,CANTP_CODE) CanTp_RxState(void)
{
  Std_ReturnType rc;

  if(canTp_BusyFlag == FALSE)
  {
    canTp_BusyFlag = TRUE;
   
    if (canTp_RxState.ReTx!=0)
    {
      Can_DisableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
    
      if (canTp_RxState.ReTx != 0)
      {
        canTp_RxState.ReTx = 0;
        Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
        
        rc = CanIf_Transmit(CANTP_TX_HANDLE,&canTp_PduInfo);
        if (rc != E_OK)
        {
          canTp_RxState.ReTx = 1;  
        }        
      }
      else
      {
        Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
      }
    }
    else    
    {
      
      if (canTp_RxState.Queued != 0)
      {
        Can_DisableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);

        if(canTp_RxState.Queued != 0)
        {
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
          if ((canTp_RxState.State != RX_STATE_WAIT_FC_CONFIRM) && (canTp_RxState.State != RX_STATE_WAIT_FC_OVRFLOW_CONFIRM))
          {
            Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_RX_STATE,CANTP_E_CHANNEL_NOT_IN_USE);  
          }
#endif 
          if (canTp_TxChannel  == CANTP_CHANNEL_FREE)
          {
            canTp_TxChannel  =  CANTP_CHANNEL_RX;
            canTp_RxState.Queued = 0;

            /* Copy Data to Buffer */
          
            /* Assemble FC */
            if (canTp_RxState.State == RX_STATE_WAIT_FC_OVRFLOW_CONFIRM)
            {
              canTp_Pdudata[ (CANTP_PCI_OFFSET) ]  = CANTP_PCI_FC_OVRRUN;
            }
            else
            {
              if (canTp_RxConfig.ApplGetBufferStatus == CANTP_FC_WAIT)
              { /* currently in status wait */
                canTp_Pdudata[ (CANTP_PCI_OFFSET) ]  = CANTP_PCI_FC_WAIT;
              }
              else
              { /* normal clear to send state */
                canTp_Pdudata[ (CANTP_PCI_OFFSET) ]  = CANTP_PCI_TYPE_FC;
              }
            }
            canTp_Pdudata[(CANTP_BS_OFFSET)]    = CANTP_BS_REQ;
            canTp_Pdudata[(CANTP_STMIN_OFFSET)] = CANTP_ST_MIN;     

            /* Reload Block Size */
            canTp_RxState.BSCounter = CANTP_BS_REQ;
            rc = CanIf_Transmit(CANTP_TX_HANDLE,&canTp_PduInfo);
 
            if ( rc == E_NOT_OK )
            {
              canTp_RxState.ReTx = 1; 
            }         
            Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
          }
        }
        else
        {
          Can_EnableControllerInterrupts(CANTP_CAN_CHANNEL_INDEX);
        }
      }
    }
    canTp_BusyFlag = FALSE;
  }
} 

/*******************************************************************************
* NAME:             CanTp_TxCopyToMsgBuffer
* CALLED BY:        CanTp_TxState
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    E_OK
*                   E_NOT_OK
* DESCRIPTION:      Copy Data to CAN  
*******************************************************************************/
_STATIC_ FUNC(Std_ReturnType,CANTP_CODE) CanTp_TxCopyToMsgBuffer(void)
{
  CanTp_CopyToCanInfoType  tpInfoStruct;

  tpInfoStruct.pSource = &canTp_TxConfig.DataBuffPtr[canTp_TxConfig.DataIndex]; 

  switch(canTp_TxState.State)
  {
    /* Transmit Single Frame */
    case TX_STATE_WAIT_FOR_SF_CONFIRM: 
    {
      
      canTp_Pdudata[(CANTP_PCI_OFFSET)] = (uint8)(canTp_TxConfig.DataLength);
      tpInfoStruct.pDestination  = (volatile uint8*)(&(canTp_Pdudata[(CANTP_SF_OFFSET)]));
      tpInfoStruct.Length        = canTp_TxConfig.DataLength;
    }
    break;
    
    /* Transmit First Frame */
    case TX_STATE_WAIT_FOR_FF_CONFIRM:
    {
      canTp_Pdudata[(CANTP_PCI_OFFSET)] = (uint8)CANTP_PCI_TYPE_FF;
      canTp_Pdudata[(CANTP_PCI_OFFSET)] |= (uint8)((canTp_TxConfig.DataLength & 0x0F00)>>8);
      canTp_Pdudata[(CANTP_DL_OFFSET)]  = (uint8)( canTp_TxConfig.DataLength & 0x00FF);

      tpInfoStruct.pDestination = (volatile uint8*)(&(canTp_Pdudata[(CANTP_FF_OFFSET)]));
      tpInfoStruct.Length       = CANTP_FF_OWN_DL;
      
      /* Set tx index to next free data element */
      canTp_TxConfig.DataIndex = CANTP_FF_OWN_DL;    
      
      /* SN set to zero */
      canTp_TxConfig.SeqNrm = 0; 
       
      /* Neccessary for correct setting of next state TX_STATE_WAIT_FC */
      canTp_TxState.BSCounter = 0;   
    }
    break;

    /* Transmit Consecutive Frame */
    case TX_STATE_WAIT_FOR_LAST_CF_CONFIRM:
    case TX_STATE_WAIT_FOR_CF_CONFIRM:   
    {      
      canTp_Pdudata[(CANTP_PCI_OFFSET)] = (uint8)CANTP_PCI_TYPE_CF;
      canTp_Pdudata[(CANTP_PCI_OFFSET)] |= (uint8)canTp_TxConfig.SeqNrm;
      tpInfoStruct.pDestination = (volatile uint8*)(&(canTp_Pdudata[(CANTP_CF_OFFSET)]));
      if (canTp_TxState.State == TX_STATE_WAIT_FOR_LAST_CF_CONFIRM)
      {
        tpInfoStruct.Length = (uint16)(canTp_TxConfig.DataLength-canTp_TxConfig.DataIndex);
      }
      else
      {
        tpInfoStruct.Length = CANTP_CF_DL;

      }    
      canTp_TxConfig.DataIndex += CANTP_CF_DL;   /*Set tx index to next free data element*/
    }
    break;
    
    default: /* Nothing to do */
    {
#if (CANTP_DEV_ERROR_DETECT == STD_ON)
      Det_ReportError(CANTP_MODULE_ID,CANTP_INSTATNCE_ID,CANTP_API_TX_COPY,CANTP_E_TX_WRONG_FRAME_AT_PRETRANSMIT);
#endif
      return E_NOT_OK; /* do not proceed with wrong state */
    }/* break; */
  }  /* end of switch state */

  MemCpy2((void*)tpInfoStruct.pDestination,(void*) tpInfoStruct.pSource, tpInfoStruct.Length);
  return E_OK;
  
}


