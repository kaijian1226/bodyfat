/*******************************************************************************
*
*  FILE
*     Can_Cfg.h
*
*  DESCRIPTION
*     Configuration for CAN driver 
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/
#ifndef _CAN_CFG_H_
#define _CAN_CFG_H_
/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Can_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Rx and Tx processing mode */
#define CAN_INTERRUPT               0
#define CAN_POLLING                 1

/* Define the channel used (range 0-4) */
#define CAN_USED_NUM_OF_CHANNEL     3

/* HW loop Timer */
#define CAN_INIT_REQ_TO_LOOP        1000 
#define CAN_SLEEP_TO_LOOP           1000
#define CAN_WKUP_TO_LOOP            1000 
#define CAN_EXIT_INIT_TO_LOOP       1000


/* OSEK Support */
#define CAN_RXINT_OSCAT2            STD_OFF
#define CAN_TXINT_OSCAT2				    STD_OFF
#define CAN_WAKEUPINT_OSCAT2		    STD_OFF
#define CAN_ERRINT_OSCAT2				    STD_OFF

/* AUTOSAR COMPLIANT */
#define CAN_DEV_ERROR_DETECT        STD_ON

/* Polling OR Interrupt Mode */
#define CAN_TX_PROCESSING           CAN_INTERRUPT
#define CAN_RX_PROCESSING           CAN_POLLING
#define CAN_WAKEUP_PROCESSING       CAN_INTERRUPT
#define CAN_BUSOFF_PROCESSING       CAN_INTERRUPT



#if( CAN_USED_NUM_OF_CHANNEL > 5 )
# error "The number of CAN channels supported is limited to a maximum of 5"
#endif

#define CAN_CHANNEL0            STD_ON
#define CAN_CHANNEL1            STD_ON
#define CAN_CHANNEL2            STD_ON
#define CAN_CHANNEL3            STD_ON
#define CAN_CHANNEL4            STD_OFF

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant declaration                         
*******************************************************************************/
extern CONST(Can_ConfigType,CAN_CONST) Can_InitObject_C[CAN_USED_NUM_OF_CHANNEL];
extern CONST(uint16,CAN_CONST) Can_InitBasisAdr_C[CAN_USED_NUM_OF_CHANNEL];
/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

#endif /* #ifndef _CAN_CFG_H_ */
