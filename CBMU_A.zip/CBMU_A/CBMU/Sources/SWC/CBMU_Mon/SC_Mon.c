/*
 * File: SC_Mon.c
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:39:52 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SC_Mon.h"

/* Include model header file for global data */
#include "CBMU_MON.h"
#include "CBMU_MON_private.h"

/* Named constants for Chart: '<S49>/Chart' */
#define CBMU_MON_IN_NO_ACTIVE_CHILD_f  ((uint8_T)0U)
#define CBMU_MON_IN_SC_MON_CAN_TO      ((uint8_T)2U)
#define CBMU_MON_IN_SC_MON_CAN_TO_00   ((uint8_T)1U)
#define CBMU_MON_IN_SC_MON_CAN_TO_01   ((uint8_T)2U)
#define CBMU_MON_IN_SC_MON_CHARGER_ERR ((uint8_T)4U)
#define CBMU_MON_IN_SC_MON_CHARGING    ((uint8_T)5U)
#define CBMU_MON_IN_SC_MON_CV_HI       ((uint8_T)6U)
#define CBMU_MON_IN_SC_MON_CV_HI_00    ((uint8_T)1U)
#define CBMU_MON_IN_SC_MON_CV_HI_01    ((uint8_T)2U)
#define CBMU_MON_IN_SC_MON_FINISHED    ((uint8_T)7U)
#define CBMU_MON_IN_SC_MON_FINISHED00  ((uint8_T)1U)
#define CBMU_MON_IN_SC_MON_FINISHED01  ((uint8_T)2U)
#define CBMU_MON_IN_SC_MON_FM2         ((uint8_T)8U)
#define CBMU_MO_IN_SC_MON_AC_DISCONNECT ((uint8_T)1U)
#define CBMU_MO_IN_SC_MON_CHARGE12V_OFF ((uint8_T)3U)
#define CBMU_MO_IN_SC_MON_CHARGER_ERR00 ((uint8_T)1U)
#define CBMU_MO_IN_SC_MON_CHARGER_ERR01 ((uint8_T)2U)
#define CBMU__IN_SC_MON_AC_DISCONNECT00 ((uint8_T)1U)
#define CBMU__IN_SC_MON_AC_DISCONNECT01 ((uint8_T)2U)

/* Forward declaration for local functions */
static void CBMU_MON_HVRelayON_SC(void);
static void CBMU_MON_SC_MON_FM2(void);
static void CBMU_MON_HVRelayOFF(void);
static void CBMU_MON_SC_MON_AC_DISCONNECT(void);
static boolean_T CBMU_MON_CheckChargerStatus(void);
static void CBMU_MON_SC_MON_CAN_TO(void);

/* Function for Chart: '<S49>/Chart' */
static void CBMU_MON_HVRelayON_SC(void)
{
  /* Graphical Function 'HVRelayON_SC': '<S50>:350' */
  /* Transition: '<S50>:353' */
  if (O_S_HVIL && O_S_SCCC) {
    /* Transition: '<S50>:358' */
    /* Transition: '<S50>:354' */
    CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl = (RELAY_ON != 0);
    com_BPSHighVoltSts = 1U;
  }
}

/* Function for Chart: '<S49>/Chart' */
static void CBMU_MON_SC_MON_FM2(void)
{
  uint32_T qY;
  uint16_T q0;
  uint16_T qY_0;

  /* During 'SC_MON_FM2': '<S50>:10' */
  if (!I_S_Sc) {
    /* Transition: '<S50>:98' */
    CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MO_IN_SC_MON_CHARGE12V_OFF;

    /* Entry 'SC_MON_CHARGE12V_OFF': '<S50>:4' */
    /* AppSCPowerOff() */
  } else {
    if (!CBMU_FM2St) {
      /* Transition: '<S50>:99' */
      CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_f;
      com_BPC2ChrgEnable = (SC_CHARGE_ENABLE != 0);
      com_BPC2ChrgSts = SC_ST_CHARGING;
      CBMU_MON_HVRelayON_SC();
      CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_SC_MON_CHARGING;

      /* Entry 'SC_MON_CHARGING': '<S50>:5' */
      /* AppSCCharging()
         com_BPC2MaxChrgVolt = 1700;
         com_BPC2MaxChrgCurrent = 160; */
      com_BPC2ChrgEnable = false;
      com_BPC2ChrgSts = 1U;

      /* com_BPC2ChrgrACInput = 0; */
      SC_MON_test = 0U;
      q0 = com_BattCurr >> 5;
      qY_0 = q0 - 1016U;
      if (qY_0 > q0) {
        qY_0 = 0U;
      }

      qY = ChargedAH + qY_0;
      if (qY < ChargedAH) {
        qY = MAX_uint32_T;
      }

      ChargedAH = qY;
    }
  }
}

/* Function for Chart: '<S49>/Chart' */
static void CBMU_MON_HVRelayOFF(void)
{
  /* Graphical Function 'HVRelayOFF': '<S50>:119' */
  /* Transition: '<S50>:122' */
  /* Transition: '<S50>:123' */
  CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl = (RELAY_OFF != 0);
  com_BPSHighVoltSts = 0U;
}

/* Function for Chart: '<S49>/Chart' */
static void CBMU_MON_SC_MON_AC_DISCONNECT(void)
{
  uint16_T q0;
  uint16_T qY;
  uint32_T qY_0;

  /* During 'SC_MON_AC_DISCONNECT': '<S50>:6' */
  /* Transition: '<S50>:155' */
  /* Transition: '<S50>:158' */
  /* Transition: '<S50>:139' */
  /* Transition: '<S50>:111' */
  if (!I_S_Sc) {
    /* Transition: '<S50>:100' */
    /* Exit Internal 'SC_MON_AC_DISCONNECT': '<S50>:6' */
    if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT ==
        CBMU__IN_SC_MON_AC_DISCONNECT00) {
      /* Exit 'SC_MON_AC_DISCONNECT00': '<S50>:162' */
      CBMU_MON_DWork.scm_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
        CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    } else {
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
        CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    }

    com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
    com_BPC2ChrgSts = SC_ST_NO_CHARGE;
    SC_MON_test = 17U;
    CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MO_IN_SC_MON_CHARGE12V_OFF;

    /* Entry 'SC_MON_CHARGE12V_OFF': '<S50>:4' */
    /* AppSCPowerOff() */
  } else if (com_CCP1ACConnect == 0) {
    /* Transition: '<S50>:159' */
    /* Exit Internal 'SC_MON_AC_DISCONNECT': '<S50>:6' */
    if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT ==
        CBMU__IN_SC_MON_AC_DISCONNECT00) {
      /* Exit 'SC_MON_AC_DISCONNECT00': '<S50>:162' */
      CBMU_MON_DWork.scm_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
        CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    } else {
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
        CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    }

    CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    com_BPC2ChrgEnable = (SC_CHARGE_ENABLE != 0);
    com_BPC2ChrgSts = SC_ST_CHARGING;
    CBMU_MON_HVRelayON_SC();
    CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_SC_MON_CHARGING;

    /* Entry 'SC_MON_CHARGING': '<S50>:5' */
    /* AppSCCharging()
       com_BPC2MaxChrgVolt = 1700;
       com_BPC2MaxChrgCurrent = 160; */
    com_BPC2ChrgEnable = false;
    com_BPC2ChrgSts = 1U;

    /* com_BPC2ChrgrACInput = 0; */
    SC_MON_test = 0U;
    q0 = com_BattCurr >> 5;
    qY = q0 - 1016U;
    if (qY > q0) {
      qY = 0U;
    }

    qY_0 = ChargedAH + qY;
    if (qY_0 < ChargedAH) {
      qY_0 = MAX_uint32_T;
    }

    ChargedAH = qY_0;
  } else if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT ==
             CBMU__IN_SC_MON_AC_DISCONNECT00) {
    /* Inport: '<Root>/SC_NA' */
    /* During 'SC_MON_AC_DISCONNECT00': '<S50>:162' */
    if (SC_NA) {
      /* Transition: '<S50>:160' */
      /* Exit 'SC_MON_AC_DISCONNECT00': '<S50>:162' */
      CBMU_MON_DWork.scm_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
        CBMU__IN_SC_MON_AC_DISCONNECT01;

      /* Entry 'SC_MON_AC_DISCONNECT01': '<S50>:161' */
      CBMU_MON_HVRelayOFF();
    } else if (CBMU_MON_DWork.scm_ct > 1500UL) {
      /* Transition: '<S50>:163' */
      /* Exit 'SC_MON_AC_DISCONNECT00': '<S50>:162' */
      CBMU_MON_DWork.scm_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
        CBMU__IN_SC_MON_AC_DISCONNECT01;

      /* Entry 'SC_MON_AC_DISCONNECT01': '<S50>:161' */
      CBMU_MON_HVRelayOFF();
    } else {
      qY_0 = CBMU_MON_DWork.scm_ct + 10UL;
      if (qY_0 < CBMU_MON_DWork.scm_ct) {
        qY_0 = MAX_uint32_T;
      }

      CBMU_MON_DWork.scm_ct = qY_0;
    }

    /* End of Inport: '<Root>/SC_NA' */
  } else {
    /* During 'SC_MON_AC_DISCONNECT01': '<S50>:161' */
  }
}

/* Function for Chart: '<S49>/Chart' */
static boolean_T CBMU_MON_CheckChargerStatus(void)
{
  boolean_T y;

  /* Inport: '<Root>/com_CCP1ChrgVolt' incorporates:
   *  Inport: '<Root>/com_CCP1ACRange'
   *  Inport: '<Root>/com_CCP1ChrgCurrOut'
   *  Inport: '<Root>/com_CCP1ChrgPreReadySts'
   *  Inport: '<Root>/com_CCP1CommSts'
   *  Inport: '<Root>/com_CCP1HwFault'
   *  Inport: '<Root>/com_CCP1TempSts'
   */
  /* Graphical Function 'CheckChargerStatus': '<S50>:80' */
  /* Transition: '<S50>:341' */
  if ((com_CCP1ChrgVolt <= 34548U) && (com_CCP1ChrgCurrOut <= 160U) &&
      (com_CCP1HwFault == 0) && (com_CCP1TempSts == 0) && (com_CCP1CommSts == 0)
      && (com_CCP1ACRange == 3) && (com_CCP1ChrgrPreReadySts == 0)) {
    /* Transition: '<S50>:331' */
    /* Transition: '<S50>:325' */
    /* Transition: '<S50>:319' */
    /* Transition: '<S50>:313' */
    /* [com_CCP1ACConnect == 0] */
    /* Transition: '<S50>:307' */
    /* Transition: '<S50>:301' */
    /* Transition: '<S50>:296' */
    /* Transition: '<S50>:290' */
    /* Transition: '<S50>:297' */
    y = true;
  } else {
    /* Transition: '<S50>:336' */
    /* Transition: '<S50>:332' */
    /* Transition: '<S50>:330' */
    /* Transition: '<S50>:326' */
    /* Transition: '<S50>:324' */
    /* Transition: '<S50>:320' */
    /* Transition: '<S50>:314' */
    /* Transition: '<S50>:312' */
    /* Transition: '<S50>:308' */
    /* Transition: '<S50>:306' */
    /* Transition: '<S50>:302' */
    /* Transition: '<S50>:300' */
    /* Transition: '<S50>:294' */
    /* Transition: '<S50>:291' */
    /* Transition: '<S50>:288' */
    /* Transition: '<S50>:286' */
    y = false;
  }

  /* End of Inport: '<Root>/com_CCP1ChrgVolt' */
  return y;
}

/* Function for Chart: '<S49>/Chart' */
static void CBMU_MON_SC_MON_CAN_TO(void)
{
  uint16_T q0;
  uint16_T qY;
  uint32_T qY_0;

  /* During 'SC_MON_CAN_TO': '<S50>:8' */
  /* Transition: '<S50>:131' */
  /* Transition: '<S50>:139' */
  /* Transition: '<S50>:111' */
  if (!I_S_Sc) {
    /* Transition: '<S50>:100' */
    /* Exit Internal 'SC_MON_CAN_TO': '<S50>:8' */
    if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO ==
        CBMU_MON_IN_SC_MON_CAN_TO_00) {
      /* Exit 'SC_MON_CAN_TO_00': '<S50>:132' */
      CBMU_MON_DWork.scm_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO =
        CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    } else {
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO =
        CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    }

    com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
    com_BPC2ChrgSts = SC_ST_NO_CHARGE;
    SC_MON_test = 17U;
    CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MO_IN_SC_MON_CHARGE12V_OFF;

    /* Entry 'SC_MON_CHARGE12V_OFF': '<S50>:4' */
    /* AppSCPowerOff() */
  } else if (!(SC_NA || COMM_NA || (!O_S_SCCC) || (!CBMU_MON_CheckChargerStatus())))
  {
    /* Transition: '<S50>:136' */
    /* Exit Internal 'SC_MON_CAN_TO': '<S50>:8' */
    if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO ==
        CBMU_MON_IN_SC_MON_CAN_TO_00) {
      /* Exit 'SC_MON_CAN_TO_00': '<S50>:132' */
      CBMU_MON_DWork.scm_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO =
        CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    } else {
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO =
        CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    }

    CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_f;
    com_BPC2ChrgEnable = (SC_CHARGE_ENABLE != 0);
    com_BPC2ChrgSts = SC_ST_CHARGING;
    CBMU_MON_HVRelayON_SC();
    CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_SC_MON_CHARGING;

    /* Entry 'SC_MON_CHARGING': '<S50>:5' */
    /* AppSCCharging()
       com_BPC2MaxChrgVolt = 1700;
       com_BPC2MaxChrgCurrent = 160; */
    com_BPC2ChrgEnable = false;
    com_BPC2ChrgSts = 1U;

    /* com_BPC2ChrgrACInput = 0; */
    SC_MON_test = 0U;
    q0 = com_BattCurr >> 5;
    qY = q0 - 1016U;
    if (qY > q0) {
      qY = 0U;
    }

    qY_0 = ChargedAH + qY;
    if (qY_0 < ChargedAH) {
      qY_0 = MAX_uint32_T;
    }

    ChargedAH = qY_0;
  } else if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO ==
             CBMU_MON_IN_SC_MON_CAN_TO_00) {
    /* Inport: '<Root>/BMS_FM2St' */
    /* During 'SC_MON_CAN_TO_00': '<S50>:132' */
    /* (mCCP1Timeout) ||(mInterCanMsgTimeout) ||*/
    if (CBMU_FM2St) {
      /* Transition: '<S50>:134' */
      /* Exit 'SC_MON_CAN_TO_00': '<S50>:132' */
      CBMU_MON_DWork.scm_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO = CBMU_MON_IN_SC_MON_CAN_TO_01;

      /* Entry 'SC_MON_CAN_TO_01': '<S50>:133' */
      CBMU_MON_HVRelayOFF();
    } else if (CBMU_MON_DWork.scm_ct > 1500UL) {
      /* Transition: '<S50>:135' */
      /* Exit 'SC_MON_CAN_TO_00': '<S50>:132' */
      CBMU_MON_DWork.scm_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO = CBMU_MON_IN_SC_MON_CAN_TO_01;

      /* Entry 'SC_MON_CAN_TO_01': '<S50>:133' */
      CBMU_MON_HVRelayOFF();
    } else {
      qY_0 = CBMU_MON_DWork.scm_ct + 10UL;
      if (qY_0 < CBMU_MON_DWork.scm_ct) {
        qY_0 = MAX_uint32_T;
      }

      CBMU_MON_DWork.scm_ct = qY_0;
    }

    /* End of Inport: '<Root>/BMS_FM2St' */
  } else {
    /* During 'SC_MON_CAN_TO_01': '<S50>:133' */
  }
}

/* Start for atomic system: '<S1>/SC_Mon' */
void CBMU_MON_SC_Mon_Start(void)
{
  /* InitializeConditions for Enabled SubSystem: '<S6>/ScMon' */
  /* InitializeConditions for Chart: '<S49>/Chart' */
  CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
    CBMU_MON_IN_NO_ACTIVE_CHILD_f;
  CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO = CBMU_MON_IN_NO_ACTIVE_CHILD_f;
  CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR =
    CBMU_MON_IN_NO_ACTIVE_CHILD_f;
  CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI = CBMU_MON_IN_NO_ACTIVE_CHILD_f;
  CBMU_MON_DWork.bitsForTID0.is_SC_MON_FINISHED = CBMU_MON_IN_NO_ACTIVE_CHILD_f;
  CBMU_MON_DWork.bitsForTID0.is_active_c36_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_f;
  CBMU_MON_DWork.scm_ct = 0UL;
  com_ShutDown = 0U;
  com_InnerBusTxEna = false;
  com_VehBusTxEna = false;
  com_SlowChrgrTxEna = false;
  com_FastChrgrTxEna = false;
  CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl = false;
  com_BPSHighVoltSts = 0U;
  com_BPC2ChrgEnable = false;
  com_BPC2ChrgSts = 0U;
  mChargeStep = 0U;

  /* End of InitializeConditions for SubSystem: '<S6>/ScMon' */
}

/* Output and update for atomic system: '<S1>/SC_Mon' */
void CBMU_MON_SC_Mon(void)
{
  uint16_T q0;
  uint16_T qY;
  uint32_T qY_0;
  int16_T tmp;

  /* Outputs for Enabled SubSystem: '<S6>/ScMon' incorporates:
   *  EnablePort: '<S49>/Enable'
   */
  /* RelationalOperator: '<S6>/Relational Operator2' incorporates:
   *  Constant: '<S6>/Constant2'
   */
  if (PwrMode == PWR_SC) {
    /* Chart: '<S49>/Chart' incorporates:
     *  Constant: '<S6>/Constant'
     *  Inport: '<Root>/BMS_FM2St'
     *  Inport: '<Root>/COMM_NA'
     *  Inport: '<Root>/SC_NA'
     *  Inport: '<Root>/com_CCP1ACConnect'
     *  Inport: '<Root>/com_SOC'
     *  RelationalOperator: '<S6>/Relational Operator'
     *  Switch: '<S6>/Switch'
     */
    /* Gateway: Task_10ms/SC_Mon/ScMon/Chart */
    /* During: Task_10ms/SC_Mon/ScMon/Chart */
    if (CBMU_MON_DWork.bitsForTID0.is_active_c36_CBMU_MON == 0U) {
      /* Entry: Task_10ms/SC_Mon/ScMon/Chart */
      CBMU_MON_DWork.bitsForTID0.is_active_c36_CBMU_MON = 1U;

      /* Entry Internal: Task_10ms/SC_Mon/ScMon/Chart */
      /* Transition: '<S50>:38' */
      CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_SC_MON_CHARGING;

      /* Entry 'SC_MON_CHARGING': '<S50>:5' */
      /* AppSCCharging()
         com_BPC2MaxChrgVolt = 1700;
         com_BPC2MaxChrgCurrent = 160; */
      com_BPC2ChrgEnable = false;
      com_BPC2ChrgSts = 1U;

      /* com_BPC2ChrgrACInput = 0; */
      SC_MON_test = 0U;
      q0 = com_BattCurr >> 5;
      qY = q0 - 1016U;
      if (qY > q0) {
        qY = 0U;
      }

      qY_0 = ChargedAH + qY;
      if (qY_0 < ChargedAH) {
        qY_0 = MAX_uint32_T;
      }

      ChargedAH = qY_0;
    } else {
      switch (CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON) {
       case CBMU_MO_IN_SC_MON_AC_DISCONNECT:
        CBMU_MON_SC_MON_AC_DISCONNECT();
        break;

       case CBMU_MON_IN_SC_MON_CAN_TO:
        CBMU_MON_SC_MON_CAN_TO();
        break;

       case CBMU_MO_IN_SC_MON_CHARGE12V_OFF:
        /* During 'SC_MON_CHARGE12V_OFF': '<S50>:4' */
        break;

       case CBMU_MON_IN_SC_MON_CHARGER_ERR:
        /* During 'SC_MON_CHARGER_ERR': '<S50>:9' */
        /* Transition: '<S50>:140' */
        /* Transition: '<S50>:111' */
        if (!I_S_Sc) {
          /* Transition: '<S50>:100' */
          /* Exit Internal 'SC_MON_CHARGER_ERR': '<S50>:9' */
          if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR ==
              CBMU_MO_IN_SC_MON_CHARGER_ERR00) {
            /* Exit 'SC_MON_CHARGER_ERR00': '<S50>:141' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
          } else {
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
          }

          com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
          com_BPC2ChrgSts = SC_ST_NO_CHARGE;
          SC_MON_test = 17U;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MO_IN_SC_MON_CHARGE12V_OFF;

          /* Entry 'SC_MON_CHARGE12V_OFF': '<S50>:4' */
          /* AppSCPowerOff() */
        } else if (CBMU_MON_CheckChargerStatus()) {
          /* Transition: '<S50>:146' */
          /* Exit Internal 'SC_MON_CHARGER_ERR': '<S50>:9' */
          if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR ==
              CBMU_MO_IN_SC_MON_CHARGER_ERR00) {
            /* Exit 'SC_MON_CHARGER_ERR00': '<S50>:141' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
          } else {
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
          }

          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MON_IN_NO_ACTIVE_CHILD_f;
          com_BPC2ChrgEnable = (SC_CHARGE_ENABLE != 0);
          com_BPC2ChrgSts = SC_ST_CHARGING;
          CBMU_MON_HVRelayON_SC();
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MON_IN_SC_MON_CHARGING;

          /* Entry 'SC_MON_CHARGING': '<S50>:5' */
          /* AppSCCharging()
             com_BPC2MaxChrgVolt = 1700;
             com_BPC2MaxChrgCurrent = 160; */
          com_BPC2ChrgEnable = false;
          com_BPC2ChrgSts = 1U;

          /* com_BPC2ChrgrACInput = 0; */
          SC_MON_test = 0U;
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
        } else if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR ==
                   CBMU_MO_IN_SC_MON_CHARGER_ERR00) {
          /* During 'SC_MON_CHARGER_ERR00': '<S50>:141' */
          /* (mCCP1Timeout) ||*/
          if (CBMU_FM2St) {
            /* Transition: '<S50>:143' */
            /* Exit 'SC_MON_CHARGER_ERR00': '<S50>:141' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR =
              CBMU_MO_IN_SC_MON_CHARGER_ERR01;

            /* Entry 'SC_MON_CHARGER_ERR01': '<S50>:142' */
            CBMU_MON_HVRelayOFF();
          } else if (CBMU_MON_DWork.scm_ct > 1500UL) {
            /* Transition: '<S50>:144' */
            /* Exit 'SC_MON_CHARGER_ERR00': '<S50>:141' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR =
              CBMU_MO_IN_SC_MON_CHARGER_ERR01;

            /* Entry 'SC_MON_CHARGER_ERR01': '<S50>:142' */
            CBMU_MON_HVRelayOFF();
          } else {
            qY_0 = CBMU_MON_DWork.scm_ct + 10UL;
            if (qY_0 < CBMU_MON_DWork.scm_ct) {
              qY_0 = MAX_uint32_T;
            }

            CBMU_MON_DWork.scm_ct = qY_0;
          }
        } else {
          /* During 'SC_MON_CHARGER_ERR01': '<S50>:142' */
        }
        break;

       case CBMU_MON_IN_SC_MON_CHARGING:
        /* During 'SC_MON_CHARGING': '<S50>:5' */
        if (!I_S_Sc) {
          /* Transition: '<S50>:44' */
          /* Exit 'SC_MON_CHARGING': '<S50>:5' */
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
          com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
          com_BPC2ChrgSts = SC_ST_NO_CHARGE;
          SC_MON_test = 1U;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MO_IN_SC_MON_CHARGE12V_OFF;

          /* Entry 'SC_MON_CHARGE12V_OFF': '<S50>:4' */
          /* AppSCPowerOff() */
        } else if (CBMU_FM2St) {
          /* Transition: '<S50>:54' */
          /* Exit 'SC_MON_CHARGING': '<S50>:5' */
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MON_IN_NO_ACTIVE_CHILD_f;
          com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
          com_BPC2ChrgSts = SC_ST_ERR;
          CBMU_MON_HVRelayOFF();
          SC_MON_test = 2U;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_SC_MON_FM2;
        } else if (SC_NA || COMM_NA || (!O_S_SCCC)) {
          /* Transition: '<S50>:92' */
          /* Exit 'SC_MON_CHARGING': '<S50>:5' */
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
          com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
          com_BPC2ChrgSts = SC_ST_ERR;
          SC_MON_test = 5U;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_SC_MON_CAN_TO;

          /* Entry 'SC_MON_CAN_TO': '<S50>:8' */
          /* AppSCCANTimeout */
          /* Entry Internal 'SC_MON_CAN_TO': '<S50>:8' */
          /* Transition: '<S50>:151' */
          CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO =
            CBMU_MON_IN_SC_MON_CAN_TO_00;

          /* Entry 'SC_MON_CAN_TO_00': '<S50>:132' */
          CBMU_MON_DWork.scm_ct = 0UL;
        } else if (!CBMU_MON_CheckChargerStatus()) {
          /* Transition: '<S50>:89' */
          /* Exit 'SC_MON_CHARGING': '<S50>:5' */
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
          com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
          com_BPC2ChrgSts = SC_ST_ERR;
          SC_MON_test = 3U;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MON_IN_SC_MON_CHARGER_ERR;

          /* Entry 'SC_MON_CHARGER_ERR': '<S50>:9' */
          /* AppSCChargerErr */
          /* Entry Internal 'SC_MON_CHARGER_ERR': '<S50>:9' */
          /* Transition: '<S50>:150' */
          CBMU_MON_DWork.bitsForTID0.is_SC_MON_CHARGER_ERR =
            CBMU_MO_IN_SC_MON_CHARGER_ERR00;

          /* Entry 'SC_MON_CHARGER_ERR00': '<S50>:141' */
          CBMU_MON_DWork.scm_ct = 0UL;
        } else if (com_CCP1ACConnect == 1) {
          /* Transition: '<S50>:93' */
          /* Exit 'SC_MON_CHARGING': '<S50>:5' */
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
          com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
          com_BPC2ChrgSts = SC_ST_NO_CHARGE;

          /* SaveSCData();
             EcuM_AppPostRun(); */
          SC_MON_test = 7U;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MO_IN_SC_MON_AC_DISCONNECT;

          /* Entry Internal 'SC_MON_AC_DISCONNECT': '<S50>:6' */
          /* Transition: '<S50>:197' */
          CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
            CBMU__IN_SC_MON_AC_DISCONNECT00;

          /* Entry 'SC_MON_AC_DISCONNECT00': '<S50>:162' */
          CBMU_MON_DWork.scm_ct = 0UL;
        } else if ((CV_St == SRC_HIGH_DEF) || (CV_St == SRC_TOO_HIGH_DEF)) {
          /* Transition: '<S50>:95' */
          /* Exit 'SC_MON_CHARGING': '<S50>:5' */
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
          SC_MON_test = 9U;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_SC_MON_CV_HI;

          /* Entry 'SC_MON_CV_HI': '<S50>:13' */
          /* AppSCCVHL1 */
          /* Entry Internal 'SC_MON_CV_HI': '<S50>:13' */
          /* Transition: '<S50>:177' */
          CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
            CBMU_MON_IN_SC_MON_CV_HI_00;

          /* Entry 'SC_MON_CV_HI_00': '<S50>:173' */
          CBMU_MON_DWork.scm_ct = 0UL;
        } else {
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
          com_BPC2ChrgEnable = false;
          com_BPC2ChrgSts = 1U;
        }
        break;

       case CBMU_MON_IN_SC_MON_CV_HI:
        /* During 'SC_MON_CV_HI': '<S50>:13' */
        if (CV_St == SRC_NON_DEF) {
          /* Transition: '<S50>:349' */
          /* Exit Internal 'SC_MON_CV_HI': '<S50>:13' */
          switch (CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI) {
           case CBMU_MON_IN_SC_MON_CV_HI_00:
            /* Exit 'SC_MON_CV_HI_00': '<S50>:173' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
            break;

           case CBMU_MON_IN_SC_MON_CV_HI_01:
            /* Exit 'SC_MON_CV_HI_01': '<S50>:174' */
            CV_St = SRC_NON_DEF;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
            break;

           default:
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
            break;
          }

          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MON_IN_SC_MON_CHARGING;

          /* Entry 'SC_MON_CHARGING': '<S50>:5' */
          /* AppSCCharging()
             com_BPC2MaxChrgVolt = 1700;
             com_BPC2MaxChrgCurrent = 160; */
          com_BPC2ChrgEnable = false;
          com_BPC2ChrgSts = 1U;

          /* com_BPC2ChrgrACInput = 0; */
          SC_MON_test = 0U;
          q0 = com_BattCurr >> 5;
          qY = q0 - 1016U;
          if (qY > q0) {
            qY = 0U;
          }

          qY_0 = ChargedAH + qY;
          if (qY_0 < ChargedAH) {
            qY_0 = MAX_uint32_T;
          }

          ChargedAH = qY_0;
        } else if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI ==
                   CBMU_MON_IN_SC_MON_CV_HI_00) {
          /* During 'SC_MON_CV_HI_00': '<S50>:173' */
          if (CBMU_FM2St) {
            /* Transition: '<S50>:106' */
            /* Exit 'SC_MON_CV_HI_00': '<S50>:173' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
            CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
            com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
            com_BPC2ChrgSts = SC_ST_ERR;
            CBMU_MON_HVRelayOFF();
            SC_MON_test = 14U;
            CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON = CBMU_MON_IN_SC_MON_FM2;
          } else if (SC_NA) {
            /* Transition: '<S50>:107' */
            /* Exit 'SC_MON_CV_HI_00': '<S50>:173' */
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
            com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
            com_BPC2ChrgSts = SC_ST_ERR;
            SC_MON_test = 13U;
            CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
              CBMU_MON_IN_SC_MON_CAN_TO;

            /* Entry 'SC_MON_CAN_TO': '<S50>:8' */
            /* AppSCCANTimeout */
            /* Entry Internal 'SC_MON_CAN_TO': '<S50>:8' */
            /* Transition: '<S50>:151' */
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CAN_TO =
              CBMU_MON_IN_SC_MON_CAN_TO_00;

            /* Entry 'SC_MON_CAN_TO_00': '<S50>:132' */
            CBMU_MON_DWork.scm_ct = 0UL;
          } else {
            /* Transition: '<S50>:168' */
            /* Transition: '<S50>:130' */
            /* Transition: '<S50>:158' */
            /* Transition: '<S50>:139' */
            /* Transition: '<S50>:111' */
            if (!I_S_Sc) {
              /* Transition: '<S50>:100' */
              /* Exit 'SC_MON_CV_HI_00': '<S50>:173' */
              CBMU_MON_DWork.scm_ct = 0UL;
              CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
                CBMU_MON_IN_NO_ACTIVE_CHILD_f;
              com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
              com_BPC2ChrgSts = SC_ST_NO_CHARGE;
              SC_MON_test = 17U;
              CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
                CBMU_MO_IN_SC_MON_CHARGE12V_OFF;

              /* Entry 'SC_MON_CHARGE12V_OFF': '<S50>:4' */
              /* AppSCPowerOff() */
            } else if (com_CCP1ACConnect == 1) {
              /* Transition: '<S50>:170' */
              /* Exit 'SC_MON_CV_HI_00': '<S50>:173' */
              CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
                CBMU_MON_IN_NO_ACTIVE_CHILD_f;
              com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
              com_BPC2ChrgSts = SC_ST_NO_CHARGE;

              /* SaveSCData();
                 EcuM_AppPostRun(); */
              SC_MON_test = 12U;
              CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
                CBMU_MO_IN_SC_MON_AC_DISCONNECT;

              /* Entry Internal 'SC_MON_AC_DISCONNECT': '<S50>:6' */
              /* Transition: '<S50>:197' */
              CBMU_MON_DWork.bitsForTID0.is_SC_MON_AC_DISCONNECT =
                CBMU__IN_SC_MON_AC_DISCONNECT00;

              /* Entry 'SC_MON_AC_DISCONNECT00': '<S50>:162' */
              CBMU_MON_DWork.scm_ct = 0UL;
            } else {
              if (com_SOC * 205U < 51200U) {
                /* Switch: '<S6>/Switch' incorporates:
                 *  Memory: '<S6>/Memory1'
                 */
                q0 = ChrgTgtTimer1;
              } else {
                /* Switch: '<S6>/Switch' incorporates:
                 *  Memory: '<S6>/Memory2'
                 */
                q0 = ChrgTgtTimer2;
              }

              if (CBMU_MON_DWork.scm_ct > q0) {
                /* Transition: '<S50>:175' */
                /* Exit 'SC_MON_CV_HI_00': '<S50>:173' */
                CBMU_MON_DWork.scm_ct = 0UL;
                SC_MON_test = 15U;
                CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
                  CBMU_MON_IN_SC_MON_CV_HI_01;

                /* Entry 'SC_MON_CV_HI_01': '<S50>:174' */
                tmp = mChargeStep + 1;
                if (tmp > 255) {
                  tmp = 255;
                }

                mChargeStep = (uint8_T)tmp;

                /* com_BPC2MaxChrgCurrent=SlowChargeTgtCur  lookup tabel outside */
              } else {
                qY_0 = CBMU_MON_DWork.scm_ct + 10UL;
                if (qY_0 < CBMU_MON_DWork.scm_ct) {
                  qY_0 = MAX_uint32_T;
                }

                CBMU_MON_DWork.scm_ct = qY_0;
              }
            }
          }
        } else {
          /* During 'SC_MON_CV_HI_01': '<S50>:174' */
          if (mChargeStep > 6) {
            /* Transition: '<S50>:179' */
            /* Transition: '<S50>:193' */
            /* Transition: '<S50>:194' */
            com_BPC2ChrgSts = SC_ST_FINISHED;

            /* Transition: '<S50>:191' */
            /* Transition: '<S50>:180' */
            /* Exit 'SC_MON_CV_HI_01': '<S50>:174' */
            CV_St = SRC_NON_DEF;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
            com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
            SC_MON_test = 16U;
            CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
              CBMU_MON_IN_SC_MON_FINISHED;

            /* Entry 'SC_MON_FINISHED': '<S50>:11' */
            /* AppSCFinished */
            /* Entry Internal 'SC_MON_FINISHED': '<S50>:11' */
            /* Transition: '<S50>:152' */
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_FINISHED =
              CBMU_MON_IN_SC_MON_FINISHED00;

            /* Entry 'SC_MON_FINISHED00': '<S50>:101' */
            CBMU_MON_DWork.scm_ct = 0UL;
          } else {
            /* Transition: '<S50>:187' */
            /* Exit 'SC_MON_CV_HI_01': '<S50>:174' */
            CV_St = SRC_NON_DEF;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_CV_HI =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
            CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
              CBMU_MON_IN_SC_MON_CHARGING;

            /* Entry 'SC_MON_CHARGING': '<S50>:5' */
            /* AppSCCharging()
               com_BPC2MaxChrgVolt = 1700;
               com_BPC2MaxChrgCurrent = 160; */
            com_BPC2ChrgEnable = false;
            com_BPC2ChrgSts = 1U;

            /* com_BPC2ChrgrACInput = 0; */
            SC_MON_test = 0U;
            q0 = com_BattCurr >> 5;
            qY = q0 - 1016U;
            if (qY > q0) {
              qY = 0U;
            }

            qY_0 = ChargedAH + qY;
            if (qY_0 < ChargedAH) {
              qY_0 = MAX_uint32_T;
            }

            ChargedAH = qY_0;
          }
        }
        break;

       case CBMU_MON_IN_SC_MON_FINISHED:
        /* During 'SC_MON_FINISHED': '<S50>:11' */
        /* Transition: '<S50>:112' */
        if (!I_S_Sc) {
          /* Transition: '<S50>:100' */
          /* Exit Internal 'SC_MON_FINISHED': '<S50>:11' */
          if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_FINISHED ==
              CBMU_MON_IN_SC_MON_FINISHED00) {
            /* Exit 'SC_MON_FINISHED00': '<S50>:101' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_FINISHED =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
          } else {
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_FINISHED =
              CBMU_MON_IN_NO_ACTIVE_CHILD_f;
          }

          com_BPC2ChrgEnable = (SC_CHARGE_DISABLE != 0);
          com_BPC2ChrgSts = SC_ST_NO_CHARGE;
          SC_MON_test = 17U;
          CBMU_MON_DWork.bitsForTID0.is_c36_CBMU_MON =
            CBMU_MO_IN_SC_MON_CHARGE12V_OFF;

          /* Entry 'SC_MON_CHARGE12V_OFF': '<S50>:4' */
          /* AppSCPowerOff() */
        } else if (CBMU_MON_DWork.bitsForTID0.is_SC_MON_FINISHED ==
                   CBMU_MON_IN_SC_MON_FINISHED00) {
          /* During 'SC_MON_FINISHED00': '<S50>:101' */
          if (CBMU_FM2St) {
            /* Transition: '<S50>:104' */
            /* Exit 'SC_MON_FINISHED00': '<S50>:101' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_FINISHED =
              CBMU_MON_IN_SC_MON_FINISHED01;

            /* Entry 'SC_MON_FINISHED01': '<S50>:102' */
            CBMU_MON_HVRelayOFF();
          } else if (CBMU_MON_DWork.scm_ct > 5000UL) {
            /* Transition: '<S50>:103' */
            /* Exit 'SC_MON_FINISHED00': '<S50>:101' */
            CBMU_MON_DWork.scm_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SC_MON_FINISHED =
              CBMU_MON_IN_SC_MON_FINISHED01;

            /* Entry 'SC_MON_FINISHED01': '<S50>:102' */
            CBMU_MON_HVRelayOFF();
          } else {
            qY_0 = CBMU_MON_DWork.scm_ct + 10UL;
            if (qY_0 < CBMU_MON_DWork.scm_ct) {
              qY_0 = MAX_uint32_T;
            }

            CBMU_MON_DWork.scm_ct = qY_0;
          }
        } else {
          /* During 'SC_MON_FINISHED01': '<S50>:102' */
        }
        break;

       default:
        CBMU_MON_SC_MON_FM2();
        break;
      }
    }

    /* End of Chart: '<S49>/Chart' */
  }

  /* End of RelationalOperator: '<S6>/Relational Operator2' */
  /* End of Outputs for SubSystem: '<S6>/ScMon' */

  /* Lookup_n-D: '<S6>/ChrgCur' incorporates:
   *  Constant: '<S6>/Constant3'
   */
  ChrgTgtCur = look2_iu8lu32n31yu16tu_e4FyxcSB(mChargeStep, 1U,
    CBMU_MON_ConstP.pooled11, CBMU_MON_ConstP.pooled12, CBMU_MON_ConstP.pooled5,
    CBMU_MON_ConstP.pooled1, 6UL);

  /* Lookup_n-D: '<S6>/ChrgCurTimeOfFullSOC' incorporates:
   *  Constant: '<S6>/Constant5'
   */
  ChrgTgtTimer2 = look2_iu8lu32n31yu16tu_e4FyxcSB(mChargeStep, 3U,
    CBMU_MON_ConstP.pooled11, CBMU_MON_ConstP.pooled12, CBMU_MON_ConstP.pooled5,
    CBMU_MON_ConstP.pooled1, 6UL);

  /* Lookup_n-D: '<S6>/ChrgCurTimeOfUnfullSOC' incorporates:
   *  Constant: '<S6>/Constant4'
   */
  ChrgTgtTimer1 = look2_iu8lu32n31yu16tu_e4FyxcSB(mChargeStep, 2U,
    CBMU_MON_ConstP.pooled11, CBMU_MON_ConstP.pooled12, CBMU_MON_ConstP.pooled5,
    CBMU_MON_ConstP.pooled1, 6UL);

  /* Memory: '<S6>/Memory' */
  com_BPC2MaxChrgCurrent = CBMU_MON_DWork.Memory_PreviousInput;

  /* Update for Memory: '<S6>/Memory' */
  CBMU_MON_DWork.Memory_PreviousInput = ChrgTgtCur;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
