

#include "PBS.h"
#include "Dio.h"

//------------------------------------------------------------------------------  0010110111
union                                                               //fault variaties
  {
    uint8 Byte;
    struct
      {
        unsigned  bit0          : 1;
        unsigned  bit1          : 1;
        unsigned  bit2          : 1;
        unsigned  bit3          : 1;
        unsigned  bit4          : 1;  
        unsigned  bit5          : 1;
        unsigned  bit6          : 1;
        unsigned  bit7          : 1;
          
      } bits;
  }  fault_Kind;
  
#define  fault_kind_flags              fault_Kind.Byte
#define  BitWidth_fault                fault_Kind.bits.bit0
#define  Start_bit_fault               fault_Kind.bits.bit1
#define  Finish_bit_fault              fault_Kind.bits.bit2
#define  Duty_width_fault              fault_Kind.bits.bit3
#define  Check_bit_fault               fault_Kind.bits.bit4
#define  FaultMsgComplete_flag         fault_Kind.bits.bit5
#define  EdgechangeOT_flag             fault_Kind.bits.bit6
#define  Parity_flag                   fault_Kind.bits.bit7
//**********************************************************************************
union                                                               //fault variaties
  {
    uint8 Byte;
    struct
      {
        unsigned  bit0          : 1;          
        unsigned  bit1          : 1;          
        unsigned  bit2          : 1;          
        unsigned  bit3          : 1;          
        unsigned  bit4          : 1;          
        unsigned  bit5          : 1;          
        unsigned  bit6          : 1;          
        unsigned  bit7          : 1;          
      } bits;
  }  OC_Mode;
  
#define  OC_OperationMode        OC_Mode.Byte
#define  Init_delay_period       OC_Mode.bits.bit0
#define  Monitor_heart_period    OC_Mode.bits.bit1
#define  Fault_rsq_period        OC_Mode.bits.bit2
#define  Fault_IC_period         OC_Mode.bits.bit3
#define  Fault_IC_delay_period   OC_Mode.bits.bit4
//------------------------------------------------------------------------------  0010110111
union                                                               //fault variaties
  {
    uint8 Byte;
    struct
      {
        unsigned  bit0          : 1;          
        unsigned  bit1          : 1;          
        unsigned  bit2          : 1;          
        unsigned  bit3          : 1;          
        unsigned  bit4          : 1;          
        unsigned  bit5          : 1;          
        unsigned  bit6          : 1;          
        unsigned  bit7          : 1;          
      } bits;
  }  Communication_state;
  
#define  Fault_period_flag       Communication_state.Byte
#define  FaultRrsq_flag          Communication_state.bits.bit0
#define  FaultRspOver_flag       Communication_state.bits.bit1
#define  FaultMsgWrong_flag      Communication_state.bits.bit2
#define  HeartSignalWrong_flag   Communication_state.bits.bit3
//------------------------------------------------------------------------------  0010110111
uint16  duty_width_a;
uint16  duty_width_b;
uint16  BitWidth_fault_CNT;            // fault record
uint16  Start_bit_fault_CNT;
uint16  Finish_bit_fault_CNT;
uint16  Duty_width_fault_CNT;
uint16  Duty_width_fault_CNT;

uint16  delaytime_a;
uint16  time1;
uint16  time2;
uint16  delaytime_b;
uint16  time3;
uint16  time4;

uint16  Heart_edge_CNT = 0;
uint16  Last_heart_edge_CNT = 0;
uint8   Fault_edge_CNT = 0;
uint16  Init_delay_CNT = 0;
uint16  Fault_start_time;
uint16  Fault_rsp_time;
uint16  Fault_array[20];
uint16  TC3_array[20];


uint8   Fault_Msg[10];
uint8   Fault_Message;
uint8   Fault_Msg_flag = 0;
uint8   Fault_array_CNT;


//------------------------------------------------------------------------------
#define  Start_bit_Value           Fault_Msg[0]
#define  UV_bit_Value              Fault_Msg[1]
#define  OV_bit_Value              Fault_Msg[2]
#define  OT_bit_Value              Fault_Msg[3]
#define  Cell_Num1_Value           Fault_Msg[4]
#define  Cell_Num2_Value           Fault_Msg[5]
#define  Cell_Num3_Value           Fault_Msg[6]
#define  Cell_Num4_Value           Fault_Msg[7]
#define  Parity_bit_Value          Fault_Msg[8]
#define  Finish_bit_Value          Fault_Msg[9]


uint8   Call_fault_rsq = 0;
uint8   Call_fault_rsv_over = 0;

boolean  pbs_heart;
uint8    pbs_faultCode;
uint16   Fault_IC_delay = 1500;
uint8    Fault_rsq_time = 15;


uint8 ect_IcNotFirst;
uint8 ect_CrashOccur;
uint8 ect_AirbagNormal;

uint16 ect_IcCountOld;
uint16 ect_IcPeriod;
uint8  ect_count;

void Ect_Flag_Init(void)
{ 
  ect_IcNotFirst = FALSE ;
  ect_CrashOccur = FALSE  ;
  ect_AirbagNormal = FALSE ;
  ect_count = 0   ;
      
}

void AirBagSingalCapture(void)
{
    uint16 curr_counter;

    SuspendAllInterrupts();

    curr_counter =  ECT_TC0;
  
    if(ect_IcNotFirst == TRUE)
    {
        ect_IcPeriod = curr_counter - ect_IcCountOld;
        
        
        if((ect_IcPeriod > 28125)&&(ect_IcPeriod < 34375) )
        {
            ect_AirbagNormal = TRUE ;
        } 
        else if( ect_IcPeriod < 320 )
        {
            ;
        }
        else
        {
            ect_AirbagNormal = FALSE ;
        }
    
        if( (ect_IcPeriod > 2812)&&(ect_IcPeriod <3238) )
        {
            ect_CrashOccur = TRUE ;
        } 
        else
        {
            ect_CrashOccur = FALSE ;
        }
    }
    else
    {
        ect_IcNotFirst=TRUE;
    }
    
    ect_IcCountOld = curr_counter;
  
    ect_count = 0 ;
    
    ResumeAllInterrupts();
} 



/***********************************************************
2013-06-26, removed

void Pbs_Init(void)
{
  ECT_TSCR1 |= ECT_TSCR1_PRNT_MASK;
  ECT_TSCR1 |= ECT_TSCR1_TFFCA_MASK;
  ECT_TSCR1 |= ECT_TSCR1_TSFRZ_MASK;
  ECT_TSCR1 |= ECT_TSCR1_TEN_MASK;
  
  ECT_TIOS |=  0b00110000; // 1 represent OC / 0 represent IC
  ECT_TIOS &=~ 0b00001100; // donot write to TIOS directly !!!
  
//OC function action 
  ECT_TCTL1 = 0x00;	       // ���ĸ�ͨ������Ϊ��ʱ����������ŶϿ�
  ECT_TCTL2 = 0x00;        // ǰ�ĸ�ͨ������Ϊ��ʱ����������ŶϿ�
  
//IC edge check 
  ECT_TCTL4 = 0xff;        // IC both raising and failing edges
  
//  ECT_TSCR2 = 0x05;	       // Timer Clock=32000000/32=1KHz,ʱ������Ϊ1us,
  ECT_PTPSR = 39;
  
  ECT_TFLG1 = 0xff;	       // �����IC/OC�жϱ�־λ
  ECT_TFLG2 = 0xff;        // ������ɶ�ʱ���жϱ�־λ
  
  Fault_period_flag = 0;
  TIE_C4I_1;  
  Init_delay_period = 1;       // X1
     
   HeartSignalWrong_flag = 1;
   
   DDRT = 0b00000010;

#if (PBS_DEBUG_PIN == STD_ON)          
   DIO_PORTA_DIR = 0xff;
   DIO_PORTB_DIR = 0xff;
   DIO_PORTS_DIR = 0xff; 
#endif 



}
*/

void Pbs_Init(void)
{
 

  /*Use three channels IOC2,IOC3 and IOC4 in ECT Module for Inpunt Capture;
    Initialization are as follows:*/
  
  ECT_TIOS=0x00;/*Configure channels as input capture*/
  

  /*EDG2B=0,EDG2A=1, EDG1B=0,EDG1A=1,EDG0B=0,EDG0A=1,*/
  //ECT_TCTL3=0x01;/*Capture on rising edges only*/
  ECT_TCTL3=0x00;/* No Capture */
  ECT_TCTL4=0x03;/* Capture on both edges */
  
  /*Delay Counter Select*/
  ECT_DLYCT=0xFF;/*Delay 1024 bus clock cycles*/


//OC function action 
  ECT_TCTL1 = 0x00;	       // ���ĸ�ͨ������Ϊ��ʱ����������ŶϿ�
  ECT_TCTL2 = 0x00;        // ǰ�ĸ�ͨ������Ϊ��ʱ����������ŶϿ�

  /*TEN=1,TSWAI=1,FSFRZ=1,TFFCA=0,PRNT=1*/
  /*Enable Timer,Precision Timer,No Fast Flag Clear;*/ 
  /*Timer Module Stops While in Wait or  Freeze Mode.*/
  ECT_TSCR1=0xE8;
    
    
  /*Input Overwrite Control*/
  //ECT_ICOVW=0x07; /*No Input Capture Overwrite*/
  
  /*SHxy=0,TFMOD=0,BUFFEN=0*/
  //ECT_ICSYS=0x00; /*No Share Input Action,Non Queue Mode,Disable IC Buffer*/
  
  /*Precision Timer Prescaler Slect*/
  ECT_PTPSR = 255;    /*Prescale Factor=256 => Frequency of TCNT=Bus Frequency/10*/ 
  //ECT_PTMCPSR = 254;  /*Prescale Factor=128 => 1/(128*255)=1/32K -> 1ms */
  
  Fault_period_flag = 0;
  
  /*Timer Interrupt Enable for configured Inpunt Capture channels*/
  TIE_C0I_1;  
  
  Init_delay_period = 1;       // X1
     
  //HeartSignalWrong_flag = 1;
  
  HeartSignalWrong_flag = 0;
  
  DDRT = 0b00000010;


}



/*****************************************************************/
void Pbs_HeartSigProcess(void)
{
  if ((ECT_TFLG1 & ECT_TFLG1_C2F_MASK) == ECT_TFLG1_C2F_MASK)
      ECT_TFLG1 |= ECT_TFLG1_C2F_MASK;
  
    time1 = time2;
    time2 = ECT_TC2;
    delaytime_a = time2 - time1;
    
       Heart_edge_CNT += 1;
       
#if (PBS_DEBUG_PIN == STD_ON)          
     if (Heart_input == PTT_PTT2_MASK)
         DIO_PORTA |=  PORTA_PA0_MASK;         
     else    
        DIO_PORTA &=~  PORTA_PA0_MASK;
#endif 

  if ((Init_delay_period == 0) && (Fault_rsq_period == 0) && 
      (Fault_IC_period == 0)   && (Fault_IC_delay_period == 0) &&
      (Heart_input == 0)) //����������������
     {      
#if (PBS_DEBUG_PIN == STD_ON)    
         DIO_PORTA |= PORTA_PA1_MASK;
#endif  
        
         TIE_C4I_1;                // A2
         Monitor_heart_period = 1; // X2         
    if ((ECT_TFLG1 & ECT_TFLG1_C4F_MASK) == ECT_TFLG1_C4F_MASK)
         ECT_TFLG1 |= ECT_TFLG1_C4F_MASK;
         ECT_TC4 = ECT_TCNT + Std_Heart_period - 50;   
         Last_heart_edge_CNT = Heart_edge_CNT;
      } 
}
/********************************************************/

void Pbs_FaultCodeProcess(void)
{
 if ((ECT_TFLG1 & ECT_TFLG1_C3F_MASK) == ECT_TFLG1_C3F_MASK)
      ECT_TFLG1 |= ECT_TFLG1_C3F_MASK;
  
    time3 = time4;
    time4 = ECT_TC3;
    delaytime_b = time4 - time3;

    if(Fault_edge_CNT != 0)
    Fault_array[Fault_edge_CNT-1] = delaytime_b;
    TC3_array[Fault_edge_CNT] = ECT_TC3;
  
    Fault_edge_CNT += 1;

#if (PBS_DEBUG_PIN == STD_ON)    
      if (Fault_input == PTT_PTT3_MASK)
        {
           DIO_PORTA |= PORTA_PA3_MASK;
           
         if (Fault_edge_CNT == 1)
         {
          DIO_PORTA |= 0x80;
         } 
           
        }
      if (Fault_input != PTT_PTT3_MASK)
        {
           DIO_PORTA &=~ PORTA_PA3_MASK;
        }                
#endif 

     if (Fault_edge_CNT == 20)
     {
         DIO_PORTA &=~ 0x80;
         Fault_edge_CNT = 0;
         Call_fault_rsv_over = 1;
         time4 = 0;
  
         TIE_C4I_1;               // A3
         Fault_IC_period = 0;
         Fault_IC_delay_period = 1;
    if ((ECT_TFLG1 & ECT_TFLG1_C4F_MASK) == ECT_TFLG1_C4F_MASK) 
         ECT_TFLG1 |= ECT_TFLG1_C4F_MASK;
         ECT_TC4 = ECT_TCNT + Fault_IC_delay;     
      }   
}

/********************************************************/

void Pbs_HeartMonitor(void)
{
  if (Init_delay_period)
   {
    if ((ECT_TFLG1 & ECT_TFLG1_C4F_MASK) == ECT_TFLG1_C4F_MASK)
         ECT_TFLG1 |= ECT_TFLG1_C4F_MASK; 
         Init_delay_CNT += 1;
    
       if (Init_delay_CNT < 501)  // every time 10ms,total 5s
         {
                 ECT_TC4 = ECT_TCNT + 10000;  
          }
       else if (Init_delay_CNT == 501)
        {
                  ECT_TC4 = ECT_TCNT + 50;        // delay 50us  
                  TIE_C2I_1;                      // IC heart;         always  ON
                  TIE_C5I_1;                      // OS_monitor        always  ON  
             if ((ECT_TFLG1 & ECT_TFLG1_C5F_MASK) == ECT_TFLG1_C5F_MASK)
                  ECT_TFLG1 |= ECT_TFLG1_C5F_MASK; 
                  ECT_TC5 = ECT_TCNT + 10000;  // 10ms
          }
       else
        {
             Init_delay_period = 0;  // X1
             TIE_C4I_0;              // A1  delay complete
          }
    }
//--------------------------------------------------------------------------------------    
  else if (Monitor_heart_period)
    {
    if ((ECT_TFLG1 & ECT_TFLG1_C4F_MASK) == ECT_TFLG1_C4F_MASK)
         ECT_TFLG1 |= ECT_TFLG1_C4F_MASK; 
                  
#if (PBS_DEBUG_PIN == STD_ON)    
         DIO_PORTA &=~ PORTA_PA1_MASK;
#endif  
           
          if (Heart_edge_CNT - Last_heart_edge_CNT == 1)
           {
                Last_heart_edge_CNT = Heart_edge_CNT; 
                HeartSignalWrong_flag = 0;     
            }
          else
           {  
                HeartSignalWrong_flag = 1;
            }
            
         Monitor_heart_period = 0; // X2 
         TIE_C4I_0;                // A2
    }
//--------------------------------------------------------------------------------------    
  else if (Fault_rsq_period)  
    {
    if ((ECT_TFLG1 & ECT_TFLG1_C4F_MASK) == ECT_TFLG1_C4F_MASK)
         ECT_TFLG1 |= ECT_TFLG1_C4F_MASK; 
         ECT_TC4 = Fault_start_time;
         FaultRsq_0;
#if (PBS_DEBUG_PIN == STD_ON)    
         DIO_PORTA &=~ PORTA_PA2_MASK;
#endif          
   //      TIE_C3I_1;                     // C1
         Fault_edge_CNT = 0;
         
         Heart_edge_CNT = 0;
         Last_heart_edge_CNT = 0;  
         
         Fault_IC_period = 1;
         Fault_rsq_period = 0;          // X4   
         TIE_C4I_0;                     // A4 
    }
//--------------------------------------------------------------------------------------    
  else if (Fault_IC_delay_period)  
    {
    if ((ECT_TFLG1 & ECT_TFLG1_C4F_MASK) == ECT_TFLG1_C4F_MASK)
         ECT_TFLG1 |= ECT_TFLG1_C4F_MASK; 
         TIE_C3I_0;                     // C1
         time4 = 0;
         Fault_edge_CNT = 0;
         
         Fault_IC_delay_period = 0;      // X4   
         TIE_C4I_0;                      // A4  
    }
}

/********************************************************/
void Pbs_FaultMonitor(void)
{
  if ((ECT_TFLG1 & ECT_TFLG1_C5F_MASK) == ECT_TFLG1_C5F_MASK) 
       ECT_TFLG1 |= ECT_TFLG1_C5F_MASK;
       ECT_TC5 = ECT_TCNT + 10000;        // 10ms 
//-------------------------------------------- 
// tell whether the heart beats normally ?       
 
    if (HeartSignalWrong_flag)
      {
         Call_fault_rsq = 1;
         TIE_C4I_1;               // A3
    if ((ECT_TFLG1 & ECT_TFLG1_C4F_MASK) == ECT_TFLG1_C4F_MASK) 
         ECT_TFLG1 |= ECT_TFLG1_C4F_MASK;
         ECT_TC4 = ECT_TCNT + Fault_rsq_time;
         FaultRsq_1; 
         TIE_C3I_1;                     // C1
         
#if (PBS_DEBUG_PIN == STD_ON)    
         DIO_PORTA |= PORTA_PA2_MASK;
#endif       
         Monitor_heart_period = 0;// X2
         Fault_rsq_period = 1;    // X3  
      }      
}

/*************************************************************/
uint8 Final_Result(void)
{
   if ( (Fault_Msg_Step_a() == 0) && (Fault_Msg_Step_b() == 0) && (Fault_Msg_Step_c() == 0) && (Fault_Msg_Step_d() == 0) ) 
    {
           Fault_Msg_flag = 1;
           if(Fault_Msg[1])
              Fault_Message |= 0x80;
           if(Fault_Msg[2])
              Fault_Message |= 0x40;
           if(Fault_Msg[3])
              Fault_Message |= 0x20;
           if(Fault_Msg[4])
              Fault_Message |= 0x10;
           if(Fault_Msg[5])
              Fault_Message |= 0x08;           
           if(Fault_Msg[6])
              Fault_Message |= 0x04;           
           if(Fault_Msg[7])
              Fault_Message |= 0x02;           
           if(Fault_Msg[8])
              Fault_Message |= 0x01;              
           
    }
           fault_kind_flags = 0;
           Duty_width_fault_CNT = 0;
           return (Fault_Msg_flag);
}  
/*************************************************************/
uint8 Fault_Msg_Step_a (void)
{
//   step_1: check the start bit

     duty_width_a = 3 * Fault_array[0];          //25%
     duty_width_b = Fault_array[1];              //75%
     
          if(duty_width_a < duty_width_b)
          {
              if(duty_width_b-duty_width_a<=5)
                {
                   Start_bit_fault = 0;
                } 
              else    
                {
                   Start_bit_fault = 1;
                   Start_bit_fault_CNT += 1;  
                }       
           }
      
          else
           {
                if(duty_width_a-duty_width_b<=5)
                 {
                   Start_bit_fault = 0;
                 }     
                else
                 {
                   Start_bit_fault = 1;
                   Start_bit_fault_CNT += 1;  
                 }
            }      
            
          Fault_Msg[0] = 0;
          return (Start_bit_fault);
}
/*************************************************************/
uint8 Fault_Msg_Step_b (void)
{
//   step_2: check the finish bit 

     duty_width_a = Fault_array[18];
     duty_width_b = 4 * duty_width_a / 3;
     
       if(  (FaultBitWidth_Min < duty_width_b) && (duty_width_b < FaultBitWidth_Max)  )
        {
             Finish_bit_fault = 0;
        }
       else
        {
             Finish_bit_fault = 1;
             Finish_bit_fault_CNT += 1;
        }
        
        Fault_Msg[9] = 1;
        Parity_flag=~Parity_flag;                              //parity
        return (Finish_bit_fault);
}
/*************************************************************/
uint16 Fault_Msg_Step_c (void)
{    
//   step_3: check the Duty width of the fault��cell�pparity bits
   
       for(Fault_array_CNT=2; Fault_array_CNT<18; Fault_array_CNT+=2)
       {   
               
         if(Fault_array[Fault_array_CNT] < Fault_array[Fault_array_CNT+1])
            {
              duty_width_a = 3 * Fault_array[Fault_array_CNT];
              duty_width_b = Fault_array[Fault_array_CNT+1]; 
              Fault_Msg[Fault_array_CNT/2] = 0;
            }
         else
            {
              duty_width_a = Fault_array[Fault_array_CNT];
             duty_width_b = 3 * Fault_array[Fault_array_CNT+1];
              Fault_Msg[Fault_array_CNT/2] = 1;
              
              if(Fault_array_CNT != 16)
                {
                   Parity_flag=~Parity_flag;                     //parity
                }              
            } 

                    if(duty_width_a < duty_width_b)
                     {
                       if(duty_width_b - duty_width_a <= 5)
                        {
                           Duty_width_fault = 0;
                         }                 
                       else
                        {
                            Duty_width_fault = 1;
                            Duty_width_fault_CNT += 1;
                         }
                     }

                     else
                      {
                       if(duty_width_a - duty_width_b <= 5)
                        {
                            Duty_width_fault = 0;
                        }                 
                       else
                        {
                            Duty_width_fault = 1;
                            Duty_width_fault_CNT += 1;
                        }
                      } 
       }
        return (Duty_width_fault_CNT);
}
/*************************************************************/
uint8 Fault_Msg_Step_d (void)
{
//   step_4: check the parity bit

     if(Parity_bit_Value != Parity_flag)
        Check_bit_fault=1;
     else
        Check_bit_fault=0;
      return (Check_bit_fault);
}

void Pbs_Task(void)
{
  if(Call_fault_rsq && Call_fault_rsv_over)
  {
    if (Final_Result())
    {          
      Fault_Msg_flag = 0;
      Call_fault_rsq = 0;
      Call_fault_rsv_over = 0;   
   }    
  }
  
  Mcu_SuspendAllInterrupt();
  
  pbs_heart = HeartSignalWrong_flag;
  pbs_faultCode = Fault_Message;  
  
  Mcu_ResumeAllInterrupt();
    
}





