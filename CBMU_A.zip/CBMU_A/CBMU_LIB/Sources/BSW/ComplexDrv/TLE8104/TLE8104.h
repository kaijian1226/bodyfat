/*******************************************************************************
*
*  FILE
*     TLE8104.h
*
*  DESCRIPTION
*      TLE8104 module header file 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*                            
*  VERSION
*    1.0.0
*
*******************************************************************************/

#ifndef _TLE8104_H_
#define _TLE8104_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "TLE8104_Types.h"
#include "TLE8104_Cfg.h"
#include "Spi.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Vendor ID. */
#define TLE8104_VENDOR_ID           6666

/* Module ID  */
#define TLE8104_MODULE_ID           250

/* Version number of the module */
#define TLE8104_SW_MAJOR_VERSION    1
#define TLE8104_SW_MINOR_VERSION    0
#define TLE8104_SW_PATCH_VERSION    0

#define DIO_PORTK  (*(volatile uint8*) 0x00000032)    
#define DIO_DDRK   (*(volatile uint8*) 0x00000033)


#define TLE8104_OC      0x01
#define TLE8104_STG     0x02
#define TLE8104_OT      0x04
#define TLE8104_WON     0x08 
#define TLE8104_WOFF    0x10    // Wrong Pin Status

#define TLE8104_WON_WOFF 0x18

#define TLE8104_CMD_RESUME         0
#define TLE8104_CMD_SHUTDOWN       1
#define TLE8104_CMD_FORCEON        2

#define TLE8104_INIT_ERR           0x10
#define TLE8104_SPI_ERR            0x20


#define TLE8104_SPI_UNKNOWN        0
#define TLE8104_SPI_KO             1
#define TLE8104_SPI_OK             2
#define TLE8104_SPI_INIT_ERR       3


#define TLE8104_FAULT_MASK         0x30

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern uint8 tle8104_currSts[TLE8104_MODULE_NUM];
extern uint8 TLE8104_VAR tle8104_SpiSts[TLE8104_MODULE_NUM];
/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,TLE8104_CODE) Tle8104_Init(void);
extern void TLE8104_CODE Tle8104_StartDiagTask(void);
extern void TLE8104_CODE Tle8104_ReadDiagDataTask(void);
extern void TLE8104_CODE Tle8104_Output(uint8 moduleNum, boolean Sts);
extern Std_ReturnType TLE8104_CODE Tle8104_CmdReq(uint8 tleCh,uint8 ch,uint8 cmd);

#endif /* _TLE8104_H_ */




