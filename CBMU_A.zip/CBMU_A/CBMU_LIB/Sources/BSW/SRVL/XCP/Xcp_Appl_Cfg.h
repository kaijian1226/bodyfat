/*******************************************************************************
*
*  FILE
*     Xcp_Appl_Cfg.h
*
*  DESCRIPTION
*     The Application Configuration Header file for Xcp Module
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

#ifndef _XCP_APPL_CFG_H_
#define _XCP_APPL_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Xcp_Types.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*************************************
* Configuration Related                                                                
*************************************/
#define XCP_PAGE_SWITCHING          STD_OFF

#define XCP_SEED_LENGTH             2 
#define XCP_KEY_LENGTH              2 


/* 2000 global address minus 2000*/
#define XCP_GLOBAL_NEAR_RAM_OFFSET         0xFC000UL
/* 4000 global address minus 4000*/
#define XCP_GLOBAL_NEAR_ROM_OFFSET         0x7F0000UL

/* use non banked address if in near rom and use global address if in banked rom*/
//#define XCP_CALRAM_START            0x3380UL
#define XCP_CALRAM_START            0xF0000UL

/* use non banked address if in near rom and use global address if in banked rom*/
//#define XCP_CALROM_START            0x4000UL
#define XCP_CALROM_START            0x7F0000UL

#define XCP_CALRAM_SIZE             0x100


#if (XCP_CALROM_START < 0x10000UL)
  #define XCP_CAL_ROM_NEAR            STD_ON
#else
  #define XCP_CAL_ROM_NEAR            STD_OFF
#endif

#if (XCP_CALRAM_START >= 0x2000UL) && (XCP_CALRAM_START <= 0x3FFFUL)
  #define XCP_CAL_RAM_NEAR            STD_ON
#else
  #define XCP_CAL_RAM_NEAR            STD_OFF
#endif 


/*************************************
* Data Type                                                               
*************************************/
#if (XCP_CAL_ROM_NEAR == STD_ON) && (XCP_CAL_RAM_NEAR == STD_ON)
  typedef sint16 Xcp_EcuPageOffsetType;
#else
  typedef sint32 Xcp_EcuPageOffsetType;
#endif

typedef sint32 Xcp_XcpPageOffsetType;

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


#if (XCP_CAL_ROM_NEAR == STD_ON) && (XCP_CAL_RAM_NEAR == STD_ON)
  #define XCP_ACCESS_CAL_LABEL(X,Y)  (*((X* )(((&Y) + ecu_page_offset))))
#else
  #define XCP_ACCESS_CAL_LABEL(X,Y)  (*((X* XCP_VAR_FAR)(((uint32)(&Y) + ecu_page_offset))))
#endif


#define XCP_GET_NEAR_RAM_GLOBAL_ADDR(X)      (X + XCP_GLOBAL_NEAR_RAM_OFFSET)
#define XCP_GET_NEAR_ROM_GLOBAL_ADDR(X)      (X + XCP_GLOBAL_NEAR_ROM_OFFSET)

#define XCP_GET_CAL_GLOBAL_ADDR(X)           (X + xcp_page_offset)


#if (XCP_CAL_ROM_NEAR == STD_ON)
  #define XCP_CALROM_START_GLOBLE_ADDR  (XCP_GET_NEAR_ROM_GLOBAL_ADDR(XCP_CALROM_START))
#else
 #define XCP_CALROM_START_GLOBLE_ADDR   (XCP_CALROM_START)
#endif

#if (XCP_CAL_RAM_NEAR == STD_ON)
  #define XCP_CALRAM_START_GLOBLE_ADDR  (XCP_GET_NEAR_RAM_GLOBAL_ADDR(XCP_CALRAM_START))
#else
 #define XCP_CALRAM_START_GLOBLE_ADDR   (XCP_CALRAM_START)
#endif


/* CAL ROM offset for global address conversion */
#if (XCP_CAL_ROM_NEAR == STD_ON)
  #define XCP_CALROM_OFFSET_FOR_ECU (XCP_GLOBAL_NEAR_ROM_OFFSET)
#else
  #define XCP_CALROM_OFFSET_FOR_ECU (0)
#endif


#define XCP_CALROM_OFFSET_FOR_XCP   XCP_CALROM_OFFSET_FOR_ECU

/* XCP_CALRAM_OFFSET_FOR_ECU is the offset between reference page and working page */
/* CAL RAM AND ROM OFFSET  */
#if (XCP_CAL_ROM_NEAR == STD_ON) && (XCP_CAL_RAM_NEAR == STD_ON)

  #define XCP_CALRAM_OFFSET_FOR_ECU            (XCP_CALRAM_START - XCP_CALROM_START)

#elif (XCP_CAL_ROM_NEAR == STD_ON) && (XCP_CAL_RAM_NEAR == STD_OFF)   

  #define XCP_CALRAM_OFFSET_FOR_ECU            (XCP_CALRAM_START_GLOBLE_ADDR - XCP_CALROM_START)

#else

  #define XCP_CALRAM_OFFSET_FOR_ECU            (XCP_CALRAM_START_GLOBLE_ADDR - XCP_CALROM_START_GLOBLE_ADDR)
  
#endif

#if (XCP_CAL_RAM_NEAR == STD_ON)
  #define XCP_CALRAM_OFFSET_FOR_XCP             (XCP_CALRAM_START + XCP_GLOBAL_NEAR_RAM_OFFSET - XCP_CALROM_START)
#else
  #define XCP_CALRAM_OFFSET_FOR_XCP             (XCP_CALRAM_START - XCP_CALROM_START)
#endif   
       

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/




#endif /* #ifndef _XCP_APPL_H_ */