/*******************************************************************************
*
*  FILE
*     Xcp.h
*
*  DESCRIPTION
*     The Header file for Xcp Module  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

#ifndef _XCP_H_
#define _XCP_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Xcp_Cfg.h"
#include "Xcp_Types.h"
#include "Xcp_Appl.h"
#include "Xcp_CanIf.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* Vendor ID. */
#define XCP_VENDOR_ID           6666

/* Module ID  */
#define XCP_MODULE_ID           212

/* Version number of the module */
#define XCP_SW_MAJOR_VERSION    1
#define XCP_SW_MINOR_VERSION    0
#define XCP_SW_PATCH_VERSION    0


#define XCP_INSTATNCE_ID          1

#define XCP_API_SERVICE           1

#define XCP_E_EVENT_CH_NA         0x01

/* Standard commands (STD) */
#define XCP_CMD_CODE_CONNECT                      0xFF
#define XCP_CMD_CODE_DISCONNECT                   0xFE
#define XCP_CMD_CODE_GET_STATUS                   0xFD
#define XCP_CMD_CODE_SYNCH                        0xFC
#define XCP_CMD_CODE_GET_COMM_MODE_INFO           0xFB
#define XCP_CMD_CODE_GET_ID                       0xFA
#define XCP_CMD_CODE_SET_REQUEST                  0xF9
#define XCP_CMD_CODE_GET_SEED                     0xF8
#define XCP_CMD_CODE_UNLOCK                       0xF7
#define XCP_CMD_CODE_SET_MTA                      0xF6
#define XCP_CMD_CODE_UPLOAD                       0xF5
#define XCP_CMD_CODE_SHORT_UPLOAD                 0xF4
#define XCP_CMD_CODE_BUILD_CHECKSUM               0xF3

#define XCP_CMD_CODE_TRANSPORT_LAYER_CMD          0xF2
#define XCP_CMD_CODE_USER_CMD                     0xF1

/* Calibration commands (CAL) */
#define XCP_CMD_CODE_DOWNLOAD                     0xF0
#define XCP_CMD_CODE_DOWNLOAD_NEXT                0xEF
#define XCP_CMD_CODE_DOWNLOAD_MAX                 0xEE
#define XCP_CMD_CODE_SHORT_DOWNLOAD               0xED
#define XCP_CMD_CODE_MODIFY_BITS                  0xEC

/* Page switching commands (PAG) */
#define XCP_CMD_CODE_SET_CAL_PAGE                 0xEB
#define XCP_CMD_CODE_GET_CAL_PAGE                 0xEA
#define XCP_CMD_CODE_GET_PAG_PROCESSOR_INFO       0xE9
#define XCP_CMD_CODE_GET_SEGMENT_INFO             0xE8
#define XCP_CMD_CODE_GET_PAGE_INFO                0xE7
#define XCP_CMD_CODE_SET_SEGMENT_MODE             0xE6
#define XCP_CMD_CODE_GET_SEGMENT_MODE             0xE5
#define XCP_CMD_CODE_COPY_CAL_PAGE                0xE4

/* Data acquisition and Stimulation commands (DAQ) */
#define XCP_CMD_CODE_CLEAR_DAQ_LIST               0xE3
#define XCP_CMD_CODE_SET_DAQ_PTR                  0xE2
#define XCP_CMD_CODE_WRITE_DAQ                    0xE1
#define XCP_CMD_CODE_SET_DAQ_LIST_MODE            0xE0
#define XCP_CMD_CODE_GET_DAQ_LIST_MODE            0xDF
#define XCP_CMD_CODE_START_STOP_DAQ_LIST          0xDE
#define XCP_CMD_CODE_START_STOP_SYNCH             0xDD
#define XCP_CMD_CODE_GET_DAQ_CLOCK                0xDC
#define XCP_CMD_CODE_READ_DAQ                     0xDB
#define XCP_CMD_CODE_GET_DAQ_PROCESSOR_INFO       0xDA
#define XCP_CMD_CODE_GET_DAQ_RESOLUTION_INFO      0xD9
#define XCP_CMD_CODE_GET_DAQ_LIST_INFO            0xD8
#define XCP_CMD_CODE_GET_DAQ_EVENT_INFO           0xD7
#define XCP_CMD_CODE_FREE_DAQ                     0xD6
#define XCP_CMD_CODE_ALLOC_DAQ                    0xD5
#define XCP_CMD_CODE_ALLOC_ODT                    0xD4
#define XCP_CMD_CODE_ALLOC_ODT_ENTRY              0xD3

/* Non-volatile memory programming commands (PGM)*/
#define XCP_CMD_CODE_PROGRAM_START                0xD2
#define XCP_CMD_CODE_PROGRAM_CLEAR                0xD1
#define XCP_CMD_CODE_PROGRAM                      0xD0
#define XCP_CMD_CODE_PROGRAM_RESET                0xCF
#define XCP_CMD_CODE_GET_PGM_PROCESSOR_INFO       0xCE
#define XCP_CMD_CODE_GET_SECTOR_INFO              0xCD
#define XCP_CMD_CODE_PROGRAM_PREPARE              0xCC
#define XCP_CMD_CODE_PROGRAM_FORMAT               0xCB
#define XCP_CMD_CODE_PROGRAM_NEXT                 0xCA
#define XCP_CMD_CODE_PROGRAM_MAX                  0xC9
#define XCP_CMD_CODE_PROGRAM_VERIFY               0xC8

/***********************************************************************
        Symbolic Definition of additional command parameters  
***********************************************************************/

/* DAQ list start/stop modes (START_STOP_DAQ_LIST) */
#define XCP_DAQ_LIST_STOP                         0x00
#define XCP_DAQ_LIST_START                        0x01
#define XCP_DAQ_LIST_SELECT                       0x02

/* DAQ list start/stop modes (START_STOP_SYNCH) */
#define XCP_DAQ_LIST_STOP_ALL                     0x00
#define XCP_DAQ_LIST_START_SELECTED               0x01
#define XCP_DAQ_LIST_STOP_SELECTED                0x02

/* checksum types */
#define XCP_ADD_11                                0x01
#define XCP_ADD_12                                0x02
#define XCP_ADD_14                                0x03
#define XCP_USER_DEFINED                          0xFF

/***********************************************************************
        Symbolic Definition of additional command parameters  
***********************************************************************/

#define XCP_E_INV_POINTER                         0x01
#define XCP_E_NOT_INITIALIZED                     0x02
#define XCP_E_INVALID_PDUID                       0x03
#define XCP_E_NULL_POINTER                        0x12

#define XCP_ERR_CMD_SYNCH                         0x00
#define XCP_ERR_CMD_BUSY                          0x10
#define XCP_ERR_DAQ_ACTIVE                        0x11
#define XCP_ERR_PGM_ACTIVE                        0x12
#define XCP_ERR_CMD_UNKNOWN                       0x20
#define XCP_ERR_CMD_SYNTAX                        0x21
#define XCP_ERR_OUT_OF_RANGE                      0x22
#define XCP_ERR_WRITE_PROTECTED                   0x23
#define XCP_ERR_ACCESS_DENIED                     0x24
#define XCP_ERR_ACCESS_LOCKED                     0x25
#define XCP_ERR_PAGE_NOT_VALID                    0x26
#define XCP_ERR_MODE_NOT_VALID                    0x27
#define XCP_ERR_SEGMENT_NOT_VALID                 0x28
#define XCP_ERR_SEQUENCE                          0x29
#define XCP_ERR_DAQ_CONFIG                        0x2A
#define XCP_ERR_MEMORY_OVERFLOW                   0x30
#define XCP_ERR_GENERIC                           0x31
#define XCP_ERR_VERIFY                            0x32

/***********************************************************************
        symbolic definitions of PID types  
***********************************************************************/
#define XCP_PID_RES                               0xFF
#define XCP_PID_ERR                               0xFE
#define XCP_PID_EV                                0xFD
#define XCP_PID_SERV                              0xFC

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global Constant declaration                         
*******************************************************************************/
extern CONST(Xcp_EventChannelInfoType,XCP_CONST) Xcp_EventInfo_C[XCP_MAX_EVENT_CHANNEL];

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,XCP_CODE) Xcp_Init(void);
extern FUNC(void,XCP_CODE) Xcp_Background(void); 
extern FUNC(void,XCP_CODE) Xcp_Service(uint16 event_channel);
extern FUNC(void,XCP_CODE) Xcp_GetVersionInfo(Std_VersionInfoType* versioninfo);

#endif /* #ifndef _XCP_H_ */