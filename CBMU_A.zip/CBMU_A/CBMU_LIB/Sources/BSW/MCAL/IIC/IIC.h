/*******************************************************************************
*
*  FILE
*     IIC.h
*
*  DESCRIPTION
*     The Header file for freescale IIC
*      
*       
*  COPYRIGHT
*     (c)Copyright 2011, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*    Gu Bin
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

#ifndef __IIC_H__
#define __IIC_H__

/*******************************************************************************
* include files
*******************************************************************************/

#include "Std_Types.h" /* platform types from AUTOSAR */
#include "IIC_Cfg.h"

/*******************************************************************************
* Defines
*******************************************************************************/


/*******************************************************************************
* Macros
*******************************************************************************/
/* define iic regsiter */

#define IIC0_IBCR           (*(volatile uint8*) 0x000000E2)
#define IIC0_IBDR           (*(volatile uint8*) 0x000000E4) 
#define IIC0_IBFD           (*(volatile uint8*) 0x000000E1) 
#define IIC0_IBCR2          (*(volatile uint8*) 0x000000E5) 
#define IIC0_IBAD           (*(volatile uint8*) 0x000000E0) 
#define IIC0_IBSR           (*(volatile uint8*) 0x000000E3) 


#define PTFRR               (*(volatile uint8*) 0x0000037F) 
 

 /* IIC control register bit */                          
 #define IIC_IBCR_IBSWAI_MASK            1
 #define IIC_IBCR_RSTA_MASK              4
 #define IIC_IBCR_TXAK_MASK              8
 #define IIC_IBCR_TX_RX_MASK             16
 #define IIC_IBCR_MS_SL_MASK             32
 #define IIC_IBCR_IBIE_MASK              64
 #define IIC_IBCR_IBEN_MASK              128 
 /* IIC status register bit */   
 #define IIC_IBSR_RXAK_MASK              1
 #define IIC_IBSR_IBIF_MASK              2
 #define IIC_IBSR_SRW_MASK               4
 #define IIC_IBSR_IBAL_MASK              16
 #define IIC_IBSR_IBB_MASK               32
 #define IIC_IBSR_IAAS_MASK              64
 #define IIC_IBSR_TCF_MASK               128
 
 /* IIC control register 2 bit */    
 #define IIC_IBCR2_ADR8_MASK             1
 #define IIC_IBCR2_ADR9_MASK             2
 #define IIC_IBCR2_ADR10_MASK            4
 #define IIC_IBCR2_ADTYPE_MASK           64
 #define IIC_IBCR2_GCEN_MASK             128
 #define IIC_IBCR2_ADR_8_MASK            7
 #define IIC_IBCR2_ADR_8_BITNUM          0


#define IIC_Routing()       (PTFRR|=0x00)         //set port PJ6,PJ7 as SDA,SCL related pins
/*******************************************************************************
* Global Variables declaration
*******************************************************************************/


/*******************************************************************************
* Global functions declaration
*******************************************************************************/
extern Std_ReturnType IIC_Wait(void);
extern Std_ReturnType IIC_WaitTransmit(void);

extern void IIC_Init(void);
extern Std_ReturnType IIC_ReceiveOneByte(IIC_ADDR_TYPE slaver_addr, uint8 operation_addr ,uint8 *iic_rx);
extern Std_ReturnType IIC_SendOneByte(IIC_ADDR_TYPE slaver_addr, uint8 operation_addr ,uint8 iic_tx);
extern Std_ReturnType IIC_ReceiveMulByte(IIC_ADDR_TYPE slaver_addr, uint8 operation_addr ,uint8 length, uint8 *iic_rx);
extern Std_ReturnType IIC_SendMulByte(IIC_ADDR_TYPE slaver_addr, uint8 operation_addr ,uint8 length, uint8 *iic_tx);

#endif /* #ifndef __IIC_H__ */
