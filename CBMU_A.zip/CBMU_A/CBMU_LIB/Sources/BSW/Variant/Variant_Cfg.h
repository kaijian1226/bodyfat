#ifndef _VARIANT_CFG_H_
#define _VARIANT_CFG_H_

#include "Std_Types.h"      




#endif 