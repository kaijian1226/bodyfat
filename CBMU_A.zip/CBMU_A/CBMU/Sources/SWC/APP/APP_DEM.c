

#include "Variant_Cfg.h"
#include "VFB.h"





void  Dcm_SetNegResponse(uint8 errorCode);
void  Dcm_ProcessingDone(void);


#define DEM_START_SEC_FAULT_ROM
#include "MemMap.h"
 
#define DEM_STOP_SEC_FAULT_ROM
#include "MemMap.h"

typedef enum
{
  REPORT_NUM_DTC = 0,
  REPORT_DTC_STATE = 1,
}Dem_DTCMaskType ;


typedef struct 
{
  uint8*  reqData;
  uint16    reqDataLen; 
  uint8*  resData;
  uint16    resDataLen; 
  uint8             resOnReq;       /* 0x00: No   0x01: Yes */ 
} Dcm_MsgContextType;



/*******************************************************************************
* NAME:             Dcm_ApplReportNumberOfDTC
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/

void Dcm_ApplReportNumberOfDTC(Dcm_MsgContextType* pMsgContext)
{
  uint8 mask;
                                                       
  mask = pMsgContext->reqData[0] ;
  
  if( mask == 0xFF)
    {
      pMsgContext->resData[0] = 0xFF ;
      pMsgContext->resDataLen = Dem_DtcAssembly(&pMsgContext->resData[0],REPORT_NUM_DTC)+1;
    }
  else 
    {
      //Dcm_SetNegResponse(DCM_E_REQUESTOUTOFRANGE);
      Dcm_SetNegResponse(0x31); 
    }
   
  Dcm_ProcessingDone();
}

