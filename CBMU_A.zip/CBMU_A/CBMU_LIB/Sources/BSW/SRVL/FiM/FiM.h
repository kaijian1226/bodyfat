/*******************************************************************************
*
*  FILE
*     FiM.h
*
*  DESCRIPTION
*     The Header file for FiM module  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

#ifndef _FIM_H_
#define _FIM_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "FiM_Types.h"
#include "FiM_Cfg.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Vendor ID. */
#define FIM_VENDOR_ID           6666

/* Module ID  */
#define FIM_MODULE_ID           11

/* Version number of the module */
#define FIM_SW_MAJOR_VERSION    1
#define FIM_SW_MINOR_VERSION    0
#define FIM_SW_PATCH_VERSION    0


#define FIM_FID_EMPTY       ((FiM_FunctionIdType)0xFF)

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,FIM_CODE) FiM_Init(void);
extern FUNC(Std_ReturnType,FIM_CODE) FiM_GetFunctionPermission(FiM_FunctionIdType FID,boolean* Permission);
extern FUNC(void,FIM_CODE) FiM_DemTriggerOnEventStatus(Dem_EventIdType EventId, uint8 EventStatus);
extern FUNC(void,FIM_CODE) FiM_GetVersionInfo(Std_VersionInfoType* versioninfo);

#endif /* #ifndef _FIM_H_ */