/*******************************************************************************
*
*  FILE
*     Can_Cfg.c
*
*  DESCRIPTION
*     The CAN driver configuration  CANͨ������
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Can.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/
/* 140, 180, 1C0, 200, 280 */
CONST(uint16,CAN_CONST)Can_InitBasisAdr_C[CAN_USED_NUM_OF_CHANNEL] = 
{
  (uint16)0x0140,
  (uint16)0x0180,
  (uint16)0x01C0,
};


/* Initialization  BEGIN */
CONST(Can_ConfigType,CAN_CONST)Can_InitObject_C[CAN_USED_NUM_OF_CHANNEL] = 
{
  { //inner can 9.16 AAA 500k
    0x04 /* Control register 0 */, 
    0x84 /* Control register 1 */, 
    0x00 /* Bustiming register 0 */, 
    0x14 /* Bustiming register 1 */, 
    0x00 /* Acceptance control register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFE /* ID mask register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFE /* ID mask register */
  },
  { //CAN����250K 9.16 AAA����CAN  20150831
    0x04 /* Control register 0 */, 
    0x84 /* Control register 1 */, 
    0x00 /* Bustiming register 0 */, 
    0x1C /* Bustiming register 1 1CΪ250k  14Ϊ500k  20150831*/, 
    0x00 /* Acceptance control register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFE /* ID mask register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFE /* ID mask register */
  },
  { //���CAN250K 9.16 AAA
    0x04 /* Control register 0 */, 
    0x84 /* Control register 1 */, 
    0x00 /* Bustiming register 0 */, 
    0x1C /* Bustiming register 1 */, 
    0x00 /* Acceptance control register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFE /* ID mask register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0x00 /* ID acceptance register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFF /* ID mask register */, 
    0xFE /* ID mask register */
  },    
};
/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/
