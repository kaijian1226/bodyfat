/*******************************************************************************
*
*  FILE
*     Com.h
*
*  DESCRIPTION
*     The Header file for Com module  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    0.01
*
*******************************************************************************/

#ifndef _COM_H_
#define _COM_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Com_Types.h"
#include "Com_Cfg.h"
#include "SD2405.h"
#include "Variant_Cfg.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/


#define COM_TX_FREE     0 //����
#define COM_TX_REQ      1 //����
#define COM_TX_XMT      2 //������

#define COM_PDU_LENGTH_NA   (0xFFFF)

#define COM_SIG_NA_2BITS    (3)
#define COM_SIG_ERR_2BITS   (3)// (2) 2015-7-23
#define COM_SIG_NA_BYTE    (0xFF)
#define COM_SIG_ERR_BYTE   (0xFF)// (0xFE) 2015-7-23
#define COM_SIG_NA_WORD    (0xFF00)
#define COM_SIG_ERR_WORD   (0xFF00)// (0xFE00) 2015-7-23
#define COM_SIG_NA_LONG    (0xFF000000)
#define COM_SIG_ERR_LONG   (0xFF000000)// (0xFE000000)     2015-7-23
/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*****************************************************
RX
*****************************************************/
//BMU from Inner Bus 
extern uint8 PackCurMode;            /* '<Root>/PackCurMode' */
extern uint8  com_CellTemp[25][5];

extern uint8  com_BalanceSts[25];
extern uint8  com_CellTempAvrg[25];
extern uint8  com_CellTempMax[25];
extern uint8  com_CellTempMin[25];
extern uint8  com_CellTempMaxNum[25];
extern uint8  com_CellTempMinNum[25];
extern uint8  com_CurSet[25];
extern uint8  com_ModuleStatus[25];
extern uint8  com_CellAlarm[25];

//HVCU from Inner Bus 
extern uint16 com_BattVoltOrg;
extern uint16 com_BattCurr;
extern uint16 com_Resistance;
extern uint16 com_ResistancePos;
extern uint16 com_ResistanceNeg;
extern uint8  com_SOC;

//HVCU HVA1
extern uint32 com_hva1Alarm;
extern uint8 com_hva1ModuleSts;
extern uint16 com_hva1FaultCode;

// From Tester,
extern uint16 com_testCmd;
extern uint8 com_testAuto;

// From Vehicle Bus, Chrgr
extern uint8  com_CCP1HwFault;
extern uint8  com_CCP1ACConnect;
extern uint8  com_CCP1TempSts;
extern uint8  com_CCP1CommSts;
extern uint8  com_CCP1ACRange;
extern uint8  com_CCP1ChrgrTemp;
extern uint8  com_CCP1ChrgrPreReadySts;
extern uint16 com_CCP1ChrgCurrOut;
extern uint16 com_CCP1ChrgVolt;

//From Motor, Vehicle Bus.
extern uint8 com_MSP3MotorTrq;
extern uint16 com_MSP3MotorSpd;

extern uint16 com_MSP1MotorDcVolt;
extern uint16 com_MSP1MotorDcCurr;

//From Dashboard, Vehicle Bus
extern uint32 com_VDTotalOdometer;
extern uint32 com_VDTripOdometer;

// From Fast Charger, Fast Charger Bus
extern uint16 com_CSOutVolt;
extern uint16 com_CSOutCurrent;
extern uint16 com_CSStatus1;
extern uint16 com_CSStatus2;

extern uint16 com_CCMaxChrgVolt;
extern uint16 com_CCMaxChrgCurr;
extern uint8  com_CCChrgSts;

//add by xql for fast charge Rx Msg,20150709
//CRM
extern uint8  com_CRM_RecResult;
extern uint8  com_CRM_ChgerNum;
extern uint8  com_CRM_AreaCode[6];
//CTS  Optional
extern uint8  com_CTS_Seconds;
extern uint8  com_CTS_Minute;
extern uint8  com_CTS_Hour;
extern uint8  com_CTS_Day;
extern uint8  com_CTS_Month;
extern uint16 com_CTS_Year;
//CML
extern uint16 com_CML_MaxOutVolt;
extern uint16 com_CML_MinOutVolt;
extern uint16 com_CML_MaxOutCurrent;
//CRO
extern uint8  com_CRO_ChgerReady;
//CCS
extern uint16 com_CCS_OutVolt;
extern uint16 com_CCS_OutCurrent;
extern uint16 com_CCS_AccChgedTime;
//CST
extern uint8  com_CST_FaultStop;
extern uint8  com_CST_ManualStop;
extern uint8  com_CST_ConditionalStop;

extern uint8  com_CST_EnergyTransFault;
extern uint8  com_CST_InnerOverTempFault;
extern uint8  com_CST_ConnecterFault;
extern uint8  com_CST_OverTempFault;
extern uint8  com_CST_OtherFault;
extern uint8  com_CST_EmergencyFault;

extern uint8  com_CST_VoltError;
extern uint8  com_CST_CurrentError;
//CSD
extern uint16 com_CSD_TotalChgedTime;
extern uint16 com_CSD_TotalOutEnergy;
extern uint8  com_CSD_ChgerNum;
//CEM
extern uint8  com_CEM_RcvBMSRecedMsg;
extern uint8  com_CEM_RcvBMSReadyMsg;
extern uint8  com_CEM_RcvChgParMsg;
extern uint8  com_CEM_RcvBMSStopMsg;
extern uint8  com_CEM_RcvBMSReqMsg;
extern uint8  com_CEM_RcvChgStateMsg;
extern uint8  com_CEM_RcvBMSTotalMsg;


/*****************************************************
TX
*****************************************************/
// From SWC To Inner Bus
extern uint8 com_BalEnable[25];
extern uint8 com_CurrentSet;
extern uint8 com_ShutDown;
extern uint8 com_chrgCmd;
extern uint8 com_chrgCellNum;
extern uint8 com_chrgDuration;

// To Vehicle Bus
extern uint16 com_BPVP1BattVolt;
extern uint16 com_BPVP1MaxCellVolt;
extern uint16 com_BPVP1MinCellVolt;
extern uint16 com_BPVP1AvrgCellVolt;
extern uint16 com_BPVP1MaxCellNum;
extern uint16 com_BPVP1MinCellNum;

extern uint8 com_BPTP1MaxCellNum;
extern uint8 com_BPTP1MinCellNum;
extern uint8 com_BPTP1MinCellTemp;
extern uint8 com_BPTP1MaxCellTemp;
extern uint8 com_BPTP1AvrgCellTemp;

extern uint16 com_BPC1MinDchrgVolt;
extern uint8 com_BPC1CurrChrgVol;
extern uint16 com_BPC1MaxDchrgCurrent;

extern boolean com_BPC2ChrgrACInput;
extern boolean com_BPC2ChrgEnable;
extern uint8   com_BPC2ChrgSts;
extern uint16 com_BPC2MaxChrgVolt;
extern uint16 com_BPC2MaxChrgCurrent;


extern uint8   com_BPSSelfChkSts;
extern uint8   com_BPSDisChMRelaySts;
extern uint8   com_BPSChMRelaySts;//����ȥ�� 20150819
extern uint8   com_BPSFCContactSts; //add 20150819 
extern uint8   com_BPSHighVoltSts;
extern boolean com_BPSBattVoltLowAlarm;
extern boolean com_BPSBattTempHighAlarm;
extern boolean com_BPSBattLeakAlarm;
extern boolean com_BPSCellVoltLowAlarm;
extern boolean com_BPSVolumLowAlarm;
extern boolean com_BPSBattMaintenanceAlarm;
extern boolean com_BPSOverCurrAlarm;
extern uint8 com_BPSSOC;
extern uint16 com_BPSCurrent;
extern uint16 com_BPSInsulationResistance;         

/* to fast charger */
extern uint16 com_CPMaxChrgVolt;
extern uint16 com_CPCmdChrgCurr;
extern uint8  com_CPCtl;
extern uint8  com_CPModuleNum;

extern uint16 com_SP1BattVolt;
extern uint16 com_SP1BattCurr;
extern uint16 com_SP1Soc;
extern uint16 com_SP1CellAlarmUpVolt;

extern uint16 com_SP2CellShutUpVolt;
extern uint16 com_SP2CellAlarmLwrVolt;
extern uint16 com_SP2CellShutLwrVolt;
extern uint16 com_SP2CellDiffAlarm;

extern uint16 com_SP3TempAlarmUpVal;
extern uint16 com_SP3MaxChrgCurr;
extern uint16 com_SP3MaxDchrgCurr;
extern uint16 com_SP3Volum;

//add by xql for fast charge Tx Msg,20150708
//BRM
extern uint8  com_BRM_SubProVersion;
extern uint16 com_BRM_ProVersion;
extern uint8  com_BRM_BatType;
extern uint16 com_BRM_RatedCap;
extern uint16 com_BRM_RatedVolt;
//BCP
extern uint16 com_BCP_MaxCellChgVolt;
extern uint16 com_BCP_MaxChgCurrent;
extern uint16 com_BCP_NominalEnergy;
extern uint16 com_BCP_MaxPackChgVolt;
extern uint8  com_BCP_MaxAllowedTemp;
extern uint16 com_BCP_PackSOC;
extern uint16 com_BCP_PackVolt;
                                    
extern uint16 DC_ReachVolt;  //ĸ����Ҫ��ѹ 20151205

//BRO
extern uint8  com_BRO_BMSReady;
//BCL
extern uint16 com_BCL_ReqVolt;
extern uint16 com_BCL_ReqCurrent; 
extern uint16 com_LUC_ReqCurrent;      // //use lookup_table ��ѯ������ 20151020
extern uint8  com_BCL_ChgMode;
//BCS
extern uint16 com_BCS_MeasuredChgVolt;
extern uint16 com_BCS_MeasuredChgCurrent;
extern uint16 com_BCS_MaxCellVolt;
extern uint8  com_BCS_MaxCVGroupNum;
extern uint8  com_BCS_CurSOC;
extern uint16 com_BCS_ChgTimeRemain;
//BSM
extern uint8  com_BSM_MaxCVCellNum;  
extern uint8  com_BSM_MinCVCellNum;
extern uint8  com_BSM_MaxCellTemp;
extern uint8  com_BSM_MaxCTCellNum;
extern uint8  com_BSM_MinCellTemp;
extern uint8  com_BSM_MinCTCellNum;
extern uint8  com_BSM_ChgTempSt;
extern uint8  com_BSM_ChgCurrentSt;
extern uint8  com_BSM_ChgSOCSt;
extern uint8  com_BSM_ChgCVSt;
extern uint8  com_BSM_ChgAllowed;
extern uint8  com_BSM_ConnecterSt;
extern uint8  com_BSM_ISOSt;
//BST
extern uint8  com_BST_SetCVReach;
extern uint8  com_BST_SetPVReach;
extern uint8  com_BST_SetSOCReach;
extern uint8  com_BST_ConnecterFault;
extern uint8  com_BST_CompOverTempFault;
extern uint8  com_BST_ConnOverTempFault;
extern uint8  com_BST_ISOFault;
extern uint8  com_BST_OtherFault;
extern uint8  com_BST_BatOverTempFault;
extern uint8  com_BST_VoltError;
extern uint8  com_BST_CurrentError;
//BSD
extern uint8  com_BSD_EndSOC;
extern uint16 com_BSD_MinCellVolt;
extern uint16 com_BSD_MaxCellVolt;
extern uint8  com_BSD_MinCellTemp;
extern uint8  com_BSD_MaxCellTemp;
//BEM
extern uint8  com_BEM_RcvChgerRecMsg_AA;
extern uint8  com_BEM_RcvChgerRecMsg_00;
extern uint8  com_BEM_RcvChgerCMLMsg;
extern uint8  com_BEM_RcvChgerReadyMsg;
extern uint8  com_BEM_RcvChgerStopMsg;
extern uint8  com_BEM_RcvChgerStateMsg;
extern uint8  com_BEM_RcvChgerTotalMsg;
/*****************************************************
Com Control
*****************************************************/

extern boolean com_VehBusRxEna;
extern boolean com_InnerBusRxEna;
extern boolean com_SlowChrgrRxEna;
extern boolean com_FastChrgrRxEna;

extern boolean com_VehBusTxEna;
extern boolean com_InnerBusTxEna;
extern boolean com_SlowChrgrTxEna;
extern boolean com_FastChrgrTxEna;
//add by xql for fast charge Tx Msg,20150708
extern boolean com_BRMTxEna;
extern boolean com_BCPTxEna;
extern boolean com_BROTxEna;
extern boolean com_BCLTxEna;
extern boolean com_BCSTxEna;
extern boolean com_BSMTxEna;
extern boolean com_BSTTxEna;
extern boolean com_BSDTxEna;
extern boolean com_BEMTxEna;

extern boolean com_CRMTimeoutFlag;//0-normal  1-timeout
extern boolean com_CTSTimeoutFlag;
extern boolean com_CMLTimeoutFlag;
extern boolean com_CROTimeoutFlag;
extern boolean com_CCSTimeoutFlag;
extern boolean com_CSTTimeoutFlag;
extern boolean com_CSDTimeoutFlag;
extern boolean com_CEMTimeoutFlag;  
extern uint8 DCVolt_Reach;//2151205

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern void COM_CODE Com_Init(void);
extern void COM_CODE Com_MainFunction(void);
extern void Com_RxTOReset(void);     



/*******************************************************************************
* ���ӵ��������� add 20150805                        
*******************************************************************************/
//////////////////////////////////////��������	��ʼ����������Ϊ0xFF	Com.c////////////////////////////
//St_BMS_1
extern uint8 BM_CRC_BMS_ST_01;//CRCֵ
extern uint8 BM_Live_BMS_ST_01;//����֡
extern uint8 BM_Fault_Level;//��ذ����󼶱� ������������
extern uint8 BM_Battery_Charge_Power_Available;//��ذ�������繦�� 1 KW �ֱ���
extern uint8 BM_Battery_Discharge_Power_Available;//��ذ������ķŵ繦�� 1 KW�ֱ���    
extern uint16 BM_Battery_Energry_Avarable;//��ذ�ʣ������ KWH  0.1�ֱ���
extern uint8 BM_Battery_SOC;//SOCֵ  1%
extern uint8 BM_Battery_User_SOC;//��ʾSOC  ��Battery_SOCһ��
//St_BMS_2
extern uint16 BM_Battery_Current;//��ذ����� A 0.1�ֱ���
extern uint16 BM_Battery_Voltage;
extern uint8 BM_Battery_Avg_T;//���ƽ���¶�
extern uint8 BM_Battery_Max_T;//�������¶�
extern uint8 BM_Battery_Min_T;//�������¶�
extern uint8 BM_Battery_SOH;//BMSδʵ�ָù��� ��Ϊ100%
//St_BMS_3
extern uint8 BM_ST_ERR_Charge_Over_Current;//���������󱨾� 0--���� 1--һ�� 2--���� 3--����
extern uint8 BM_ST_ERR_DisChgrge_Over_Current;//�ŵ�������󱨾� 0--���� 1--һ�� 2--���� 3--����
extern uint8 BM_ST_ERR_Cell_Over_Voltage;////��о��ѹѹ���� 0--���� 1--һ�� 2--����
extern uint8 BM_ST_ERR_Cell_Under_Voltage;//��оǷѹ���� 0--���� 1--һ�� 2--���� 

extern uint8 BM_ST_ERR_Cell_Voltage_Uniformity;//�������������
extern uint8 BM_ST_ERR_Battery_Over_Voltage;//�ܵ�ѹ���߱��� 0--���� 1--һ�� 2--����
extern uint8 BM_ST_ERR_Battery_Under_Voltage;//�ܵ�ѹ���ͱ��� 0--���� 1--һ�� 2--����
extern uint8 BM_ST_ERR_Over_Temperature;//�¶ȹ��߱��� 0--���� 1--һ�� 2--����

extern uint8 BM_ST_ERR_Low_Temperature;//�¶ȹ��ͱ��� 0--���� 1--һ�� 2--����
extern uint8 BM_ST_ERR_Over_SOC;//SOC����  0--���� 1--һ�� 2--����
extern uint8 BM_ST_ERR_Low_SOC;//SOC����  0--���� 1--һ�� 2--����
extern uint8 BM_ST_ERR_Insulation_Resistance;//��Ե���� 

extern uint8 BM_ST_ERR_INNCAN_Communication_Fault;//�ڲ�CAN
extern uint8 BM_ST_ERR_Cell_Voltage_Sensor_Fault;//��������쳣 0--���� 1--�쳣
extern uint8 BM_ST_ERR_Temperature_Sensor_Fault;//�¶Ȳ����쳣 0--���� 1--�쳣
extern uint8 BM_ST_ERR_Current_Sensor_Fault;//���������쳣 0--���� 1--�쳣// 1--��· 2--��· 3--����

extern uint8 BM_ST_ERR_CellTemp_Unbalance_Fault;//�¶Ȳ����� 0--���� 1--�쳣
extern uint8 BM_ST_ERR_SysPower_Supply_Fault;//ϵͳ������� 0--���� 1--�쳣
extern uint8 BM_ST_ERR_BatteryVoltage_High_Fault;//���ص�ѹ���� 0--���� 1--�쳣
extern uint8 BM_ST_ERR_BatteryVoltage_Low_Fault;//���ص�ѹ���� 0--���� 1--�쳣
extern uint8 BM_ST_ERR_SOCCalc_Fault;//SOC�ɼ��쳣 0--���� 1--�쳣
extern uint8 BM_ST_ERR_ISOCalc_Fault;//��Ե����ɼ��쳣 0--���� 1--�쳣
extern uint8 BM_ST_ERR_PVoltage_Sensor_Fault;//�ܵ�ѹ�ɼ��쳣 0--���� 1--һ�� 2--����
extern uint8 BM_ST_ERR_VEHCAN_Communication_Fault;//����CAN 0--���� 1--�쳣
extern uint8 BM_ST_ERR_PTC_Fault;//PTC�쳣 0--���� 1--��· 2--��· 3--����
extern uint8 BM_ST_ERR_OrigCur_Fault;//��ʼ�����쳣 0--���� 1--�쳣
extern uint8 BM_ST_ERR_OffCur_Fault;//�µ�����쳣 0--���� 1--�쳣
extern uint8 BM_ST_ERR_NegRelaySticky_Fault;//�����̵���ճ�� 0--���� 1--�쳣
//St_BMS_4
extern uint8 BM_CRC_ST_BMS_4;
extern uint8 BM_LIV_ST_BMS_4;//����֡��	ÿ�μ�1  ��15��Ϊ0
extern uint8 BM_ST_HV_Online;//��ذ��ϵ�״̬�� 0 "Power Off" 1 "Power On"
extern uint8 BM_ST_HV_Positive_Relay1;//�����̵���1״̬�� 0 "open" 1 "close"
extern uint8 BM_ST_HV_Positive_Relay2;//û��  �����̵���2״̬�� 0 "open" 1 "close"
extern uint8 BM_ST_HV_Positive_Relay3;//û��  �����̵���3״̬�� 0 "open" 1 "close"
extern uint8 BM_ST_HV_Positive_Relay_FaultStatus;//�����̵�������״̬�� 0 "No faut" 1 "Fault"
extern uint8 BM_ST_HV_Negative_Relay;//�����̵���״̬��0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"
extern uint8 BM_ST_Precharge_Relay;//Ŀǰ���ã�Ԥ��̵���״̬�� 0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"	
extern uint8 BM_ST_FCharge_Positive_Relay;//����!!!������̵���״̬�� 0 "Open" 1 "Closed"
extern uint8 BM_ST_SCharge_Positive_Relay;//����  �������̵���״̬�� 0 "Open" 1 "Closed"
extern uint8 BM_ST_Charge_Negative_Relay;//����  �为�̵���״̬(�������乫�ø����̵���)��  0 "Open" 1 "Closed"
extern uint8 BM_ST_Healting_Relay;//����  ���ȼ̵���״̬��  0 "Open" 1 "Closed"

extern uint8 BM_ST_Charging;
extern uint8 BM_ST_Cooling_Relay;

extern uint8 BM_ST_Heating;	// 0 "Open"  1 "Closed"  
extern uint8 BM_ST_Cooling;// 0 "Open" 1 "Closed"
extern uint8 BM_ST_Charging_Gun;	// 0 "Open" 1 "Closed"
extern uint8 BM_ST_Resistance;//��Ե����


//ST_VMS_3
extern uint8 BM_CMD_HV_Power;//�������������͵ĸ�ѹ���µ�ָ�0 "Open HV Switch" 1 "Open HV switchurgently" 2 "Close HV switch" 3 "Keepcurrent state"

extern boolean Relay_CZ;//add 20150819�̵ܼ���״̬




extern uint8 COM_FM1St; 
extern uint8 COM_FM2St;
 


extern uint8 BMU_NoActive[25];//BMU��������� ����Ϊ0 ��ʧΪ1  20150905


extern uint16 com_BCP_PackSOC; //��䱨�ĵ�ǰSOC
extern uint16 com_BCP_PackVolt; //��䱨�ĵ�ǰ�ܵ�ѹ

#endif /* #ifndef _COM_H_ */
