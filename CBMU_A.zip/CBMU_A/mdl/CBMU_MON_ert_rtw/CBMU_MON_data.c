/*
 * File: CBMU_MON_data.c
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "CBMU_MON.h"
#include "CBMU_MON_private.h"

/* Constant parameters (auto storage) */
const ConstParam_CBMU_MON CBMU_MON_ConstP = {
  /* Pooled Parameter (Expression: )
   * Referenced by:
   *   '<S6>/ChrgCur'
   *   '<S6>/ChrgCurTimeOfFullSOC'
   *   '<S6>/ChrgCurTimeOfUnfullSOC'
   */
  { 5U, 2U },

  /* Pooled Parameter (Expression: uint16(reshape([160,130,100,70,40,30,15000,15000,15000,20000,20000,40000,4000,4000,5000,5000,6000,6000],6,3));)
   * Referenced by:
   *   '<S6>/ChrgCur'
   *   '<S6>/ChrgCurTimeOfFullSOC'
   *   '<S6>/ChrgCurTimeOfUnfullSOC'
   */
  { 160U, 130U, 100U, 70U, 40U, 30U, 15000U, 15000U, 15000U, 20000U, 20000U,
    40000U, 4000U, 4000U, 5000U, 5000U, 6000U, 6000U },

  /* Pooled Parameter (Expression: uint8([1,2,3,4,5,6]);)
   * Referenced by:
   *   '<S6>/ChrgCur'
   *   '<S6>/ChrgCurTimeOfFullSOC'
   *   '<S6>/ChrgCurTimeOfUnfullSOC'
   */
  { 1U, 2U, 3U, 4U, 5U, 6U },

  /* Pooled Parameter (Expression: uint8([1,2,3]);)
   * Referenced by:
   *   '<S6>/ChrgCur'
   *   '<S6>/ChrgCurTimeOfFullSOC'
   *   '<S6>/ChrgCurTimeOfUnfullSOC'
   */
  { 1U, 2U, 3U }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
