#include "Variant_Cfg.h"

#pragma CONST_SEG EOL_DATA





#pragma CONST_SEG DEFAULT


