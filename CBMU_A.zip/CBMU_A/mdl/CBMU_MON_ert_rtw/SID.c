/*
 * File: SID.c
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SID.h"

/* Include model header file for global data */
#include "CBMU_MON.h"
#include "CBMU_MON_private.h"

/* Named constants for Chart: '<S66>/Switch_Debouncing' */
#define CBMU_MON_IN_NO_ACTIVE_CHILD_e  ((uint8_T)0U)
#define CBMU_MON_IN_Switch_OFF         ((uint8_T)1U)
#define CBMU_MON_IN_Switch_ON          ((uint8_T)3U)
#define CBMU_MO_IN_Switch_ON_Debouncing ((uint8_T)4U)
#define CBMU_M_IN_Switch_OFF_Debouncing ((uint8_T)2U)

/* Named constants for Chart: '<S105>/SRC_Check' */
#define CBMU_MON_IN_Defect             ((uint8_T)1U)
#define CBMU_MON_IN_NO_ACTIVE_CHILD_eo ((uint8_T)0U)
#define CBMU_MON_IN_NO_Defect          ((uint8_T)2U)
#define CBMU_MON_IN_SRC_High_Confimed  ((uint8_T)1U)
#define CBMU_MON_IN_SRC_High_Debouncing ((uint8_T)2U)
#define CBMU_MON_IN_SRC_High_Healing   ((uint8_T)3U)
#define CBMU_MON_IN_SRC_Low_Confimed   ((uint8_T)4U)
#define CBMU_MON_IN_SRC_Low_Debouncing ((uint8_T)5U)
#define CBMU_MON_IN_SRC_Low_Healing    ((uint8_T)6U)

/* Declare variables for internal data of system '<S52>/O_SW_HVIL_Swt' */
rtB_O_SW_HVIL_Swt_CBMU_MON CBMU_MON_O_SW_HVIL_Swt_B;
rtDW_O_SW_HVIL_Swt_CBMU_MON CBMU_MON_O_SW_HVIL_Swt_DW;

/* Declare variables for internal data of system '<S53>/O_SW_HVIL_Swt' */
rtB_O_SW_HVIL_Swt_CBMU_MON_i CBMU_MON_O_SW_HVIL_Swt_B_h;
rtDW_O_SW_HVIL_Swt_CBMU_MON_e CBMU_MON_O_SW_HVIL_Swt_DW_d;

/* Declare variables for internal data of system '<S7>/O_SW_HVIL_Swt' */
rtB_O_SW_HVIL_Swt_CBMU_MON_d CBMU_MON_O_SW_HVIL_Swt_B_e;
rtDW_O_SW_HVIL_Swt_CBMU_MON_p CBMU_MON_O_SW_HVIL_Swt_DW_c;

/* Declare variables for internal data of system '<S60>/O_SW_HVIL_Swt' */
rtB_O_SW_HVIL_Swt_CBMU_MON_m CBMU_MON_O_SW_HVIL_Swt_B_g;
rtDW_O_SW_HVIL_Swt_CBMU_MON_k CBMU_MON_O_SW_HVIL_Swt_DW_o;

/* Declare variables for internal data of system '<S60>/O_SW_HVIL_Swt1' */
rtB_O_SW_HVIL_Swt1_CBMU_MON CBMU_MON_O_SW_HVIL_Swt1_B;
rtDW_O_SW_HVIL_Swt1_CBMU_MON CBMU_MON_O_SW_HVIL_Swt1_DW;

/* Declare variables for internal data of system '<S60>/O_SW_NegRlyCtl_Swt' */
rtB_O_SW_NegRlyCtl_Swt_CBMU_MON CBMU_MON_O_SW_NegRlyCtl_Swt_B;
rtDW_O_SW_NegRlyCtl_Swt_CBMU_MO CBMU_MON_O_SW_NegRlyCtl_Swt_DW;

/* Declare variables for internal data of system '<S60>/O_SW_PosRlyCtl_Swt' */
rtB_O_SW_PosRlyCtl_Swt_CBMU_MON CBMU_MON_O_SW_PosRlyCtl_Swt_B;
rtDW_O_SW_PosRlyCtl_Swt_CBMU_MO CBMU_MON_O_SW_PosRlyCtl_Swt_DW;

/* Declare variables for internal data of system '<S61>/O_SW_HVIL_Swt' */
rtB_O_SW_HVIL_Swt_CBMU_MON_ii CBMU_MON_O_SW_HVIL_Swt_B_hk;
rtDW_O_SW_HVIL_Swt_CBMU_MON_d CBMU_MON_O_SW_HVIL_Swt_DW_b;

/*
 * System initialize for atomic system:
 *    '<S52>/Chart'
 *    '<S61>/Chart'
 */
void CBMU_MON_Chart_Init(rtB_Chart_CBMU_MON *localB)
{
  localB->bitsForTID0.O_S_CC_Swt = false;
}

/*
 * Output and update for atomic system:
 *    '<S52>/Chart'
 *    '<S61>/Chart'
 */
void CBMU_MON_Chart(t_Voltage1 rtu_CCVolt, t_Voltage1 rtu_CC_VoltHigh,
                    t_Voltage1 rtu_CC_VoltLow, rtB_Chart_CBMU_MON *localB)
{
  /* Gateway: Task_10ms/SID/FCCC/Chart */
  /* During: Task_10ms/SID/FCCC/Chart */
  /* Entry Internal: Task_10ms/SID/FCCC/Chart */
  /* Transition: '<S64>:11' */
  /*  HVIL swt tell  */
  if ((rtu_CCVolt > rtu_CC_VoltLow) && (rtu_CCVolt < rtu_CC_VoltHigh)) {
    /* Transition: '<S64>:12' */
    /* Transition: '<S64>:19' */
    localB->bitsForTID0.O_S_CC_Swt = true;
  } else {
    /* Transition: '<S64>:13' */
    /* Transition: '<S64>:14' */
    localB->bitsForTID0.O_S_CC_Swt = false;

    /* Transition: '<S64>:17' */
    /* Transition: '<S64>:18' */
  }

  /* Transition: '<S64>:20' */
}

/*
 * System initialize for atomic system:
 *    '<S65>/Swtich_Debouncing'
 *    '<S69>/Swtich_Debouncing'
 *    '<S59>/Swtich_Debouncing'
 *    '<S75>/Swtich_Debouncing'
 *    '<S76>/Swtich_Debouncing'
 *    '<S77>/Swtich_Debouncing'
 *    '<S78>/Swtich_Debouncing'
 *    '<S91>/Swtich_Debouncing'
 */
void CBMU_MON_Swtich_Debouncing_Init(rtB_Swtich_Debouncing_CBMU_MON *localB,
  rtDW_Swtich_Debouncing_CBMU_MON *localDW)
{
  /* SystemInitialize for Chart: '<S66>/Switch_Debouncing' */
  localDW->bitsForTID0.is_active_c47_CBMU_MON = 0U;
  localDW->bitsForTID0.is_c47_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_e;
  localDW->localTimer = 0U;
  localB->bitsForTID0.swtDeb = false;
}

/*
 * Output and update for atomic system:
 *    '<S65>/Swtich_Debouncing'
 *    '<S69>/Swtich_Debouncing'
 *    '<S59>/Swtich_Debouncing'
 *    '<S75>/Swtich_Debouncing'
 *    '<S76>/Swtich_Debouncing'
 *    '<S77>/Swtich_Debouncing'
 *    '<S78>/Swtich_Debouncing'
 *    '<S91>/Swtich_Debouncing'
 */
void CBMU_MON_Swtich_Debouncing(boolean_T rtu_swtRaw, uint16_T
  rtu_Par_SwtOffDebTime, uint16_T rtu_Par_SwtOnDebTime, uint8_T
  rtu_Par_SampleTime, rtB_Swtich_Debouncing_CBMU_MON *localB,
  rtDW_Swtich_Debouncing_CBMU_MON *localDW)
{
  /* Chart: '<S66>/Switch_Debouncing' */
  /* Gateway: Task_10ms/SID/FCCC/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing */
  /* During: Task_10ms/SID/FCCC/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing */
  if (localDW->bitsForTID0.is_active_c47_CBMU_MON == 0U) {
    /* Entry: Task_10ms/SID/FCCC/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing */
    localDW->bitsForTID0.is_active_c47_CBMU_MON = 1U;

    /* Entry Internal: Task_10ms/SID/FCCC/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing */
    /* Transition: '<S67>:5' */
    localDW->bitsForTID0.is_c47_CBMU_MON = CBMU_MON_IN_Switch_OFF;

    /* Entry 'Switch_OFF': '<S67>:1' */
    localB->bitsForTID0.swtDeb = SWT_OFF;
  } else {
    switch (localDW->bitsForTID0.is_c47_CBMU_MON) {
     case CBMU_MON_IN_Switch_OFF:
      /* During 'Switch_OFF': '<S67>:1' */
      if (rtu_swtRaw == SWT_ON) {
        /* Transition: '<S67>:6' */
        localDW->bitsForTID0.is_c47_CBMU_MON = CBMU_MO_IN_Switch_ON_Debouncing;

        /* Entry 'Switch_ON_Debouncing': '<S67>:2' */
        localDW->localTimer = rtu_Par_SampleTime;
      }
      break;

     case CBMU_M_IN_Switch_OFF_Debouncing:
      /* During 'Switch_OFF_Debouncing': '<S67>:4' */
      if (localDW->localTimer > rtu_Par_SwtOffDebTime) {
        /* Transition: '<S67>:11' */
        localDW->bitsForTID0.is_c47_CBMU_MON = CBMU_MON_IN_Switch_OFF;

        /* Entry 'Switch_OFF': '<S67>:1' */
        localB->bitsForTID0.swtDeb = SWT_OFF;
      } else if (rtu_swtRaw == SWT_ON) {
        /* Transition: '<S67>:10' */
        localDW->bitsForTID0.is_c47_CBMU_MON = CBMU_MON_IN_Switch_ON;

        /* Entry 'Switch_ON': '<S67>:3' */
        localB->bitsForTID0.swtDeb = SWT_ON;
      } else {
        localDW->localTimer += rtu_Par_SampleTime;
      }
      break;

     case CBMU_MON_IN_Switch_ON:
      /* During 'Switch_ON': '<S67>:3' */
      if (rtu_swtRaw == SWT_OFF) {
        /* Transition: '<S67>:9' */
        localDW->bitsForTID0.is_c47_CBMU_MON = CBMU_M_IN_Switch_OFF_Debouncing;

        /* Entry 'Switch_OFF_Debouncing': '<S67>:4' */
        localDW->localTimer = rtu_Par_SampleTime;
      }
      break;

     default:
      /* During 'Switch_ON_Debouncing': '<S67>:2' */
      if (localDW->localTimer > rtu_Par_SwtOnDebTime) {
        /* Transition: '<S67>:8' */
        localDW->bitsForTID0.is_c47_CBMU_MON = CBMU_MON_IN_Switch_ON;

        /* Entry 'Switch_ON': '<S67>:3' */
        localB->bitsForTID0.swtDeb = SWT_ON;
      } else if (rtu_swtRaw == SWT_OFF) {
        /* Transition: '<S67>:7' */
        localDW->bitsForTID0.is_c47_CBMU_MON = CBMU_MON_IN_Switch_OFF;

        /* Entry 'Switch_OFF': '<S67>:1' */
        localB->bitsForTID0.swtDeb = SWT_OFF;
      } else {
        localDW->localTimer += rtu_Par_SampleTime;
      }
      break;
    }
  }

  /* End of Chart: '<S66>/Switch_Debouncing' */
}

/* System initialize for atomic system: '<S52>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S65>/Swtich_Debouncing' */
  CBMU_MON_Swtich_Debouncing_Init(&CBMU_MON_O_SW_HVIL_Swt_B.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW.Swtich_Debouncing);

  /* End of SystemInitialize for SubSystem: '<S65>/Swtich_Debouncing' */
}

/* Output and update for atomic system: '<S52>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt(void)
{
  /* Outputs for Atomic SubSystem: '<S65>/Swtich_Debouncing' */

  /* Constant: '<S65>/Constant4' incorporates:
   *  Constant: '<S65>/Constant5'
   *  Constant: '<S65>/Constant6'
   */
  CBMU_MON_Swtich_Debouncing(CBMU_MON_B.sf_Chart_i.bitsForTID0.O_S_CC_Swt, 200U,
    200U, ((uint8_T)StepTim), &CBMU_MON_O_SW_HVIL_Swt_B.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW.Swtich_Debouncing);

  /* End of Outputs for SubSystem: '<S65>/Swtich_Debouncing' */

  /* SignalConversion: '<S65>/TmpSignal ConversionAtSwtich_DebouncingOutport1' */
  O_S_FCCC = CBMU_MON_O_SW_HVIL_Swt_B.Swtich_Debouncing.bitsForTID0.swtDeb;
}

/* System initialize for atomic system: '<S53>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_j_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S69>/Swtich_Debouncing' */
  CBMU_MON_Swtich_Debouncing_Init(&CBMU_MON_O_SW_HVIL_Swt_B_h.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW_d.Swtich_Debouncing);

  /* End of SystemInitialize for SubSystem: '<S69>/Swtich_Debouncing' */
}

/* Output and update for atomic system: '<S53>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_e(void)
{
  /* Outputs for Atomic SubSystem: '<S69>/Swtich_Debouncing' */

  /* Constant: '<S69>/Constant4' incorporates:
   *  Constant: '<S69>/Constant5'
   *  Constant: '<S69>/Constant6'
   */
  CBMU_MON_Swtich_Debouncing(CBMU_MON_B.bitsForTID0.O_S_HVIL_Swt, 5000U, 5000U,
    ((uint8_T)StepTim), &CBMU_MON_O_SW_HVIL_Swt_B_h.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW_d.Swtich_Debouncing);

  /* End of Outputs for SubSystem: '<S69>/Swtich_Debouncing' */
}

/* System initialize for atomic system: '<S7>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_o_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S59>/Swtich_Debouncing' */
  CBMU_MON_Swtich_Debouncing_Init(&CBMU_MON_O_SW_HVIL_Swt_B_e.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW_c.Swtich_Debouncing);

  /* End of SystemInitialize for SubSystem: '<S59>/Swtich_Debouncing' */
}

/* Output and update for atomic system: '<S7>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_k(void)
{
  /* Outputs for Atomic SubSystem: '<S59>/Swtich_Debouncing' */

  /* Inport: '<Root>/Relay_CZ' incorporates:
   *  Constant: '<S59>/Constant4'
   *  Constant: '<S59>/Constant5'
   *  Constant: '<S59>/Constant6'
   */
  CBMU_MON_Swtich_Debouncing(Relay_CZ, 600U, 60U, ((uint8_T)StepTim),
    &CBMU_MON_O_SW_HVIL_Swt_B_e.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW_c.Swtich_Debouncing);

  /* End of Outputs for SubSystem: '<S59>/Swtich_Debouncing' */
}

/* System initialize for atomic system: '<S60>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_d_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S75>/Swtich_Debouncing' */
  CBMU_MON_Swtich_Debouncing_Init(&CBMU_MON_O_SW_HVIL_Swt_B_g.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW_o.Swtich_Debouncing);

  /* End of SystemInitialize for SubSystem: '<S75>/Swtich_Debouncing' */
}

/* Output and update for atomic system: '<S60>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_l(void)
{
  /* Outputs for Atomic SubSystem: '<S75>/Swtich_Debouncing' */

  /* Inport: '<Root>/DisChMRelaySt' incorporates:
   *  Constant: '<S75>/Constant4'
   *  Constant: '<S75>/Constant5'
   *  Constant: '<S75>/Constant6'
   */
  CBMU_MON_Swtich_Debouncing(SID_m_st_DisChMRelay, 650U, 650U, ((uint8_T)StepTim),
    &CBMU_MON_O_SW_HVIL_Swt_B_g.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW_o.Swtich_Debouncing);

  /* End of Outputs for SubSystem: '<S75>/Swtich_Debouncing' */
}

/* System initialize for atomic system: '<S60>/O_SW_HVIL_Swt1' */
void CBMU_MON_O_SW_HVIL_Swt1_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S76>/Swtich_Debouncing' */
  CBMU_MON_Swtich_Debouncing_Init(&CBMU_MON_O_SW_HVIL_Swt1_B.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt1_DW.Swtich_Debouncing);

  /* End of SystemInitialize for SubSystem: '<S76>/Swtich_Debouncing' */
}

/* Output and update for atomic system: '<S60>/O_SW_HVIL_Swt1' */
void CBMU_MON_O_SW_HVIL_Swt1(void)
{
  /* Outputs for Atomic SubSystem: '<S76>/Swtich_Debouncing' */

  /* Inport: '<Root>/ChMRelaySt' incorporates:
   *  Constant: '<S76>/Constant4'
   *  Constant: '<S76>/Constant5'
   *  Constant: '<S76>/Constant6'
   */
  CBMU_MON_Swtich_Debouncing(SID_m_st_ChMRelay, 650U, 650U, ((uint8_T)StepTim),
    &CBMU_MON_O_SW_HVIL_Swt1_B.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt1_DW.Swtich_Debouncing);

  /* End of Outputs for SubSystem: '<S76>/Swtich_Debouncing' */
}

/* System initialize for atomic system: '<S60>/O_SW_NegRlyCtl_Swt' */
void CBMU_MO_O_SW_NegRlyCtl_Swt_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S77>/Swtich_Debouncing' */
  CBMU_MON_Swtich_Debouncing_Init
    (&CBMU_MON_O_SW_NegRlyCtl_Swt_B.Swtich_Debouncing,
     &CBMU_MON_O_SW_NegRlyCtl_Swt_DW.Swtich_Debouncing);

  /* End of SystemInitialize for SubSystem: '<S77>/Swtich_Debouncing' */
}

/* Output and update for atomic system: '<S60>/O_SW_NegRlyCtl_Swt' */
void CBMU_MON_O_SW_NegRlyCtl_Swt(void)
{
  /* Outputs for Atomic SubSystem: '<S77>/Swtich_Debouncing' */

  /* Constant: '<S77>/Constant4' incorporates:
   *  Constant: '<S77>/Constant5'
   *  Constant: '<S77>/Constant6'
   */
  CBMU_MON_Swtich_Debouncing(CBMU_MON_B.bitsForTID0.RelationalOperator1, 5000U,
    5000U, ((uint8_T)StepTim), &CBMU_MON_O_SW_NegRlyCtl_Swt_B.Swtich_Debouncing,
    &CBMU_MON_O_SW_NegRlyCtl_Swt_DW.Swtich_Debouncing);

  /* End of Outputs for SubSystem: '<S77>/Swtich_Debouncing' */
}

/* System initialize for atomic system: '<S60>/O_SW_PosRlyCtl_Swt' */
void CBMU_MO_O_SW_PosRlyCtl_Swt_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S78>/Swtich_Debouncing' */
  CBMU_MON_Swtich_Debouncing_Init
    (&CBMU_MON_O_SW_PosRlyCtl_Swt_B.Swtich_Debouncing,
     &CBMU_MON_O_SW_PosRlyCtl_Swt_DW.Swtich_Debouncing);

  /* End of SystemInitialize for SubSystem: '<S78>/Swtich_Debouncing' */
}

/* Output and update for atomic system: '<S60>/O_SW_PosRlyCtl_Swt' */
void CBMU_MON_O_SW_PosRlyCtl_Swt(void)
{
  /* Outputs for Atomic SubSystem: '<S78>/Swtich_Debouncing' */

  /* Constant: '<S78>/Constant4' incorporates:
   *  Constant: '<S78>/Constant5'
   *  Constant: '<S78>/Constant6'
   */
  CBMU_MON_Swtich_Debouncing(CBMU_MON_B.bitsForTID0.RelationalOperator, 5000U,
    5000U, ((uint8_T)StepTim), &CBMU_MON_O_SW_PosRlyCtl_Swt_B.Swtich_Debouncing,
    &CBMU_MON_O_SW_PosRlyCtl_Swt_DW.Swtich_Debouncing);

  /* End of Outputs for SubSystem: '<S78>/Swtich_Debouncing' */
}

/* System initialize for atomic system: '<S61>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_e_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S91>/Swtich_Debouncing' */
  CBMU_MON_Swtich_Debouncing_Init(&CBMU_MON_O_SW_HVIL_Swt_B_hk.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW_b.Swtich_Debouncing);

  /* End of SystemInitialize for SubSystem: '<S91>/Swtich_Debouncing' */
}

/* Output and update for atomic system: '<S61>/O_SW_HVIL_Swt' */
void CBMU_MON_O_SW_HVIL_Swt_p(void)
{
  /* Outputs for Atomic SubSystem: '<S91>/Swtich_Debouncing' */

  /* Constant: '<S91>/Constant4' incorporates:
   *  Constant: '<S91>/Constant5'
   *  Constant: '<S91>/Constant6'
   */
  CBMU_MON_Swtich_Debouncing(CBMU_MON_B.sf_Chart_c.bitsForTID0.O_S_CC_Swt, 200U,
    200U, ((uint8_T)StepTim), &CBMU_MON_O_SW_HVIL_Swt_B_hk.Swtich_Debouncing,
    &CBMU_MON_O_SW_HVIL_Swt_DW_b.Swtich_Debouncing);

  /* End of Outputs for SubSystem: '<S91>/Swtich_Debouncing' */

  /* SignalConversion: '<S91>/TmpSignal ConversionAtSwtich_DebouncingOutport1' */
  O_S_SCCC = CBMU_MON_O_SW_HVIL_Swt_B_hk.Swtich_Debouncing.bitsForTID0.swtDeb;
}

/*
 * System initialize for atomic system:
 *    '<S104>/SRC_Check'
 *    '<S109>/SRC_Check'
 *    '<S114>/SRC_Check'
 *    '<S119>/SRC_Check'
 */
void CBMU_MON_SRC_Check_Init(rtB_SRC_Check_CBMU_MON *localB,
  rtDW_SRC_Check_CBMU_MON *localDW)
{
  /* SystemInitialize for Chart: '<S105>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
  localDW->bitsForTID0.is_active_c33_CBMU_MON = 0U;
  localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S104>/SRC_Check'
 *    '<S109>/SRC_Check'
 *    '<S114>/SRC_Check'
 *    '<S119>/SRC_Check'
 */
void CBMU_MON_SRC_Check(boolean_T rtu_Clear_Def_Flag, t_Voltage1 rtu_Sig_Volt,
  t_Voltage1 rtu_Par_SRC_H_Threshold, t_Voltage1 rtu_Par_SRC_L_Threshold,
  uint16_T rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_CBMU_MON *localB, rtDW_SRC_Check_CBMU_MON
  *localDW)
{
  /* Chart: '<S105>/SRC_Check' */
  /* Gateway: Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c33_CBMU_MON == 0U) {
    /* Entry: Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c33_CBMU_MON = 1U;

    /* Entry Internal: Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S106>:9' */
    localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_NO_Defect;

    /* Entry 'NO_Defect': '<S106>:1' */
    localB->SRC_Def_Status = ((uint8_T)SRC_NON_DEF);
  } else if (localDW->bitsForTID0.is_c33_CBMU_MON == CBMU_MON_IN_Defect) {
    /* During 'Defect': '<S106>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S106>:22' */
      /* Exit Internal 'Defect': '<S106>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case CBMU_MON_IN_SRC_High_Debouncing:
        /* Exit 'SRC_High_Debouncing': '<S106>:4' */
        localDW->bitsForTID0.is_Defect = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
        break;

       case CBMU_MON_IN_SRC_Low_Debouncing:
        /* Exit 'SRC_Low_Debouncing': '<S106>:3' */
        localDW->bitsForTID0.is_Defect = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
        break;

       default:
        localDW->bitsForTID0.is_Defect = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
        break;
      }

      localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_NO_Defect;

      /* Entry 'NO_Defect': '<S106>:1' */
      localB->SRC_Def_Status = ((uint8_T)SRC_NON_DEF);
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case CBMU_MON_IN_SRC_High_Confimed:
        localB->SRC_Def_Status = ((uint8_T)SRC_HIGH_DEF);

        /* During 'SRC_High_Confimed': '<S106>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S106>:13' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_SRC_High_Healing;

          /* Entry 'SRC_High_Healing': '<S106>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case CBMU_MON_IN_SRC_High_Debouncing:
        /* During 'SRC_High_Debouncing': '<S106>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S106>:12' */
          /* Exit 'SRC_High_Debouncing': '<S106>:4' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
          localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_NO_Defect;

          /* Entry 'NO_Defect': '<S106>:1' */
          localB->SRC_Def_Status = ((uint8_T)SRC_NON_DEF);
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S106>:14' */
          /* Exit 'SRC_High_Debouncing': '<S106>:4' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_SRC_High_Confimed;

          /* Entry 'SRC_High_Confimed': '<S106>:5' */
          localB->SRC_Def_Status = ((uint8_T)SRC_HIGH_DEF);
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case CBMU_MON_IN_SRC_High_Healing:
        /* During 'SRC_High_Healing': '<S106>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S106>:15' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
          localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_NO_Defect;

          /* Entry 'NO_Defect': '<S106>:1' */
          localB->SRC_Def_Status = ((uint8_T)SRC_NON_DEF);
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S106>:17' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_SRC_High_Confimed;

          /* Entry 'SRC_High_Confimed': '<S106>:5' */
          localB->SRC_Def_Status = ((uint8_T)SRC_HIGH_DEF);
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case CBMU_MON_IN_SRC_Low_Confimed:
        localB->SRC_Def_Status = ((uint8_T)SRC_LOW_DEF);

        /* During 'SRC_Low_Confimed': '<S106>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S106>:18' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_SRC_Low_Healing;

          /* Entry 'SRC_Low_Healing': '<S106>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case CBMU_MON_IN_SRC_Low_Debouncing:
        /* During 'SRC_Low_Debouncing': '<S106>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S106>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S106>:3' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
          localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_NO_Defect;

          /* Entry 'NO_Defect': '<S106>:1' */
          localB->SRC_Def_Status = ((uint8_T)SRC_NON_DEF);
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S106>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S106>:3' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_SRC_Low_Confimed;

          /* Entry 'SRC_Low_Confimed': '<S106>:6' */
          localB->SRC_Def_Status = ((uint8_T)SRC_LOW_DEF);
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S106>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S106>:20' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_NO_ACTIVE_CHILD_eo;
          localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_NO_Defect;

          /* Entry 'NO_Defect': '<S106>:1' */
          localB->SRC_Def_Status = ((uint8_T)SRC_NON_DEF);
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S106>:19' */
          localDW->bitsForTID0.is_Defect = CBMU_MON_IN_SRC_Low_Confimed;

          /* Entry 'SRC_Low_Confimed': '<S106>:6' */
          localB->SRC_Def_Status = ((uint8_T)SRC_LOW_DEF);
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    localB->SRC_Def_Status = ((uint8_T)SRC_NON_DEF);

    /* During 'NO_Defect': '<S106>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S106>:10' */
      localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_Defect;
      localDW->bitsForTID0.is_Defect = CBMU_MON_IN_SRC_High_Debouncing;

      /* Entry 'SRC_High_Debouncing': '<S106>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S106>:11' */
        localDW->bitsForTID0.is_c33_CBMU_MON = CBMU_MON_IN_Defect;
        localDW->bitsForTID0.is_Defect = CBMU_MON_IN_SRC_Low_Debouncing;

        /* Entry 'SRC_Low_Debouncing': '<S106>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
      }
    }
  }

  /* End of Chart: '<S105>/SRC_Check' */
}

/* System initialize for atomic system: '<S1>/SID' */
void CBMU_MON_SID_Init(void)
{
  /* SystemInitialize for Atomic SubSystem: '<S104>/SRC_Check' */
  CBMU_MON_SRC_Check_Init(&CBMU_MON_B.SRC_Check, &CBMU_MON_DWork.SRC_Check);

  /* End of SystemInitialize for SubSystem: '<S104>/SRC_Check' */

  /* SystemInitialize for Atomic SubSystem: '<S114>/SRC_Check' */
  CBMU_MON_SRC_Check_Init(&CBMU_MON_B.SRC_Check_b, &CBMU_MON_DWork.SRC_Check_b);

  /* End of SystemInitialize for SubSystem: '<S114>/SRC_Check' */

  /* SystemInitialize for Atomic SubSystem: '<S119>/SRC_Check' */
  CBMU_MON_SRC_Check_Init(&CBMU_MON_B.SRC_Check_l, &CBMU_MON_DWork.SRC_Check_l);

  /* End of SystemInitialize for SubSystem: '<S119>/SRC_Check' */

  /* SystemInitialize for Atomic SubSystem: '<S109>/SRC_Check' */
  CBMU_MON_SRC_Check_Init(&CBMU_MON_B.SRC_Check_e, &CBMU_MON_DWork.SRC_Check_e);

  /* End of SystemInitialize for SubSystem: '<S109>/SRC_Check' */

  /* SystemInitialize for Chart: '<S53>/Chart' */
  CBMU_MON_B.bitsForTID0.O_S_HVIL_Swt = false;

  /* SystemInitialize for Atomic SubSystem: '<S53>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt_j_Init();

  /* End of SystemInitialize for SubSystem: '<S53>/O_SW_HVIL_Swt' */

  /* SystemInitialize for Chart: '<S61>/Chart' */
  CBMU_MON_Chart_Init(&CBMU_MON_B.sf_Chart_c);

  /* SystemInitialize for Atomic SubSystem: '<S61>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt_e_Init();

  /* End of SystemInitialize for SubSystem: '<S61>/O_SW_HVIL_Swt' */

  /* SystemInitialize for Chart: '<S62>/Chart' */
  CBMU_MON_B.bitsForTID0.SafeBag_St = false;

  /* SystemInitialize for Atomic SubSystem: '<S7>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt_o_Init();

  /* End of SystemInitialize for SubSystem: '<S7>/O_SW_HVIL_Swt' */

  /* SystemInitialize for Atomic SubSystem: '<S60>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt_d_Init();

  /* End of SystemInitialize for SubSystem: '<S60>/O_SW_HVIL_Swt' */

  /* SystemInitialize for Chart: '<S79>/Chart' */
  com_BPSDisChMRelaySts = 0U;

  /* SystemInitialize for Atomic SubSystem: '<S60>/O_SW_PosRlyCtl_Swt' */
  CBMU_MO_O_SW_PosRlyCtl_Swt_Init();

  /* End of SystemInitialize for SubSystem: '<S60>/O_SW_PosRlyCtl_Swt' */

  /* SystemInitialize for Atomic SubSystem: '<S60>/O_SW_HVIL_Swt1' */
  CBMU_MON_O_SW_HVIL_Swt1_Init();

  /* End of SystemInitialize for SubSystem: '<S60>/O_SW_HVIL_Swt1' */

  /* SystemInitialize for Chart: '<S74>/Chart' */
  com_BPSChMRelaySts = 0U;

  /* SystemInitialize for Atomic SubSystem: '<S60>/O_SW_NegRlyCtl_Swt' */
  CBMU_MO_O_SW_NegRlyCtl_Swt_Init();

  /* End of SystemInitialize for SubSystem: '<S60>/O_SW_NegRlyCtl_Swt' */

  /* SystemInitialize for Chart: '<S52>/Chart' */
  CBMU_MON_Chart_Init(&CBMU_MON_B.sf_Chart_i);

  /* SystemInitialize for Atomic SubSystem: '<S52>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt_Init();

  /* End of SystemInitialize for SubSystem: '<S52>/O_SW_HVIL_Swt' */
}

/* Output and update for atomic system: '<S1>/SID' */
void CBMU_MON_SID(void)
{
  boolean_T rtb_RelationalOperator2_f;
  uint8_T rtb_DataTypeConversion6;
  int16_T tmp;
  boolean_T guard1 = false;
  boolean_T guard2 = false;

  /* Outputs for Atomic SubSystem: '<S104>/SRC_Check' */

  /* Constant: '<S104>/Constant1' incorporates:
   *  Constant: '<S104>/Constant2'
   *  Constant: '<S104>/Constant3'
   *  Constant: '<S104>/Constant4'
   *  Constant: '<S104>/Constant5'
   *  Constant: '<S104>/Constant6'
   *  Constant: '<S104>/Constant7'
   *  Constant: '<S104>/Constant8'
   *  Inport: '<Root>/ioa_battVoltActRaw'
   */
  CBMU_MON_SRC_Check(false, ioa_battVoltActRaw, BatVoltSigASRCHigh,
                     BatVoltSigASRCLow, BatVoltSigASRCHighPosDeb,
                     BatVoltSigASRCHighNegDeb, BatVoltSigASRCLowPosDeb,
                     BatVoltSigASRCLowNegDeb, ((uint8_T)StepTim),
                     &CBMU_MON_B.SRC_Check, &CBMU_MON_DWork.SRC_Check);

  /* End of Outputs for SubSystem: '<S104>/SRC_Check' */

  /* Switch: '<S95>/Switch2' incorporates:
   *  Constant: '<S95>/Constant4'
   *  DataStoreRead: '<S95>/Data Store Read1'
   *  Logic: '<S95>/Logical Operator3'
   */
  if (!(CBMU_MON_DWork.Dem_stClear != 0)) {
    rtb_DataTypeConversion6 = CBMU_MON_B.SRC_Check.SRC_Def_Status;
  } else {
    rtb_DataTypeConversion6 = ((uint8_T)SRC_NON_DEF);
  }

  /* End of Switch: '<S95>/Switch2' */

  /* Switch: '<S95>/Switch' incorporates:
   *  Constant: '<S95>/Constant4'
   *  RelationalOperator: '<S95>/Relational Operator1'
   */
  if (rtb_DataTypeConversion6 != ((uint8_T)SRC_NON_DEF)) {
    BatVolt_St = CBMU_MON_B.SRC_Check.SRC_Def_Status;
  } else {
    BatVolt_St = ((uint8_T)SRC_NON_DEF);
  }

  /* End of Switch: '<S95>/Switch' */

  /* SwitchCase: '<S7>/Switch Case1' incorporates:
   *  Constant: '<S7>/Constant13'
   *  Constant: '<S7>/Constant9'
   *  Inport: '<S54>/L1'
   *  Inport: '<S57>/L1'
   *  Inport: '<S58>/L1'
   */
  switch ((int32_T)BatVolt_St) {
   case 1L:
    /* Outputs for IfAction SubSystem: '<S7>/High' incorporates:
     *  ActionPort: '<S54>/Action Port'
     */
    rtb_DataTypeConversion6 = 1U;

    /* End of Outputs for SubSystem: '<S7>/High' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S7>/Low' incorporates:
     *  ActionPort: '<S57>/Action Port'
     */
    rtb_DataTypeConversion6 = 0U;

    /* End of Outputs for SubSystem: '<S7>/Low' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S7>/Normal' incorporates:
     *  ActionPort: '<S58>/Action Port'
     */
    rtb_DataTypeConversion6 = 0U;

    /* End of Outputs for SubSystem: '<S7>/Normal' */
    break;
  }

  /* End of SwitchCase: '<S7>/Switch Case1' */

  /* DataTypeConversion: '<S7>/Data Type Conversion3' incorporates:
   *  Constant: '<S7>/Constant6'
   *  RelationalOperator: '<S7>/Relational Operator3'
   */
  rtb_DataTypeConversion6 = (uint8_T)(rtb_DataTypeConversion6 != ((uint8_T)
    SRC_NON_DEF));

  /* S-Function (sfun_SetErr): '<S7>/sfun_SetErr_SrcH3' incorporates:
   *  Constant: '<S7>/Constant5'
   */
  Dem_SetError( (uint16_T)37U, (uint8_T)rtb_DataTypeConversion6);

  /* Switch: '<S98>/Switch' incorporates:
   *  Constant: '<S63>/Constant7'
   *  Constant: '<S63>/Constant8'
   *  Constant: '<S98>/Constant'
   *  Inport: '<Root>/ioa_ScVoltActRaw'
   *  RelationalOperator: '<S98>/Relational Operator'
   *  RelationalOperator: '<S98>/Relational Operator1'
   *  UnitDelay: '<S98>/Unit Delay'
   */
  if (ioa_chrgVoltActRaw >= ScSwtHigh) {
    I_S_Sc = true;
  } else {
    I_S_Sc = ((!(ioa_chrgVoltActRaw <= ScSwtLow)) && I_S_Sc);
  }

  /* End of Switch: '<S98>/Switch' */

  /* Outputs for Atomic SubSystem: '<S114>/SRC_Check' */

  /* Constant: '<S114>/Constant1' incorporates:
   *  Constant: '<S114>/Constant2'
   *  Constant: '<S114>/Constant3'
   *  Constant: '<S114>/Constant4'
   *  Constant: '<S114>/Constant5'
   *  Constant: '<S114>/Constant6'
   *  Constant: '<S114>/Constant7'
   *  Constant: '<S114>/Constant8'
   *  Inport: '<Root>/ioa_ScVoltActRaw'
   */
  CBMU_MON_SRC_Check(false, ioa_chrgVoltActRaw, ScVoltSigASRCHigh,
                     ScVoltSigASRCLow, BatVoltSigASRCHighPosDeb,
                     BatVoltSigASRCHighNegDeb, BatVoltSigASRCLowPosDeb,
                     BatVoltSigASRCLowNegDeb, ((uint8_T)StepTim),
                     &CBMU_MON_B.SRC_Check_b, &CBMU_MON_DWork.SRC_Check_b);

  /* End of Outputs for SubSystem: '<S114>/SRC_Check' */

  /* Switch: '<S100>/Switch2' incorporates:
   *  Constant: '<S100>/Constant4'
   *  DataStoreRead: '<S100>/Data Store Read1'
   *  Logic: '<S100>/Logical Operator3'
   */
  if (!(CBMU_MON_DWork.Dem_stClear_p != 0)) {
    rtb_DataTypeConversion6 = CBMU_MON_B.SRC_Check_b.SRC_Def_Status;
  } else {
    rtb_DataTypeConversion6 = ((uint8_T)SRC_NON_DEF);
  }

  /* End of Switch: '<S100>/Switch2' */

  /* Switch: '<S100>/Switch' incorporates:
   *  Constant: '<S100>/Constant4'
   *  RelationalOperator: '<S100>/Relational Operator1'
   */
  if (rtb_DataTypeConversion6 != ((uint8_T)SRC_NON_DEF)) {
    ScVolt_St = CBMU_MON_B.SRC_Check_b.SRC_Def_Status;
  } else {
    ScVolt_St = ((uint8_T)SRC_NON_DEF);
  }

  /* End of Switch: '<S100>/Switch' */

  /* Switch: '<S97>/Switch' incorporates:
   *  Constant: '<S63>/Constant10'
   *  Constant: '<S63>/Constant9'
   *  Constant: '<S97>/Constant'
   *  Inport: '<Root>/ioa_T15VoltActRaw'
   *  RelationalOperator: '<S97>/Relational Operator'
   *  RelationalOperator: '<S97>/Relational Operator1'
   *  UnitDelay: '<S97>/Unit Delay'
   */
  if (ioa_T15VoltActRaw >= T15SwtHigh) {
    I_S_T15 = true;
  } else {
    I_S_T15 = ((!(ioa_T15VoltActRaw <= T15SwtLow)) && I_S_T15);
  }

  /* End of Switch: '<S97>/Switch' */

  /* Outputs for Atomic SubSystem: '<S119>/SRC_Check' */

  /* Constant: '<S119>/Constant1' incorporates:
   *  Constant: '<S119>/Constant2'
   *  Constant: '<S119>/Constant3'
   *  Constant: '<S119>/Constant4'
   *  Constant: '<S119>/Constant5'
   *  Constant: '<S119>/Constant6'
   *  Constant: '<S119>/Constant7'
   *  Constant: '<S119>/Constant8'
   *  Inport: '<Root>/ioa_T15VoltActRaw'
   */
  CBMU_MON_SRC_Check(false, ioa_T15VoltActRaw, T15VoltSigASRCHigh,
                     T15VoltSigASRCLow, BatVoltSigASRCHighPosDeb,
                     BatVoltSigASRCHighNegDeb, BatVoltSigASRCLowPosDeb,
                     BatVoltSigASRCLowNegDeb, ((uint8_T)StepTim),
                     &CBMU_MON_B.SRC_Check_l, &CBMU_MON_DWork.SRC_Check_l);

  /* End of Outputs for SubSystem: '<S119>/SRC_Check' */

  /* Outputs for Atomic SubSystem: '<S109>/SRC_Check' */

  /* Constant: '<S109>/Constant1' incorporates:
   *  Constant: '<S109>/Constant2'
   *  Constant: '<S109>/Constant3'
   *  Constant: '<S109>/Constant4'
   *  Constant: '<S109>/Constant5'
   *  Constant: '<S109>/Constant6'
   *  Constant: '<S109>/Constant7'
   *  Constant: '<S109>/Constant8'
   *  Inport: '<Root>/ioa_FC12VVoltActRaw'
   */
  CBMU_MON_SRC_Check(false, ioa_FC12VVoltActRaw, FcVoltSigASRCHigh,
                     FcVoltSigASRCLow, BatVoltSigASRCHighPosDeb,
                     BatVoltSigASRCHighNegDeb, BatVoltSigASRCLowPosDeb,
                     BatVoltSigASRCLowNegDeb, ((uint8_T)StepTim),
                     &CBMU_MON_B.SRC_Check_e, &CBMU_MON_DWork.SRC_Check_e);

  /* End of Outputs for SubSystem: '<S109>/SRC_Check' */

  /* Switch: '<S96>/Switch2' incorporates:
   *  Constant: '<S96>/Constant4'
   *  DataStoreRead: '<S96>/Data Store Read1'
   *  Logic: '<S96>/Logical Operator3'
   */
  if (!(CBMU_MON_DWork.Dem_stClear_p2 != 0)) {
    rtb_DataTypeConversion6 = CBMU_MON_B.SRC_Check_e.SRC_Def_Status;
  } else {
    rtb_DataTypeConversion6 = ((uint8_T)SRC_NON_DEF);
  }

  /* End of Switch: '<S96>/Switch2' */

  /* Switch: '<S96>/Switch' incorporates:
   *  Constant: '<S96>/Constant4'
   *  RelationalOperator: '<S96>/Relational Operator1'
   */
  if (rtb_DataTypeConversion6 != ((uint8_T)SRC_NON_DEF)) {
    FcVolt_St = CBMU_MON_B.SRC_Check_e.SRC_Def_Status;
  } else {
    FcVolt_St = ((uint8_T)SRC_NON_DEF);
  }

  /* End of Switch: '<S96>/Switch' */

  /* Switch: '<S99>/Switch' incorporates:
   *  Constant: '<S63>/Constant2'
   *  Constant: '<S63>/Constant3'
   *  Constant: '<S99>/Constant'
   *  Inport: '<Root>/ioa_FC12VVoltActRaw'
   *  RelationalOperator: '<S99>/Relational Operator'
   *  RelationalOperator: '<S99>/Relational Operator1'
   *  UnitDelay: '<S99>/Unit Delay'
   */
  if (ioa_FC12VVoltActRaw >= FcSwtHigh) {
    I_S_Fc = true;
  } else {
    I_S_Fc = ((!(ioa_FC12VVoltActRaw <= FcSwtLow)) && I_S_Fc);
  }

  /* End of Switch: '<S99>/Switch' */

  /* Chart: '<S53>/Chart' incorporates:
   *  Inport: '<Root>/ioa_HVILVoltActRaw '
   */
  /* Gateway: Task_10ms/SID/HVIL/Chart */
  /* During: Task_10ms/SID/HVIL/Chart */
  /* Entry Internal: Task_10ms/SID/HVIL/Chart */
  /* Transition: '<S68>:11' */
  /*  HVIL swt tell  */
  if (ioa_HVILVoltActRaw < 901U) {
    /* Transition: '<S68>:13' */
    /* Transition: '<S68>:14' */
    CBMU_MON_B.bitsForTID0.O_S_HVIL_Swt = true;

    /* Transition: '<S68>:17' */
    /* Transition: '<S68>:18' */
  } else {
    /* Transition: '<S68>:12' */
    if (ioa_HVILVoltActRaw > 1720U) {
      /* Transition: '<S68>:15' */
      /* Transition: '<S68>:16' */
      CBMU_MON_B.bitsForTID0.O_S_HVIL_Swt = false;

      /* Transition: '<S68>:18' */
    } else {
      /* Transition: '<S68>:19' */
    }
  }

  /* End of Chart: '<S53>/Chart' */

  /* Outputs for Atomic SubSystem: '<S53>/O_SW_HVIL_Swt' */

  /* Transition: '<S68>:20' */
  CBMU_MON_O_SW_HVIL_Swt_e();

  /* End of Outputs for SubSystem: '<S53>/O_SW_HVIL_Swt' */

  /* DataTypeConversion: '<S7>/Data Type Conversion4' incorporates:
   *  RelationalOperator: '<S7>/Relational Operator1'
   */
  HVIL_test0 = (uint8_T)
    !CBMU_MON_O_SW_HVIL_Swt_B_h.Swtich_Debouncing.bitsForTID0.swtDeb;

  /* S-Function (sfun_SetErr): '<S7>/sfun_SetErr_SrcH4' incorporates:
   *  Constant: '<S7>/Constant11'
   */
  Dem_SetError( (uint16_T)33U, (uint8_T)HVIL_test0);

  /* Chart: '<S61>/Chart' incorporates:
   *  Constant: '<S61>/Constant'
   *  Constant: '<S61>/Constant1'
   *  Inport: '<Root>/ioa_SCCCVoltActRaw'
   */
  CBMU_MON_Chart(ioa_SCCCVoltActRaw, SCCC_High, SCCC_Low, &CBMU_MON_B.sf_Chart_c);

  /* Outputs for Atomic SubSystem: '<S61>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt_p();

  /* End of Outputs for SubSystem: '<S61>/O_SW_HVIL_Swt' */

  /* Chart: '<S62>/Chart' */
  /* Gateway: Task_10ms/SID/SafeBagMon/Chart */
  /* During: Task_10ms/SID/SafeBagMon/Chart */
  /* Entry Internal: Task_10ms/SID/SafeBagMon/Chart */
  /* Transition: '<S94>:62' */
  if (CBMU_MON_B.Memory1 == 1) {
    /* Transition: '<S94>:46' */
    /* Transition: '<S94>:48' */
    tmp = ect_count + 1;
    if (tmp > 255) {
      tmp = 255;
    }

    ect_count = (uint8_T)tmp;
    guard1 = false;
    guard2 = false;
    if (ect_count > 50) {
      /* Transition: '<S94>:41' */
      /* Transition: '<S94>:54' */
      ect_count = 0U;
      CBMU_MON_B.bitsForTID0.SafeBag_St = false;
      ect_AirbagNormal = 0U;

      /* Transition: '<S94>:24' */
      /* Transition: '<S94>:26' */
      guard1 = true;
    } else {
      /* Transition: '<S94>:50' */
      if (ect_AirbagNormal == 1) {
        /* Transition: '<S94>:20' */
        /* Transition: '<S94>:21' */
        tmp = SafebagNormalCount + 1;
        if (tmp > 255) {
          tmp = 255;
        }

        SafebagNormalCount = (uint8_T)tmp;
        SafebagErrCount = 0U;
        guard2 = true;
      } else {
        if (ect_AirbagNormal == 0) {
          /* Transition: '<S94>:18' */
          /* Transition: '<S94>:19' */
          SafebagNormalCount = 0U;
          tmp = SafebagErrCount + 1;
          if (tmp > 255) {
            tmp = 255;
          }

          SafebagErrCount = (uint8_T)tmp;
          guard2 = true;
        }
      }
    }

    if (guard2) {
      if (SafebagNormalCount > 120) {
        /* Transition: '<S94>:25' */
        /* Transition: '<S94>:59' */
        CBMU_MON_B.bitsForTID0.SafeBag_St = true;
        guard1 = true;
      } else if (SafebagErrCount > 250) {
        /* Transition: '<S94>:22' */
        /* Transition: '<S94>:66' */
        CBMU_MON_B.bitsForTID0.SafeBag_St = false;

        /* Transition: '<S94>:24' */
        /* Transition: '<S94>:26' */
        guard1 = true;
      } else {
        /* Transition: '<S94>:57' */
      }
    }

    if (guard1) {
      /* Transition: '<S94>:53' */
      SafebagNormalCount = 0U;
      SafebagErrCount = 0U;
    }
  }

  /* End of Chart: '<S62>/Chart' */

  /* Outputs for IfAction SubSystem: '<S7>/If Action Subsystem' incorporates:
   *  ActionPort: '<S55>/Action Port'
   */
  /* If: '<S7>/If' incorporates:
   *  Constant: '<S7>/Constant17'
   *  Inport: '<S55>/In1'
   *  Switch: '<S7>/Switch'
   */
  O_S_AirBag = (SafeBag_TestPoint || ((!(CBMU_MON_B.Memory1 == 1)) ||
    CBMU_MON_B.bitsForTID0.SafeBag_St));

  /* End of Outputs for SubSystem: '<S7>/If Action Subsystem' */

  /* RelationalOperator: '<S7>/Relational Operator4' */
  SafeBag_test0 = !O_S_AirBag;

  /* DataTypeConversion: '<S7>/Data Type Conversion1' */
  rtb_DataTypeConversion6 = SafeBag_test0;

  /* S-Function (sfun_SetErr): '<S7>/sfun_SetErr_SrcH1' incorporates:
   *  Constant: '<S7>/Constant1'
   */
  Dem_SetError( (uint16_T)34U, (uint8_T)rtb_DataTypeConversion6);

  /* Outputs for Atomic SubSystem: '<S7>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt_k();

  /* End of Outputs for SubSystem: '<S7>/O_SW_HVIL_Swt' */

  /* Switch: '<S7>/Switch1' incorporates:
   *  Constant: '<S51>/Constant'
   *  RelationalOperator: '<S51>/Compare'
   */
  CBMU_MON_B.bitsForTID0.Switch1 = ((CBMU_MON_B.Memory1 == 1) &&
    CBMU_MON_O_SW_HVIL_Swt_B_e.Swtich_Debouncing.bitsForTID0.swtDeb);

  /* Outputs for Atomic SubSystem: '<S60>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt_l();

  /* End of Outputs for SubSystem: '<S60>/O_SW_HVIL_Swt' */

  /* Chart: '<S79>/Chart' */
  /* Gateway: Task_10ms/SID/RlySitck/PosRlyCheck/Chart */
  /* During: Task_10ms/SID/RlySitck/PosRlyCheck/Chart */
  /* Entry Internal: Task_10ms/SID/RlySitck/PosRlyCheck/Chart */
  /* Transition: '<S89>:11' */
  if (CBMU_MON_B.bitsForTID0.RelationalOperator &&
      (!CBMU_MON_O_SW_HVIL_Swt_B_g.Swtich_Debouncing.bitsForTID0.swtDeb)) {
    /* Transition: '<S89>:12' */
    /* Transition: '<S89>:28' */
    com_BPSDisChMRelaySts = 1U;

    /* Transition: '<S89>:29' */
  } else {
    /* Transition: '<S89>:15' */
    if (CBMU_MON_B.bitsForTID0.RelationalOperator &&
        CBMU_MON_O_SW_HVIL_Swt_B_g.Swtich_Debouncing.bitsForTID0.swtDeb) {
      /* Transition: '<S89>:17' */
      /* Transition: '<S89>:33' */
      com_BPSDisChMRelaySts = 2U;

      /* Transition: '<S89>:38' */
      /* Transition: '<S89>:29' */
    } else {
      /* Transition: '<S89>:20' */
      if ((!CBMU_MON_B.bitsForTID0.RelationalOperator) &&
          CBMU_MON_O_SW_HVIL_Swt_B_g.Swtich_Debouncing.bitsForTID0.swtDeb) {
        /* Transition: '<S89>:21' */
        /* Transition: '<S89>:34' */
        com_BPSDisChMRelaySts = 0U;

        /* Transition: '<S89>:37' */
        /* Transition: '<S89>:38' */
        /* Transition: '<S89>:29' */
      } else {
        /* Transition: '<S89>:24' */
        if ((!CBMU_MON_B.bitsForTID0.RelationalOperator) &&
            (!CBMU_MON_O_SW_HVIL_Swt_B_g.Swtich_Debouncing.bitsForTID0.swtDeb))
        {
          /* Transition: '<S89>:25' */
          /* Transition: '<S89>:35' */
          com_BPSDisChMRelaySts = 2U;

          /* Transition: '<S89>:36' */
          /* Transition: '<S89>:37' */
          /* Transition: '<S89>:38' */
          /* Transition: '<S89>:29' */
        }
      }
    }
  }

  /* End of Chart: '<S79>/Chart' */

  /* RelationalOperator: '<S60>/Relational Operator' incorporates:
   *  Constant: '<S60>/Constant'
   */
  CBMU_MON_B.bitsForTID0.RelationalOperator = (com_BPSDisChMRelaySts == 2);

  /* Outputs for Atomic SubSystem: '<S60>/O_SW_PosRlyCtl_Swt' */
  CBMU_MON_O_SW_PosRlyCtl_Swt();

  /* End of Outputs for SubSystem: '<S60>/O_SW_PosRlyCtl_Swt' */

  /* RelationalOperator: '<S60>/Relational Operator2' */
  rtb_RelationalOperator2_f =
    CBMU_MON_O_SW_PosRlyCtl_Swt_B.Swtich_Debouncing.bitsForTID0.swtDeb;

  /* Outputs for Atomic SubSystem: '<S60>/O_SW_HVIL_Swt1' */
  CBMU_MON_O_SW_HVIL_Swt1();

  /* End of Outputs for SubSystem: '<S60>/O_SW_HVIL_Swt1' */

  /* Chart: '<S74>/Chart' */
  /* Gateway: Task_10ms/SID/RlySitck/NegRlyCheck/Chart */
  /* During: Task_10ms/SID/RlySitck/NegRlyCheck/Chart */
  /* Entry Internal: Task_10ms/SID/RlySitck/NegRlyCheck/Chart */
  /* Transition: '<S80>:11' */
  if (CBMU_MON_B.bitsForTID0.RelationalOperator1 &&
      (!CBMU_MON_O_SW_HVIL_Swt1_B.Swtich_Debouncing.bitsForTID0.swtDeb)) {
    /* Transition: '<S80>:12' */
    /* Transition: '<S80>:28' */
    com_BPSChMRelaySts = 1U;

    /* Transition: '<S80>:29' */
  } else {
    /* Transition: '<S80>:15' */
    if (CBMU_MON_B.bitsForTID0.RelationalOperator1 &&
        CBMU_MON_O_SW_HVIL_Swt1_B.Swtich_Debouncing.bitsForTID0.swtDeb) {
      /* Transition: '<S80>:17' */
      /* Transition: '<S80>:33' */
      com_BPSChMRelaySts = 2U;

      /* Transition: '<S80>:38' */
      /* Transition: '<S80>:29' */
    } else {
      /* Transition: '<S80>:20' */
      if ((!CBMU_MON_B.bitsForTID0.RelationalOperator1) &&
          CBMU_MON_O_SW_HVIL_Swt1_B.Swtich_Debouncing.bitsForTID0.swtDeb) {
        /* Transition: '<S80>:21' */
        /* Transition: '<S80>:34' */
        com_BPSChMRelaySts = 0U;

        /* Transition: '<S80>:37' */
        /* Transition: '<S80>:38' */
        /* Transition: '<S80>:29' */
      } else {
        /* Transition: '<S80>:24' */
        if ((!CBMU_MON_B.bitsForTID0.RelationalOperator1) &&
            (!CBMU_MON_O_SW_HVIL_Swt1_B.Swtich_Debouncing.bitsForTID0.swtDeb)) {
          /* Transition: '<S80>:25' */
          /* Transition: '<S80>:35' */
          com_BPSChMRelaySts = 2U;

          /* Transition: '<S80>:36' */
          /* Transition: '<S80>:37' */
          /* Transition: '<S80>:38' */
          /* Transition: '<S80>:29' */
        }
      }
    }
  }

  /* End of Chart: '<S74>/Chart' */

  /* RelationalOperator: '<S60>/Relational Operator1' incorporates:
   *  Constant: '<S60>/Constant'
   */
  CBMU_MON_B.bitsForTID0.RelationalOperator1 = (2 == com_BPSChMRelaySts);

  /* Outputs for Atomic SubSystem: '<S60>/O_SW_NegRlyCtl_Swt' */
  CBMU_MON_O_SW_NegRlyCtl_Swt();

  /* End of Outputs for SubSystem: '<S60>/O_SW_NegRlyCtl_Swt' */

  /* Logic: '<S60>/Logical Operator' incorporates:
   *  RelationalOperator: '<S60>/Relational Operator3'
   */
  rtb_RelationalOperator2_f = (rtb_RelationalOperator2_f ||
    CBMU_MON_O_SW_NegRlyCtl_Swt_B.Swtich_Debouncing.bitsForTID0.swtDeb);

  /* DataTypeConversion: '<S7>/Data Type Conversion2' */
  rtb_DataTypeConversion6 = rtb_RelationalOperator2_f;

  /* S-Function (sfun_SetErr): '<S7>/sfun_SetErr_SrcH2' incorporates:
   *  Constant: '<S7>/Constant3'
   */
  Dem_SetError( (uint16_T)35U, (uint8_T)rtb_DataTypeConversion6);

  /* Inport: '<S7>/HW_Err' incorporates:
   *  Inport: '<Root>/HW_Err'
   */
  CBMU_MON_B.bitsForTID0.HW_Err_n = HW_Err;

  /* DataTypeConversion: '<S7>/Data Type Conversion6' incorporates:
   *  RelationalOperator: '<S7>/Relational Operator6'
   */
  rtb_DataTypeConversion6 = CBMU_MON_B.bitsForTID0.HW_Err_n;

  /* S-Function (sfun_SetErr): '<S7>/sfun_SetErr_SrcH6' incorporates:
   *  Constant: '<S7>/Constant10'
   */
  Dem_SetError( (uint16_T)36U, (uint8_T)rtb_DataTypeConversion6);

  /* Chart: '<S52>/Chart' incorporates:
   *  Constant: '<S52>/Constant'
   *  Constant: '<S52>/Constant1'
   *  Inport: '<Root>/ioa_FCCCVoltActRaw'
   */
  CBMU_MON_Chart(ioa_FCCCVoltActRaw, FCCC_High, FCCC_Low, &CBMU_MON_B.sf_Chart_i);

  /* Outputs for Atomic SubSystem: '<S52>/O_SW_HVIL_Swt' */
  CBMU_MON_O_SW_HVIL_Swt();

  /* End of Outputs for SubSystem: '<S52>/O_SW_HVIL_Swt' */
}

/* Initialize for atomic system: '<S52>/O_SW_HVIL_Swt' */
void CBMU_M_O_SW_HVIL_Swt_initialize(void)
{
  (void) memset((void *) &CBMU_MON_O_SW_HVIL_Swt_B, 0,
                sizeof(rtB_O_SW_HVIL_Swt_CBMU_MON));

  /* exported global signals */
  O_S_FCCC = false;
  (void) memset((void *)&CBMU_MON_O_SW_HVIL_Swt_DW, 0,
                sizeof(rtDW_O_SW_HVIL_Swt_CBMU_MON));
}

/* Initialize for atomic system: '<S53>/O_SW_HVIL_Swt' */
void CBMU_O_SW_HVIL_Swt_h_initialize(void)
{
  (void) memset((void *) &CBMU_MON_O_SW_HVIL_Swt_B_h, 0,
                sizeof(rtB_O_SW_HVIL_Swt_CBMU_MON_i));
  (void) memset((void *)&CBMU_MON_O_SW_HVIL_Swt_DW_d, 0,
                sizeof(rtDW_O_SW_HVIL_Swt_CBMU_MON_e));
}

/* Initialize for atomic system: '<S7>/O_SW_HVIL_Swt' */
void CBMU_O_SW_HVIL_Swt_l_initialize(void)
{
  (void) memset((void *) &CBMU_MON_O_SW_HVIL_Swt_B_e, 0,
                sizeof(rtB_O_SW_HVIL_Swt_CBMU_MON_d));
  (void) memset((void *)&CBMU_MON_O_SW_HVIL_Swt_DW_c, 0,
                sizeof(rtDW_O_SW_HVIL_Swt_CBMU_MON_p));
}

/* Initialize for atomic system: '<S60>/O_SW_HVIL_Swt' */
void CBMU_O_SW_HVIL_Swt_p_initialize(void)
{
  (void) memset((void *) &CBMU_MON_O_SW_HVIL_Swt_B_g, 0,
                sizeof(rtB_O_SW_HVIL_Swt_CBMU_MON_m));
  (void) memset((void *)&CBMU_MON_O_SW_HVIL_Swt_DW_o, 0,
                sizeof(rtDW_O_SW_HVIL_Swt_CBMU_MON_k));
}

/* Initialize for atomic system: '<S60>/O_SW_HVIL_Swt1' */
void CBMU__O_SW_HVIL_Swt1_initialize(void)
{
  (void) memset((void *) &CBMU_MON_O_SW_HVIL_Swt1_B, 0,
                sizeof(rtB_O_SW_HVIL_Swt1_CBMU_MON));
  (void) memset((void *)&CBMU_MON_O_SW_HVIL_Swt1_DW, 0,
                sizeof(rtDW_O_SW_HVIL_Swt1_CBMU_MON));
}

/* Initialize for atomic system: '<S60>/O_SW_NegRlyCtl_Swt' */
void C_O_SW_NegRlyCtl_Swt_initialize(void)
{
  (void) memset((void *) &CBMU_MON_O_SW_NegRlyCtl_Swt_B, 0,
                sizeof(rtB_O_SW_NegRlyCtl_Swt_CBMU_MON));
  (void) memset((void *)&CBMU_MON_O_SW_NegRlyCtl_Swt_DW, 0,
                sizeof(rtDW_O_SW_NegRlyCtl_Swt_CBMU_MO));
}

/* Initialize for atomic system: '<S60>/O_SW_PosRlyCtl_Swt' */
void C_O_SW_PosRlyCtl_Swt_initialize(void)
{
  (void) memset((void *) &CBMU_MON_O_SW_PosRlyCtl_Swt_B, 0,
                sizeof(rtB_O_SW_PosRlyCtl_Swt_CBMU_MON));
  (void) memset((void *)&CBMU_MON_O_SW_PosRlyCtl_Swt_DW, 0,
                sizeof(rtDW_O_SW_PosRlyCtl_Swt_CBMU_MO));
}

/* Initialize for atomic system: '<S61>/O_SW_HVIL_Swt' */
void CBMU_O_SW_HVIL_Swt_k_initialize(void)
{
  (void) memset((void *) &CBMU_MON_O_SW_HVIL_Swt_B_hk, 0,
                sizeof(rtB_O_SW_HVIL_Swt_CBMU_MON_ii));

  /* exported global signals */
  O_S_SCCC = false;
  (void) memset((void *)&CBMU_MON_O_SW_HVIL_Swt_DW_b, 0,
                sizeof(rtDW_O_SW_HVIL_Swt_CBMU_MON_d));
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
