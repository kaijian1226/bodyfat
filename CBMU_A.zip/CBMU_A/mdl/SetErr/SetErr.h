typedef unsigned int uint16;
typedef unsigned char uint8;
extern uint16 errIndex;
extern uint8 errsStatus;
