/*******************************************************************************
*
*  FILE
*     Dcm_Appl.h
*
*  DESCRIPTION
*     The Application Interface Header file for Dcm  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*  DATE: 2014-01-06 
*******************************************************************************/

#ifndef _DCM_APPL_H_
#define _DCM_APPL_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Dcm.h"  
#include "Dem.h"

#ifndef _DCM_H_
//# error "Include sequence error! You must include Dcm.h before Dcm_Appl.h."
#endif
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
 
/* Read ECU identification */
#define DCM_READ_ECU_ID_SERIAL_NUM        0x82U
#define DCM_READ_ECU_ID_APPSW_VERSION     0x83U
#define DCM_READ_ECU_ID_BOOTSW_VERSION    0x84U
#define DCM_READ_ECU_ID_BSW_VERSION       0x88U
#define DCM_READ_ECU_ID_BSW_DATE          0x89U

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern const uint8 Dcm_AppSwVersion[12];    /* DF_BMS CHINA */
extern const uint8 Dcm_SerialNum[12] ;      /* ���кţ�888888888888*/
extern const uint8 Dcm_BootSwVersion[12] ;  /* 1.0000000000*/
extern const uint8 Dcm_BSWVersion[6] ;                      /*���綨�������汾��,V01.07*/
extern const uint8 Dcm_BSWDate[6] ;                         /*��������:10-08-31*/
extern const uint8 Dcm_BSWPartNumber[14] ;                  /*ECU Part Number*/
extern const uint8 Dcm_BSW_VIN[17] ;                        /*VIN:����ʶ�����*/
extern const uint8 Dcm_BSW_HardwareNumber[5] ;              /*ECU Hardware Number*/
extern const uint8 Dcm_BSW_AppSwNumber[5]  ;                 /*ECU Application Software Number*/
extern const uint8 Dcm_BSW_CalibrationSwNumber[5] ;         /*ECU Calibration Software Number*/
/* COP */
#define COP_RST_CTL   (*(volatile uint8*) 0x0000003CUL)
#define COP_RST_ADR   (*(volatile uint8*) 0x0000003FUL)

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,DCM_CODE) Dcm_ApplStartDefaultSession(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplStartEOLSession(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplStartProgSession(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplStartDevSession(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplResetPowerOn(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplClearFaultMemory(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplReadStatusOfDTC(Dcm_MsgContextType* pMsgContext);
//extern FUNC(void,DCM_CODE) Dcm_ApplReadInactiveDTC(Dcm_MsgContextType* pMsgContext);
//extern FUNC(void,DCM_CODE) Dcm_ApplReadActiveDTC(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplReadAllDTC(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplReportNumberOfDTC(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplReportDTC(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplReportDTCSnapshotID(Dcm_MsgContextType* pMsgContext);

extern FUNC(void,DCM_CODE) Dcm_ApplReadECUId(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplReadDataByLocalID(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplReadMemoryByAddr(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplReqSeedLvl1(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplSendKeyLvl1(Dcm_MsgContextType* pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_ApplMainFunction(void);

extern FUNC(uint8,DCM_CODE)App_DCM_Handle( Dcm_LocalIdType id,uint8* ptr,uint8 max_length);
extern FUNC(void,DCM_CODE) Dcm_DTCControlSetON(Dcm_MsgContextType* pMsgContext); //add 2013-7-31
extern FUNC(void,DCM_CODE) Dcm_DTCControlSetOFF(Dcm_MsgContextType* pMsgContext); //add 2013-7-31
extern void DCM_CODE Dcm_ApplEnableRxAndTx(Dcm_MsgContextType *pMsgContext);
extern void DCM_CODE Dcm_ApplDisableRxAndTx(Dcm_MsgContextType *pMsgContext);
extern void DCM_CODE Dcm_ApplRequestDownload(Dcm_MsgContextType *pMsgContext);
extern void DCM_CODE Dcm_ApplTransferData(Dcm_MsgContextType *pMsgContext);
extern void DCM_CODE Dcm_ApplRequestTransferExit(Dcm_MsgContextType *pMsgContext);


#endif /* #ifndef _DCM_APPL_H_ */
