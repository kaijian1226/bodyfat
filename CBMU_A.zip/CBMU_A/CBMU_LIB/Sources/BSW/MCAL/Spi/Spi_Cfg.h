/*******************************************************************************
*
*  FILE
*     SPI_Cfg.h
*
*  DESCRIPTION
*     The Configuration Header file for 9S12HY64 SPI Driver   
*      
*       
*  COPYRIGHT
*     (c)Copyright 2012, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*     Gu Bin
*
*  VERSION
*    1.0.0
*
*******************************************************************************/
#ifndef __SPI_CFG_H__
#define __SPI_CFG_H__

/*******************************************************************************
* include files
*******************************************************************************/

#include "Std_Types.h"

/*******************************************************************************
* Defines
*******************************************************************************/

/* SPI baudrate = BusClock/BaudRateDivisor 
  BaudRateDivisor = (SPPR+1)*(2^(SPR+1) 
  PE can be assitant for determine the baudrate
 
  fBUS=40MHZ,  fclk=1MB/s  ,  SPI_BAUDRATE = 0x42
               fclk=5MB/s  ,  SPI_BAUDRATE = 0x02
               fclk=2.5MB/s ,  SPI_BAUDRATE = 0x12
*/
#define SPI_BR_SET0  0x42

/* PIE=0,   Disable SPI interrupt
   SPE=1,   Enable SPI 
   SPTIE=0, Disable SPI transmit interrupt     
   MSTR=1,  SPI in Master mode
   CPOL=0,  Active-low clocks selected, in idle state SCK is high,
   CPHA=1,  Sample of data occurs at even edge of the SCK clock (2,4,6)
   SSOE=1,  SS not used or with MODF feature
   LSBFE=0  Data is transfered MSB first 
 */
#define SPI_CR1_SET0  0x56

/* bit7       empty
   XFRW=0,    Tranfer Width, 8 Bits  
   bit5       empty    
   MODFEN=1,  SS used 
   BIDIROE=0, Output buffer disabled
   bit2       empty
   SPISWAI=1, Stop SPI clock when in wait mode
   SPIC0=0    disable bidirectional operation 
 */
#define SPI_CR2_SET0  0x12




/* for baudrate 1MHz */
#define SPI_MAX_TIMES         200


/*******************************************************************************
* Macros
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration
*******************************************************************************/

/*******************************************************************************
* Global functions declaration
*******************************************************************************/



#endif /* __SPI_CFG_H__ */