#include "Pbs.h"


#define PBS_START_SEC_CODE_NEAR
#include "MemMap.h"

IRQFUNC(Pbs_Ect2Interrupt)
{
  //Pbs_HeartSigProcess(); 
  ECT_TFLG1 |= ECT_TFLG1_C2F_MASK;
   
}

IRQFUNC(Pbs_Ect3Interrupt)
{
  //Pbs_FaultCodeProcess();    
   ECT_TFLG1 |= ECT_TFLG1_C3F_MASK;

}

IRQFUNC(Pbs_Ect4Interrupt)
{
  //Pbs_FaultCodeProcess();    
   ECT_TFLG1 |= ECT_TFLG1_C4F_MASK;

}

IRQFUNC(AirBag_Ect0Interrupt)
{
  //Pbs_HeartMonitor();  //2013-06-25, AirBag Signal Input PWM
  AirBagSingalCapture();  
  ECT_TFLG1 |= ECT_TFLG1_C0F_MASK;

}

IRQFUNC(Pbs_Ect5Interrupt)
{
  //Pbs_FaultMonitor();    //2013-06-26
     ECT_TFLG1 |= ECT_TFLG1_C5F_MASK;

}


#define PBS_STOP_SEC_CODE_NEAR
#include "MemMap.h"