/*
 * File: CBMU_Data.h
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:39:52 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_CBMU_Data_h_
#define RTW_HEADER_CBMU_Data_h_
#include "rtwtypes.h"
#include "CBMU_MON_types.h"

/* Exported data define */
#define PWR_FC                         ((uint8_T) 3U)
#define PWR_SC                         ((uint8_T) 2U)
#define RELAY_OFF                      ((uint8_T) 0U)
#define RELAY_ON                       ((uint8_T) 1U)
#define RLY_ST_OPEN                    ((uint8_T) 0U)
#define SC_CHARGE_DISABLE              ((uint8_T) 1U)
#define SC_CHARGE_ENABLE               ((uint8_T) 0U)
#define SC_ST_CHARGING                 ((uint8_T) 1U)
#define SC_ST_ERR                      ((uint8_T) 2U)
#define SC_ST_FINISHED                 ((uint8_T) 3U)
#define SC_ST_NO_CHARGE                ((uint8_T) 0U)
#define SRC_HIGH_DEF                   ((uint8_T) 1U)
#define SRC_LOW_DEF                    ((uint8_T) 2U)
#define SRC_NON_DEF                    ((uint8_T) 0U)
#define SRC_TOO_HIGH_DEF               ((uint8_T) 3U)
#define SWT_OFF                        0
#define SWT_ON                         1
#define StepTim                        ((uint8_T) 10U)

/* Exported data declaration */
extern const uint8_T BMSCapacity;
extern const t_Voltage1 BatVoltSigASRCHigh;
extern const uint16_T BatVoltSigASRCHighNegDeb;
extern const uint16_T BatVoltSigASRCHighPosDeb;
extern const t_Voltage1 BatVoltSigASRCLow;
extern const uint16_T BatVoltSigASRCLowNegDeb;
extern const uint16_T BatVoltSigASRCLowPosDeb;
extern const t_Voltage1 FCCC_High;
extern const t_Voltage1 FCCC_Low;
extern const t_Voltage1 FcSwtHigh;
extern const t_Voltage1 FcSwtLow;
extern const t_Voltage1 FcVoltSigASRCHigh;
extern const t_Voltage1 FcVoltSigASRCLow;
extern const t_Voltage1 SCCC_High;
extern const t_Voltage1 SCCC_Low;
extern const boolean_T SafeBag_TestPoint;
extern const t_Voltage1 ScSwtHigh;
extern const t_Voltage1 ScSwtLow;
extern const t_Voltage1 ScVoltSigASRCHigh;
extern const t_Voltage1 ScVoltSigASRCLow;
extern const t_Voltage1 T15SwtHigh;
extern const t_Voltage1 T15SwtLow;
extern const t_Voltage1 T15VoltSigASRCHigh;
extern const t_Voltage1 T15VoltSigASRCLow;
extern uint8_T HVIL_test0;
extern boolean_T HW_Err;
extern boolean_T I_S_Fc;
extern boolean_T I_S_Sc;
extern boolean_T I_S_T15;
extern boolean_T O_S_AirBag;
extern boolean_T O_S_HVIL;
extern uint8_T PwrMode;
extern boolean_T SID_m_st_ChMRelay;
extern boolean_T SID_m_st_DisChMRelay;
extern boolean_T SafeBag_test0;

#endif                                 /* RTW_HEADER_CBMU_Data_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
