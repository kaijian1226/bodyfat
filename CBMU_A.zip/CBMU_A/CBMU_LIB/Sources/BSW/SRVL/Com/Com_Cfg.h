/*******************************************************************************
*
*  FILE
*     Com_Cfg.h
*
*  DESCRIPTION
*     The Configuration Header file for Com module  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    0.01
*
*******************************************************************************/

#ifndef _COM_CFG_H_
#define _COM_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "CanIf_Cfg.h"
#include "Com_Types.h"
#include "FC_PGN.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define COM_CYCLE_TIME              10

#define COM_RX_STRT_DELAY           1000

#define COM_NUMBER_OF_RX_PDU        CANIF_INIT_NUMBER_OF_CANRXPDUIDS//(22+8+3)

#define COM_NUMBER_OF_MSG_BMU       3

#define COM_ERROR_VALUE_SET         STD_ON


/* Rx Data */
/* Tx Data */ 
#define PG_DATALEN             8
#define CANTP_TEST_DATALEN     18//2015-07-07 xyl    
#define DM1_DATALEN   18//2015-07-07 xyl    

/* COM PDU */
#define COM_RX_HVA1_MSG              CANIF_RX_HVA1_MSG    //0
#define COM_RX_HVM1_MSG              CANIF_RX_HVM1_MSG
#define CON_RX_ISO_MSG             CANIF_RX_ISO_MSG
#define COM_RX_M1CMT_MSG             CANIF_RX_M1CMT_MSG
#define COM_RX_M1STS1_MSG            CANIF_RX_M1STS1_MSG
#define COM_RX_M1STS2_MSG            CANIF_RX_M1STS2_MSG
#define COM_RX_M2CMT_MSG             CANIF_RX_M2CMT_MSG
#define COM_RX_M2STS1_MSG            CANIF_RX_M2STS1_MSG
#define COM_RX_M2STS2_MSG            CANIF_RX_M2STS2_MSG
#define COM_RX_M3CMT_MSG             CANIF_RX_M3CMT_MSG
#define COM_RX_M3STS1_MSG            CANIF_RX_M3STS1_MSG
#define COM_RX_M3STS2_MSG            CANIF_RX_M3STS2_MSG
#define COM_RX_M4CMT_MSG             CANIF_RX_M4CMT_MSG
#define COM_RX_M4STS1_MSG            CANIF_RX_M4STS1_MSG
#define COM_RX_M4STS2_MSG            CANIF_RX_M4STS2_MSG //14                 //37  //
 //��������5~12��BMU add  20150805 
#define COM_RX_M5CMT_MSG              CANIF_RX_M5CMT_MSG //15                     //38
#define COM_RX_M5STS1_MSG             CANIF_RX_M5STS1_MSG                     //39
#define COM_RX_M5STS2_MSG             CANIF_RX_M5STS2_MSG                     //40
#define COM_RX_M6CMT_MSG              CANIF_RX_M6CMT_MSG                      //41
#define COM_RX_M6STS1_MSG             CANIF_RX_M6STS1_MSG                     //42
#define COM_RX_M6STS2_MSG             CANIF_RX_M6STS2_MSG                     //43
#define COM_RX_M7CMT_MSG              CANIF_RX_M7CMT_MSG                      //44
#define COM_RX_M7STS1_MSG             CANIF_RX_M7STS1_MSG                     //45
#define COM_RX_M7STS2_MSG             CANIF_RX_M7STS2_MSG                     //46
#define COM_RX_M8CMT_MSG              CANIF_RX_M8CMT_MSG                      //47
#define COM_RX_M8STS1_MSG             CANIF_RX_M8STS1_MSG                     //48
#define COM_RX_M8STS2_MSG             CANIF_RX_M8STS2_MSG                     //49
#define COM_RX_M9CMT_MSG              CANIF_RX_M9CMT_MSG                      //50
#define COM_RX_M9STS1_MSG             CANIF_RX_M9STS1_MSG                     //51
#define COM_RX_M9STS2_MSG             CANIF_RX_M9STS2_MSG                     //52
#define COM_RX_M10CMT_MSG             CANIF_RX_M10CMT_MSG                     //53
#define COM_RX_M10STS1_MSG            CANIF_RX_M10STS1_MSG                    //54
#define COM_RX_M10STS2_MSG            CANIF_RX_M10STS2_MSG                    //55
#define COM_RX_M11CMT_MSG             CANIF_RX_M11CMT_MSG                     //56
#define COM_RX_M11STS1_MSG            CANIF_RX_M11STS1_MSG                    //57
#define COM_RX_M11STS2_MSG            CANIF_RX_M11STS2_MSG                    //58
#define COM_RX_M12CMT_MSG             CANIF_RX_M12CMT_MSG                     //59
#define COM_RX_M12STS1_MSG            CANIF_RX_M12STS1_MSG                    //60
#define COM_RX_M12STS2_MSG            CANIF_RX_M12STS2_MSG//38
#define COM_RX_M13CMT_MSG             CANIF_RX_M13CMT_MSG                    
#define COM_RX_M13STS1_MSG            CANIF_RX_M13STS1_MSG                   
#define COM_RX_M13STS2_MSG            CANIF_RX_M13STS2_MSG                  
#define COM_RX_M14CMT_MSG             CANIF_RX_M14CMT_MSG                   
#define COM_RX_M14STS1_MSG            CANIF_RX_M14STS1_MSG                   
#define COM_RX_M14STS2_MSG            CANIF_RX_M14STS2_MSG
#define COM_RX_M15CMT_MSG             CANIF_RX_M15CMT_MSG                     
#define COM_RX_M15STS1_MSG            CANIF_RX_M15STS1_MSG                   
#define COM_RX_M15STS2_MSG            CANIF_RX_M15STS2_MSG                    
#define COM_RX_M16CMT_MSG             CANIF_RX_M16CMT_MSG                    
#define COM_RX_M16STS1_MSG            CANIF_RX_M16STS1_MSG                   
#define COM_RX_M16STS2_MSG            CANIF_RX_M16STS2_MSG
#define COM_RX_M17CMT_MSG             CANIF_RX_M17CMT_MSG                     
#define COM_RX_M17STS1_MSG            CANIF_RX_M17STS1_MSG                    
#define COM_RX_M17STS2_MSG            CANIF_RX_M17STS2_MSG                    
#define COM_RX_M18CMT_MSG             CANIF_RX_M18CMT_MSG                    
#define COM_RX_M18STS1_MSG            CANIF_RX_M18STS1_MSG                   
#define COM_RX_M18STS2_MSG            CANIF_RX_M18STS2_MSG
#define COM_RX_M19CMT_MSG             CANIF_RX_M19CMT_MSG                    
#define COM_RX_M19STS1_MSG            CANIF_RX_M19STS1_MSG                  
#define COM_RX_M19STS2_MSG            CANIF_RX_M19STS2_MSG                   
#define COM_RX_M20CMT_MSG             CANIF_RX_M20CMT_MSG                   
#define COM_RX_M20STS1_MSG            CANIF_RX_M20STS1_MSG                   
#define COM_RX_M20STS2_MSG            CANIF_RX_M20STS2_MSG
#define COM_RX_M21CMT_MSG             CANIF_RX_M21CMT_MSG                     
#define COM_RX_M21STS1_MSG            CANIF_RX_M21STS1_MSG                   
#define COM_RX_M21STS2_MSG            CANIF_RX_M21STS2_MSG                   
#define COM_RX_M22CMT_MSG             CANIF_RX_M22CMT_MSG                   
#define COM_RX_M22STS1_MSG            CANIF_RX_M22STS1_MSG                 
#define COM_RX_M22STS2_MSG            CANIF_RX_M22STS2_MSG
#define COM_RX_M23CMT_MSG             CANIF_RX_M23CMT_MSG                    
#define COM_RX_M23STS1_MSG            CANIF_RX_M23STS1_MSG                  
#define COM_RX_M23STS2_MSG            CANIF_RX_M23STS2_MSG                  
#define COM_RX_M24CMT_MSG             CANIF_RX_M24CMT_MSG                   
#define COM_RX_M24STS1_MSG            CANIF_RX_M24STS1_MSG                 
#define COM_RX_M24STS2_MSG            CANIF_RX_M24STS2_MSG
#define COM_RX_M25CMT_MSG             CANIF_RX_M25CMT_MSG                    
#define COM_RX_M25STS1_MSG            CANIF_RX_M25STS1_MSG                   
#define COM_RX_M25STS2_MSG            CANIF_RX_M25STS2_MSG   
                                                                              
#define COM_RX_M1CV1_MSG              CANIF_RX_M1CV1_MSG  //add20151210                 
#define COM_RX_M1CV2_MSG              CANIF_RX_M1CV2_MSG                  
#define COM_RX_M1CV3_MSG              CANIF_RX_M1CV3_MSG                   
#define COM_RX_M1CV4_MSG              CANIF_RX_M1CV4_MSG                    
#define COM_RX_M2CV1_MSG              CANIF_RX_M2CV1_MSG                   
#define COM_RX_M2CV2_MSG              CANIF_RX_M2CV2_MSG                  
#define COM_RX_M2CV3_MSG              CANIF_RX_M2CV3_MSG                   
#define COM_RX_M2CV4_MSG              CANIF_RX_M2CV4_MSG                    
#define COM_RX_M3CV1_MSG              CANIF_RX_M3CV1_MSG                   
#define COM_RX_M3CV2_MSG              CANIF_RX_M3CV2_MSG                  
#define COM_RX_M3CV3_MSG              CANIF_RX_M3CV3_MSG                   
#define COM_RX_M3CV4_MSG              CANIF_RX_M3CV4_MSG                    
#define COM_RX_M4CV1_MSG              CANIF_RX_M4CV1_MSG                   
#define COM_RX_M4CV2_MSG              CANIF_RX_M4CV2_MSG                  
#define COM_RX_M4CV3_MSG              CANIF_RX_M4CV3_MSG                   
#define COM_RX_M4CV4_MSG              CANIF_RX_M4CV4_MSG                    
#define COM_RX_M5CV1_MSG              CANIF_RX_M5CV1_MSG                   
#define COM_RX_M5CV2_MSG              CANIF_RX_M5CV2_MSG                  
#define COM_RX_M5CV3_MSG              CANIF_RX_M5CV3_MSG                   
#define COM_RX_M5CV4_MSG              CANIF_RX_M5CV4_MSG                    
#define COM_RX_M6CV1_MSG              CANIF_RX_M6CV1_MSG                   
#define COM_RX_M6CV2_MSG              CANIF_RX_M6CV2_MSG                  
#define COM_RX_M6CV3_MSG              CANIF_RX_M6CV3_MSG                   
#define COM_RX_M6CV4_MSG              CANIF_RX_M6CV4_MSG                    
#define COM_RX_M7CV1_MSG              CANIF_RX_M7CV1_MSG                   
#define COM_RX_M7CV2_MSG              CANIF_RX_M7CV2_MSG                  
#define COM_RX_M7CV3_MSG              CANIF_RX_M7CV3_MSG                   
#define COM_RX_M7CV4_MSG              CANIF_RX_M7CV4_MSG                    
#define COM_RX_M8CV1_MSG              CANIF_RX_M8CV1_MSG                   
#define COM_RX_M8CV2_MSG              CANIF_RX_M8CV2_MSG                  
#define COM_RX_M8CV3_MSG              CANIF_RX_M8CV3_MSG                   
#define COM_RX_M8CV4_MSG              CANIF_RX_M8CV4_MSG                    
#define COM_RX_M9CV1_MSG              CANIF_RX_M9CV1_MSG                   
#define COM_RX_M9CV2_MSG              CANIF_RX_M9CV2_MSG                  
#define COM_RX_M9CV3_MSG              CANIF_RX_M9CV3_MSG                   
#define COM_RX_M9CV4_MSG              CANIF_RX_M9CV4_MSG                    
#define COM_RX_M10CV1_MSG             CANIF_RX_M10CV1_MSG                   
#define COM_RX_M10CV2_MSG             CANIF_RX_M10CV2_MSG                  
#define COM_RX_M10CV3_MSG             CANIF_RX_M10CV3_MSG                   
#define COM_RX_M10CV4_MSG             CANIF_RX_M10CV4_MSG                    
#define COM_RX_M11CV1_MSG             CANIF_RX_M11CV1_MSG                   
#define COM_RX_M11CV2_MSG             CANIF_RX_M11CV2_MSG                  
#define COM_RX_M11CV3_MSG             CANIF_RX_M11CV3_MSG                   
#define COM_RX_M11CV4_MSG             CANIF_RX_M11CV4_MSG                        
#define COM_RX_M12CV1_MSG             CANIF_RX_M12CV1_MSG                   
#define COM_RX_M12CV2_MSG             CANIF_RX_M12CV2_MSG                  
#define COM_RX_M12CV3_MSG             CANIF_RX_M12CV3_MSG                   
#define COM_RX_M12CV4_MSG             CANIF_RX_M12CV4_MSG                        

#define COM_RX_TESTCMD2_MSG           CANIF_RX_TESTCMD2_MSG
#define COM_RX_XCP_MSG                CANIF_RX_XCP_MSG

#define COM_RX_DISRELAYDEBUG_MSG          CANIF_RX_DISRELAYDEBUG_MSG	//�ڲ�CAN�̵�����������

#define COM_RX_RESERVE1_MSG          CANIF_RX_RESERVE1_MSG

//�����
#define COM_RX_CCP1_MSG              CANIF_RX_CCP1_MSG             
#define COM_RX_MSP1_MSG              CANIF_RX_MSP1_MSG  
#define COM_RX_MSP3_MSG              CANIF_RX_MSP3_MSG  
#define COM_RX_VD_MSG                CANIF_RX_VD_MSG  
//minibus�������ձ��� add  20150805 
#define COM_RX_MB_ST_VMS_3           CANIF_RX_MB_ST_VMS_3 
#define COM_RX_MB_ST_MCU_2           CANIF_RX_MB_ST_MCU_2 //add20151205 
#define COM_RX_MB_ST_VMS_7           CANIF_RX_MB_ST_VMS_7   
#define COM_RX_MB_ST_CMU_5           CANIF_RX_MB_ST_CMU_5   

//���
#define COM_RX_CC_MSG                CANIF_RX_CC_MSG  
#define COM_RX_CS_MSG                CANIF_RX_CS_MSG  
//add by xql for fast charge
#define COM_RX_CRM_MSG               CANIF_RX_CRM_MSG
#define COM_RX_CTS_MSG               CANIF_RX_CTS_MSG
#define COM_RX_CML_MSG               CANIF_RX_CML_MSG
#define COM_RX_CRO_MSG               CANIF_RX_CRO_MSG
#define COM_RX_CCS_MSG               CANIF_RX_CCS_MSG
#define COM_RX_CST_MSG               CANIF_RX_CST_MSG
#define COM_RX_CSD_MSG               CANIF_RX_CSD_MSG
#define COM_RX_CEM_MSG               CANIF_RX_CEM_MSG

//add by xyl 2015-7-22 for test
#define COM_RX_DM1_MSG               CANIF_RX_DM1_MSG
#define COM_RX_BCP_MSG               CANIF_RX_BCP_MSG
#define COM_RX_BCS_MSG               CANIF_RX_BCS_MSG  
#define COM_RX_BRM_MSG               CANIF_RX_BRM_MSG
                  //61                
  
//COM_NUMBER_OF_RX_PDU should change when change
/////////////////////////////////////////////////////////////////////////////////////



/////////////////����Ϊ����/////////////////////////////////////
#define COM_IF_MAP_TX_CMD_MSG               CANIF_TX_CMD_STATIC_MSG    //0
#define COM_IF_MAP_TX_TD_MSG                CANIF_TX_TD_STATIC_MSG  
#define COM_IF_MAP_TX_TEST1_MSG             CANIF_TX_TEST1_STATIC_MSG  
#define COM_IF_MAP_TX_TEST2_MSG             CANIF_TX_TEST2_STATIC_MSG  
#define COM_IF_MAP_TX_RESERVE1_MSG             CANIF_TX_RESERVE1_STATIC_MSG  
#define COM_IF_MAP_TX_BPVP1_MSG             CANIF_TX_BPVP1_STATIC_MSG 
#define COM_IF_MAP_TX_BPTP1_MSG             CANIF_TX_BPTP1_STATIC_MSG 
#define COM_IF_MAP_TX_BPC1_MSG              CANIF_TX_BPC1_STATIC_MSG 
#define COM_IF_MAP_TX_BPC2_MSG              CANIF_TX_BPC2_STATIC_MSG 
#define COM_IF_MAP_TX_BPS_MSG               CANIF_TX_BPS_STATIC_MSG 
#define COM_IF_MAP_TX_CP_MSG                CANIF_TX_CP_STATIC_MSG 
#define COM_IF_MAP_TX_SP1_MSG               CANIF_TX_SP1_STATIC_MSG  //11
#define COM_IF_MAP_TX_SP2_MSG               CANIF_TX_SP2_STATIC_MSG 
#define COM_IF_MAP_TX_SP3_MSG               CANIF_TX_SP3_STATIC_MSG             
#define COM_IF_MAP_TX_BCI_MSG               CANIF_TX_BCI_STATIC_MSG 

#define COM_IF_MAP_TX_XCP_MSG               CANIF_TX_XCP_STATIC_MSG  //XCP
#define COM_IF_MAP_TX_CANTP_MSG             CANIF_TX_CANTP_STATIC_MSG//16

#define COM_IF_MAP_TX_TPCM_MSG              CANIF_TX_TPCM_STATIC_MSG  //
#define COM_IF_MAP_TX_TPDT_MSG              CANIF_TX_TPDT_STATIC_MSG//

#define COM_IF_MAP_TX_DM1_MSG               CANIF_TX_DM1_STATIC_MSG  //19
#define COM_IF_MAP_TX_BRM_MSG               CANIF_TX_BRM_STATIC_MSG  //20
#define COM_IF_MAP_TX_BCP_MSG               CANIF_TX_BCP_STATIC_MSG  //
#define COM_IF_MAP_TX_BRO_MSG               CANIF_TX_BRO_STATIC_MSG
#define COM_IF_MAP_TX_BCL_MSG               CANIF_TX_BCL_STATIC_MSG
#define COM_IF_MAP_TX_BCS_MSG               CANIF_TX_BCS_STATIC_MSG
#define COM_IF_MAP_TX_BSM_MSG               CANIF_TX_BSM_STATIC_MSG
#define COM_IF_MAP_TX_BST_MSG               CANIF_TX_BST_STATIC_MSG
#define COM_IF_MAP_TX_BSD_MSG               CANIF_TX_BSD_STATIC_MSG
#define COM_IF_MAP_TX_BEM_MSG               CANIF_TX_BEM_STATIC_MSG  //28
                                                                     
//4��MINIBUS�������ձ��� ���ӱ��  add 20150805                                                
#define COM_TX_MB_ST_BMS_1                CANIF_TX_MB_ST_BMS_1             // 29
#define COM_TX_MB_ST_BMS_2                CANIF_TX_MB_ST_BMS_2             // 30  
#define COM_TX_MB_ST_BMS_3                CANIF_TX_MB_ST_BMS_3             // 31  
#define COM_TX_MB_ST_BMS_4                CANIF_TX_MB_ST_BMS_4             // 32  
//#define CANIF_TX_ST_BMS_CHG               33  //Ŀǰû��
          //33  //Ŀǰû��

//COM�ĸ�����CANIF��һ����ȫ��Ӧ��ֻ��һ��ӳ��
//#define COM_NUMBER_OF_TX_PDU        (16+9)

typedef enum
{
  COM_TX_CMD_MSG_IDX  = 0,  //0      
  COM_TX_TD_MSG_IDX,         
  COM_TX_TEST1_MSG_IDX,      
  COM_TX_TEST2_MSG_IDX,      
  COM_TX_RESERVE1_MSG_IDX, 	 
  COM_TX_BPVP1_MSG_IDX,      
  COM_TX_BPTP1_MSG_IDX,    //6  
  COM_TX_BPC1_MSG_IDX,       
  COM_TX_BPC2_MSG_IDX,       
  COM_TX_BPS_MSG_IDX,        
  COM_TX_CP_MSG_IDX,         
  COM_TX_SP1_MSG_IDX,      //11 
  COM_TX_SP2_MSG_IDX,        
  COM_TX_SP3_MSG_IDX,   //13     
  COM_TX_BCI_MSG_IDX,        
  COM_TX_CANTP_MSG_IDX,      
  COM_TX_DM1_MSG_IDX,//16
  COM_TX_BRM_MSG_IDX,
  COM_TX_BCP_MSG_IDX,//J1939TP multi packets
  COM_TX_BRO_MSG_IDX,
  COM_TX_BCL_MSG_IDX,
  COM_TX_BCS_MSG_IDX,//J1939TP multi packets 21
  COM_TX_BSM_MSG_IDX,
  COM_TX_BST_MSG_IDX,
  COM_TX_BSD_MSG_IDX,
  COM_TX_BEM_MSG_IDX,//25
  
  COM_TX_MB_ST_BMS_1_IDX, //26
  COM_TX_MB_ST_BMS_2_IDX,
  COM_TX_MB_ST_BMS_3_IDX,
  COM_TX_MB_ST_BMS_4_IDX,
  
  COM_NUMBER_OF_TX_PDU,  //30
}Com_Tx_Index_Type;
                   
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern uint8 com_TxMsg_CMD[PG_DATALEN]; 
extern uint8 com_TxMsg_TD[PG_DATALEN]; 
extern uint8 com_TxMsg_TEST1[PG_DATALEN]; 
extern uint8 com_TxMsg_TEST2[PG_DATALEN]; 
extern uint8 com_TxMsg_RESERVE1[PG_DATALEN]; 

extern uint8 com_TxMsg_BPVP1[PG_DATALEN];  
extern uint8 com_TxMsg_BPTP1[PG_DATALEN];  
extern uint8 com_TxMsg_BPC1[PG_DATALEN];  
extern uint8 com_TxMsg_BPC2[PG_DATALEN];  
extern uint8 com_TxMsg_BPS[PG_DATALEN]; 
extern uint8 com_TxMsg_CP[PG_DATALEN];  
extern uint8 com_TxMsg_SP1[PG_DATALEN];  
extern uint8 com_TxMsg_SP2[PG_DATALEN];  
extern uint8 com_TxMsg_SP3[PG_DATALEN]; 
extern uint8 com_TxMsg_BCI[PG_DATALEN];  
extern uint8 com_TxMsg_DM1[DM1_DATALEN];//2015-07-10 xyl  
extern uint8 com_TxMsg_CANTP[CANTP_TEST_DATALEN];//2015-07-07 xyl 

//add by xql for fast charge Tx Msg,20150708
extern volatile struct BRM_tag 		com_TxMsg_BRM;
extern volatile struct BCP_tag 		com_TxMsg_BCP;
extern volatile struct BRO_tag 		com_TxMsg_BRO;
extern volatile struct BCL_tag 		com_TxMsg_BCL;
extern volatile struct BCS_tag 		com_TxMsg_BCS;
extern volatile struct BSM_tag 		com_TxMsg_BSM;
extern volatile struct BST_tag 		com_TxMsg_BST;
extern volatile struct BSD_tag 		com_TxMsg_BSD;
extern volatile struct BEM_tag 		com_TxMsg_BEM;
//for rx messages
//add by xql for fast charge Rx Msg,20150709  
extern volatile struct CRM_tag* 		com_RxMsg_CRM;
extern volatile struct CTS_tag* 		com_RxMsg_CTS;
extern volatile struct CML_tag* 		com_RxMsg_CML;
extern volatile struct CRO_tag* 		com_RxMsg_CRO;
extern volatile struct CCS_tag* 		com_RxMsg_CCS;
extern volatile struct CST_tag* 		com_RxMsg_CST;
extern volatile struct CSD_tag* 		com_RxMsg_CSD;
extern volatile struct CEM_tag* 		com_RxMsg_CEM;
//add by xyl 2015-7-22 for test
extern volatile uint8 com_RxMsg_DM1[DM1_DATALEN];//2015-07-23 xyl  
extern volatile struct BCP_tag 		com_RxMsg_BCP;
extern volatile struct BCS_tag 		com_RxMsg_BCS;   
extern volatile struct BRM_tag 		com_RxMsg_BRM;

//add 20150805 
//////////////////////////////////////�ⲿ����	���Ľṹ������	����	Com_Cfg.h add 20150805 //////////////////////////////////////
//////////////����
extern volatile  struct MB_ST_BMS_1_tag  com_TxMsg_MB_ST_BMS_1;//0x18FF200F,8 bytes,cyc 100ms		BMS->VMS
extern volatile  struct MB_ST_BMS_2_tag  com_TxMsg_MB_ST_BMS_2;//0x18FF210F,8 bytes,cyc 100ms		BMS->VMS
extern volatile  struct MB_ST_BMS_3_tag  com_TxMsg_MB_ST_BMS_3;//0x18FF220F,8 bytes,cyc 100ms		BMS->VMS
extern volatile  struct MB_ST_BMS_4_tag  com_TxMsg_MB_ST_BMS_4;//0x18FF230F,8 bytes,cyc 100ms		BMS->VMS
//////////////����
//extern volatile  struct MB_ST_VMS_3_tag*  com_RxMsg_MB_ST_VMS_3;//0x18FF132F,8 bytes,cyc 20ms		VMS->BMS

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

/*******************************************************************************
* Global Constant declaration                         
*******************************************************************************/
extern const uint8 com_TimeOutPosDeb_C;

extern const uint8 com_TimeOutNegDeb_C;

extern const Com_PduTxConfigType com_TxConfig_C[COM_NUMBER_OF_TX_PDU];

extern const Com_PduRxConfigType com_RxConfig_C[COM_NUMBER_OF_RX_PDU];

#endif /* #ifndef _COM_CFG_H_ */
