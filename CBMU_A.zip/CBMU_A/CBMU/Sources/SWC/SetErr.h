

#include "VFB.h"



/*



#define EUREKA_CAL
EUREKA_CAL uint8_T BMSCapacity = 100U;
EUREKA_CAL t_Voltage1 BatVoltSigASRCHigh = 26214U;
EUREKA_CAL uint16_T BatVoltSigASRCHighNegDeb = 300U;
EUREKA_CAL uint16_T BatVoltSigASRCHighPosDeb = 300U;
EUREKA_CAL t_Voltage1 BatVoltSigASRCLow = 16384U;
EUREKA_CAL uint16_T BatVoltSigASRCLowNegDeb = 300U;
EUREKA_CAL uint16_T BatVoltSigASRCLowPosDeb = 300U;
EUREKA_CAL t_Voltage1 FCCC_High = 2867U;
EUREKA_CAL t_Voltage1 FCCC_Low = 1638U;
EUREKA_CAL t_Voltage1 FcSwtHigh = 6554U;
EUREKA_CAL t_Voltage1 FcSwtLow = 4096U;
EUREKA_CAL t_Voltage1 FcVoltSigASRCHigh = 26214U;
EUREKA_CAL t_Voltage1 FcVoltSigASRCLow = 13107U;
EUREKA_CAL t_Voltage1 SCCC_High = 2703U;
EUREKA_CAL t_Voltage1 SCCC_Low = 1761U;
EUREKA_CAL boolean_T SafeBag_TestPoint = 1;
EUREKA_CAL t_Voltage1 ScSwtHigh = 6554U;
EUREKA_CAL t_Voltage1 ScSwtLow = 4096U;
EUREKA_CAL t_Voltage1 ScVoltSigASRCHigh = 26214U;
EUREKA_CAL t_Voltage1 ScVoltSigASRCLow = 13107U;
EUREKA_CAL t_Voltage1 T15SwtHigh = 6554U;
EUREKA_CAL t_Voltage1 T15SwtLow = 4096U;
EUREKA_CAL t_Voltage1 T15VoltSigASRCHigh = 26214U;
EUREKA_CAL t_Voltage1 T15VoltSigASRCLow = 13107U;



EUREKA_CAL uint16_T BmsSigASRCHighNegDeb = 3000U;
EUREKA_CAL uint16_T BmsSigASRCHighPosDeb = 3000U;
EUREKA_CAL uint16_T BmsSigASRCLowNegDeb = 3000U;
EUREKA_CAL uint16_T BmsSigASRCLowPosDeb = 3000U;
EUREKA_CAL t_Voltage3 CellVoltDiffSigASRCHigh = 1638U;
EUREKA_CAL t_Voltage3 CellVoltDiffSigASRCLow = 0U;
EUREKA_CAL t_Voltage3 CellVoltSigASRCHigh = 11960U;
EUREKA_CAL t_Voltage3 CellVoltSigASRCLow = 9175U;
EUREKA_CAL t_Voltage3 CellVoltSigASRCTooHigh = 12452U;
EUREKA_CAL t_Voltage3 CellVoltSigASRCTooLow = 8192U;
EUREKA_CAL t_Temp1 DiffTempSigASRCHigh = 48U;
EUREKA_CAL t_Temp1 DiffTempSigASRCLow = 40U;
EUREKA_CAL t_Current1 DsgCurSigASRCHigh = 37312U;
EUREKA_CAL t_Current1 DsgCurSigASRCLow = 25152U;
EUREKA_CAL t_Current1 DsgCurSigASRCTooHigh = 37312U;
EUREKA_CAL t_Current1 DsgCurSigASRCTooLow = 24512U;
EUREKA_CAL t_Temp1 DsgTempSigASRCHigh = 90U;
EUREKA_CAL t_Temp1 DsgTempSigASRCLow = 25U;
EUREKA_CAL t_Temp1 DsgTempSigASRCTooHigh = 93U;
EUREKA_CAL t_Temp1 DsgTempSigASRCTooLow = 20U;
EUREKA_CAL t_Current1 FcCurSigASRCHigh = 35872U;
EUREKA_CAL t_Current1 FcCurSigASRCLow = 32512U;
EUREKA_CAL t_Current1 FcCurSigASRCTooHigh = 36352U;
EUREKA_CAL t_Current1 FcCurSigASRCTooLow = 32512U;
EUREKA_CAL t_Temp1 FcTempSigASRCHigh = 80U;
EUREKA_CAL t_Temp1 FcTempSigASRCLow = 45U;
EUREKA_CAL t_Temp1 FcTempSigASRCTooHigh = 85U;
EUREKA_CAL t_Temp1 FcTempSigASRCTooLow = 45U;
EUREKA_CAL uint16_T IsoSigASRCHigh = 6500U;
EUREKA_CAL uint16_T IsoSigASRCLow = 200U;
EUREKA_CAL uint16_T IsoSigASRCTooHigh = 6500U;
EUREKA_CAL uint16_T IsoSigASRCTooLow = 100U;
EUREKA_CAL t_Voltage3 LTCellVoltSigASRCHigh = 10486U;
EUREKA_CAL t_Voltage3 LTCellVoltSigASRCLow = 7537U;
EUREKA_CAL t_Voltage3 LTCellVoltSigASRCTooHigh = 11469U;
EUREKA_CAL t_Voltage3 LTCellVoltSigASRCTooLow = 6881U;
EUREKA_CAL t_Temp1 LT_TempPoint = 40U;
EUREKA_CAL t_Voltage4 PackVoltSigASRCHigh = 16800U;
EUREKA_CAL t_Voltage4 PackVoltSigASRCLow = 12896U;
EUREKA_CAL t_Voltage4 PackVoltSigASRCTooHigh = 17504U;
EUREKA_CAL t_Voltage4 PackVoltSigASRCTooHighHeal = 16960U;
EUREKA_CAL t_Voltage4 PackVoltSigASRCTooLow = 11520U;
EUREKA_CAL t_Voltage4 PackVoltSigASRCTooLowHeal = 12480U;
EUREKA_CAL t_Current1 ScCurSigASRCHigh = 33152U;
EUREKA_CAL t_Current1 ScCurSigASRCLow = 32512U;
EUREKA_CAL t_Current1 ScCurSigASRCTooHigh = 33280U;
EUREKA_CAL t_Current1 ScCurSigASRCTooLow = 32512U;
EUREKA_CAL t_Temp1 ScTempSigASRCHigh = 80U;
EUREKA_CAL t_Temp1 ScTempSigASRCLow = 40U;
EUREKA_CAL t_Temp1 ScTempSigASRCTooHigh = 85U;
EUREKA_CAL t_Temp1 ScTempSigASRCTooLow = 40U;
EUREKA_CAL t_Soc1 SocSigASRCHigh = 250U;
EUREKA_CAL t_Soc1 SocSigASRCLow = 38U;
EUREKA_CAL t_Soc1 SocSigASRCTooHigh = 250U;
EUREKA_CAL t_Soc1 SocSigASRCTooLow = 3U;












EUREKA_CAL t_Voltage1 BatVoltSigASRCHigh = 14746U;
EUREKA_CAL uint16_T BatVoltSigASRCHighNegDeb = 50U;
EUREKA_CAL uint16_T BatVoltSigASRCHighPosDeb = 50U;
EUREKA_CAL t_Voltage1 BatVoltSigASRCLow = 8192U;
EUREKA_CAL uint16_T BatVoltSigASRCLowNegDeb = 50U;
EUREKA_CAL uint16_T BatVoltSigASRCLowPosDeb = 50U;
EUREKA_CAL t_Voltage1 FcSwtHigh = 6553U;
EUREKA_CAL t_Voltage1 FcSwtLow = 4096U;//819U
EUREKA_CAL t_Voltage1 FcVoltSigASRCHigh = 14746U;
EUREKA_CAL t_Voltage1 FcVoltSigASRCLow = 8192U;
EUREKA_CAL boolean_T SafeBag_TestPoint = 0;      //1-no safebag  0-with safebag
EUREKA_CAL t_Voltage1 ScSwtHigh = 6553U;
EUREKA_CAL t_Voltage1 ScSwtLow = 4096U;//819U-1000   2457U-3000
EUREKA_CAL t_Voltage1 ScVoltSigASRCHigh = 14746U;
EUREKA_CAL t_Voltage1 ScVoltSigASRCLow = 8192U;
EUREKA_CAL t_Voltage1 T15SwtHigh = 6553U;
EUREKA_CAL t_Voltage1 T15SwtLow = 4096U;//819U
EUREKA_CAL t_Voltage1 T15VoltSigASRCHigh = 14746U;
EUREKA_CAL t_Voltage1 T15VoltSigASRCLow = 8192U;



uint8_T T15_SelfCheckErrCode;
uint8_T SC_SelfCheckErrCode;
uint8_T FC_SelfCheckErrCode;



        T15_SelfCheckErrCode = 1;
        
        if      (HVCU_NA)
        {
          T15_SelfCheckErrCode = 2;
        }
        else if (BMU0_NA)
        {
          T15_SelfCheckErrCode = 3;
        }
        else if (BMU1_NA)
        {
          T15_SelfCheckErrCode = 4;
        }
        else if (BMU2_NA)
        {
          T15_SelfCheckErrCode = 5;
        }
        else if (BMU3_NA)
        {
          T15_SelfCheckErrCode = 6;
        }
        else if (HW_Err)
        {
          T15_SelfCheckErrCode = 7;
        }
        else if (O_S_HVIL == FALSE)
        {
          T15_SelfCheckErrCode = 8;
        }
        else if (O_S_AirBag == FALSE)
        {
          T15_SelfCheckErrCode = 9;
        }
        else if (((com_Resistance > 200U) && (com_Resistance < 6501U)) == FALSE)
        {
          T15_SelfCheckErrCode = 10;
        }
        else if (((SWC_CellTempMax < 90) && (SWC_CellTempMin > 40)) == FALSE)
        {
          T15_SelfCheckErrCode = 11;
        }                           
        
        
        
        
        
        
        
        
        SC_SelfCheckErrCode = 1;
        
        if      (HVCU_NA)
        {
          SC_SelfCheckErrCode = 2;
        }
        else if (BMU0_NA)
        {
          SC_SelfCheckErrCode = 3;
        }
        else if (BMU1_NA)
        {
          SC_SelfCheckErrCode = 4;
        }
        else if (BMU2_NA)
        {
          SC_SelfCheckErrCode = 5;
        }
        else if (BMU3_NA)
        {
          SC_SelfCheckErrCode = 6;
        }
        else if (HW_Err)
        {
          SC_SelfCheckErrCode = 7;
        }
        else if (SC_NA)
        {
          SC_SelfCheckErrCode = 8;
        }
        else if (O_S_SCCC == FALSE)
        {
          SC_SelfCheckErrCode = 9;
        }
        else if (O_S_HVIL == FALSE)
        {
          SC_SelfCheckErrCode = 10;
        }
        else if (((com_Resistance > 200U) && (com_Resistance < 6501U)) == FALSE)
        {
          SC_SelfCheckErrCode = 11;
        }
        else if (((SWC_CellTempMax < 90) && (SWC_CellTempMin > 40)) == FALSE)
        {
          SC_SelfCheckErrCode = 12;
        } 
        else if (ScVolt_St != 0)
        {
          SC_SelfCheckErrCode = 13;
        }
        else if (BatVolt_St != 0)
        {
          SC_SelfCheckErrCode = 14;
        }
        else if (com_CCP1ChrgVolt > 34548U)
        {
          SC_SelfCheckErrCode = 15;
        }
        else if (com_CCP1ChrgCurrOut > 160U)
        {
          SC_SelfCheckErrCode = 16;
        }
        else if (com_CCP1HwFault != 0)
        {
          SC_SelfCheckErrCode = 17;
        }
        else if (com_CCP1ACConnect != 0)
        {
          SC_SelfCheckErrCode = 18;
        }
        else if (com_CCP1TempSts != 0)
        {
          SC_SelfCheckErrCode = 19;
        }
        else if (com_CCP1CommSts != 0)
        {
          SC_SelfCheckErrCode = 20;
        }
        else if (com_CCP1ACRange != 3)
        {
          SC_SelfCheckErrCode = 21;
        }
        else if (com_CCP1ChrgrPreReadySts != 0)
        {
          SC_SelfCheckErrCode = 22;
        }     
        
        
        
        
        
        
        
    
        FC_SelfCheckErrCode = 1;
        
        
        if      (HVCU_NA)
        {
          FC_SelfCheckErrCode = 2;
        }
        else if (BMU0_NA)
        {
          FC_SelfCheckErrCode = 3;
        }
        else if (BMU1_NA)
        {
          FC_SelfCheckErrCode = 4;
        }
        else if (BMU2_NA)
        {
          FC_SelfCheckErrCode = 5;
        }
        else if (BMU3_NA)
        {
          FC_SelfCheckErrCode = 6;
        }
        else if (HW_Err)
        {
          FC_SelfCheckErrCode = 7;
        }
        else if (O_S_FCCC != TRUE)
        {
          FC_SelfCheckErrCode = 8;
        }
        else if (O_S_HVIL != TRUE)
        {
          FC_SelfCheckErrCode = 9;
        }
        else if (BatVolt_St != 0)
        {
          FC_SelfCheckErrCode = 10;
        }
        else if (FcVolt_St != 0)
        {
          FC_SelfCheckErrCode = 11;
        }
        else if (!((com_Resistance > 200U) && (com_Resistance < 6501U)))
        {
          FC_SelfCheckErrCode = 12;
        }
        else if (!((SWC_CellTempMax < 90) && (SWC_CellTempMin > 40)))
        {
          FC_SelfCheckErrCode = 13;
        }
        else if (com_CRMTimeoutFlag)
        {
          FC_SelfCheckErrCode = 14;
        }
        else if (com_CRM_RecResult != 0)
        {
          FC_SelfCheckErrCode = 15;
        }        
 
 
 
    
    
    
        
        
        
        
        
        
        
        
           
        */