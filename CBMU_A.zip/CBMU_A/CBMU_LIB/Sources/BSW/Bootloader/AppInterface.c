#include "AppInterface.h"

extern void near _Startup(void);



#pragma CONST_SEG APPREG_DATA
volatile const AppRegisterData AppRegisterTable = 
{  
    _Startup,
    (unsigned int)kAppMainVersion,
    (unsigned int)kAppSubVersion,
    (unsigned int)kAppYear,
    (unsigned int)kAppMonthDay,
    (unsigned int)0xffff,        
    (unsigned int)0xffff,
    (unsigned int)0xffff
};



						




