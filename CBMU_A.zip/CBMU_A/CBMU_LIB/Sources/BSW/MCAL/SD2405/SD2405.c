#include "SD2405.h"



/*******************************************************************************
* Global Variables definition
*******************************************************************************/
SD2405_TD_TYPE  sd2405_CurTime;
SD2405_TD_TYPE  sd2405_SetTime;

boolean sd2405_setTimeFlg;




/*******************************************************************************
* Local Functions prototypes
*******************************************************************************/
_STATIC_ Std_ReturnType SD2405_WriteTimeOff(void);
_STATIC_ Std_ReturnType SD2405_WriteTimeOn(void);

void SD2405_Init(void)
{
  IIC_Init();
}
/*
********************************************************************************
*            SD2405_WriteTimeOff
*
*disable write time to register(except CTR1,CTR2,CTR3)
********************************************************************************
*/
_STATIC_ Std_ReturnType SD2405_WriteTimeOff(void)
{
  uint8 sd2405_Txdata[2]={0,0};      //tx data

  if(IIC_SendMulByte(SD2405_ADDR,SD2405_REG_CTR1,2,&sd2405_Txdata[0]) == E_NOT_OK)   //WRTC2,WRTC3=0 ,WRTC1=0
  {	
  	return E_NOT_OK;
	}
	return E_OK;	
}

/*
********************************************************************************
*            SD2405_WriteTimeOn
*
* enable write time to register(except CTR1,CTR2,CTR3)
********************************************************************************
*/
_STATIC_ Std_ReturnType SD2405_WriteTimeOn(void)
{
	if (IIC_SendOneByte(SD2405_ADDR,SD2405_REG_CTR2,0x80) == E_NOT_OK)   	//WRTC1=1
	{
	  return E_NOT_OK; 
	}
	
	if (IIC_SendOneByte(SD2405_ADDR,SD2405_REG_CTR1,0x84) == E_NOT_OK)   	//WRTC2,WRTC3=1
	{
	  return E_NOT_OK; 
	}
	
	return E_OK;
}


/*
********************************************************************************
*            SD2405_ReadRealTime
*
* read current time register
********************************************************************************
*/
Std_ReturnType SD2405_ReadRealTime(void)
{
	boolean sts;
  uint8 cnt;
  cnt=0;
  do
  {
    sts = IIC_ReceiveMulByte(SD2405_ADDR, SD2405_REG_SECOND ,7, (uint8 *)(&sd2405_CurTime)); 
    if(cnt++ >= SD2405_MAXERRTIMES)
    {
      sd2405_CurTime.year = 0xFF;
      sd2405_CurTime.month = 0xFF;
      sd2405_CurTime.day = 0xFF;
      sd2405_CurTime.week = 0xFF;
      sd2405_CurTime.hour = 0xFF;
      sd2405_CurTime.minute = 0xFF;
      sd2405_CurTime.second = 0xFF;
      
      return E_NOT_OK; 
    }  
  }
  while(sts == E_NOT_OK);
  
  sd2405_CurTime.year = (sd2405_CurTime.year&0x0f) + (sd2405_CurTime.year>>4&0x0f)*10;
  sd2405_CurTime.month = (sd2405_CurTime.month&0x0f) + (sd2405_CurTime.month>>4&0x01)*10;
  sd2405_CurTime.day = (sd2405_CurTime.day&0x0f) + (sd2405_CurTime.day>>4&0x03)*10;
  sd2405_CurTime.week = sd2405_CurTime.week&0x07;
  sd2405_CurTime.hour = (sd2405_CurTime.hour&0x0f) + (sd2405_CurTime.hour>>4&0x03)*10;
  sd2405_CurTime.minute = (sd2405_CurTime.minute&0x0f) + (sd2405_CurTime.minute>>4&0x07)*10;
  sd2405_CurTime.second = (sd2405_CurTime.second&0x0f) + (sd2405_CurTime.second>>4&0x07)*10;
  
  
  return E_OK;
	
}

/*
********************************************************************************
*            SD2405_SetTime
*
* write time register
********************************************************************************
*/
Std_ReturnType SD2405_SetTime(void)
{
	boolean sts;
  uint8 cnt = 0;
  
  sd2405_SetTime.year = sd2405_SetTime.year/10*16 + sd2405_SetTime.year%10;
  sd2405_SetTime.month = sd2405_SetTime.month/10*16 + sd2405_SetTime.month%10;
  sd2405_SetTime.day = sd2405_SetTime.day/10*16 + sd2405_SetTime.day%10;
  sd2405_SetTime.hour = (sd2405_SetTime.hour/10*16 + sd2405_SetTime.hour%10)|0x80;
  sd2405_SetTime.minute = sd2405_SetTime.minute/10*16 + sd2405_SetTime.minute%10;
  sd2405_SetTime.second = sd2405_SetTime.minute/10*16 + sd2405_SetTime.second%10;

  
  /*1. enable write time register*/
  if(SD2405_WriteTimeOn() == E_NOT_OK)
  {
  	return E_NOT_OK;
  }	
  
  /*2. write settime to time register*/
  do
  {
    sts=IIC_SendMulByte(SD2405_ADDR ,SD2405_REG_SECOND ,7, (uint8 *)(&sd2405_SetTime));
    if(cnt++ >= SD2405_MAXERRTIMES)
    {
     return E_NOT_OK; 
    } 
  }
  while(sts == E_NOT_OK);
  
  /*3. clear digital adjust Register (address: 0x12H)*/
  if (IIC_SendOneByte(SD2405_ADDR,SD2405_REG_TIMEADJ,0x0) == E_NOT_OK)   	
	{
	  return E_NOT_OK; 
	}
	
	/*4. disable write time register*/
	if(SD2405_WriteTimeOff() == E_NOT_OK)
  {
  	return E_NOT_OK;
  }	
  
  return E_OK; 
	
}

void SD2405_Task(void)
{
  if (sd2405_setTimeFlg == TRUE)
  {
    SD2405_SetTime(); 
    sd2405_setTimeFlg = FALSE; 
  }
  
  SD2405_ReadRealTime();
}



