/*
 * File: CBMU_MON.c
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "CBMU_MON.h"
#include "CBMU_MON_private.h"

/* Named constants for Chart: '<S30>/RlyCtl' */
#define CBMU_MON_IN_NO_ACTIVE_CHILD_n  ((uint8_T)0U)
#define CBMU_MON_IN_RlyErr             ((uint8_T)1U)
#define CBMU_MON_IN_RlyOFF             ((uint8_T)2U)
#define CBMU_MON_IN_RlyOFFConfirm      ((uint8_T)3U)
#define CBMU_MON_IN_RlyON              ((uint8_T)4U)
#define CBMU_MON_IN_RlyON1             ((uint8_T)5U)
#define CBMU_MON_IN_RlyONCount         ((uint8_T)6U)

/* Named constants for Chart: '<S31>/RlyCtl' */
#define CBMU_MON_IN_RlyOFFConfirm_d    ((uint8_T)2U)
#define CBMU_MON_IN_RlyOFF_b           ((uint8_T)1U)
#define CBMU_MON_IN_RlyON_d            ((uint8_T)3U)

/* Named constants for Chart: '<S37>/RlyCtl' */
#define CBMU_MON_IN_Init_i             ((uint8_T)1U)
#define CBMU_MON_IN_RlyOFF1            ((uint8_T)2U)
#define CBMU_MON_IN_count              ((uint8_T)2U)
#define CBMU_MON_IN_wait_p             ((uint8_T)6U)

/* Named constants for Chart: '<S38>/RlyCtl' */
#define CBMU_MON_IN_RlyON1_l           ((uint8_T)4U)
#define CBMU_MON_IN_RlyON2             ((uint8_T)5U)

/* Named constants for Chart: '<S44>/RlyCtl' */
#define CBMU_MON_IN_RlyONCount1        ((uint8_T)7U)
#define CBMU_MON_IN_RlyOff1            ((uint8_T)8U)

/* Exported block signals */
uint16_T ChrgTgtCur;                   /* '<S6>/ChrgCur' */
uint16_T ChrgTgtTimer2;                /* '<S6>/ChrgCurTimeOfFullSOC' */
uint16_T ChrgTgtTimer1;                /* '<S6>/ChrgCurTimeOfUnfullSOC' */
uint8_T BatVolt_St;                    /* '<S95>/Switch' */
uint8_T ScVolt_St;                     /* '<S100>/Switch' */
uint8_T FcVolt_St;                     /* '<S96>/Switch' */
uint8_T mChargeStep;                   /* '<S49>/Chart' */
boolean_T O_S_SCCC;                    /* '<S91>/Swtich_Debouncing' */
boolean_T O_S_FCCC;                    /* '<S65>/Swtich_Debouncing' */

/* Exported block states */
uint8_T SafebagNormalCount;            /* '<S7>/Data Store Memory2' */
uint8_T SafebagErrCount;               /* '<S7>/Data Store Memory3' */
uint8_T SC_MON_test;                   /* '<S49>/Data Store Memory1' */
uint8_T FC_MON_test;                   /* '<S8>/Data Store Memory1' */

/* Block signals (auto storage) */
BlockIO_CBMU_MON CBMU_MON_B;

/* Block states (auto storage) */
D_Work_CBMU_MON CBMU_MON_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_CBMU_MON CBMU_MON_U;

/* Real-time model */
RT_MODEL_CBMU_MON CBMU_MON_M_;
RT_MODEL_CBMU_MON *const CBMU_MON_M = &CBMU_MON_M_;
uint16_T look2_iu8lu32n31yu16tu_e4FyxcSB(uint8_T u0, uint8_T u1, const uint8_T
  bp0[], const uint8_T bp1[], const uint16_T table[], const uint32_T maxIndex[],
  uint32_T stride)
{
  uint32_T frac;
  uint32_T bpIndices[2];
  uint32_T fractions[2];
  int32_T yL_1d;
  uint32_T bpIdx;
  uint32_T iLeft;

  /* Lookup 2-D
     Canonical function name: look2_iu8lu32n31yu16tu16Ds32Is32n15_binlcs
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  if (u0 <= bp0[0UL]) {
    iLeft = 0UL;
    frac = 0UL;
  } else if (u0 < bp0[maxIndex[0UL]]) {
    /* Binary Search */
    bpIdx = maxIndex[0UL] >> 1UL;
    iLeft = 0UL;
    frac = maxIndex[0UL];
    while (frac - iLeft > 1UL) {
      if (u0 < bp0[bpIdx]) {
        frac = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (frac + iLeft) >> 1UL;
    }

    frac = div_nzp_repeat_u32((uint32_T)(uint8_T)((uint16_T)u0 - bp0[iLeft]) <<
      24, (uint8_T)((uint16_T)bp0[iLeft + 1UL] - bp0[iLeft]), 7U);
  } else {
    iLeft = maxIndex[0UL] - 1UL;
    frac = 2147483648UL;
  }

  fractions[0UL] = frac;
  bpIndices[0UL] = iLeft;

  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  if (u1 <= bp1[0UL]) {
    iLeft = 0UL;
    frac = 0UL;
  } else if (u1 < bp1[maxIndex[1UL]]) {
    /* Binary Search */
    bpIdx = maxIndex[1UL] >> 1UL;
    iLeft = 0UL;
    frac = maxIndex[1UL];
    while (frac - iLeft > 1UL) {
      if (u1 < bp1[bpIdx]) {
        frac = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (frac + iLeft) >> 1UL;
    }

    frac = div_nzp_repeat_u32((uint32_T)(uint8_T)((uint16_T)u1 - bp1[iLeft]) <<
      24, (uint8_T)((uint16_T)bp1[iLeft + 1UL] - bp1[iLeft]), 7U);
  } else {
    iLeft = maxIndex[1UL] - 1UL;
    frac = 2147483648UL;
  }

  /* Interpolation 2-D
     Canonical function name: intrp2d_u16p15s32s32u32u32n31l_s
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Rounding mode: 'simplest'
     Overflow mode: 'wrapping'
   */
  bpIdx = iLeft * stride + bpIndices[0UL];
  yL_1d = mul_ssu32_loSR((int32_T)table[bpIdx + 1UL] - table[bpIdx], fractions
    [0UL], 16UL) + ((int32_T)table[bpIdx] << 15);
  bpIdx += stride;
  return (uint16_T)((mul_ssu32_loSR((mul_ssu32_loSR((int32_T)table[bpIdx + 1UL]
    - table[bpIdx], fractions[0UL], 16UL) + ((int32_T)table[bpIdx] << 15)) -
    yL_1d, frac, 31UL) + yL_1d) >> 15);
}

uint16_T div_usu16_sat(int16_T numerator, uint16_T denominator)
{
  uint16_T quotient;
  if (denominator == 0U) {
    quotient = numerator >= 0 ? MAX_uint16_T : 0U;

    /* Divide by zero handler */
  } else if (numerator < 0) {
    quotient = 0U;
  } else {
    quotient = (numerator < 0 ? ~(uint16_T)numerator + 1U : (uint16_T)numerator)
      / denominator;
  }

  return quotient;
}

int16_T div_nzp_s16(int16_T numerator, int16_T denominator)
{
  uint16_T tempAbsQuotient;
  tempAbsQuotient = (numerator < 0 ? ~(uint16_T)numerator + 1U : (uint16_T)
                     numerator) / (denominator < 0 ? ~(uint16_T)denominator + 1U
    : (uint16_T)denominator);
  return (numerator < 0) != (denominator < 0) ? -(int16_T)tempAbsQuotient :
    (int16_T)tempAbsQuotient;
}

void mul_wide_su32(int32_T in0, uint32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                   *ptrOutBitsLo)
{
  uint32_T outBitsLo;
  uint32_T absIn0;
  uint32_T in0Hi;
  uint32_T in1Lo;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn0 = in0 < 0L ? ~(uint32_T)in0 + 1UL : (uint32_T)in0;
  in0Hi = absIn0 >> 16UL;
  absIn0 &= 65535UL;
  in1Hi = in1 >> 16UL;
  in1Lo = in1 & 65535UL;
  productHiLo = in0Hi * in1Lo;
  productLoHi = absIn0 * in1Hi;
  absIn0 *= in1Lo;
  in1Lo = 0UL;
  outBitsLo = (productLoHi << 16UL) + absIn0;
  if (outBitsLo < absIn0) {
    in1Lo = 1UL;
  }

  absIn0 = outBitsLo;
  outBitsLo += productHiLo << 16UL;
  if (outBitsLo < absIn0) {
    in1Lo++;
  }

  absIn0 = (((productLoHi >> 16UL) + (productHiLo >> 16UL)) + in0Hi * in1Hi) +
    in1Lo;
  if (!((in1 == 0UL) || (in0 >= 0L))) {
    absIn0 = ~absIn0;
    outBitsLo = ~outBitsLo;
    outBitsLo++;
    if (outBitsLo == 0UL) {
      absIn0++;
    }
  }

  *ptrOutBitsHi = absIn0;
  *ptrOutBitsLo = outBitsLo;
}

int32_T mul_ssu32_loSR(int32_T a, uint32_T b, uint32_T aShift)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_su32(a, b, &u32_chi, &u32_clo);
  u32_clo = u32_chi << (32UL - aShift) | u32_clo >> aShift;
  return (int32_T)u32_clo;
}

uint32_T div_nzp_repeat_u32(uint32_T numerator, uint32_T denominator, uint16_T
  nRepeatSub)
{
  uint32_T quotient;
  uint16_T iRepeatSub;
  boolean_T numeratorExtraBit;
  quotient = numerator / denominator;
  numerator %= denominator;
  for (iRepeatSub = 0U; iRepeatSub < nRepeatSub; iRepeatSub++) {
    numeratorExtraBit = (numerator >= 2147483648UL);
    numerator <<= 1UL;
    quotient <<= 1UL;
    if (numeratorExtraBit || (numerator >= denominator)) {
      quotient++;
      numerator -= denominator;
    }
  }

  return quotient;
}

/* Model step function */
void CBMU_MON_step(void)
{
  boolean_T rtb_LogicalOperator3_p;
  uint16_T qY;
  boolean_T guard1 = false;

  /* Memory: '<S1>/Memory1' */
  CBMU_MON_B.Memory1 = CBMU_MON_DWork.Memory1_PreviousInput_g;

  /* Memory: '<S1>/Memory' */
  CBMU_MON_B.bitsForTID0.RelationalOperator =
    CBMU_MON_DWork.bitsForTID0.Memory_PreviousInput_n;

  /* Memory: '<S1>/Memory2' */
  CBMU_MON_B.bitsForTID0.RelationalOperator1 =
    CBMU_MON_DWork.bitsForTID0.Memory2_PreviousInput_i;

  /* Outputs for Atomic SubSystem: '<S1>/SID' */
  CBMU_MON_SID();

  /* End of Outputs for SubSystem: '<S1>/SID' */

  /* DataStoreRead: '<Root>/Data Store Read5' */
  CBMU_MON_B.DataStoreRead5 = com_BattCurr;

  /* Outputs for Atomic SubSystem: '<S1>/PwrON' */
  CBMU_MON_PwrON();

  /* End of Outputs for SubSystem: '<S1>/PwrON' */

  /* Outputs for Atomic SubSystem: '<S1>/SC_Mon' */
  CBMU_MON_SC_Mon();

  /* End of Outputs for SubSystem: '<S1>/SC_Mon' */

  /* DataStoreRead: '<S1>/Data Store Read3' */
  CBMU_MON_B.bitsForTID0.DataStoreRead3_m = com_CMLTimeoutFlag;

  /* DataStoreRead: '<S1>/Data Store Read2' */
  CBMU_MON_B.bitsForTID0.DataStoreRead2_a = com_CSDTimeoutFlag;

  /* DataStoreRead: '<S1>/Data Store Read1' */
  CBMU_MON_B.bitsForTID0.DataStoreRead1_d = com_CSTTimeoutFlag;

  /* DataStoreRead: '<S1>/Data Store Read' */
  CBMU_MON_B.bitsForTID0.DataStoreRead = com_CCSTimeoutFlag;

  /* Product: '<S1>/Divide' incorporates:
   *  Inport: '<Root>/com_CVMaxNum'
   */
  CBMU_MON_B.Divide = (uint8_T)(uMaxNum / 12U);

  /* DataStoreRead: '<Root>/Data Store Read6' */
  CBMU_MON_B.DataStoreRead6 = com_BattVolt;

  /* DataStoreRead: '<Root>/Data Store Read1' */
  CBMU_MON_B.DataStoreRead1 = CV_St;

  /* DataStoreRead: '<Root>/Data Store Read2' */
  CBMU_MON_B.DataStoreRead2 = FCCur_St;

  /* DataStoreRead: '<Root>/Data Store Read4' */
  CBMU_MON_B.DataStoreRead4 = SOC_St;

  /* DataStoreRead: '<Root>/Data Store Read3' */
  CBMU_MON_B.DataStoreRead3 = CTMaxFc_St;

  /* DataStoreRead: '<Root>/Data Store Read7' */
  CBMU_MON_B.DataStoreRead7 = ISO_St;

  /* Outputs for Atomic SubSystem: '<S1>/FC_Mon' */
  CBMU_MON_FC_Mon();

  /* End of Outputs for SubSystem: '<S1>/FC_Mon' */

  /* Outputs for Enabled SubSystem: '<S1>/RelayCtrl' incorporates:
   *  EnablePort: '<S5>/Enable'
   */
  /* RelationalOperator: '<S2>/Compare' incorporates:
   *  Constant: '<S2>/Constant'
   *  Inport: '<Root>/DebugMode'
   */
  if (DebugMode == 0) {
    /* SwitchCase: '<S5>/ModeChoose' incorporates:
     *  Constant: '<S25>/Constant22'
     *  Constant: '<S26>/Constant22'
     *  Constant: '<S27>/Constant22'
     *  Inport: '<Root>/ContactorMode'
     *  RelationalOperator: '<S25>/Relational Operator'
     *  RelationalOperator: '<S26>/Relational Operator'
     *  RelationalOperator: '<S27>/Relational Operator'
     */
    switch ((int32_T)ContactorMode) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S5>/Mode0' incorporates:
       *  ActionPort: '<S25>/Action Port'
       */
      /* Outputs for Enabled SubSystem: '<S25>/Subsystem' incorporates:
       *  EnablePort: '<S28>/Enable'
       */
      /* Outputs for Enabled SubSystem: '<S25>/Subsystem1' incorporates:
       *  EnablePort: '<S29>/Enable'
       */
      if (CBMU_MON_B.ContactorEnable == 1) {
        /* Logic: '<S28>/Logical Operator3' incorporates:
         *  Logic: '<S28>/Logical Operator4'
         */
        rtb_LogicalOperator3_p = (CBMU_MON_B.bitsForTID0.Switch1 && (!(O_S_FCCC ||
          O_S_SCCC)));

        /* Chart: '<S30>/RlyCtl' incorporates:
         *  Inport: '<Root>/DCVolt_Reach'
         */
        /* Gateway: Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl/RlyCtl */
        /* During: Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl/RlyCtl */
        if (CBMU_MON_DWork.bitsForTID0.is_active_c17_CBMU_MON == 0U) {
          /* Entry: Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl/RlyCtl */
          CBMU_MON_DWork.bitsForTID0.is_active_c17_CBMU_MON = 1U;

          /* Entry Internal: Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl/RlyCtl */
          /* Transition: '<S32>:9' */
          CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON = CBMU_MON_IN_RlyOFF;

          /* Entry 'RlyOFF': '<S32>:5' */
          ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        } else {
          guard1 = false;
          switch (CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON) {
           case CBMU_MON_IN_RlyErr:
            /* During 'RlyErr': '<S32>:20' */
            break;

           case CBMU_MON_IN_RlyOFF:
            /* During 'RlyOFF': '<S32>:5' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_ON)) {
              /* Transition: '<S32>:7' */
              CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON =
                CBMU_MON_IN_RlyONCount;

              /* Entry 'RlyONCount': '<S32>:3' */
              CBMU_MON_DWork.rlyctl_ct_o = 0U;
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_ON) != 0);
            }
            break;

           case CBMU_MON_IN_RlyOFFConfirm:
            /* During 'RlyOFFConfirm': '<S32>:25' */
            if ((CBMU_MON_B.DataStoreRead5 < 32672U) &&
                (CBMU_MON_B.DataStoreRead5 > 32352U)) {
              /* Transition: '<S32>:27' */
              guard1 = true;
            } else if (CBMU_MON_DWork.cnt_b3 >= 3000U) {
              /* Transition: '<S32>:32' */
              CBMU_MON_B.Merge3_d = 1U;
              guard1 = true;
            } else {
              qY = CBMU_MON_DWork.cnt_b3 + 10U;
              if (qY < CBMU_MON_DWork.cnt_b3) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt_b3 = qY;
            }
            break;

           case CBMU_MON_IN_RlyON:
            /* During 'RlyON': '<S32>:10' */
            if (CBMU_MON_DWork.rlyctl_ct_o > 1000U) {
              /* Transition: '<S32>:19' */
              /* Exit 'RlyON': '<S32>:10' */
              CBMU_MON_DWork.rlyctl_ct_o = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON = CBMU_MON_IN_RlyON1;

              /* Entry 'RlyON1': '<S32>:17' */
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else {
              qY = CBMU_MON_DWork.rlyctl_ct_o + 10U;
              if (qY < CBMU_MON_DWork.rlyctl_ct_o) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.rlyctl_ct_o = qY;
            }
            break;

           case CBMU_MON_IN_RlyON1:
            /* During 'RlyON1': '<S32>:17' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S32>:14' */
              CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON =
                CBMU_MON_IN_RlyOFFConfirm;

              /* Entry 'RlyOFFConfirm': '<S32>:25' */
              CBMU_MON_DWork.cnt_b3 = 0U;
            }
            break;

           default:
            /* During 'RlyONCount': '<S32>:3' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S32>:6' */
              /* Exit 'RlyONCount': '<S32>:3' */
              CBMU_MON_DWork.rlyctl_ct_o = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON = CBMU_MON_IN_RlyOFF;

              /* Entry 'RlyOFF': '<S32>:5' */
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else if ((CBMU_MON_DWork.rlyctl_ct_o > 1000U) && (DCVolt_Reach ==
                        1)) {
              /* Transition: '<S32>:11' */
              /* Exit 'RlyONCount': '<S32>:3' */
              CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON = CBMU_MON_IN_RlyON;

              /* Entry 'RlyON': '<S32>:10' */
              CBMU_MON_DWork.rlyctl_ct_o = 0U;
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_ON) != 0);
            } else if ((CBMU_MON_DWork.rlyctl_ct_o > 3000U) && (DCVolt_Reach !=
                        1)) {
              /* Transition: '<S32>:21' */
              /* Exit 'RlyONCount': '<S32>:3' */
              CBMU_MON_DWork.rlyctl_ct_o = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON = CBMU_MON_IN_RlyErr;

              /* Entry 'RlyErr': '<S32>:20' */
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else {
              qY = CBMU_MON_DWork.rlyctl_ct_o + 10U;
              if (qY < CBMU_MON_DWork.rlyctl_ct_o) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.rlyctl_ct_o = qY;
            }
            break;
          }

          if (guard1) {
            /* Exit 'RlyOFFConfirm': '<S32>:25' */
            CBMU_MON_DWork.cnt_b3 = 0U;
            CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON = CBMU_MON_IN_RlyOFF;

            /* Entry 'RlyOFF': '<S32>:5' */
            ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          }
        }

        /* End of Chart: '<S30>/RlyCtl' */

        /* Logic: '<S28>/Logical Operator1' */
        rtb_LogicalOperator3_p = (CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_a ||
          CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl);

        /* Chart: '<S31>/RlyCtl' */
        /* Gateway: Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl1/RlyCtl */
        /* During: Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl1/RlyCtl */
        if (CBMU_MON_DWork.bitsForTID0.is_active_c18_CBMU_MON == 0U) {
          /* Entry: Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl1/RlyCtl */
          CBMU_MON_DWork.bitsForTID0.is_active_c18_CBMU_MON = 1U;

          /* Entry Internal: Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl1/RlyCtl */
          /* Transition: '<S33>:9' */
          CBMU_MON_DWork.bitsForTID0.is_c18_CBMU_MON = CBMU_MON_IN_RlyOFF_b;

          /* Entry 'RlyOFF': '<S33>:5' */
          ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        } else {
          guard1 = false;
          switch (CBMU_MON_DWork.bitsForTID0.is_c18_CBMU_MON) {
           case CBMU_MON_IN_RlyOFF_b:
            /* During 'RlyOFF': '<S33>:5' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_ON)) {
              /* Transition: '<S33>:7' */
              CBMU_MON_DWork.bitsForTID0.is_c18_CBMU_MON = CBMU_MON_IN_RlyON_d;

              /* Entry 'RlyON': '<S33>:3' */
              ioa_ChMRelayCtl = (((uint8_T)RELAY_ON) != 0);
            }
            break;

           case CBMU_MON_IN_RlyOFFConfirm_d:
            /* During 'RlyOFFConfirm': '<S33>:25' */
            if ((CBMU_MON_B.DataStoreRead5 < 32672U) &&
                (CBMU_MON_B.DataStoreRead5 > 32352U)) {
              /* Transition: '<S33>:27' */
              guard1 = true;
            } else if (CBMU_MON_DWork.cnt_k >= 3000U) {
              /* Transition: '<S33>:31' */
              CBMU_MON_B.Merge3_d = 1U;
              guard1 = true;
            } else {
              qY = CBMU_MON_DWork.cnt_k + 10U;
              if (qY < CBMU_MON_DWork.cnt_k) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt_k = qY;
            }
            break;

           default:
            /* During 'RlyON': '<S33>:3' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S33>:14' */
              CBMU_MON_DWork.bitsForTID0.is_c18_CBMU_MON =
                CBMU_MON_IN_RlyOFFConfirm_d;

              /* Entry 'RlyOFFConfirm': '<S33>:25' */
              CBMU_MON_DWork.cnt_k = 0U;
            }
            break;
          }

          if (guard1) {
            /* Exit 'RlyOFFConfirm': '<S33>:25' */
            CBMU_MON_DWork.cnt_k = 0U;
            CBMU_MON_DWork.bitsForTID0.is_c18_CBMU_MON = CBMU_MON_IN_RlyOFF_b;

            /* Entry 'RlyOFF': '<S33>:5' */
            ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          }
        }

        /* End of Chart: '<S31>/RlyCtl' */

        /* S-Function (sfun_SetErr): '<S28>/sfun_SetErr_SrcH2' incorporates:
         *  Constant: '<S28>/Constant2'
         */
        Dem_SetError( (uint16_T)92U, (uint8_T)CBMU_MON_B.Merge3_d);
      } else {
        /* Chart: '<S29>/RlyCtl1' */
        /* Gateway: Task_10ms/RelayCtrl/Mode0/Subsystem1/RlyCtl1 */
        /* During: Task_10ms/RelayCtrl/Mode0/Subsystem1/RlyCtl1 */
        /* Entry Internal: Task_10ms/RelayCtrl/Mode0/Subsystem1/RlyCtl1 */
        /* Transition: '<S34>:9' */
        ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
      }

      /* End of Outputs for SubSystem: '<S25>/Subsystem1' */
      /* End of Outputs for SubSystem: '<S25>/Subsystem' */
      /* End of Outputs for SubSystem: '<S5>/Mode0' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S5>/Mode1' incorporates:
       *  ActionPort: '<S26>/Action Port'
       */
      /* Outputs for Enabled SubSystem: '<S26>/Subsystem' incorporates:
       *  EnablePort: '<S35>/Enable'
       */
      /* Outputs for Enabled SubSystem: '<S26>/Subsystem1' incorporates:
       *  EnablePort: '<S36>/Enable'
       */
      if (CBMU_MON_B.ContactorEnable == 1) {
        /* Logic: '<S35>/Logical Operator1' */
        rtb_LogicalOperator3_p = (CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_a ||
          CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl);

        /* Chart: '<S38>/RlyCtl' */
        /* Gateway: Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl1/RlyCtl */
        /* During: Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl1/RlyCtl */
        if (CBMU_MON_DWork.bitsForTID0.is_active_c19_CBMU_MON == 0U) {
          /* Entry: Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl1/RlyCtl */
          CBMU_MON_DWork.bitsForTID0.is_active_c19_CBMU_MON = 1U;

          /* Entry Internal: Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl1/RlyCtl */
          /* Transition: '<S40>:44' */
          CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON = CBMU_MON_IN_wait_p;

          /* Entry 'wait': '<S40>:43' */
          ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          ioa_ChMRelayCtl = (((uint8_T)RELAY_ON) != 0);
        } else {
          guard1 = false;
          switch (CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON) {
           case CBMU_MON_IN_RlyOFF_b:
            /* During 'RlyOFF': '<S40>:5' */
            if (CBMU_MON_DWork.cnt2_o >= 500U) {
              /* Transition: '<S40>:53' */
              /* Exit 'RlyOFF': '<S40>:5' */
              CBMU_MON_DWork.cnt2_o = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON = CBMU_MON_IN_RlyOFF1;

              /* Entry 'RlyOFF1': '<S40>:41' */
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else {
              qY = CBMU_MON_DWork.cnt2_o + 10U;
              if (qY < CBMU_MON_DWork.cnt2_o) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt2_o = qY;
            }
            break;

           case CBMU_MON_IN_RlyOFF1:
            /* During 'RlyOFF1': '<S40>:41' */
            /* Transition: '<S40>:45' */
            CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON = CBMU_MON_IN_wait_p;

            /* Entry 'wait': '<S40>:43' */
            ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            ioa_ChMRelayCtl = (((uint8_T)RELAY_ON) != 0);
            break;

           case CBMU_MON_IN_RlyOFFConfirm:
            /* During 'RlyOFFConfirm': '<S40>:25' */
            if ((CBMU_MON_B.DataStoreRead5 < 32672U) &&
                (CBMU_MON_B.DataStoreRead5 > 32352U)) {
              /* Transition: '<S40>:27' */
              guard1 = true;
            } else if (CBMU_MON_DWork.cnt_g >= 3000U) {
              /* Transition: '<S40>:49' */
              CBMU_MON_B.Merge3_p = 1U;
              guard1 = true;
            } else {
              qY = CBMU_MON_DWork.cnt_g + 10U;
              if (qY < CBMU_MON_DWork.cnt_g) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt_g = qY;
            }
            break;

           case CBMU_MON_IN_RlyON1_l:
            /* During 'RlyON1': '<S40>:34' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S40>:14' */
              CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON =
                CBMU_MON_IN_RlyOFFConfirm;

              /* Entry 'RlyOFFConfirm': '<S40>:25' */
              CBMU_MON_DWork.cnt_g = 0U;
            }
            break;

           case CBMU_MON_IN_RlyON2:
            /* During 'RlyON2': '<S40>:62' */
            if ((rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) ||
                (CBMU_MON_DWork.cnt2_o >= 200U)) {
              /* Transition: '<S40>:65' */
              /* Transition: '<S40>:63' */
              /* Exit Internal 'RlyON2': '<S40>:62' */
              CBMU_MON_DWork.bitsForTID0.is_RlyON2 =
                CBMU_MON_IN_NO_ACTIVE_CHILD_n;

              /* Exit 'RlyON2': '<S40>:62' */
              CBMU_MON_DWork.cnt1_j = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON = CBMU_MON_IN_RlyOFF_b;

              /* Entry 'RlyOFF': '<S40>:5' */
              ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              CBMU_MON_DWork.cnt2_o = 0U;
            } else if (CBMU_MON_DWork.cnt1_j >= 800U) {
              /* Transition: '<S40>:35' */
              /* Exit Internal 'RlyON2': '<S40>:62' */
              CBMU_MON_DWork.bitsForTID0.is_RlyON2 =
                CBMU_MON_IN_NO_ACTIVE_CHILD_n;

              /* Exit 'RlyON2': '<S40>:62' */
              CBMU_MON_DWork.cnt1_j = 0U;
              CBMU_MON_DWork.cnt2_o = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON = CBMU_MON_IN_RlyON1_l;

              /* Entry 'RlyON1': '<S40>:34' */
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_ON) != 0);
            } else {
              qY = CBMU_MON_DWork.cnt1_j + 10U;
              if (qY < CBMU_MON_DWork.cnt1_j) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt1_j = qY;
              if (CBMU_MON_DWork.bitsForTID0.is_RlyON2 == CBMU_MON_IN_Init_i) {
                /* During 'Init': '<S40>:58' */
                if (CBMU_MON_B.DataStoreRead5 == 32512U) {
                  /* Transition: '<S40>:61' */
                  CBMU_MON_DWork.bitsForTID0.is_RlyON2 = CBMU_MON_IN_count;
                }
              } else {
                /* During 'count': '<S40>:60' */
                if (CBMU_MON_B.DataStoreRead5 != 32512U) {
                  /* Transition: '<S40>:57' */
                  CBMU_MON_DWork.bitsForTID0.is_RlyON2 = CBMU_MON_IN_Init_i;

                  /* Entry 'Init': '<S40>:58' */
                  CBMU_MON_B.Merge1 = 0U;
                } else {
                  qY = CBMU_MON_DWork.cnt2_o + 10U;
                  if (qY < CBMU_MON_DWork.cnt2_o) {
                    qY = MAX_uint16_T;
                  }

                  CBMU_MON_DWork.cnt2_o = qY;
                }
              }
            }
            break;

           default:
            /* During 'wait': '<S40>:43' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_ON)) {
              /* Transition: '<S40>:46' */
              CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON = CBMU_MON_IN_RlyON2;

              /* Entry 'RlyON2': '<S40>:62' */
              ioa_ChMRelayCtl = (((uint8_T)RELAY_ON) != 0);
              CBMU_MON_DWork.cnt1_j = 0U;
              CBMU_MON_DWork.cnt2_o = 0U;

              /* Entry Internal 'RlyON2': '<S40>:62' */
              /* Transition: '<S40>:59' */
              CBMU_MON_DWork.bitsForTID0.is_RlyON2 = CBMU_MON_IN_Init_i;

              /* Entry 'Init': '<S40>:58' */
              CBMU_MON_B.Merge1 = 0U;
            }
            break;
          }

          if (guard1) {
            /* Exit 'RlyOFFConfirm': '<S40>:25' */
            CBMU_MON_DWork.cnt_g = 0U;
            CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON = CBMU_MON_IN_RlyOFF_b;

            /* Entry 'RlyOFF': '<S40>:5' */
            ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            CBMU_MON_DWork.cnt2_o = 0U;
          }
        }

        /* End of Chart: '<S38>/RlyCtl' */

        /* Logic: '<S35>/Logical Operator3' incorporates:
         *  Logic: '<S35>/Logical Operator4'
         */
        rtb_LogicalOperator3_p = (CBMU_MON_B.bitsForTID0.Switch1 && (!(O_S_FCCC ||
          O_S_SCCC)));

        /* Chart: '<S37>/RlyCtl' */
        /* Gateway: Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl/RlyCtl */
        /* During: Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl/RlyCtl */
        if (CBMU_MON_DWork.bitsForTID0.is_active_c8_CBMU_MON == 0U) {
          /* Entry: Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl/RlyCtl */
          CBMU_MON_DWork.bitsForTID0.is_active_c8_CBMU_MON = 1U;

          /* Entry Internal: Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl/RlyCtl */
          /* Transition: '<S39>:44' */
          CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON = CBMU_MON_IN_wait_p;

          /* Entry 'wait': '<S39>:43' */
          ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        } else {
          guard1 = false;
          switch (CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON) {
           case CBMU_MON_IN_RlyOFF_b:
            /* During 'RlyOFF': '<S39>:5' */
            if (CBMU_MON_DWork.cnt2_on >= 500U) {
              /* Transition: '<S39>:52' */
              /* Exit 'RlyOFF': '<S39>:5' */
              CBMU_MON_DWork.cnt2_on = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON = CBMU_MON_IN_RlyOFF1;

              /* Entry 'RlyOFF1': '<S39>:41' */
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else {
              qY = CBMU_MON_DWork.cnt2_on + 10U;
              if (qY < CBMU_MON_DWork.cnt2_on) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt2_on = qY;
            }
            break;

           case CBMU_MON_IN_RlyOFF1:
            /* During 'RlyOFF1': '<S39>:41' */
            /* Transition: '<S39>:45' */
            CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON = CBMU_MON_IN_wait_p;

            /* Entry 'wait': '<S39>:43' */
            ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            break;

           case CBMU_MON_IN_RlyOFFConfirm:
            /* During 'RlyOFFConfirm': '<S39>:25' */
            if ((CBMU_MON_B.DataStoreRead5 < 32672U) &&
                (CBMU_MON_B.DataStoreRead5 > 32352U)) {
              /* Transition: '<S39>:27' */
              guard1 = true;
            } else if (CBMU_MON_DWork.cnt_b >= 3000U) {
              /* Transition: '<S39>:49' */
              CBMU_MON_B.Merge3_p = 1U;
              guard1 = true;
            } else {
              qY = CBMU_MON_DWork.cnt_b + 10U;
              if (qY < CBMU_MON_DWork.cnt_b) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt_b = qY;
            }
            break;

           case CBMU_MON_IN_RlyON:
            /* During 'RlyON': '<S39>:3' */
            if ((rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) ||
                (CBMU_MON_DWork.cnt2_on >= 200U)) {
              /* Transition: '<S39>:67' */
              /* Transition: '<S39>:64' */
              /* Exit Internal 'RlyON': '<S39>:3' */
              CBMU_MON_DWork.bitsForTID0.is_RlyON =
                CBMU_MON_IN_NO_ACTIVE_CHILD_n;

              /* Exit 'RlyON': '<S39>:3' */
              CBMU_MON_DWork.cnt1_c = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON = CBMU_MON_IN_RlyOFF_b;

              /* Entry 'RlyOFF': '<S39>:5' */
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              CBMU_MON_DWork.cnt2_on = 0U;
            } else if (CBMU_MON_DWork.cnt1_c >= 800U) {
              /* Transition: '<S39>:35' */
              /* Exit Internal 'RlyON': '<S39>:3' */
              CBMU_MON_DWork.bitsForTID0.is_RlyON =
                CBMU_MON_IN_NO_ACTIVE_CHILD_n;

              /* Exit 'RlyON': '<S39>:3' */
              CBMU_MON_DWork.cnt1_c = 0U;
              CBMU_MON_DWork.cnt2_on = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON = CBMU_MON_IN_RlyON1;

              /* Entry 'RlyON1': '<S39>:34' */
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_ON) != 0);
            } else {
              qY = CBMU_MON_DWork.cnt1_c + 10U;
              if (qY < CBMU_MON_DWork.cnt1_c) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt1_c = qY;
              if (CBMU_MON_DWork.bitsForTID0.is_RlyON == CBMU_MON_IN_Init_i) {
                /* During 'Init': '<S39>:54' */
                if (CBMU_MON_B.DataStoreRead5 == 32512U) {
                  /* Transition: '<S39>:57' */
                  CBMU_MON_DWork.bitsForTID0.is_RlyON = CBMU_MON_IN_count;
                }
              } else {
                /* During 'count': '<S39>:56' */
                if (CBMU_MON_B.DataStoreRead5 != 32512U) {
                  /* Transition: '<S39>:58' */
                  CBMU_MON_DWork.bitsForTID0.is_RlyON = CBMU_MON_IN_Init_i;

                  /* Entry 'Init': '<S39>:54' */
                  CBMU_MON_B.Merge1 = 0U;
                } else {
                  qY = CBMU_MON_DWork.cnt2_on + 10U;
                  if (qY < CBMU_MON_DWork.cnt2_on) {
                    qY = MAX_uint16_T;
                  }

                  CBMU_MON_DWork.cnt2_on = qY;
                }
              }
            }
            break;

           case CBMU_MON_IN_RlyON1:
            /* During 'RlyON1': '<S39>:34' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S39>:14' */
              CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON =
                CBMU_MON_IN_RlyOFFConfirm;

              /* Entry 'RlyOFFConfirm': '<S39>:25' */
              CBMU_MON_DWork.cnt_b = 0U;
            }
            break;

           default:
            /* During 'wait': '<S39>:43' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_ON)) {
              /* Transition: '<S39>:46' */
              CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON = CBMU_MON_IN_RlyON;

              /* Entry 'RlyON': '<S39>:3' */
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_ON) != 0);
              CBMU_MON_DWork.cnt1_c = 0U;
              CBMU_MON_DWork.cnt2_on = 0U;

              /* Entry Internal 'RlyON': '<S39>:3' */
              /* Transition: '<S39>:55' */
              CBMU_MON_DWork.bitsForTID0.is_RlyON = CBMU_MON_IN_Init_i;

              /* Entry 'Init': '<S39>:54' */
              CBMU_MON_B.Merge1 = 0U;
            }
            break;
          }

          if (guard1) {
            /* Exit 'RlyOFFConfirm': '<S39>:25' */
            CBMU_MON_DWork.cnt_b = 0U;
            CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON = CBMU_MON_IN_RlyOFF_b;

            /* Entry 'RlyOFF': '<S39>:5' */
            ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            CBMU_MON_DWork.cnt2_on = 0U;
          }
        }

        /* End of Chart: '<S37>/RlyCtl' */

        /* S-Function (sfun_SetErr): '<S35>/sfun_SetErr_SrcH2' incorporates:
         *  Constant: '<S35>/Constant2'
         */
        Dem_SetError( (uint16_T)92U, (uint8_T)CBMU_MON_B.Merge3_p);

        /* S-Function (sfun_SetErr): '<S35>/sfun_SetErr_SrcH3' incorporates:
         *  Constant: '<S35>/Constant3'
         */
        Dem_SetError( (uint16_T)91U, (uint8_T)CBMU_MON_B.Merge1);
      } else {
        /* Chart: '<S36>/RlyCtl1' */
        /* Gateway: Task_10ms/RelayCtrl/Mode1/Subsystem1/RlyCtl1 */
        /* During: Task_10ms/RelayCtrl/Mode1/Subsystem1/RlyCtl1 */
        /* Entry Internal: Task_10ms/RelayCtrl/Mode1/Subsystem1/RlyCtl1 */
        /* Transition: '<S41>:9' */
        ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
      }

      /* End of Outputs for SubSystem: '<S26>/Subsystem1' */
      /* End of Outputs for SubSystem: '<S26>/Subsystem' */
      /* End of Outputs for SubSystem: '<S5>/Mode1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S5>/Mode2' incorporates:
       *  ActionPort: '<S27>/Action Port'
       */
      /* Outputs for Enabled SubSystem: '<S27>/Subsystem' incorporates:
       *  EnablePort: '<S42>/Enable'
       */
      /* Outputs for Enabled SubSystem: '<S27>/Subsystem1' incorporates:
       *  EnablePort: '<S43>/Enable'
       */
      if (CBMU_MON_B.ContactorEnable == 1) {
        /* Logic: '<S42>/Logical Operator1' */
        rtb_LogicalOperator3_p = (CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl_a ||
          CBMU_MON_B.bitsForTID0.ioa_negativeRelayCtl);

        /* Chart: '<S45>/RlyCtl' */
        /* Gateway: Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl1/RlyCtl */
        /* During: Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl1/RlyCtl */
        if (CBMU_MON_DWork.bitsForTID0.is_active_c7_CBMU_MON == 0U) {
          /* Entry: Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl1/RlyCtl */
          CBMU_MON_DWork.bitsForTID0.is_active_c7_CBMU_MON = 1U;

          /* Entry Internal: Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl1/RlyCtl */
          /* Transition: '<S47>:44' */
          CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON = CBMU_MON_IN_wait_p;

          /* Entry 'wait': '<S47>:43' */
          ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        } else {
          guard1 = false;
          switch (CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON) {
           case CBMU_MON_IN_RlyOFF_b:
            /* During 'RlyOFF': '<S47>:5' */
            if (CBMU_MON_DWork.cnt2 >= 500U) {
              /* Transition: '<S47>:53' */
              /* Exit 'RlyOFF': '<S47>:5' */
              CBMU_MON_DWork.cnt2 = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON = CBMU_MON_IN_RlyOFF1;

              /* Entry 'RlyOFF1': '<S47>:41' */
              ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else {
              qY = CBMU_MON_DWork.cnt2 + 10U;
              if (qY < CBMU_MON_DWork.cnt2) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt2 = qY;
            }
            break;

           case CBMU_MON_IN_RlyOFF1:
            /* During 'RlyOFF1': '<S47>:41' */
            /* Transition: '<S47>:45' */
            CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON = CBMU_MON_IN_wait_p;

            /* Entry 'wait': '<S47>:43' */
            ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            break;

           case CBMU_MON_IN_RlyOFFConfirm:
            /* During 'RlyOFFConfirm': '<S47>:25' */
            if ((CBMU_MON_B.DataStoreRead5 < 32672U) &&
                (CBMU_MON_B.DataStoreRead5 > 32352U)) {
              /* Transition: '<S47>:27' */
              guard1 = true;
            } else if (CBMU_MON_DWork.cnt_j >= 3000U) {
              /* Transition: '<S47>:49' */
              CBMU_MON_B.Merge3 = 1U;
              guard1 = true;
            } else {
              qY = CBMU_MON_DWork.cnt_j + 10U;
              if (qY < CBMU_MON_DWork.cnt_j) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt_j = qY;
            }
            break;

           case CBMU_MON_IN_RlyON:
            /* During 'RlyON': '<S47>:3' */
            if (CBMU_MON_DWork.cnt1 >= 500U) {
              /* Transition: '<S47>:35' */
              /* Exit 'RlyON': '<S47>:3' */
              CBMU_MON_DWork.cnt1 = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON = CBMU_MON_IN_RlyON1;

              /* Entry 'RlyON1': '<S47>:34' */
              ioa_ChMRelayCtl = (((uint8_T)RELAY_ON) != 0);
            } else if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S47>:57' */
              /* Exit 'RlyON': '<S47>:3' */
              CBMU_MON_DWork.cnt1 = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON = CBMU_MON_IN_RlyOFF_b;

              /* Entry 'RlyOFF': '<S47>:5' */
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              CBMU_MON_DWork.cnt2 = 0U;
            } else {
              qY = CBMU_MON_DWork.cnt1 + 10U;
              if (qY < CBMU_MON_DWork.cnt1) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt1 = qY;
            }
            break;

           case CBMU_MON_IN_RlyON1:
            /* During 'RlyON1': '<S47>:34' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S47>:14' */
              CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON =
                CBMU_MON_IN_RlyOFFConfirm;

              /* Entry 'RlyOFFConfirm': '<S47>:25' */
              CBMU_MON_DWork.cnt_j = 0U;
            }
            break;

           default:
            /* During 'wait': '<S47>:43' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_ON)) {
              /* Transition: '<S47>:46' */
              CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON = CBMU_MON_IN_RlyON;

              /* Entry 'RlyON': '<S47>:3' */
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_ON) != 0);
              CBMU_MON_DWork.cnt1 = 0U;
            }
            break;
          }

          if (guard1) {
            /* Exit 'RlyOFFConfirm': '<S47>:25' */
            CBMU_MON_DWork.cnt_j = 0U;
            CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON = CBMU_MON_IN_RlyOFF_b;

            /* Entry 'RlyOFF': '<S47>:5' */
            ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            CBMU_MON_DWork.cnt2 = 0U;
          }
        }

        /* End of Chart: '<S45>/RlyCtl' */

        /* Logic: '<S42>/Logical Operator3' incorporates:
         *  Logic: '<S42>/Logical Operator4'
         */
        rtb_LogicalOperator3_p = (CBMU_MON_B.bitsForTID0.Switch1 && (!(O_S_FCCC ||
          O_S_SCCC)));

        /* Chart: '<S44>/RlyCtl' incorporates:
         *  Inport: '<Root>/DCVolt_Reach'
         */
        /* Gateway: Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl/RlyCtl */
        /* During: Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl/RlyCtl */
        if (CBMU_MON_DWork.bitsForTID0.is_active_c4_CBMU_MON == 0U) {
          /* Entry: Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl/RlyCtl */
          CBMU_MON_DWork.bitsForTID0.is_active_c4_CBMU_MON = 1U;

          /* Entry Internal: Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl/RlyCtl */
          /* Transition: '<S46>:9' */
          CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyOFF;

          /* Entry 'RlyOFF': '<S46>:5' */
          ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        } else {
          guard1 = false;
          switch (CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON) {
           case CBMU_MON_IN_RlyErr:
            /* During 'RlyErr': '<S46>:20' */
            break;

           case CBMU_MON_IN_RlyOFF:
            /* During 'RlyOFF': '<S46>:5' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_ON)) {
              /* Transition: '<S46>:7' */
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON =
                CBMU_MON_IN_RlyONCount1;

              /* Entry 'RlyONCount1': '<S46>:34' */
              CBMU_MON_DWork.rlyctl_ct = 0U;
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_ON) != 0);
            }
            break;

           case CBMU_MON_IN_RlyOFFConfirm:
            /* During 'RlyOFFConfirm': '<S46>:25' */
            if (CBMU_MON_DWork.cnt_a >= 3000U) {
              /* Transition: '<S46>:32' */
              CBMU_MON_B.Merge3 = 1U;
              guard1 = true;
            } else if ((CBMU_MON_B.DataStoreRead5 < 32672U) &&
                       (CBMU_MON_B.DataStoreRead5 > 32352U)) {
              /* Transition: '<S46>:27' */
              guard1 = true;
            } else {
              qY = CBMU_MON_DWork.cnt_a + 10U;
              if (qY < CBMU_MON_DWork.cnt_a) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.cnt_a = qY;
            }
            break;

           case CBMU_MON_IN_RlyON:
            /* During 'RlyON': '<S46>:10' */
            if (CBMU_MON_DWork.rlyctl_ct > 1000U) {
              /* Transition: '<S46>:19' */
              /* Exit 'RlyON': '<S46>:10' */
              CBMU_MON_DWork.rlyctl_ct = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyON1;

              /* Entry 'RlyON1': '<S46>:17' */
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else {
              qY = CBMU_MON_DWork.rlyctl_ct + 10U;
              if (qY < CBMU_MON_DWork.rlyctl_ct) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.rlyctl_ct = qY;
            }
            break;

           case CBMU_MON_IN_RlyON1:
            /* During 'RlyON1': '<S46>:17' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S46>:14' */
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON =
                CBMU_MON_IN_RlyOFFConfirm;

              /* Entry 'RlyOFFConfirm': '<S46>:25' */
              CBMU_MON_DWork.cnt_a = 0U;
            }
            break;

           case CBMU_MON_IN_RlyONCount:
            /* During 'RlyONCount': '<S46>:3' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S46>:38' */
              /* Exit 'RlyONCount': '<S46>:3' */
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyOff1;

              /* Entry 'RlyOff1': '<S46>:36' */
              CBMU_MON_DWork.rlyctl_ct = 0U;
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else if ((CBMU_MON_DWork.rlyctl_ct > 1000U) && (DCVolt_Reach == 1))
            {
              /* Transition: '<S46>:11' */
              /* Exit 'RlyONCount': '<S46>:3' */
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyON;

              /* Entry 'RlyON': '<S46>:10' */
              CBMU_MON_DWork.rlyctl_ct = 0U;
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_ON) != 0);
            } else if ((CBMU_MON_DWork.rlyctl_ct > 3000U) && (DCVolt_Reach != 1))
            {
              /* Transition: '<S46>:21' */
              /* Exit 'RlyONCount': '<S46>:3' */
              CBMU_MON_DWork.rlyctl_ct = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyErr;

              /* Entry 'RlyErr': '<S46>:20' */
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else {
              qY = CBMU_MON_DWork.rlyctl_ct + 10U;
              if (qY < CBMU_MON_DWork.rlyctl_ct) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.rlyctl_ct = qY;
            }
            break;

           case CBMU_MON_IN_RlyONCount1:
            /* During 'RlyONCount1': '<S46>:34' */
            if (rtb_LogicalOperator3_p == ((uint8_T)RELAY_OFF)) {
              /* Transition: '<S46>:6' */
              /* Exit 'RlyONCount1': '<S46>:34' */
              CBMU_MON_DWork.rlyctl_ct = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyOFF;

              /* Entry 'RlyOFF': '<S46>:5' */
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else if (CBMU_MON_DWork.rlyctl_ct >= 500U) {
              /* Transition: '<S46>:35' */
              /* Exit 'RlyONCount1': '<S46>:34' */
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyONCount;

              /* Entry 'RlyONCount': '<S46>:3' */
              CBMU_MON_DWork.rlyctl_ct = 0U;
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_ON) != 0);
            } else {
              qY = CBMU_MON_DWork.rlyctl_ct + 10U;
              if (qY < CBMU_MON_DWork.rlyctl_ct) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.rlyctl_ct = qY;
            }
            break;

           default:
            /* During 'RlyOff1': '<S46>:36' */
            if (CBMU_MON_DWork.rlyctl_ct >= 500U) {
              /* Transition: '<S46>:37' */
              /* Exit 'RlyOff1': '<S46>:36' */
              CBMU_MON_DWork.rlyctl_ct = 0U;
              CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyOFF;

              /* Entry 'RlyOFF': '<S46>:5' */
              ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
              ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
            } else {
              qY = CBMU_MON_DWork.rlyctl_ct + 10U;
              if (qY < CBMU_MON_DWork.rlyctl_ct) {
                qY = MAX_uint16_T;
              }

              CBMU_MON_DWork.rlyctl_ct = qY;
            }
            break;
          }

          if (guard1) {
            /* Exit 'RlyOFFConfirm': '<S46>:25' */
            CBMU_MON_DWork.cnt_a = 0U;
            CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_RlyOff1;

            /* Entry 'RlyOff1': '<S46>:36' */
            CBMU_MON_DWork.rlyctl_ct = 0U;
            ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
          }
        }

        /* End of Chart: '<S44>/RlyCtl' */

        /* S-Function (sfun_SetErr): '<S42>/sfun_SetErr_SrcH2' incorporates:
         *  Constant: '<S42>/Constant2'
         */
        Dem_SetError( (uint16_T)92U, (uint8_T)CBMU_MON_B.Merge3);
      } else {
        /* Chart: '<S43>/RlyCtl1' */
        /* Gateway: Task_10ms/RelayCtrl/Mode2/Subsystem1/RlyCtl1 */
        /* During: Task_10ms/RelayCtrl/Mode2/Subsystem1/RlyCtl1 */
        /* Entry Internal: Task_10ms/RelayCtrl/Mode2/Subsystem1/RlyCtl1 */
        /* Transition: '<S48>:9' */
        ioa_NegativeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        ioa_DisChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        ioa_ChMRelayCtl = (((uint8_T)RELAY_OFF) != 0);
        ioa_PreChargeRelayCtl = (((uint8_T)RELAY_OFF) != 0);
      }

      /* End of Outputs for SubSystem: '<S27>/Subsystem1' */
      /* End of Outputs for SubSystem: '<S27>/Subsystem' */
      /* End of Outputs for SubSystem: '<S5>/Mode2' */
      break;
    }

    /* End of SwitchCase: '<S5>/ModeChoose' */
  }

  /* End of RelationalOperator: '<S2>/Compare' */
  /* End of Outputs for SubSystem: '<S1>/RelayCtrl' */

  /* Update for Memory: '<S1>/Memory1' */
  CBMU_MON_DWork.Memory1_PreviousInput_g = PwrMode;

  /* Update for Memory: '<S1>/Memory' */
  CBMU_MON_DWork.bitsForTID0.Memory_PreviousInput_n = ioa_DisChMRelayCtl;

  /* Update for Memory: '<S1>/Memory2' */
  CBMU_MON_DWork.bitsForTID0.Memory2_PreviousInput_i = ioa_ChMRelayCtl;
}

/* Model initialize function */
void CBMU_MON_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(CBMU_MON_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &CBMU_MON_B), 0,
                sizeof(BlockIO_CBMU_MON));

  /* exported global signals */
  ChrgTgtCur = 0U;
  ChrgTgtTimer2 = 0U;
  ChrgTgtTimer1 = 0U;
  BatVolt_St = 0U;
  ScVolt_St = 0U;
  FcVolt_St = 0U;
  mChargeStep = 0U;

  /* custom signals */
  HVIL_test0 = 0U;
  PwrMode = 0U;
  O_S_HVIL = true;
  I_S_Sc = false;
  I_S_T15 = false;
  I_S_Fc = false;
  O_S_AirBag = true;
  SafeBag_test0 = false;

  /* states (dwork) */
  (void) memset((void *)&CBMU_MON_DWork, 0,
                sizeof(D_Work_CBMU_MON));

  /* exported global states */
  SafebagNormalCount = 0U;
  SafebagErrCount = 0U;
  SC_MON_test = 0U;
  FC_MON_test = 0U;

  /* external inputs */
  CBMU_MON_U.ect_AirbagNormal_d = 0UL;
  SID_m_st_DisChMRelay = false;
  SID_m_st_ChMRelay = false;
  HW_Err = false;

  /* Initialize subsystem data */
  CBMU_M_O_SW_HVIL_Swt_initialize();
  CBMU_O_SW_HVIL_Swt_h_initialize();
  CBMU_O_SW_HVIL_Swt_l_initialize();
  CBMU_O_SW_HVIL_Swt_p_initialize();
  CBMU__O_SW_HVIL_Swt1_initialize();
  C_O_SW_NegRlyCtl_Swt_initialize();
  C_O_SW_PosRlyCtl_Swt_initialize();
  CBMU_O_SW_HVIL_Swt_k_initialize();

  /* Start for Constant: '<S1>/Constant1' */
  O_S_HVIL = true;

  /* Start for Atomic SubSystem: '<S1>/FC_Mon' */
  CBMU_MON_FC_Mon_Start();

  /* End of Start for SubSystem: '<S1>/FC_Mon' */

  /* ConstCode for Constant: '<S1>/Constant1' */
  O_S_HVIL = true;

  /* SystemInitialize for Atomic SubSystem: '<S1>/SID' */
  CBMU_MON_SID_Init();

  /* End of SystemInitialize for SubSystem: '<S1>/SID' */

  /* SystemInitialize for Atomic SubSystem: '<S1>/PwrON' */
  CBMU_MON_PwrON_Init();

  /* End of SystemInitialize for SubSystem: '<S1>/PwrON' */

  /* SystemInitialize for Atomic SubSystem: '<S1>/SC_Mon' */
  CBMU_MON_SC_Mon_Init();

  /* End of SystemInitialize for SubSystem: '<S1>/SC_Mon' */

  /* SystemInitialize for Atomic SubSystem: '<S1>/FC_Mon' */
  CBMU_MON_FC_Mon_Init();

  /* End of SystemInitialize for SubSystem: '<S1>/FC_Mon' */

  /* SystemInitialize for Enabled SubSystem: '<S1>/RelayCtrl' */
  /* SystemInitialize for IfAction SubSystem: '<S5>/Mode0' */
  /* SystemInitialize for Enabled SubSystem: '<S25>/Subsystem' */
  /* SystemInitialize for Chart: '<S30>/RlyCtl' */
  CBMU_MON_DWork.bitsForTID0.is_active_c17_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c17_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_n;
  CBMU_MON_DWork.rlyctl_ct_o = 0U;
  CBMU_MON_DWork.cnt_b3 = 0U;

  /* SystemInitialize for Chart: '<S31>/RlyCtl' */
  CBMU_MON_DWork.bitsForTID0.is_active_c18_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c18_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_n;
  CBMU_MON_DWork.cnt_k = 0U;
  CBMU_MON_B.Merge3_d = 0U;

  /* End of SystemInitialize for SubSystem: '<S25>/Subsystem' */
  /* End of SystemInitialize for SubSystem: '<S5>/Mode0' */

  /* SystemInitialize for IfAction SubSystem: '<S5>/Mode1' */
  /* SystemInitialize for Enabled SubSystem: '<S26>/Subsystem' */
  /* SystemInitialize for Chart: '<S38>/RlyCtl' */
  CBMU_MON_DWork.bitsForTID0.is_RlyON2 = CBMU_MON_IN_NO_ACTIVE_CHILD_n;
  CBMU_MON_DWork.bitsForTID0.is_active_c19_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c19_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_n;
  CBMU_MON_DWork.cnt_g = 0U;
  CBMU_MON_DWork.cnt1_j = 0U;
  CBMU_MON_DWork.cnt2_o = 0U;

  /* SystemInitialize for Chart: '<S37>/RlyCtl' */
  CBMU_MON_DWork.bitsForTID0.is_RlyON = CBMU_MON_IN_NO_ACTIVE_CHILD_n;
  CBMU_MON_DWork.bitsForTID0.is_active_c8_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c8_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_n;
  CBMU_MON_DWork.cnt_b = 0U;
  CBMU_MON_DWork.cnt1_c = 0U;
  CBMU_MON_DWork.cnt2_on = 0U;
  CBMU_MON_B.Merge3_p = 0U;
  CBMU_MON_B.Merge1 = 0U;

  /* End of SystemInitialize for SubSystem: '<S26>/Subsystem' */
  /* End of SystemInitialize for SubSystem: '<S5>/Mode1' */

  /* SystemInitialize for IfAction SubSystem: '<S5>/Mode2' */
  /* SystemInitialize for Enabled SubSystem: '<S27>/Subsystem' */
  /* SystemInitialize for Chart: '<S45>/RlyCtl' */
  CBMU_MON_DWork.bitsForTID0.is_active_c7_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c7_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_n;
  CBMU_MON_DWork.cnt_j = 0U;
  CBMU_MON_DWork.cnt1 = 0U;
  CBMU_MON_DWork.cnt2 = 0U;

  /* SystemInitialize for Chart: '<S44>/RlyCtl' */
  CBMU_MON_DWork.bitsForTID0.is_active_c4_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c4_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_n;
  CBMU_MON_DWork.rlyctl_ct = 0U;
  CBMU_MON_DWork.cnt_a = 0U;
  CBMU_MON_B.Merge3 = 0U;

  /* End of SystemInitialize for SubSystem: '<S27>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S27>/Subsystem1' */
  /* SystemInitialize for Chart: '<S43>/RlyCtl1' */
  ioa_NegativeRelayCtl = false;
  ioa_DisChMRelayCtl = false;
  ioa_ChMRelayCtl = false;
  ioa_PreChargeRelayCtl = false;

  /* End of SystemInitialize for SubSystem: '<S27>/Subsystem1' */
  /* End of SystemInitialize for SubSystem: '<S5>/Mode2' */
  /* End of SystemInitialize for SubSystem: '<S1>/RelayCtrl' */
}

/* Model terminate function */
void CBMU_MON_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
