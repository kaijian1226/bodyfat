/*******************************************************************************
*
*  FILE
*     Eep.c
*
*  DESCRIPTION
*     Eep (eeprom init,enable,disable,checkfinish and partition) 
*      ģ��EEPROM�������ü���������
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.2
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include <MC9S12XEP100.h>     /* derivative information */
#include "Eep.h"
#include "Det.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/
#define EEP_LOOP_TIMER_START(timer)   {eep_LoopTimer = timer;}
#define EEP_LOOP_TIMER_LOOP()         ((--eep_LoopTimer) != 0)
#define EEP_LOOP_TIMER_END()          (eep_LoopTimer == 0)


#define EEP_COMMAND_NOT_COMPLETE()    (!(EEP_REG_FSTAT & EEP_FSTAT_CCIF_MASK))
/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
boolean eep_Status;
/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ VAR(uint16,EEP_VAR) eep_LoopTimer;

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ FUNC(Std_ReturnType,EEP_CODE) Eep_ChkIfCmdComplete(void);
_STATIC_ FUNC(Eep_ErrType,EEP_CODE) Eep_Partition(void);
/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/


/*******************************************************************************
* NAME:             Eep_Init (bean IntEEPROM)
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      Initializes the associated peripheral(s) and the bean internal
*                   variables. The method is called automatically as a part of the
*                   application initialization code.
*                   This method is internal. It is used by Processor Expert only.
*******************************************************************************/
void EEP_CODE Eep_Init(void)
{
    eep_Status = E_NOT_OK;
  
    /* Wait for command completition */  
    if (Eep_ChkIfCmdComplete() == E_NOT_OK)
    {
        return;
    }
  
    if( !FCLKDIV_FDIVLD )           //can only be written when FDIVLD = 0
    {
        FCLKDIV = 0x03;
    }
 
  /* Set up Clock Divider Register */
  //EEP_REG_FCLKDIV = EEP_FCLK_DIV; 2014-01-17, BootRom set it already
                
  /* Wait for command completition */            
  if (Eep_ChkIfCmdComplete() == E_NOT_OK)
  {
    return;
  } 
  
  if (Eep_Partition() != EEP_E_OK)
  {
    return;  
  }
    
  if (Eep_DisableEEE() != EEP_E_OK)
  {
    return;  
  }
  eep_Status = E_OK;
}

/*******************************************************************************
* NAME:             Eep_EnableEEE
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* RETURN VALUES:    Eep_ErrType
* DESCRIPTION:      Enable the automatical write to EEPROM
*******************************************************************************/
Eep_ErrType EEP_CODE Eep_EnableEEE(void)
{
  /* wait for command completition */
  if (Eep_ChkIfCmdComplete() == E_NOT_OK)
  {
    return EEP_E_BUSY;
  }
   
  /* Clear error flags */
  EEP_REG_FSTAT = 48;
  /* Clear index register */                          
  EEP_REG_FCCOBIX = 0;
  /* Enable Emulated EEPROM command */                         
  EEP_REG_FCCOBHI = 19; 
  /* Clear flag command complete */                       
  EEP_REG_FSTAT = 128; 
   
  /* Is access error detected ? */
  /* If yes then error */                       
  if (EEP_REG_FSTAT & EEP_FSTAT_ACCERR_MASK) 
  { 
    return EEP_E_NOTAVAIL;              
  }
  /* If yes then wait for command completition */
  if (Eep_ChkIfCmdComplete() == E_NOT_OK)
  {
    return EEP_E_BUSY;
  } 
  /* OK */               
  return EEP_E_OK;                    
}

/*******************************************************************************
* NAME:             Eep_DisableEEE
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* RETURN VALUES:    Eep_ErrType
* DESCRIPTION:      Disable the automatical write to EEPROM
*******************************************************************************/
Eep_ErrType EEP_CODE Eep_DisableEEE(void)
{
  if (Eep_ChkIfCmdComplete() == E_NOT_OK)
  {                    
    return EEP_E_BUSY;                   
  }
  /* Clear error flags */
  EEP_REG_FSTAT = 48; 
  /* Clear index register */                         
  EEP_REG_FCCOBIX = 0;
  /* Enable Emulated EEPROM command */                         
  EEP_REG_FCCOBHI = 20;
  /* Clear flag command complete */                        
  EEP_REG_FSTAT = 128;
  
  /* Is access error detected ? */
  /* If yes then error */                         
  if(EEP_REG_FSTAT & EEP_FSTAT_ACCERR_MASK) 
  {                  
    return EEP_E_NOTAVAIL;               
  }
  
  /* If yes then wait for command completition */
  if (Eep_ChkIfCmdComplete() == E_NOT_OK)
  {
    return EEP_E_BUSY;
  } 
  
  /* OK */                
  return EEP_E_OK;                        
}

/*******************************************************************************
* NAME:             Eep_ChkSaveIfFinish
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* RETURN VALUES:    Std_ReturnType
* DESCRIPTION:   
*******************************************************************************/
Std_ReturnType EEP_CODE Eep_ChkSaveIfFinish(void)
{
  if ((EEP_REG_ETAG == 0)&&((EEP_REG_FSTAT & EEP_FSTAT_MGBUSY_MASK) == 0))
  {
    return E_OK;
  }
  else
  {
    return E_NOT_OK;
  }
}


/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Eep_ChkIfCmdComplete
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* Returns VALUES  : Std_ReturnType
* DESCRIPTION:      Check if Eep Command is completed  
*******************************************************************************/
_STATIC_ Std_ReturnType EEP_CODE Eep_ChkIfCmdComplete(void) 
{
  EEP_LOOP_TIMER_START(EEP_WAIT_CMD_COMPLETE_TIME);
  while(EEP_COMMAND_NOT_COMPLETE() && EEP_LOOP_TIMER_LOOP()) {}
  if (EEP_LOOP_TIMER_END())
  {
#if (EEP_DEV_ERROR_DETECT == STD_ON)
    Det_ReportError(EEP_MODULE_ID,EEP_INSTATNCE_ID,EEP_API_CMD_COMPLETE_ID,EEP_E_PARAM_LOOP_TO);
#endif    
    return E_NOT_OK;    
  }else
  {
    return E_OK;
  }  
}
/*******************************************************************************
* NAME:             Eep_Partition
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* Returns VALUES  : Eep_ErrType
* DESCRIPTION:      The method checks current partitions of D-Flash and buffer
*                   RAM used for Emulated EEPROM and compares it to "D-Flash
*                   sector count (DFPART)" and "Buffer RAM sector count for
*                   Emulated EEPROM (ERPART)" settings. If the settings equals
*                   with current partition, the method just enables EEPROM
*                   emulation. If the settings differ, the method proceeds to
*                   full partition of D-Flash memory according to ERPART and
*                   DFPART settings and enables Emulated EEPROM feature. Warning:
*                   All data in D-Flash memory will be erased during full
*                   partition process. Full partition command is only provided
*                   if the cpu runs in unsecured special mode otherwise the
*                   method returns error code (ERR_NOTAVAIL). If "<Partition
*                   D-Flash in init>" property is set to yes, this method is
*                   automatically called in init.
*******************************************************************************/
_STATIC_ Eep_ErrType EEP_CODE Eep_Partition(void)
{
  boolean IsPartitioned;
  uint16 idx;
  
  IsPartitioned = TRUE;
  
  /* Is reading from EEPROM possible? */
  if (Eep_ChkIfCmdComplete() == E_NOT_OK)
  {
    return EEP_E_BUSY;
  }
  /* Query the Emulated EEPROM status */
  /* FSTAT: ACCERR=1,FPVIOL=1 */
  
  /* Clear error flags */
  EEP_REG_FSTAT = 48;
  /* Clear index register */                          
  EEP_REG_FCCOBIX = 0;
  /* Query Emulated EEPROM status command */                         
  EEP_REG_FCCOBHI = 21; 
  /* Clear flag command complete */                       
  EEP_REG_FSTAT = 128;  
  
  /* Is access error detected ? */
  /* If yes then error */                      
  if (EEP_REG_FSTAT & EEP_FSTAT_ACCERR_MASK) 
  {                   
    return EEP_E_NOTAVAIL;               
  }
  
  /* Wait for command completition */
  if (Eep_ChkIfCmdComplete() == E_NOT_OK)
  {
    return EEP_E_BUSY;
  }
  
  /* Index the DFPART info */               
  EEP_REG_FCCOBIX++;
  
  /* Is DFPART set correctly ? */                           
  if(EEP_REG_FCCOB != EEP_DFPART)
  {                     
    IsPartitioned = FALSE;           
  }
  
  /* Index the ERPART info */
  EEP_REG_FCCOBIX++;  
  
  /* Is ERPART set correctly ? */                         
  if(EEP_REG_FCCOB != EEP_EEE_SECTORS) 
  {                  
    IsPartitioned = FALSE;         
  }
  
  /* Need to be partitioned ? */
  if(IsPartitioned == FALSE) 
  { 
    /* Clear error flags */              
    EEP_REG_FSTAT = 48;
    /* Clear index register */                        
    EEP_REG_FCCOBIX = 0; 
    /* Partition D-Flash command */                      
//    EEP_REG_FCCOBHI = 15;
    EEP_REG_FCCOBHI = 20;   //2015-06-29, lzy, 15 is full partition, it can only exec. in Special Single mode
    /* Index the DFPART info */                      
    EEP_REG_FCCOBIX++; 
    /* Write DFPART */                        
    EEP_REG_FCCOB = EEP_DFPART;
    /* Index the DFPART info */                         
    EEP_REG_FCCOBIX++;
    /* Write ERPART */                        
    EEP_REG_FCCOB = EEP_EEE_SECTORS;
    /* Clear flag command complete */                        
    EEP_REG_FSTAT = 128;

    for (idx=0; idx<EEP_DELAY_CNT; idx++){}
        
    /* Is access error detected ? */
    /* If yes then error */                       
    if (EEP_REG_FSTAT & EEP_FSTAT_ACCERR_MASK) 
    {               
      return EEP_E_NOTAVAIL;             
    }
  }
  /* If yes then wait for command completition */
  if (Eep_ChkIfCmdComplete() == E_NOT_OK)
  {
    return EEP_E_BUSY;
  }
                 
  return EEP_E_OK;                  
}