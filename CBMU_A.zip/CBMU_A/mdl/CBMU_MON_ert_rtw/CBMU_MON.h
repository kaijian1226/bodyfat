/*
 * File: CBMU_MON.h
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_CBMU_MON_h_
#define RTW_HEADER_CBMU_MON_h_
#include <stddef.h>
#include <string.h>
#ifndef CBMU_MON_COMMON_INCLUDES_
# define CBMU_MON_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "SetErr.h"
#endif                                 /* CBMU_MON_COMMON_INCLUDES_ */

#include "CBMU_MON_types.h"

/* Child system includes */
#include "FC_Mon.h"
#include "PwrON.h"
#include "SC_Mon.h"
#include "SID.h"

/* Includes for objects with custom storage classes. */
#include "CBMU_Data.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (auto storage) */
typedef struct {
  uint16_T DataStoreRead5;             /* '<Root>/Data Store Read5' */
  uint16_T DataStoreRead6;             /* '<Root>/Data Store Read6' */
  uint16_T ChgCur;                     /* '<S15>/Chgcurrentcalc' */
  struct {
    uint_T DataStoreRead3_m:1;         /* '<S1>/Data Store Read3' */
    uint_T DataStoreRead2_a:1;         /* '<S1>/Data Store Read2' */
    uint_T DataStoreRead1_d:1;         /* '<S1>/Data Store Read1' */
    uint_T DataStoreRead:1;            /* '<S1>/Data Store Read' */
    uint_T Switch1:1;                  /* '<S7>/Switch1' */
    uint_T HW_Err_n:1;                 /* '<S7>/HW_Err' */
    uint_T SafeBag_St:1;               /* '<S62>/Chart' */
    uint_T O_S_HVIL_Swt:1;             /* '<S53>/Chart' */
    uint_T ioa_negativeRelayCtl:1;     /* '<S49>/Chart' */
    uint_T PwrErrFlag:1;               /* '<S23>/Chart' */
    uint_T ioa_negativeRelayCtl_a:1;   /* '<S8>/Chart' */
    uint_T RelationalOperator:1;       /* '<S60>/Relational Operator' */
    uint_T RelationalOperator1:1;      /* '<S60>/Relational Operator1' */
  } bitsForTID0;

  uint8_T Memory1;                     /* '<S1>/Memory1' */
  uint8_T Divide;                      /* '<S1>/Divide' */
  uint8_T DataStoreRead1;              /* '<Root>/Data Store Read1' */
  uint8_T DataStoreRead2;              /* '<Root>/Data Store Read2' */
  uint8_T DataStoreRead4;              /* '<Root>/Data Store Read4' */
  uint8_T DataStoreRead3;              /* '<Root>/Data Store Read3' */
  uint8_T DataStoreRead7;              /* '<Root>/Data Store Read7' */
  uint8_T Merge3;                      /* '<S42>/Merge3' */
  uint8_T Merge3_p;                    /* '<S35>/Merge3' */
  uint8_T Merge1;                      /* '<S35>/Merge1' */
  uint8_T Merge3_d;                    /* '<S28>/Merge3' */
  uint8_T CurError;                    /* '<S23>/Chart' */
  uint8_T ContactorEnable;             /* '<S23>/Chart' */
  uint8_T CalcStart;                   /* '<S12>/current' */
  uint8_T PTCerr1;                     /* '<S8>/Chart' */
  uint8_T PTCerr2;                     /* '<S8>/Chart' */
  uint8_T PTCerr3;                     /* '<S8>/Chart' */
  uint8_T PTCerr4;                     /* '<S8>/Chart' */
  uint8_T TimeOutErr;                  /* '<S8>/Chart' */
  uint8_T PTCStickyErr;                /* '<S8>/Chart' */
  rtB_SRC_Check_CBMU_MON SRC_Check_l;  /* '<S119>/SRC_Check' */
  rtB_SRC_Check_CBMU_MON SRC_Check_b;  /* '<S114>/SRC_Check' */
  rtB_SRC_Check_CBMU_MON SRC_Check_e;  /* '<S109>/SRC_Check' */
  rtB_SRC_Check_CBMU_MON SRC_Check;    /* '<S104>/SRC_Check' */
  rtB_Chart_CBMU_MON sf_Chart_c;       /* '<S61>/Chart' */
  rtB_Chart_CBMU_MON sf_Chart_i;       /* '<S52>/Chart' */
} BlockIO_CBMU_MON;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  uint32_T scm_ct;                     /* '<S49>/Chart' */
  uint32_T pwr_ct;                     /* '<S23>/Chart' */
  uint32_T cnt;                        /* '<S8>/Chart' */
  uint32_T cnt4;                       /* '<S8>/Chart' */
  uint16_T Memory_PreviousInput;       /* '<S6>/Memory' */
  uint16_T cnt_j;                      /* '<S45>/RlyCtl' */
  uint16_T cnt1;                       /* '<S45>/RlyCtl' */
  uint16_T cnt2;                       /* '<S45>/RlyCtl' */
  uint16_T rlyctl_ct;                  /* '<S44>/RlyCtl' */
  uint16_T cnt_a;                      /* '<S44>/RlyCtl' */
  uint16_T cnt_g;                      /* '<S38>/RlyCtl' */
  uint16_T cnt1_j;                     /* '<S38>/RlyCtl' */
  uint16_T cnt2_o;                     /* '<S38>/RlyCtl' */
  uint16_T cnt_b;                      /* '<S37>/RlyCtl' */
  uint16_T cnt1_c;                     /* '<S37>/RlyCtl' */
  uint16_T cnt2_on;                    /* '<S37>/RlyCtl' */
  uint16_T cnt_k;                      /* '<S31>/RlyCtl' */
  uint16_T rlyctl_ct_o;                /* '<S30>/RlyCtl' */
  uint16_T cnt_b3;                     /* '<S30>/RlyCtl' */
  uint16_T cnt6;                       /* '<S23>/Chart' */
  uint16_T cnt7;                       /* '<S23>/Chart' */
  uint16_T cnt8;                       /* '<S23>/Chart' */
  uint16_T cnt_d;                      /* '<S13>/current' */
  uint16_T cnt_e;                      /* '<S12>/current' */
  uint16_T Memory_PreviousInput_f;     /* '<S15>/Memory' */
  uint16_T cnt1_b;                     /* '<S15>/Chgcurrentcalc' */
  uint16_T cnt2_g;                     /* '<S15>/Chgcurrentcalc' */
  uint16_T fc_ct;                      /* '<S8>/Chart' */
  uint16_T cnt1_bm;                    /* '<S8>/Chart' */
  uint16_T cnt2_n;                     /* '<S8>/Chart' */
  uint16_T cnt3;                       /* '<S8>/Chart' */
  uint16_T ONcnt;                      /* '<S8>/Chart' */
  uint16_T cnt5;                       /* '<S8>/Chart' */
  struct {
    uint_T is_c36_CBMU_MON:4;          /* '<S49>/Chart' */
    uint_T is_c4_CBMU_MON:4;           /* '<S44>/RlyCtl' */
    uint_T is_c7_CBMU_MON:3;           /* '<S45>/RlyCtl' */
    uint_T is_c19_CBMU_MON:3;          /* '<S38>/RlyCtl' */
    uint_T is_c8_CBMU_MON:3;           /* '<S37>/RlyCtl' */
    uint_T is_c17_CBMU_MON:3;          /* '<S30>/RlyCtl' */
    uint_T is_c35_CBMU_MON:3;          /* '<S23>/Chart' */
    uint_T is_ChargePwrON:3;           /* '<S23>/Chart' */
    uint_T is_FCSelfCheck:3;           /* '<S23>/Chart' */
    uint_T is_SCSelfCheck:3;           /* '<S23>/Chart' */
    uint_T is_T15PwrON:3;              /* '<S23>/Chart' */
    uint_T is_c9_CBMU_MON:3;           /* '<S8>/Chart' */
    uint_T is_FC_Handing:3;            /* '<S8>/Chart' */
    uint_T is_ParamSetting:3;          /* '<S8>/Chart' */
    uint_T is_ChargingStop:3;          /* '<S8>/Chart' */
    uint_T is_SC_MON_FINISHED:2;       /* '<S49>/Chart' */
    uint_T is_SC_MON_CHARGER_ERR:2;    /* '<S49>/Chart' */
    uint_T is_SC_MON_CAN_TO:2;         /* '<S49>/Chart' */
    uint_T is_SC_MON_AC_DISCONNECT:2;  /* '<S49>/Chart' */
    uint_T is_SC_MON_CV_HI:2;          /* '<S49>/Chart' */
    uint_T is_RlyON2:2;                /* '<S38>/RlyCtl' */
    uint_T is_RlyON:2;                 /* '<S37>/RlyCtl' */
    uint_T is_c18_CBMU_MON:2;          /* '<S31>/RlyCtl' */
    uint_T is_PwrOnStart:2;            /* '<S23>/Chart' */
    uint_T is_state1:2;                /* '<S23>/Chart' */
    uint_T is_state2:2;                /* '<S23>/Chart' */
    uint_T is_state1_m:2;              /* '<S23>/Chart' */
    uint_T is_state2_m:2;              /* '<S23>/Chart' */
    uint_T is_PwrOFF:2;                /* '<S23>/Chart' */
    uint_T is_c24_CBMU_MON:2;          /* '<S13>/current' */
    uint_T is_c1_CBMU_MON:2;           /* '<S12>/current' */
    uint_T is_FC_Charging:2;           /* '<S8>/Chart' */
    uint_T is_Heating:2;               /* '<S8>/Chart' */
    uint_T is_PTCRelayCheck:2;         /* '<S8>/Chart' */
    uint_T is_CHECK1:2;                /* '<S8>/Chart' */
    uint_T is_CHECK2:2;                /* '<S8>/Chart' */
    uint_T is_CHECK3:2;                /* '<S8>/Chart' */
    uint_T is_CHECK4_1:2;              /* '<S8>/Chart' */
    uint_T is_CHECK4_2:2;              /* '<S8>/Chart' */
    uint_T is_CHECK4_3:2;              /* '<S8>/Chart' */
    uint_T is_CCS_Mon:2;               /* '<S8>/Chart' */
    uint_T Memory_PreviousInput_n:1;   /* '<S1>/Memory' */
    uint_T Memory2_PreviousInput_i:1;  /* '<S1>/Memory2' */
    uint_T FcMon_MODE:1;               /* '<S3>/FcMon' */
    uint_T is_active_c36_CBMU_MON:1;   /* '<S49>/Chart' */
    uint_T is_active_c7_CBMU_MON:1;    /* '<S45>/RlyCtl' */
    uint_T is_active_c4_CBMU_MON:1;    /* '<S44>/RlyCtl' */
    uint_T is_active_c19_CBMU_MON:1;   /* '<S38>/RlyCtl' */
    uint_T is_active_c8_CBMU_MON:1;    /* '<S37>/RlyCtl' */
    uint_T is_active_c18_CBMU_MON:1;   /* '<S31>/RlyCtl' */
    uint_T is_active_c17_CBMU_MON:1;   /* '<S30>/RlyCtl' */
    uint_T is_active_c35_CBMU_MON:1;   /* '<S23>/Chart' */
    uint_T is_active_c24_CBMU_MON:1;   /* '<S13>/current' */
    uint_T is_active_c1_CBMU_MON:1;    /* '<S12>/current' */
    uint_T is_active_c9_CBMU_MON:1;    /* '<S8>/Chart' */
  } bitsForTID0;

  int8_T SwitchCase_ActiveSubsystem;   /* '<S10>/Switch Case' */
  int8_T SwitchCase_ActiveSubsystem_b; /* '<S12>/Switch Case' */
  uint8_T Memory1_PreviousInput_g;     /* '<S1>/Memory1' */
  uint8_T Dem_stClear;                 /* '<S95>/CLT_BITEPOINTADAPT_POSN' */
  uint8_T Dem_stClear_p;               /* '<S100>/CLT_BITEPOINTADAPT_POSN' */
  uint8_T Dem_stClear_p2;              /* '<S96>/CLT_BITEPOINTADAPT_POSN' */
  uint8_T tminback;                    /* '<S8>/Chart' */
  rtDW_SRC_Check_CBMU_MON SRC_Check_l; /* '<S119>/SRC_Check' */
  rtDW_SRC_Check_CBMU_MON SRC_Check_b; /* '<S114>/SRC_Check' */
  rtDW_SRC_Check_CBMU_MON SRC_Check_e; /* '<S109>/SRC_Check' */
  rtDW_SRC_Check_CBMU_MON SRC_Check;   /* '<S104>/SRC_Check' */
} D_Work_CBMU_MON;

/* Constant parameters (auto storage) */
typedef struct {
  /* Pooled Parameter (Expression: )
   * Referenced by:
   *   '<S6>/ChrgCur'
   *   '<S6>/ChrgCurTimeOfFullSOC'
   *   '<S6>/ChrgCurTimeOfUnfullSOC'
   */
  uint32_T pooled1[2];

  /* Pooled Parameter (Expression: uint16(reshape([160,130,100,70,40,30,15000,15000,15000,20000,20000,40000,4000,4000,5000,5000,6000,6000],6,3));)
   * Referenced by:
   *   '<S6>/ChrgCur'
   *   '<S6>/ChrgCurTimeOfFullSOC'
   *   '<S6>/ChrgCurTimeOfUnfullSOC'
   */
  uint16_T pooled5[18];

  /* Pooled Parameter (Expression: uint8([1,2,3,4,5,6]);)
   * Referenced by:
   *   '<S6>/ChrgCur'
   *   '<S6>/ChrgCurTimeOfFullSOC'
   *   '<S6>/ChrgCurTimeOfUnfullSOC'
   */
  uint8_T pooled11[6];

  /* Pooled Parameter (Expression: uint8([1,2,3]);)
   * Referenced by:
   *   '<S6>/ChrgCur'
   *   '<S6>/ChrgCurTimeOfFullSOC'
   *   '<S6>/ChrgCurTimeOfUnfullSOC'
   */
  uint8_T pooled12[3];
} ConstParam_CBMU_MON;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  uint32_T ect_AirbagNormal_d;         /* '<Root>/ect_AirbagNormal' */
} ExternalInputs_CBMU_MON;

/* Real-time Model Data Structure */
struct tag_RTM_CBMU_MON {
  const char_T * volatile errorStatus;
};

/* Block signals (auto storage) */
extern BlockIO_CBMU_MON CBMU_MON_B;

/* Block states (auto storage) */
extern D_Work_CBMU_MON CBMU_MON_DWork;

/* External inputs (root inport signals with auto storage) */
extern ExternalInputs_CBMU_MON CBMU_MON_U;

/* Constant parameters (auto storage) */
extern const ConstParam_CBMU_MON CBMU_MON_ConstP;

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  Code generation will declare the memory for
 * these signals and export their symbols.
 *
 */
extern uint16_T ChrgTgtCur;            /* '<S6>/ChrgCur' */
extern uint16_T ChrgTgtTimer2;         /* '<S6>/ChrgCurTimeOfFullSOC' */
extern uint16_T ChrgTgtTimer1;         /* '<S6>/ChrgCurTimeOfUnfullSOC' */
extern uint8_T BatVolt_St;             /* '<S95>/Switch' */
extern uint8_T ScVolt_St;              /* '<S100>/Switch' */
extern uint8_T FcVolt_St;              /* '<S96>/Switch' */
extern uint8_T mChargeStep;            /* '<S49>/Chart' */
extern boolean_T O_S_SCCC;             /* '<S91>/Swtich_Debouncing' */
extern boolean_T O_S_FCCC;             /* '<S65>/Swtich_Debouncing' */

/*
 * Exported States
 *
 * Note: Exported states are block states with an exported global
 * storage class designation.  Code generation will declare the memory for these
 * states and exports their symbols.
 *
 */
extern uint8_T SafebagNormalCount;     /* '<S7>/Data Store Memory2' */
extern uint8_T SafebagErrCount;        /* '<S7>/Data Store Memory3' */
extern uint8_T SC_MON_test;            /* '<S49>/Data Store Memory1' */
extern uint8_T FC_MON_test;            /* '<S8>/Data Store Memory1' */

/* Model entry point functions */
extern void CBMU_MON_initialize(void);
extern void CBMU_MON_step(void);
extern void CBMU_MON_terminate(void);

/* Real-time Model object */
extern RT_MODEL_CBMU_MON *const CBMU_MON_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'CBMU_MON'
 * '<S1>'   : 'CBMU_MON/Task_10ms'
 * '<S2>'   : 'CBMU_MON/Task_10ms/Compare To Zero'
 * '<S3>'   : 'CBMU_MON/Task_10ms/FC_Mon'
 * '<S4>'   : 'CBMU_MON/Task_10ms/PwrON'
 * '<S5>'   : 'CBMU_MON/Task_10ms/RelayCtrl'
 * '<S6>'   : 'CBMU_MON/Task_10ms/SC_Mon'
 * '<S7>'   : 'CBMU_MON/Task_10ms/SID'
 * '<S8>'   : 'CBMU_MON/Task_10ms/FC_Mon/FcMon'
 * '<S9>'   : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Chart'
 * '<S10>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem'
 * '<S11>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Compare To Constant'
 * '<S12>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem'
 * '<S13>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem1'
 * '<S14>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem/Switch Case Action Subsystem1'
 * '<S15>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem/Switch Case Action Subsystem2'
 * '<S16>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem/current'
 * '<S17>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem/Switch Case Action Subsystem2/Chgcurrentcalc'
 * '<S18>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem/Switch Case Action Subsystem2/PID Controller'
 * '<S19>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem/Switch Case Action Subsystem2/currentcalc'
 * '<S20>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem/Switch Case Action Subsystem2/smooth'
 * '<S21>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem/Switch Case Action Subsystem2/smooth/currentcalc'
 * '<S22>'  : 'CBMU_MON/Task_10ms/FC_Mon/FcMon/Subsystem/Switch Case Action Subsystem1/current'
 * '<S23>'  : 'CBMU_MON/Task_10ms/PwrON/PwrON_Check'
 * '<S24>'  : 'CBMU_MON/Task_10ms/PwrON/PwrON_Check/Chart'
 * '<S25>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode0'
 * '<S26>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode1'
 * '<S27>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode2'
 * '<S28>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode0/Subsystem'
 * '<S29>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode0/Subsystem1'
 * '<S30>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl'
 * '<S31>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl1'
 * '<S32>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl/RlyCtl'
 * '<S33>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode0/Subsystem/RlyCtl1/RlyCtl'
 * '<S34>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode0/Subsystem1/RlyCtl1'
 * '<S35>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode1/Subsystem'
 * '<S36>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode1/Subsystem1'
 * '<S37>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl'
 * '<S38>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl1'
 * '<S39>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl/RlyCtl'
 * '<S40>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode1/Subsystem/RlyCtl1/RlyCtl'
 * '<S41>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode1/Subsystem1/RlyCtl1'
 * '<S42>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode2/Subsystem'
 * '<S43>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode2/Subsystem1'
 * '<S44>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl'
 * '<S45>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl1'
 * '<S46>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl/RlyCtl'
 * '<S47>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode2/Subsystem/RlyCtl1/RlyCtl'
 * '<S48>'  : 'CBMU_MON/Task_10ms/RelayCtrl/Mode2/Subsystem1/RlyCtl1'
 * '<S49>'  : 'CBMU_MON/Task_10ms/SC_Mon/ScMon'
 * '<S50>'  : 'CBMU_MON/Task_10ms/SC_Mon/ScMon/Chart'
 * '<S51>'  : 'CBMU_MON/Task_10ms/SID/Compare To Constant'
 * '<S52>'  : 'CBMU_MON/Task_10ms/SID/FCCC'
 * '<S53>'  : 'CBMU_MON/Task_10ms/SID/HVIL'
 * '<S54>'  : 'CBMU_MON/Task_10ms/SID/High'
 * '<S55>'  : 'CBMU_MON/Task_10ms/SID/If Action Subsystem'
 * '<S56>'  : 'CBMU_MON/Task_10ms/SID/If Action Subsystem1'
 * '<S57>'  : 'CBMU_MON/Task_10ms/SID/Low'
 * '<S58>'  : 'CBMU_MON/Task_10ms/SID/Normal'
 * '<S59>'  : 'CBMU_MON/Task_10ms/SID/O_SW_HVIL_Swt'
 * '<S60>'  : 'CBMU_MON/Task_10ms/SID/RlySitck'
 * '<S61>'  : 'CBMU_MON/Task_10ms/SID/SCCC'
 * '<S62>'  : 'CBMU_MON/Task_10ms/SID/SafeBagMon'
 * '<S63>'  : 'CBMU_MON/Task_10ms/SID/VoltMon'
 * '<S64>'  : 'CBMU_MON/Task_10ms/SID/FCCC/Chart'
 * '<S65>'  : 'CBMU_MON/Task_10ms/SID/FCCC/O_SW_HVIL_Swt'
 * '<S66>'  : 'CBMU_MON/Task_10ms/SID/FCCC/O_SW_HVIL_Swt/Swtich_Debouncing'
 * '<S67>'  : 'CBMU_MON/Task_10ms/SID/FCCC/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing'
 * '<S68>'  : 'CBMU_MON/Task_10ms/SID/HVIL/Chart'
 * '<S69>'  : 'CBMU_MON/Task_10ms/SID/HVIL/O_SW_HVIL_Swt'
 * '<S70>'  : 'CBMU_MON/Task_10ms/SID/HVIL/O_SW_HVIL_Swt/Swtich_Debouncing'
 * '<S71>'  : 'CBMU_MON/Task_10ms/SID/HVIL/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing'
 * '<S72>'  : 'CBMU_MON/Task_10ms/SID/O_SW_HVIL_Swt/Swtich_Debouncing'
 * '<S73>'  : 'CBMU_MON/Task_10ms/SID/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing'
 * '<S74>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/NegRlyCheck'
 * '<S75>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_HVIL_Swt'
 * '<S76>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_HVIL_Swt1'
 * '<S77>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_NegRlyCtl_Swt'
 * '<S78>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_PosRlyCtl_Swt'
 * '<S79>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/PosRlyCheck'
 * '<S80>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/NegRlyCheck/Chart'
 * '<S81>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_HVIL_Swt/Swtich_Debouncing'
 * '<S82>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing'
 * '<S83>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_HVIL_Swt1/Swtich_Debouncing'
 * '<S84>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_HVIL_Swt1/Swtich_Debouncing/Switch_Debouncing'
 * '<S85>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_NegRlyCtl_Swt/Swtich_Debouncing'
 * '<S86>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_NegRlyCtl_Swt/Swtich_Debouncing/Switch_Debouncing'
 * '<S87>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_PosRlyCtl_Swt/Swtich_Debouncing'
 * '<S88>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/O_SW_PosRlyCtl_Swt/Swtich_Debouncing/Switch_Debouncing'
 * '<S89>'  : 'CBMU_MON/Task_10ms/SID/RlySitck/PosRlyCheck/Chart'
 * '<S90>'  : 'CBMU_MON/Task_10ms/SID/SCCC/Chart'
 * '<S91>'  : 'CBMU_MON/Task_10ms/SID/SCCC/O_SW_HVIL_Swt'
 * '<S92>'  : 'CBMU_MON/Task_10ms/SID/SCCC/O_SW_HVIL_Swt/Swtich_Debouncing'
 * '<S93>'  : 'CBMU_MON/Task_10ms/SID/SCCC/O_SW_HVIL_Swt/Swtich_Debouncing/Switch_Debouncing'
 * '<S94>'  : 'CBMU_MON/Task_10ms/SID/SafeBagMon/Chart'
 * '<S95>'  : 'CBMU_MON/Task_10ms/SID/VoltMon/BatVolt_SRC_Check'
 * '<S96>'  : 'CBMU_MON/Task_10ms/SID/VoltMon/FcVolt_SRC_Check'
 * '<S97>'  : 'CBMU_MON/Task_10ms/SID/VoltMon/RelayDynamic1'
 * '<S98>'  : 'CBMU_MON/Task_10ms/SID/VoltMon/RelayDynamic3'
 * '<S99>'  : 'CBMU_MON/Task_10ms/SID/VoltMon/RelayDynamic4'
 * '<S100>' : 'CBMU_MON/Task_10ms/SID/VoltMon/ScVolt_SRC_Check'
 * '<S101>' : 'CBMU_MON/Task_10ms/SID/VoltMon/T15Volt_SRC_Check'
 * '<S102>' : 'CBMU_MON/Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRCCheck'
 * '<S103>' : 'CBMU_MON/Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRC_Collect'
 * '<S104>' : 'CBMU_MON/Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRCCheck/Signal_SRC'
 * '<S105>' : 'CBMU_MON/Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check'
 * '<S106>' : 'CBMU_MON/Task_10ms/SID/VoltMon/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check'
 * '<S107>' : 'CBMU_MON/Task_10ms/SID/VoltMon/FcVolt_SRC_Check/SRCCheck'
 * '<S108>' : 'CBMU_MON/Task_10ms/SID/VoltMon/FcVolt_SRC_Check/SRC_Collect'
 * '<S109>' : 'CBMU_MON/Task_10ms/SID/VoltMon/FcVolt_SRC_Check/SRCCheck/Signal_SRC'
 * '<S110>' : 'CBMU_MON/Task_10ms/SID/VoltMon/FcVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check'
 * '<S111>' : 'CBMU_MON/Task_10ms/SID/VoltMon/FcVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check'
 * '<S112>' : 'CBMU_MON/Task_10ms/SID/VoltMon/ScVolt_SRC_Check/SRCCheck'
 * '<S113>' : 'CBMU_MON/Task_10ms/SID/VoltMon/ScVolt_SRC_Check/SRC_Collect'
 * '<S114>' : 'CBMU_MON/Task_10ms/SID/VoltMon/ScVolt_SRC_Check/SRCCheck/Signal_SRC'
 * '<S115>' : 'CBMU_MON/Task_10ms/SID/VoltMon/ScVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check'
 * '<S116>' : 'CBMU_MON/Task_10ms/SID/VoltMon/ScVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check'
 * '<S117>' : 'CBMU_MON/Task_10ms/SID/VoltMon/T15Volt_SRC_Check/SRCCheck'
 * '<S118>' : 'CBMU_MON/Task_10ms/SID/VoltMon/T15Volt_SRC_Check/SRC_Collect'
 * '<S119>' : 'CBMU_MON/Task_10ms/SID/VoltMon/T15Volt_SRC_Check/SRCCheck/Signal_SRC'
 * '<S120>' : 'CBMU_MON/Task_10ms/SID/VoltMon/T15Volt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check'
 * '<S121>' : 'CBMU_MON/Task_10ms/SID/VoltMon/T15Volt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check'
 */
#endif                                 /* RTW_HEADER_CBMU_MON_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
