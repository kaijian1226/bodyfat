/*******************************************************************************
*
*  FILE
*     SPI.c
*
*  DESCRIPTION
*     The Driver for 9S12HY64 SPI Driver   
*      
*       
*  COPYRIGHT
*     (c)Copyright 2012, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*     Gu Bin
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

/*******************************************************************************
* include files
*******************************************************************************/

#include "Compiler.h"
#include "Platform_types.h"
#include "SPI.h"

/*******************************************************************************
* Defines
*******************************************************************************/

/*******************************************************************************
* Macros
*******************************************************************************/
#define SPI_LOOP_TIMER_START(timer)   {spi_LoopTimer = timer;}
#define SPI_LOOP_TIMER_LOOP()         ((--spi_LoopTimer) != 0)
#define SPI_LOOP_TIMER_END()          (spi_LoopTimer == 0)

#define SPI0_TX_NOT_EMPTY()          ((SPI_REG_SPI0SR & SPI_SPTEF_MASK) == 0)
#define SPI0_RX_IDLE()               ((SPI_REG_SPI0SR & SPI_SPIF_MASK) == 0)
#define SPI1_TX_NOT_EMPTY()          ((SPI_REG_SPI1SR & SPI_SPTEF_MASK) == 0)
#define SPI1_RX_IDLE()               ((SPI_REG_SPI1SR & SPI_SPIF_MASK) == 0)
#define SPI2_TX_NOT_EMPTY()          ((SPI_REG_SPI2SR & SPI_SPTEF_MASK) == 0)
#define SPI2_RX_IDLE()               ((SPI_REG_SPI2SR & SPI_SPIF_MASK) == 0)
/*******************************************************************************
* Global Variables definition
*******************************************************************************/

/*******************************************************************************
* Local Variables definition
*******************************************************************************/
_STATIC_ uint16 spi_LoopTimer;
/*******************************************************************************
* Local Functions prototypes
*******************************************************************************/

/*******************************************************************************
* Functions
*******************************************************************************/

/*******************************************************************************
* NAME:             SPI_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize SPI interface   
*******************************************************************************/
void Spi_Init(uint8 spiCh)
{ 
  /* PIE=0,   Disable SPI interrupt
     SPE=0,   Disable SPI 
     SPTIE=0, Disable SPI transmit interrupt     
     MSTR=0,  SPI in slave mode
     CPOL=0,  Active-high clocks selected, in idle state SCK is low,
     CPHA=1,  Sample of data occurs at odds edge of the SCK clock (1,3,5)
     SSOE=0,  SS not used or with MODF feature
     LSBFE=0  Data is transfered MSB first 
   */
  
  if (spiCh == 0)
  {
    SPI_REG_SPI0CR1 = 0x04;            /* Reset the device register */  

    SPI_REG_SPI0BR  =  SPI_BR_SET0;
    SPI_REG_SPI0CR1 = SPI_CR1_SET0; 
    SPI_REG_SPI0CR2 = SPI_CR2_SET0; 
    
    /* configure the re-routing of SPI0 port*/
    SPI_REG_MODRR &= SPI_SPI0_NMASK_PM;   
        
  }else if (spiCh == 1)
  {
    SPI_REG_SPI1CR1 = 0x04;            /* Reset the device register */  


    SPI_REG_SPI1BR  = SPI_BR_SET0;
    SPI_REG_SPI1CR1 = SPI_CR1_SET0;
    SPI_REG_SPI1CR2 = SPI_CR2_SET0;
    
    /* configure the re-routing of SPI1 port*/
    SPI_REG_MODRR |= SPI_SPI1_MASK_PH0;      
  }else if (spiCh == 2)
  {
    SPI_REG_SPI2CR1 = 0x04;            /* Reset the device register */  

    SPI_REG_SPI2BR  = SPI_BR_SET0;
    SPI_REG_SPI2CR1 = SPI_CR1_SET0;
    SPI_REG_SPI2CR2 = SPI_CR2_SET0;    

    /* configure the re-routing of SPI2 port*/
    SPI_REG_MODRR |= SPI_SPI2_MASK_PH4;   
  }
  
}

/*******************************************************************************
* NAME:             Spi_SendByte
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: chr: this data will be send by SPI bus.
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize SPI interface   
*******************************************************************************/
Std_ReturnType Spi_SendByte(uint8 spiCh,uint8 data)
{  
  if (spiCh == 0)
  {
    SPI_REG_SPI0DRL = data;                       
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    
    while (SPI0_TX_NOT_EMPTY() && SPI_LOOP_TIMER_LOOP()){}

    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    }     
  }else if (spiCh == 1)
  {
    SPI_REG_SPI1DRL = data;                       
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    
    while (SPI1_TX_NOT_EMPTY() && SPI_LOOP_TIMER_LOOP()){}

    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    }    
  }else if (spiCh == 2)
  {
    SPI_REG_SPI2DRL = data;                       
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    
    while (SPI2_TX_NOT_EMPTY() && SPI_LOOP_TIMER_LOOP()){}

    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    }  
  }
  
  return E_OK;
}

Std_ReturnType Spi_SendWord(uint8 spiCh,uint16 data)
{  
  if (spiCh == 0)
  {
    SPI_REG_SPI0DR = data;                       
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    
    while (SPI0_TX_NOT_EMPTY() && SPI_LOOP_TIMER_LOOP()){}

    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    }     
  }else if (spiCh == 1)
  {
    SPI_REG_SPI1DR = data;                       
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    
    while (SPI1_TX_NOT_EMPTY() && SPI_LOOP_TIMER_LOOP()){}

    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    }    
  }else if (spiCh == 2)
  {
    SPI_REG_SPI2DR = data;                       
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    
    while (SPI2_TX_NOT_EMPTY() && SPI_LOOP_TIMER_LOOP()){}

    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    }  
  }
  return E_OK;
}

Std_ReturnType Spi_ReadByte(uint8 spiCh,uint8* dataPtr)
{  
  if (spiCh == 0)
  {
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI0_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI0DRL;      
  }else if (spiCh == 1)
  {
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI1_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI1DRL;      
  }else if (spiCh == 2)
  {
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI2_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI2DRL;   
  }
  return E_OK;
}

Std_ReturnType Spi_ReadWord(uint8 spiCh,uint16* dataPtr)
{   
  if (spiCh == 0)
  {
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI0_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI0DR;      
  }else if (spiCh == 1)
  {
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI1_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI1DR;      
  }else if (spiCh == 2)
  {
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI2_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI2DR;   
  } 
  return E_OK; 
}

Std_ReturnType Spi_RWByte(uint8 spiCh,uint8 data,uint8* dataPtr)
{  
  if (spiCh == 0)
  {
    SPI_REG_SPI0DRL = data;   
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI0_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI0DRL;       
  }else if (spiCh == 1)
  {
    SPI_REG_SPI1DRL = data;   
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI1_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI1DRL;     
  }else if (spiCh == 2)
  {
    SPI_REG_SPI2DRL = data;   
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI2_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI2DRL;    
  }   
  return E_OK;  
}

Std_ReturnType Spi_RWWord(uint8 spiCh,uint16 data, uint16* dataPtr)
{  
  if (spiCh == 0)
  {
    SPI_REG_SPI0DR = data;   
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI0_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI0DR;       
  }else if (spiCh == 1)
  {
    SPI_REG_SPI1DR = data;   
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI1_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI1DR;     
  }else if (spiCh == 2)
  {
    SPI_REG_SPI2DR = data;   
    
    SPI_LOOP_TIMER_START(SPI_MAX_TIMES);
    while(SPI2_RX_IDLE() && SPI_LOOP_TIMER_LOOP()){}
    if (SPI_LOOP_TIMER_END())
    {
      return E_NOT_OK;
    } 
    *dataPtr = SPI_REG_SPI2DR;    
  }   
  return E_OK;  
}






































