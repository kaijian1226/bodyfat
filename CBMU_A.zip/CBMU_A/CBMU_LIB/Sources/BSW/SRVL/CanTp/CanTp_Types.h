/*******************************************************************************
*
*  FILE
*     CanTp_Types.h
*
*  DESCRIPTION
*     The data Type Header file for CanTp
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

#ifndef _CANTP_TYPES_H_
#define _CANTP_TYPES_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
typedef struct 
{
  uint8   Channel;              /* TP Channel*/
  volatile uint8* pDestination; /* Pointer to destination buffer */
  uint8* pSource;               /* Pointer to source buffer */
  uint16  Length;               /* The maximum length to copy */
}CanTp_CopyToCanInfoType;

typedef uint16 CanTp_TimerType;

typedef struct 
{
  uint8* DataBuffPtr;
  uint16 DataIndex;
  uint16 DataLength;
  uint8 FFDataBuff[6];
  uint8 SeqNrm; 
  uint8 ApplGetBufferStatus;      
}CanTp_RxInfoType;

typedef struct 
{
  uint8* DataBuffPtr;
  uint16 DataIndex;
  uint16 DataLength;
  uint8 TrgAddr;
  uint8 BlockSize;
  uint8 STMin;
  uint8  SeqNrm;
} CanTp_TxInfoType;

typedef enum 
{
  RX_STATE_IDLE = 0,
  RX_STATE_APP_INFORMED,
  RX_STATE_CAN_FRAME_RECEIVED,
  RX_STATE_WAIT_CF,
  RX_STATE_WAIT_FC,
  RX_STATE_WAIT_FC_CONFIRM,
  RX_STATE_WAIT_FC_WAIT,
  RX_STATE_WAIT_FC_OVRFLOW_CONFIRM,
  RX_STATE_ERROR
}CanTp_RxStateType;

typedef enum 
{
  TX_STATE_IDLE = 0,
  TX_STATE_WAIT_FC,
  TX_STATE_WAIT_FOR_TX_CF,
  TX_STATE_WAIT_FOR_MIN_TIMER,
  TX_STATE_WAIT_FOR_SF_CONFIRM,     
  TX_STATE_WAIT_FOR_FF_CONFIRM,        
  TX_STATE_WAIT_FOR_CF_CONFIRM,        
  TX_STATE_WAIT_FOR_LAST_CF_CONFIRM,    
  TX_STATE_ERROR
} CanTp_TxStateType;

typedef struct
{
  CanTp_TimerType Timer;
  uint8 BSCounter;
  CanTp_TxStateType State;
  bittype Queued:1;    
  bittype ReTx:1;    
  bittype firstFC:1;
} CanTp_TxStatusType;

typedef struct 
{
  CanTp_TimerType Timer;
  uint8 BSCounter;
  uint8 WFTCounter;
  CanTp_RxStateType State;
  bittype Queued:1;
  bittype ReTx:1;
} CanTp_RxStatusType;


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

#endif /* #ifndef _CANTP_TYPES_H_ */

 




