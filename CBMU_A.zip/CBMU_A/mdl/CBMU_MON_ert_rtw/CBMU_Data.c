/*
 * File: CBMU_Data.c
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtwtypes.h"
#include "CBMU_MON_types.h"

/* Exported data definition */

/* Const memory section */
/* Definition for custom storage class: Const */
const uint8_T BMSCapacity = 100U;
const t_Voltage1 BatVoltSigASRCHigh = 26214U;
const uint16_T BatVoltSigASRCHighNegDeb = 50U;
const uint16_T BatVoltSigASRCHighPosDeb = 50U;
const t_Voltage1 BatVoltSigASRCLow = 16384U;
const uint16_T BatVoltSigASRCLowNegDeb = 50U;
const uint16_T BatVoltSigASRCLowPosDeb = 50U;
const t_Voltage1 FCCC_High = 2867U;
const t_Voltage1 FCCC_Low = 1638U;
const t_Voltage1 FcSwtHigh = 6554U;
const t_Voltage1 FcSwtLow = 4096U;
const t_Voltage1 FcVoltSigASRCHigh = 26214U;
const t_Voltage1 FcVoltSigASRCLow = 7373U;
const t_Voltage1 SCCC_High = 2703U;
const t_Voltage1 SCCC_Low = 1761U;
const boolean_T SafeBag_TestPoint = 1;
const t_Voltage1 ScSwtHigh = 6554U;
const t_Voltage1 ScSwtLow = 4096U;
const t_Voltage1 ScVoltSigASRCHigh = 26214U;
const t_Voltage1 ScVoltSigASRCLow = 13107U;
const t_Voltage1 T15SwtHigh = 6554U;
const t_Voltage1 T15SwtLow = 4096U;
const t_Voltage1 T15VoltSigASRCHigh = 26214U;
const t_Voltage1 T15VoltSigASRCLow = 13107U;

/* Definition for custom storage class: Global */
uint8_T HVIL_test0;
boolean_T HW_Err;
boolean_T I_S_Fc;
boolean_T I_S_Sc;
boolean_T I_S_T15;
boolean_T O_S_AirBag;
boolean_T O_S_HVIL;
uint8_T PwrMode;
boolean_T SID_m_st_ChMRelay;
boolean_T SID_m_st_DisChMRelay;
boolean_T SafeBag_test0;

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
