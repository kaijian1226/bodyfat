/*******************************************************************************
*
*  FILE
*     Xcp_Appl.c
*
*  DESCRIPTION
*     Application Interface of Xcp Module  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Xcp.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
VAR(Xcp_EcuPageOffsetType,XCP_VAR) ecu_page_offset;

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/* variables for storing the actual page offset for ECU and XCP */
_STATIC_ VAR(Xcp_XcpPageOffsetType,XCP_VAR) xcp_page_offset;


_STATIC_ VAR(uint16,XCP_VAR) rand_seed;
/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Xcp_ApplInit
* CALLED BY:        Xcp_Init
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      initializes additional external resources  
*******************************************************************************/
FUNC(void,XCP_CODE) Xcp_ApplInit(void)
{

  /* Initialize the Calibration RAM */
#if (XCP_PAGE_SWITCHING == STD_ON)

    uint16 index;
  #if (XCP_CAL_ROM_NEAR == STD_ON)  
    uint8* src_addr;
  #else
    uint8* XCP_VAR_FAR src_addr;
  #endif

  #if (XCP_CAL_RAM_NEAR == STD_ON)   
    uint8*  dst_addr;
  #else
    uint8* XCP_VAR_FAR dst_addr;
  #endif  
    
  #if (XCP_CAL_ROM_NEAR == STD_ON)
    src_addr = (uint8 *)(XCP_CALROM_START);
  #else
    src_addr = (uint8 * XCP_VAR_FAR)(XCP_CALROM_START);
  #endif 

  #if (XCP_CAL_RAM_NEAR == STD_ON)   
    dst_addr = (uint8 *)(XCP_CALRAM_START);
  #else
    dst_addr = (uint8 * XCP_VAR_FAR)(XCP_CALRAM_START);
  #endif 
     
    for (index=0; index < XCP_CALRAM_SIZE; index ++)
    {
       *dst_addr = *src_addr;
       dst_addr++;
       src_addr++;
    }

#endif /* #if (XCP_PAGE_SWITCHING == STD_ON) */ 
 
  xcp_page_offset = (Xcp_EcuPageOffsetType)XCP_CALROM_OFFSET_FOR_XCP;
  ecu_page_offset = (Xcp_EcuPageOffsetType)XCP_CALROM_OFFSET_FOR_ECU;
}

/*******************************************************************************
* NAME:             Xcp_ApplGetAddressPtr
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint32 address
*                   uint8 extension: address extension
* RETURN VALUES:    Xcp_MtaPtrType: pointer to memory location
* DESCRIPTION:      This function calculates a pointer to a memory location from 
*                   a given logical XCP address and extension.
*******************************************************************************/
FUNC(Xcp_MtaPtrType,XCP_CODE) Xcp_ApplGetAddressPtr(uint32 address, uint8 extension)
{
  if ((address >= XCP_CALROM_START) && (address < (XCP_CALROM_START + XCP_CALRAM_SIZE)))
  {
    return ((Xcp_MtaPtrType)(XCP_GET_CAL_GLOBAL_ADDR(address)));
  }
  else if((address >= 0x2000) && (address < 0x4000))
  {    
    return ((Xcp_MtaPtrType)(XCP_GET_NEAR_RAM_GLOBAL_ADDR(address)));
  }
  else if ((address >= 0x4000) && (address < 0x10000))
  {
    return ((Xcp_MtaPtrType)(XCP_GET_NEAR_ROM_GLOBAL_ADDR(address)));
  }
  else
  {
    return ((Xcp_MtaPtrType)(address));
  }
}

/*******************************************************************************
* NAME:             Xcp_ApplMemAccessChk
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint32 address
*                   uint8 extension: address extension
*                   uint32 length:  data length
*                   uint8 type:
*               access type (XCP_MEMORY_ACCESS_TYPE_READ,
*                            XCP_MEMORY_ACCESS_TYPE_WRITE,
*                            XCP_MEMORY_ACCESS_TYPE_DAQ_STIM,
*                            XCP_MEMORY_ACCESS_TYPE_PGM,
*                            XCP_MEMORY_ACCESS_TYPE_CAL_PAGE_STIM)
*
* RETURN VALUES:    E_OK
*                   E_NOT_OK
* DESCRIPTION:      This function checks, if an access to the given memory range
*                   is allowed for the given access type.
*******************************************************************************/
FUNC(Std_ReturnType,XCP_CODE) Xcp_ApplMemAccessChk(uint32 address, uint8 extension, uint32 length, uint8 type)
{
  switch (type)
  {
    case XCP_MEMORY_ACCESS_TYPE_READ:
      if (((address >= 0x2000) && ((address + length) <= 0x5000))||
      ((address >= 0x13F000) && ((address + length) <= 0x13FFFF))||
      ((address >= 0xF0000) && ((address + length) <= 0xFDFFF))||
      ((address >= 0x7F0000) && ((address + length) <= 0x7FFFFF))
      )
      {
        return (E_OK);
      }
      break;
    case XCP_MEMORY_ACCESS_TYPE_WRITE:
      if (((address >= 0x2000) && ((address + length) <= 0x5000))||
      ((address >= 0x13F200) && ((address + length) <= 0x13FFFF))||
      ((address >= 0xF0000) && ((address + length) <= 0xFDFFF))||
      ((address >= 0x7F0000) && ((address + length) <= 0x7FFFFF))
      )
      {
        return (E_OK);
      }
      break;
    case XCP_MEMORY_ACCESS_TYPE_DAQ_STIM:
      if (((address >= 0x2000) && ((address + length) <= 0x5000))||
      ((address >= 0x13F000) && ((address + length) <= 0x13FFFF))||
      ((address >= 0xF0000) && ((address + length) <= 0xFDFFF)))
      {
        return (E_OK);
      }
      break;
    case XCP_MEMORY_ACCESS_TYPE_PGM:
      if ((address >= 0x20000) && ((address + length) <= 0x30000))
      {
        return (E_OK);
      }
      break;
    case XCP_MEMORY_ACCESS_TYPE_CAL_PAGE_STIM:
      if (
      (address >= 0x50000) && ((address + length) <= 0x60000)||
       ((address >= 0x7F0000) && ((address + length) <= 0x7FFFFF))
      )
      {
        return (E_OK);
      }
      break;
    default:
      return (E_NOT_OK);
  }
  return (E_NOT_OK);
}

/*******************************************************************************
* NAME:             Xcp_ApplGetSeed
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint8* seed�� pointer to seed buffer
*                   uint8 resource: XCP ressource, which is requested to be unlocked
* RETURN VALUES:    uint8 : length of seed
* DESCRIPTION:      This function calculates a random seed to unlock a resource.
*******************************************************************************/
FUNC(uint8,XCP_CODE) Xcp_ApplGetSeed(uint8* seed, uint8 resource)
{
  uint8_least idx;
  
  rand_seed++;

  for (idx = 0; idx < XCP_SEED_LENGTH; idx++)
  {
    srand(rand_seed);
    seed[idx] = (uint8)rand();
  }
  return (XCP_SEED_LENGTH);
}

/*******************************************************************************
* NAME:             Xcp_ApplUnlock
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint8* seed:  pointer to seed buffer
*                   uint8* key:   pointer to key buffer
*                   uint8 resource: XCP ressource, which is requested to be unlocked
* RETURN VALUES:    E_OK
*                   E_NOT_OK
* DESCRIPTION:      This function checks the given seed and key to unlock a resource.
*******************************************************************************/
FUNC(Std_ReturnType,XCP_CODE) Xcp_ApplUnlock(uint8* seed, uint8* key, uint8 resource)
{
  uint8_least idx;

  switch (resource)
  {
    case XCP_SEED_KEY_RESOURCE_CAL_PAG:
    {     
      for (idx = 0; idx < 6; idx++)
      {
        if (key[idx] != seed[idx] + 1)
        {
          return (E_NOT_OK);
        }
      } 
    }
    break;
      
    case XCP_SEED_KEY_RESOURCE_DAQ:
    {
      for (idx = 0; idx < 7; idx++)
      {
        if (key[idx] != seed[idx] + 2)
        {
          return (E_NOT_OK);
        }
      }
    }
    break;
      
    case XCP_SEED_KEY_RESOURCE_STIM:
    {
      for (idx = 0; idx < 8; idx++)
      {
        if (key[idx] != seed[idx] + 3)
        {
          return (E_NOT_OK);
        }
      }
    }
    break;
    
    case XCP_SEED_KEY_RESOURCE_PGM:
    {
      for (idx = 0; idx < 20; idx++)
      {
        if (key[idx] != seed[idx] + 4)
        {
          return (E_NOT_OK);
        }
      }
    }
    break;
      
    default:
    return (E_NOT_OK);
  }
  return (E_OK);
}

/*******************************************************************************
* NAME:             Xcp_ApplSetCalPage
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint8 segment:  segment number
*                   uint8 page:     page number
*                   uint8 mode
* RETURN VALUES:    E_OK
*                   E_NOT_OK
* DESCRIPTION:      This function sets the active calibration page of a segment
*******************************************************************************/
FUNC(Std_ReturnType,XCP_CODE) Xcp_ApplSetCalPage(uint8 segment, uint8 page, uint8 mode)
{
  if ((mode & XCP_CAL_PAGE_MODE_ALL) != XCP_CAL_PAGE_MODE_ALL)
  {
    return (E_NOT_OK);
  }
  else
  {
    if (mode & XCP_CAL_PAGE_MODE_ECU)
    {
      if (page == 0)
      {
        /* set active calibration for ECU access to reference page */
        ecu_page_offset = (Xcp_EcuPageOffsetType)(XCP_CALROM_OFFSET_FOR_ECU); 
      }
      else
      {
        /* set active calibration for ECU access to working page */
        ecu_page_offset = (Xcp_EcuPageOffsetType)(XCP_CALRAM_OFFSET_FOR_ECU);
      }
    }

    if (mode & XCP_CAL_PAGE_MODE_XCP)
    {
      if (page == 0)
      {
        /* set active calibration for XCP access to reference page */
        xcp_page_offset = (Xcp_XcpPageOffsetType)(XCP_CALROM_OFFSET_FOR_XCP);
      }
      else
      {
        /* set active calibration for XCP access to working page */
        xcp_page_offset = (Xcp_XcpPageOffsetType)(XCP_CALRAM_OFFSET_FOR_XCP);
      }
    }

    return (E_OK);
  }
}

/*******************************************************************************
* NAME:             Xcp_ApplSetCalPage
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint8 segment:  segment number                 
*                   uint8 mode
* RETURN VALUES:    uint8 :     page number
* DESCRIPTION:      This function returns the active calibration page of a segment.
*******************************************************************************/
FUNC(uint8,XCP_CODE) Xcp_ApplGetCalPage(uint8 segment, uint8 mode)
{
  uint8 page;

  /* add code for returning the active calibration page */
  if (mode & XCP_CAL_PAGE_MODE_ECU)
  {
     /* return active calibration page for ECU access */
     
     /* reference page */
    if (ecu_page_offset == (Xcp_EcuPageOffsetType)XCP_CALROM_OFFSET_FOR_ECU) 
    {
      page = 0;
    }
    /* working page */
    else if (ecu_page_offset == ((Xcp_EcuPageOffsetType)XCP_CALRAM_OFFSET_FOR_ECU)) 
    {
      page = 1;
    }  
  }
  else
  {
    /* return active calibration page for XCP access */
    /* reference page */
    if (xcp_page_offset == (Xcp_XcpPageOffsetType)XCP_CALROM_OFFSET_FOR_ECU) 
    {
      page = 0;
    }
     /* working page */
    else if (xcp_page_offset == ((Xcp_XcpPageOffsetType)XCP_CALRAM_OFFSET_FOR_ECU))
    {
      page = 1;
    }
  }
  return (page);
}

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/















