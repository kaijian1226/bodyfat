/*******************************************************************************
*
*  FILE
*     Com.c
*
*  DESCRIPTION
*     Source File for Com Module  ͨ��ģ���շ����Ƽ����ݽ���
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Com.h"
#include "CanIf.h"
#include "VFB.h"
#include "Dem.h"
#include "Ioa.h"
#include "Pbs.h"
#include "ecum.h"
#include "CanTp.h"
#include "J1939Tp_Cfg.h"
#include "J1939Tp.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define NOT_AVAILABLE   (0xFF)
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*****************************************************
RX
*****************************************************/

#define MINIBUS



uint8 TTT;
uint8 Cell_Module_Num = 25;	//���ģ����
uint8 Temp_Number = 4;		//ÿ�����¶ȴ�������Ŀ
uint16 Total_CellNumber = 0;	//�ܵ�о��Ŀ
uint8 Module_CellNumber[25];	//ÿ���ص�о��Ŀ

uint8  com_CellTemp[25][5];//��о�¶� ģ����\�¶ȴ��������

//STS1
uint8  com_BalanceSts[25];//����״̬
uint8  com_CellTempAvrg[25]; //ģ��ƽ���¶�
uint8  com_CellTempMax[25]; //ģ������¶�
uint8  com_CellTempMin[25]; //ģ����С�¶�
uint8  com_CellTempMaxNum[25]; //ģ������¶�
uint8  com_CellTempMinNum[25]; //ģ����С�¶�
uint8  com_CurSet[25];//
uint8  com_ModuleStatus[25];  //
uint8  com_CellAlarm[25]; //

//STS2
uint16  com_CellVoltAvrg[25]; //ģ��ƽ����о��ѹ
uint16  com_CellVoltMax[25];  //ģ�����о��ѹ
uint16  com_CellVoltMin[25];  //ģ����С��о��ѹ
uint8   com_CellVoltMaxNum[25];//��о����ѹ
uint8   com_CellVoltMinNum[25];//��о��С��ѹ


//CV
uint16  com_CellVoltCur[25][12];   //��ǰģ�鵥о��ѹ 20151210
uint16  com_CellVoltBef[25][12];   //��ǰģ�鵥о��ѹ 
uint16  com_CellVoltCgeCnt[25];  //��о��ѹ�仯����ֵ

uint16  com_CellVoltMin[25];  //
uint8  com_CellVoltMaxNum[25];//
uint8  com_CellVoltMinNum[25];//

//HVCU HVM1
uint16 com_BattVoltOrg;    //�ܵ�ѹ(�ܵ�ѹԭʼֵ����Ӧ�ò㣬�������쳣��Ӧ�ò������Ӧ����)
uint16 com_BattCurr;    //�ܵ���
uint16 com_Resistance;  //��Ե����
uint8  com_SOC;         //SOCֵ
uint16 com_ResistancePos;  //������Ե����
uint16 com_ResistanceNeg;  //������Ե����

//HVCU HVA1
uint32 com_hva1Alarm;    //
uint8 com_hva1ModuleSts; //
uint16 com_hva1FaultCode; //

// From Tester,
uint16 com_testCmd; //
uint8 com_testAuto; //

//From Chrgr, Vehicle Bus.����
uint8  com_CCP1HwFault;   //
uint8  com_CCP1ACConnect; //
uint8  com_CCP1TempSts;   //
uint8  com_CCP1CommSts;   //
uint8  com_CCP1ACRange;   //
uint8  com_CCP1ChrgrTemp; //
uint8  com_CCP1ChrgrPreReadySts;//
uint16 com_CCP1ChrgCurrOut;  //
uint16 com_CCP1ChrgVolt; //

//From Motor, Vehicle Bus.���������
uint8 com_MSP3MotorTrq;  //
uint16 com_MSP3MotorSpd; //

uint16 com_MSP1MotorDcVolt;//
uint16 com_MSP1MotorDcCurr;//

//From Dashboard, Vehicle Bus�Ǳ�
uint32 com_VDTotalOdometer;//
uint32 com_VDTripOdometer;//

// From Fast Charger, Fast Charger Bus
uint16 com_CSOutVolt;  //
uint16 com_CSOutCurrent;  //
uint16 com_CSStatus1; //
uint16 com_CSStatus2; //

uint16 com_CCMaxChrgVolt; //
uint16 com_CCMaxChrgCurr; //
uint8  com_CCChrgSts;

//add by xql for fast charge Rx Msg,20150709
//CRM
uint8  com_CRM_RecResult;  //
uint8  com_CRM_ChgerNum;   //
uint8  com_CRM_AreaCode[6]; //
//CTS  Optional
uint8  com_CTS_Seconds;   //
uint8  com_CTS_Minute;    //
uint8  com_CTS_Hour;      //
uint8  com_CTS_Day;       //
uint8  com_CTS_Month;     //
uint16 com_CTS_Year;      //
//CML
uint16 com_CML_MaxOutVolt;    //
uint16 com_CML_MinOutVolt;    //
uint16 com_CML_MaxOutCurrent; //
//CRO
uint8  com_CRO_ChgerReady;   //
//CCS
uint16 com_CCS_OutVolt;      //
uint16 com_CCS_OutCurrent;   //
uint16 com_CCS_AccChgedTime; //
//CST
uint8  com_CST_FaultStop;          //
uint8  com_CST_ManualStop;         //
uint8  com_CST_ConditionalStop;    //

uint8  com_CST_EnergyTransFault;   //
uint8  com_CST_InnerOverTempFault; //
uint8  com_CST_ConnecterFault;     //
uint8  com_CST_OverTempFault;      //
uint8  com_CST_OtherFault;         //
uint8  com_CST_EmergencyFault;     //

uint8  com_CST_VoltError;          //
uint8  com_CST_CurrentError;       //
//CSD
uint16 com_CSD_TotalChgedTime;     //
uint16 com_CSD_TotalOutEnergy;     //
uint8  com_CSD_ChgerNum;           //
//CEM
uint8  com_CEM_RcvBMSRecedMsg;     //
uint8  com_CEM_RcvBMSReadyMsg;     //
uint8  com_CEM_RcvChgParMsg;       //
uint8  com_CEM_RcvBMSStopMsg;      //
uint8  com_CEM_RcvBMSReqMsg;       //
uint8  com_CEM_RcvChgStateMsg;     //
uint8  com_CEM_RcvBMSTotalMsg;     //



//add by xql for fast charge Tx Msg,20150708
//BRM
uint8  com_BRM_SubProVersion;   //
uint16 com_BRM_ProVersion;      //
uint8  com_BRM_BatType;         //
uint16 com_BRM_RatedCap;        //
uint16 com_BRM_RatedVolt;       //
//BCP
uint16 com_BCP_MaxCellChgVolt;  //
uint16 com_BCP_MaxChgCurrent;   //
uint16 com_BCP_NominalEnergy;   //
uint16 com_BCP_MaxPackChgVolt;  //
uint8  com_BCP_MaxAllowedTemp;  //
uint16 com_BCP_PackSOC;         //
uint16 com_BCP_PackVolt;        //   

uint16 DC_ReachVolt;  //ĸ����Ҫ��ѹ 20151205

//BRO
uint8  com_BRO_BMSReady;        //
//BCL
uint16 com_BCL_ReqVolt;         //        
uint16 com_BCL_ReqCurrent;      // 
uint16 com_LUC_ReqCurrent;      // //use lookup_table ��ѯ������ 20151020
uint8  com_BCL_ChgMode;         //
//BCS
uint16 com_BCS_MeasuredChgVolt;      //
uint16 com_BCS_MeasuredChgCurrent;   //
uint16 com_BCS_MaxCellVolt;          //
uint8  com_BCS_MaxCVGroupNum;        //
uint8  com_BCS_CurSOC;               //
uint16 com_BCS_ChgTimeRemain;        //
//BSM
uint8  com_BSM_MaxCVCellNum;    // 
uint8  com_BSM_MinCVCellNum;    //
uint8  com_BSM_MaxCellTemp;     //
uint8  com_BSM_MaxCTCellNum;    //
uint8  com_BSM_MinCellTemp;     //
uint8  com_BSM_MinCTCellNum;    //
uint8  com_BSM_ChgTempSt;       //
uint8  com_BSM_ChgCurrentSt;    //
uint8  com_BSM_ChgSOCSt;        //
uint8  com_BSM_ChgCVSt;         //
uint8  com_BSM_ChgAllowed;      //
uint8  com_BSM_ConnecterSt;     //
uint8  com_BSM_ISOSt;           //
//BST
uint8  com_BST_SetCVReach;        //
uint8  com_BST_SetPVReach;        //
uint8  com_BST_SetSOCReach;       //
uint8  com_BST_ConnecterFault;    //
uint8  com_BST_CompOverTempFault; //
uint8  com_BST_ConnOverTempFault; //
uint8  com_BST_ISOFault;          //
uint8  com_BST_OtherFault;        //
uint8  com_BST_BatOverTempFault;  //
uint8  com_BST_VoltError;         //
uint8  com_BST_CurrentError;      //
//BSD
uint8  com_BSD_EndSOC;           //
uint16 com_BSD_MinCellVolt;      //
uint16 com_BSD_MaxCellVolt;      //
uint8  com_BSD_MinCellTemp;      //
uint8  com_BSD_MaxCellTemp;      //
//BEM
uint8  com_BEM_RcvChgerRecMsg_AA;   //
uint8  com_BEM_RcvChgerRecMsg_00;   //
uint8  com_BEM_RcvChgerCMLMsg;      //
uint8  com_BEM_RcvChgerReadyMsg;    //
uint8  com_BEM_RcvChgerStopMsg;     //
uint8  com_BEM_RcvChgerStateMsg;    //
uint8  com_BEM_RcvChgerTotalMsg;    //

/*****************************************************
TX
*****************************************************/

// From SWC, Tx, Cmd, Inner Bus  ->BMU
uint8 com_BalEnable[25]; //����ʹ��
uint8 com_CurrentSet;      //�������
uint8 com_ShutDown;        //�ر�����
uint8 com_chrgCmd;         //����
uint8 com_chrgCellNum;     //����
uint8 com_chrgDuration;    //����

// From SWC, Vehicle Bus
uint16 com_BPVP1BattVolt;     //�ܵ�ѹ
uint16 com_BPVP1MaxCellVolt;   //������ѹ
uint16 com_BPVP1MinCellVolt;   //��С�����ѹ
uint16 com_BPVP1AvrgCellVolt;  //ƽ����ѹ
uint16 com_BPVP1MaxCellNum;    //����о��
uint16 com_BPVP1MinCellNum;    //��С��о��

uint8 com_BPTP1MaxCellNum;    //���ģ���о��
uint8 com_BPTP1MinCellNum;    //��Сģ���о��
uint8 com_BPTP1MinCellTemp;   //��С��о�¶�
uint8 com_BPTP1MaxCellTemp;   //���о�¶�
uint8 com_BPTP1AvrgCellTemp;  //ƽ���¶�

uint16 com_BPC1MinDchrgVolt;   //������С����ѹ
uint8 com_BPC1CurrChrgVol;     //�Ѿ���ĵ���
uint16 com_BPC1MaxDchrgCurrent;  //������

boolean com_BPC2ChrgrACInput;  //������Ƿ���AC��Դ����
boolean com_BPC2ChrgEnable;    //����ʹ��
uint8   com_BPC2ChrgSts;       //����״̬
uint16 com_BPC2MaxChrgVolt;    //����������ѹ
uint16 com_BPC2MaxChrgCurrent; //������

//���������� ???
uint8   com_BPSSelfChkSts;     //�Լ�״̬
uint8   com_BPSDisChMRelaySts;   //�ŵ����̵���״̬
uint8   com_BPSChMRelaySts;  	//������̵���״̬
uint8   com_BPSFCContactSts;  // add 20150819 ���ڸ�Ϊ���̵���
uint8   com_BPSHighVoltSts;      //��ѹ���״̬on OFF
boolean com_BPSBattVoltLowAlarm; //�ܵ�ѹ�͵�ѹ����ֻ��һλ
boolean com_BPSBattTempHighAlarm;//�¶ȹ��߱���
boolean com_BPSBattLeakAlarm;    //��Ե�������
boolean com_BPSCellVoltLowAlarm; //��о��ѹ�ͱ���
boolean com_BPSVolumLowAlarm;    //SOC���ͱ���
boolean com_BPSBattMaintenanceAlarm; //ά������ ����û��
boolean com_BPSOverCurrAlarm;        //��������
uint8 com_BPSSOC;                    //SOCֵ
uint16 com_BPSCurrent;               //����
uint16 com_BPSInsulationResistance;  //��Ե����ֵ        
uint8 PackCurMode;		//����ģʽ:0-�ŵ�;1-����;2-���;3-�������;4-PTC����;  


/* from SWC to fast charger */
uint16 com_CPMaxChrgVolt;    //
uint16 com_CPCmdChrgCurr;    //
uint8  com_CPCtl;            //
uint8  com_CPModuleNum;      //

uint16 com_SP1BattVolt;      //
uint16 com_SP1BattCurr;      //
uint16 com_SP1Soc;           //
uint16 com_SP1CellAlarmUpVolt; //

uint16 com_SP2CellShutUpVolt;   //
uint16 com_SP2CellAlarmLwrVolt; //
uint16 com_SP2CellShutLwrVolt;  //
uint16 com_SP2CellDiffAlarm;    //

uint16 com_SP3TempAlarmUpVal;   //
uint16 com_SP3MaxChrgCurr;      //
uint16 com_SP3MaxDchrgCurr;     //
uint16 com_SP3Volum;            //

uint8  BMS_ChargerDCInput;      //
uint8  BMS_FaultState;          //
uint8  BMS_SupplierNum;         //
uint16 BMS_SWVersion;           //
uint32 BMS_SWDesignDate;        //

/*****************************************************
Others
*****************************************************/

boolean com_RxHvcuMsgCntErr;      //���ո�ѹ�屨�ļ���������
boolean com_RxHvcuMsgCntResetErr; //��λ���� ����

boolean com_RxBmuMsgCntErr[25];      //����  ����ֵ���ϴ�ֵ+1����
boolean com_RxBmuMsgCntResetErr[25]; //����

boolean com_VehBusRxCurrSts;      //����CAN��ǰ״̬
boolean com_InnerBusRxCurrSts;    //�ڲ�CAN��ǰ״̬
boolean com_SlowChrgrRxCurrSts;   //����CAN��ǰ״̬
boolean com_FastChrgrRxCurrSts;   //���CAN��ǰ״̬

boolean com_VehBusTxCurrSts;      //
boolean com_InnerBusTxCurrSts;    //
boolean com_SlowChrgrTxCurrSts;   //
boolean com_FastChrgrTxCurrSts;   //
  

/*****************************************************
Com Control
*****************************************************/
boolean com_VehBusRxEna;     //����CAN����ʹ��
boolean com_InnerBusRxEna;   //�ڲ�
boolean com_SlowChrgrRxEna;  //����
boolean com_FastChrgrRxEna;  //���

boolean com_VehBusTxEna;     //
boolean com_InnerBusTxEna;   //
boolean com_SlowChrgrTxEna;  //
boolean com_FastChrgrTxEna;  //
//add by xql for fast charge Tx Msg,20150708
boolean com_BRMTxEna;    //
boolean com_BCPTxEna;    //
boolean com_BROTxEna;    //
boolean com_BCLTxEna;    //
boolean com_BCSTxEna;    //
boolean com_BSMTxEna;    //
boolean com_BSTTxEna;    //
boolean com_BSDTxEna;    //
boolean com_BEMTxEna;    //

boolean com_BRMRxEna;    //
boolean com_CTSRxEna;    //
boolean com_CMLRxEna;    //
boolean com_CRORxEna;    //
boolean com_CCSRxEna;    //
boolean com_CSTRxEna;    //
boolean com_CSDRxEna;    //
boolean com_CEMRxEna;    //

boolean com_CRMTimeoutFlag;//0-normal  1-timeout
boolean com_CTSTimeoutFlag;   //
boolean com_CMLTimeoutFlag;   //
boolean com_CROTimeoutFlag;   //
boolean com_CCSTimeoutFlag;   //
boolean com_CSTTimeoutFlag;   //
boolean com_CSDTimeoutFlag;   //
boolean com_CEMTimeoutFlag;   //    
uint8 DCVolt_Reach;//2151205
boolean com_RelayTimeoutFlag;   //�̵����źų�ʱadd 20150805 


uint8 COM_FM1St; 
uint8 COM_FM2St;  
uint8 COM_FM3St;  

                               
//minibus����ʹ���ź�add 20150805 
boolean com_VMS_3RXEna;    // 


uint8 AirconCtrlOrder;		//�յ���������
uint8 AirPTCConCtrlOrder;	//�յ�AC��������

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/
/* Inner Bus */
_STATIC_ uint8 com_Hva1TimeOutCnt; //����
_STATIC_ uint8 com_Hvm1TimeOutCnt; //����
//2014��8��6��
_STATIC_ uint8 com_RelayTimeOutCnt;//����

_STATIC_ uint8 com_CmtTimeOutCnt[25];   //����
_STATIC_ uint8 com_Sts1TimeOutCnt[25];  //����
_STATIC_ uint8 com_Sts2TimeOutCnt[25];  //����

_STATIC_ uint8 com_CmdTxMsgCnt;      //

_STATIC_ boolean com_RxHvcuFirst;    //
_STATIC_ uint8 com_HvcuMsgCntLast;   //
_STATIC_ uint8 com_HvcuMsgCnt;       //

_STATIC_ boolean com_RxBmuFirst[25];    //
_STATIC_ uint8 com_BmuMsgCntLast[25];   //
_STATIC_ uint8 com_BmuMsgCnt[25];       //

/* Vehicle Bus */
_STATIC_ uint8 com_ccp1TimeOutCnt;  //
_STATIC_ uint8 com_msp1TimeOutCnt;  //
_STATIC_ uint8 com_msp3TimeOutCnt;  //
_STATIC_ uint8 com_vdTimeOutCnt;    //

_STATIC_ uint8 com_csTimeOutCnt;    //
_STATIC_ uint8 com_ccTimeOutCnt;    //


_STATIC_ uint8 com_bpsTxMsgCnt;     //


/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ Com_PduTxStructType COM_VAR com_TxPduTbl[COM_NUMBER_OF_TX_PDU];
_STATIC_ Com_PduRxStructType COM_VAR com_RxPduTbl[COM_NUMBER_OF_RX_PDU];

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ void COM_CODE Com_TxPreCopy(PduIdType PduId);
_STATIC_ void COM_CODE Com_RxTOIndication(PduIdType PduId);
_STATIC_ void COM_CODE Com_ChkHvcuMsgCnt(void);
_STATIC_ void COM_CODE Com_ChkBmuMsgCnt(uint8 index);
_STATIC_ void COM_CODE Com_SetBmuCmtSigErr(uint8 index);
_STATIC_ void COM_CODE Com_SetBmuSts1SigErr(uint8 index);
_STATIC_ void COM_CODE Com_SetBmuSts2SigErr(uint8 index);                    
_STATIC_ void COM_CODE Com_SetBmuCmtSig(uint8 index,const PduInfoType* PduInfoPtr);
_STATIC_ void COM_CODE Com_SetBmuSts1Sig(uint8 index,const PduInfoType* PduInfoPtr);
_STATIC_ void COM_CODE Com_SetBmuSts2Sig(uint8 index,const PduInfoType* PduInfoPtr); 
_STATIC_ void COM_CODE Com_SetBmuCV1(uint8 index,const PduInfoType* PduInfoPtr);
_STATIC_ void COM_CODE Com_SetBmuCV2(uint8 index,const PduInfoType* PduInfoPtr);
_STATIC_ void COM_CODE Com_SetBmuCV3(uint8 index,const PduInfoType* PduInfoPtr);
_STATIC_ void COM_CODE Com_SetBmuCV4(uint8 index,const PduInfoType* PduInfoPtr);
_STATIC_ void COM_CODE Com_Setccp1SigNA(void);
_STATIC_ void COM_CODE Com_SetVehicleBusSigNA(void);
_STATIC_ void COM_CODE Com_SetFastChrgrSigNA(void);
                                            
/*******************************************************************************
* ���ӵ��������� add 20150805                        
*******************************************************************************/
//////////////////////////////////////��������	��ʼ����������Ϊ0xFF	Com.c////////////////////////////
//St_BMS_1
 uint8 BM_CRC_BMS_ST_01;//CRCֵ
 uint8 BM_Live_BMS_ST_01;//����֡
 uint8 BM_Fault_Level;//��ذ����󼶱� ??????
 uint8 BM_Battery_Charge_Power_Available;//��ذ�������繦��  1KW �ֱ���
 uint8 BM_Battery_Discharge_Power_Available;//��ذ������ķŵ繦�� 1 KW �ֱ���    
 uint16 BM_Battery_Energry_Avarable;//��ذ�ʣ������ KWH  0.1�ֱ���
 uint8 BM_Battery_SOC;//SOCֵ  1%
 uint8 BM_Battery_User_SOC;//��ʾSOC  ��Battery_SOCһ��
//MS_2
 uint16 BM_Battery_Current;//��ذ����� A 0.1�ֱ���
 uint16 BM_Battery_Voltage;
 uint8 BM_Battery_Avg_T;//���ƽ���¶�
 uint8 BM_Battery_Max_T;//�������¶�
 uint8 BM_Battery_Min_T;//�������¶�
 uint8 BM_Battery_SOH ;//BMSδʵ�ָù��� ��Ϊ100%
//MS_3
 uint8 BM_ST_ERR_Charge_Over_Current;//���������󱨾� 0--���� 1--һ�� 2--���� 3--����
 uint8 BM_ST_ERR_DisChgrge_Over_Current;//�ŵ�������󱨾� 0--���� 1--һ�� 2--���� 3--����
 uint8 BM_ST_ERR_Cell_Over_Voltage;////��оǷѹ���� 0--���� 1--һ�� 2--����
 uint8 BM_ST_ERR_Cell_Under_Voltage;//��о��ѹ���� 0--���� 1--һ�� 2--���� 
 uint8 BM_ST_ERR_Battery_Over_Voltage;//�ܵ�ѹ���߱��� 0--���� 1--һ�� 2--����
 uint8 BM_ST_ERR_Battery_Under_Voltage;//�ܵ�ѹ���ͱ��� 0--���� 1--һ�� 2--����
 uint8 BM_ST_ERR_Cell_Voltage_Uniformity;//�������������
 uint8 BM_ST_ERR_Over_Temperature;//�¶ȹ��߱��� 0--���� 1--һ�� 2--����
 uint8 BM_ST_ERR_Low_Temperature;//�¶ȹ��ͱ��� 0--���� 1--һ�� 2--����
 uint8 BM_ST_ERR_Over_SOC;//SOC����  0--���� 1--һ�� 2--����
 uint8 BM_ST_ERR_Low_SOC;//SOC����  0--���� 1--һ�� 2--����
 uint8 BM_ST_ERR_Insulation_Resistance;//��Ե���� 
 uint8 BM_ST_ERR_INNCAN_Communication_Fault;//�ڲ�CAN
 uint8 BM_ST_ERR_Cell_Voltage_Sensor_Fault;//��������쳣 0--���� 1--�쳣
 uint8 BM_ST_ERR_Temperature_Sensor_Fault;//�¶Ȳ����쳣 0--���� 1--�쳣
 
 uint8 BM_ST_ERR_Current_Sensor_Fault;//���������쳣 0--���� 1--�쳣// 1--��· 2--��· 3--����
 
 uint8 BM_ST_ERR_CellTemp_Unbalance_Fault;//�¶Ȳ����� 0--���� 1--�쳣
 uint8 BM_ST_ERR_SysPower_Supply_Fault;//ϵͳ������� 0--���� 1--�쳣
 uint8 BM_ST_ERR_BatteryVoltage_High_Fault;//���ص�ѹ���� 0--���� 1--�쳣
 uint8 BM_ST_ERR_BatteryVoltage_Low_Fault;//���ص�ѹ���� 0--���� 1--�쳣
 uint8 BM_ST_ERR_SOCCalc_Fault;//SOC�ɼ��쳣 0--���� 1--�쳣
 uint8 BM_ST_ERR_ISOCalc_Fault;//��Ե����ɼ��쳣 0--���� 1--�쳣
 uint8 BM_ST_ERR_PVoltage_Sensor_Fault;//�ܵ�ѹ�ɼ��쳣 0--���� 1--һ�� 2--����
 uint8 BM_ST_ERR_VEHCAN_Communication_Fault;//����CAN 0--���� 1--�쳣
 uint8 BM_ST_ERR_PTC_Fault;//PTC�쳣 0--���� 1--��· 2--��· 3--����
 uint8 BM_ST_ERR_OrigCur_Fault;//��ʼ�����쳣 0--���� 1--�쳣
 uint8 BM_ST_ERR_OffCur_Fault;//�µ�����쳣 0--���� 1--�쳣
 uint8 BM_ST_ERR_NegRelaySticky_Fault;//�����̵���ճ�� 0--���� 1--�쳣
//MS_4
 uint8 BM_CRC_ST_BMS_4;
 uint8 BM_LIV_ST_BMS_4;//����֡��	ÿ�μ�1  ��15��Ϊ0
 uint8 BM_ST_HV_Online;//��ذ��ϵ�״̬�� 0 "Power Off" 1 "Power On"
 uint8 BM_ST_HV_Positive_Relay1;//�����̵���1״̬�� 0 "open" 1 "close"
 uint8 BM_ST_HV_Positive_Relay2;//û��  �����̵���2״̬�� 0 "open" 1 "close"
 uint8 BM_ST_HV_Positive_Relay3;//û��  �����̵���3״̬�� 0 "open" 1 "close"
 uint8 BM_ST_HV_Positive_Relay_FaultStatus;//�����̵�������״̬�� 0 "No faut" 1 "Fault"
 uint8 BM_ST_HV_Negative_Relay;//�����̵���״̬��0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"
 uint8 BM_ST_Precharge_Relay;//Ŀǰ���ã�Ԥ��̵���״̬�� 0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"	
 uint8 BM_ST_FCharge_Positive_Relay;//����!!!������̵���״̬�� 0 "Open" 1 "Closed"
 uint8 BM_ST_SCharge_Positive_Relay;//����  �������̵���״̬�� 0 "Open" 1 "Closed"
 uint8 BM_ST_Charge_Negative_Relay;//����  �为�̵���״̬(�������乫�ø����̵���)��  0 "Open" 1 "Closed"
 uint8 BM_ST_Healting_Relay;//����  ���ȼ̵���״̬��  0 "Open" 1 "Closed"
 uint8 BM_ST_Charging;  //����!!!���״̬�źš� 0"No charging"   1 "Charging"  2 "Chargefinished"  
 uint8 BM_ST_Cooling_Relay;////����  ɢ�ȼ̵���״̬��    0 "Open" 1 "Closed"
 
 uint8 BM_ST_Heating;	// 0 "Open"  1 "Closed"  
 uint8 BM_ST_Cooling;// 0 "Open" 1 "Closed"
 uint8 BM_ST_Charging_Gun;	// 0 "Open" 1 "Closed"
 uint8 BM_ST_Resistance;//��Ե����


//VMS_3
 uint8 BM_CMD_HV_Power;//�������������͵ĸ�ѹ���µ�ָ�0 "Open HV Switch" 1 "Open HV switchurgently" 2 "Close HV switch" 3 "Keepcurrent state"
//MCU_2
 uint16 BM_DC_HV_Voltage;//ĸ�ߵ�ѹ 20151205
//VMS_7
 uint16 BM_VMS_Mil;//������������������  20151205

 uint8 BMU_NoActive[25];//BMU��������� ����Ϊ0 ��ʧΪ1  20150905


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Com_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void 
* DESCRIPTION:      Initialize Com  
*******************************************************************************/
void COM_CODE Com_Init(void)
{
  uint8 index; 
  uint8 count; 
  uint8 jj;
  
  for(index=0; index<COM_NUMBER_OF_TX_PDU; index++)
  {
    com_TxPduTbl[index].State = COM_TX_FREE;
    (void)MemSet(com_TxConfig_C[index].DataPtr,NOT_AVAILABLE,com_TxConfig_C[index].DataLen);
  }
  
     
  //time slice for J1939Tp multi packets
  com_TxPduTbl[COM_TX_BCP_MSG_IDX].Timer = 50;
  com_TxPduTbl[COM_TX_BCS_MSG_IDX].Timer = 0;
  com_TxPduTbl[COM_TX_DM1_MSG_IDX].Timer = 100;  
  com_TxPduTbl[COM_TX_BRM_MSG_IDX].Timer = 50;


  com_BRMRxEna = TRUE;  
  com_CTSRxEna = TRUE; 
  com_CMLRxEna = TRUE; 
  com_CRORxEna = TRUE; 
  com_CCSRxEna = TRUE; 
  com_CSTRxEna = TRUE; 
  com_CSDRxEna = TRUE; 
  com_CEMRxEna = TRUE;
  
  /*com_CRMTimeoutFlag = TRUE;
  com_CTSTimeoutFlag = TRUE;
  com_CMLTimeoutFlag = TRUE;
  com_CROTimeoutFlag = TRUE;
  com_CCSTimeoutFlag = TRUE;
  com_CSTTimeoutFlag = TRUE;
  com_CSDTimeoutFlag = TRUE;
  com_CEMTimeoutFlag = TRUE; */
  
  
  com_RelayTimeoutFlag=  0;  //add 20150805  !!!!!!���Ե�ʱ����  ����ΪTRUE;
  
     
  /*************************************************/
  /* Signal Initialization */
  /*************************************************/
  
  /* Inner Bus  - RX HVCU*/
  com_hva1Alarm = COM_SIG_NA_LONG;
  com_hva1ModuleSts = COM_SIG_NA_BYTE;
  com_hva1FaultCode = COM_SIG_NA_WORD;

  com_BattVoltOrg = COM_SIG_NA_WORD;
  com_BattCurr = COM_SIG_NA_WORD;
  com_Resistance = COM_SIG_NA_WORD;
  com_SOC = COM_SIG_NA_BYTE; 
  com_ResistancePos = COM_SIG_NA_WORD;
  com_ResistanceNeg = COM_SIG_NA_WORD;
  
  /* Inner Bus  - RX BMU */

  
  for(index=0;index<Cell_Module_Num; index++)
  {
    //for (count=0;count<Cells_onemodule;count++)      
    //{
      //com_CellVolt[index][count] = COM_SIG_NA_WORD;  
    //} 
    for (count=0;count<Temp_Number;count++)      
    {
      com_CellTemp[index][count] = COM_SIG_NA_BYTE;  
    } 

    com_ModuleStatus[index] = COM_SIG_NA_BYTE;
    com_BalanceSts[index]= COM_SIG_NA_BYTE;
    com_CurSet[index] = COM_SIG_NA_BYTE;
    com_CellTempAvrg[index] = COM_SIG_NA_BYTE; 
    com_CellTempMax[index] = COM_SIG_NA_BYTE;
    com_CellTempMin[index] = COM_SIG_NA_BYTE;
    com_CellTempMaxNum[index] = COM_SIG_NA_BYTE; 
    com_CellTempMinNum[index]= COM_SIG_NA_BYTE;
    com_CellAlarm[index] = COM_SIG_NA_BYTE;
    
    com_CellVoltAvrg[index] = COM_SIG_NA_WORD;
    com_CellVoltMax[index] = COM_SIG_NA_WORD;
    com_CellVoltMin[index] = COM_SIG_NA_WORD;
    com_CellVoltMaxNum[index] = COM_SIG_NA_BYTE;
    com_CellVoltMinNum[index] = COM_SIG_NA_BYTE;        
  }

  /* Vehicle Bus  - RX from slow charger and other controllers in vehicle */

  Com_Setccp1SigNA();
  Com_SetVehicleBusSigNA();
  
  /* Fast Charger Bus  - RX from fast charger */
  Com_SetFastChrgrSigNA(); 
  Dem_SetError( DTC_IDX_VEH_COMERR, 0);   //Ŀǰ�ȼ���!!!!!!20150831 
  
  
  com_CurrentSet = 0xC8 ;   //4000mA Balance Current 
  for(jj=0;jj<Cell_Module_Num;jj++)
  {
    com_BalEnable[jj] = 0; //�رվ���!!!!!!20150924
  }
}


/*******************************************************************************
* NAME:             Com_RxTOReset
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void 
* DESCRIPTION:      Reset the Rx TimeOut Status   
*******************************************************************************/
void COM_CODE Com_RxTOReset(void)
{
  uint8 index;
  com_ccp1TimeOutCnt = 0;
  com_msp1TimeOutCnt = 0;
  com_msp3TimeOutCnt = 0;
  com_vdTimeOutCnt = 0;
  
  com_csTimeOutCnt = 0;    
  com_ccTimeOutCnt = 0; 
  
  com_Hva1TimeOutCnt = 0; //����
  com_Hvm1TimeOutCnt = 0; //����
  com_RelayTimeOutCnt = 0;  ///����2014��8��6��
  
  for (index = 0;index<Cell_Module_Num; index++)
  {
    com_CmtTimeOutCnt[index] = 0;
    com_Sts1TimeOutCnt[index] = 0;
    com_Sts2TimeOutCnt[index] = 0;
  }
  
}


/*******************************************************************************
* NAME:             Com_MainFunction
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void 
* DESCRIPTION:       
*******************************************************************************/
void Com_MainFunction(void) //CAN����   $$$��ѯ����ָ����Ҫ������  �����Ƿ�ʱ
{
  uint8 idx;
  uint8 transResult;
  PduInfoType PduInfo;  //�ṹ�嶨��

  for (idx = 0; idx< (COM_NUMBER_OF_TX_PDU); idx++)  //��Ҫ���͵ı�������
  {
    if (com_TxPduTbl[idx].Enable == TRUE )       //��������
    {
      /* normal message transmission */
      if (com_TxConfig_C[idx].TransType == COM_TT_CYCLIC)        //�����Է��ͱ���
      {
        if (com_TxPduTbl[idx].Timer > COM_CYCLE_TIME)     //û�дﵽ�����趨ʱ��
        {
          com_TxPduTbl[idx].Timer -= COM_CYCLE_TIME; //-10
        }else
        {
          com_TxPduTbl[idx].Timer = com_TxConfig_C[idx].TransRate;  // //���¸���ֵ
          com_TxPduTbl[idx].State = COM_TX_REQ; ////״̬��Ϊ������               
        }
      }      
                
      if(com_TxPduTbl[idx].State == COM_TX_REQ)  //״̬��Ϊ������
      {
        Com_TxPreCopy(idx);  //���
        
        PduInfo.SduDataPtr = com_TxConfig_C[idx].DataPtr; //Ҫ���͵ı������� ָ��
        PduInfo.SduLength = com_TxConfig_C[idx].DataLen;//����  
        if(com_TxConfig_C[idx].TpType==COM_TP_TYPE_NO)  //$$$���ķ�������
        {         
          //if (CanIf_Transmit(idx,&PduInfo) == E_OK)
          transResult = CanIf_Transmit(com_TxConfig_C[idx].CanIfIndex,&PduInfo);
            /*if((idx == COM_TX_MB_ST_BMS_1_IDX)&&(transResult == E_OK))
            {TTT=3;}
            if((idx == COM_TX_MB_ST_BMS_1_IDX)&&(transResult != E_OK))
            {TTT=2;}*/
        }
        else if(com_TxConfig_C[idx].TpType==COM_TP_TYPE_CANTP)
        {
          transResult = CanTp_Transmit(PduInfo.SduDataPtr,PduInfo.SduLength);
        }
        else if(com_TxConfig_C[idx].TpType==COM_TP_TYPE_J1939TP)
        {
          transResult = J1939Tp_Transmit(com_TxConfig_C[idx].CanIfIndex, &PduInfo);          
        }
        
        if(E_OK==transResult)
        {
          com_TxPduTbl[idx].State = COM_TX_XMT;  //������
        }
      }      
    }
  }

  for (idx = 0; idx< COM_NUMBER_OF_RX_PDU; idx++)     //�������ճ�ʱ
  {
    if (com_RxPduTbl[idx].Enable == TRUE)  //�����Ƿ���Ҫ����
    {
      if (com_RxConfig_C[idx].TransType == COM_TT_CYCLIC)   //�ǲ��������Ա���
      {
        if (com_RxPduTbl[idx].Timer > COM_CYCLE_TIME)    //�趨��ʱ��ÿ�μ�10ms
        {
          com_RxPduTbl[idx].Timer -= COM_CYCLE_TIME;   
        }else
        {
          Com_RxTOIndication(idx);  //��ʱ��������
          com_RxPduTbl[idx].Timer = com_RxConfig_C[idx].TimeOut;//�ٴθ���ֵ              
        }
      }
    }
  }    
}

/*******************************************************************************
* NAME:             Com_TxConfirmation
* CALLED BY:        CanIf
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void 
* DESCRIPTION:       
*******************************************************************************/
//modified by xyl 2015-7-21
void COM_CODE Com_TxConfirmation(PduIdType PduId)
{
  uint8 idx;
  for (idx = 0; idx< (COM_NUMBER_OF_TX_PDU); idx++)
  {
    if(com_TxConfig_C[idx].CanIfIndex == PduId)
    {      
      com_TxPduTbl[idx].State = COM_TX_FREE;
      break;    
    }
  }
}
/*void COM_CODE Com_TxConfirmation(PduIdType PduId)
{
  com_TxPduTbl[PduId].State = COM_TX_FREE;    
}*/
	
//==========================================================================
//��������:void Com_BusCtrlTask(VOID)
//��������:�����ĵķ��ͽ���ʹ�ܿ��Ƽ���ʼͨѶ��������
//�������:��
//�������:��
//��������:10ms
//==========================================================================
void COM_CODE Com_BusCtrlTask(void)
{
  uint8 enable;
  uint8 i = 0;
  // Rx 
  if (com_InnerBusRxCurrSts != com_InnerBusRxEna)
  {
    enable = com_InnerBusRxEna;
    com_InnerBusRxCurrSts = enable;

    com_RxPduTbl[COM_RX_HVA1_MSG].Enable = enable; 
    com_RxPduTbl[COM_RX_HVM1_MSG].Enable = enable;
    com_RxPduTbl[CON_RX_ISO_MSG].Enable = enable; 
    
	for (i =3; i <(Cell_Module_Num*3 + 3) ; i++)
	{
		com_RxPduTbl[i].Enable = enable; 
	} 
	
	for (i =78; i <(Cell_Module_Num*4 + 78); i++)
	{
		com_RxPduTbl[i].Enable = enable; 
	}
	
    com_RxPduTbl[COM_RX_TESTCMD2_MSG].Enable = enable; 
    com_RxPduTbl[COM_RX_DISRELAYDEBUG_MSG].Enable = enable; 
    com_RxPduTbl[COM_RX_RESERVE1_MSG].Enable = enable; 
    
    if (enable == TRUE)
    {
      /* used for counter reset */
      com_RxHvcuFirst = TRUE;
      
      com_RxPduTbl[COM_RX_HVA1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_HVA1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_HVA1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_HVM1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_HVM1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_HVM1_MSG].TimeOut);  
      
      com_RxPduTbl[COM_RX_MB_ST_VMS_3].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_MB_ST_VMS_3].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_MB_ST_VMS_3].TimeOut);        
      //���Ӹ�ѹ��̵������ݽ��ձ��� 2014��8��6��
      com_RxPduTbl[CON_RX_ISO_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[CON_RX_ISO_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[CON_RX_ISO_MSG].TimeOut); 
            
      com_RxPduTbl[COM_RX_M1CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M1CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M1CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M1STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M1STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M1STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M1STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M1STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M1STS2_MSG].TimeOut);  

      com_RxPduTbl[COM_RX_M2CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M2CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M2CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M2STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M2STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M2STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M2STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M2STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M2STS2_MSG].TimeOut); 

      com_RxPduTbl[COM_RX_M3CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M3CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M3CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M3STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M3STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M3STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M3STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M3STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M3STS2_MSG].TimeOut); 

      com_RxPduTbl[COM_RX_M4CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M4CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M4CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M4STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M4STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M4STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M4STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M4STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M4STS2_MSG].TimeOut); 
       
      com_RxPduTbl[COM_RX_M5CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M5CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M5CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M5STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M5STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M5STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M5STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M5STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M5STS2_MSG].TimeOut); 
       
      com_RxPduTbl[COM_RX_M6CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M6CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M6CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M6STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M6STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M6STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M6STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M6STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M6STS2_MSG].TimeOut);  
    
     //add 20150805   
      com_RxPduTbl[COM_RX_M7CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M7CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M7CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M7STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M7STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M7STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M7STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M7STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M7STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M8CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M8CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M8CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M8STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M8STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M8STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M8STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M8STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M8STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M9CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M9CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M9CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M9STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M9STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M9STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M9STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M9STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M9STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M10CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M10CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M10CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M10STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M10STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M10STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M10STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M10STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M10STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M11CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M11CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M11CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M11STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M11STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M11STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M11STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M11STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M11STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M12CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M12CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M12CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M12STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M12STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M12STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M12STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M12STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M12STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M13CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M13CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M13CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M13STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M13STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M13STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M13STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M13STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M13STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M14CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M14CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M14CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M14STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M14STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M14STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M14STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M14STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M14STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M15CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M15CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M15CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M15STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M15STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M15STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M15STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M15STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M15STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M16CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M16CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M16CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M16STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M16STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M16STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M16STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M16STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M16STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M17CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M17CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M17CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M17STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M17STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M17STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M17STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M17STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M17STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M18CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M18CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M18CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M18STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M18STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M18STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M18STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M18STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M18STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M19CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M19CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M19CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M19STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M19STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M19STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M19STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M19STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M19STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M20CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M20CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M20CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M20STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M20STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M20STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M20STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M20STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M20STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M21CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M21CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M21CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M21STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M21STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M21STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M21STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M21STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M21STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M22CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M22CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M22CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M22STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M22STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M22STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M22STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M22STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M22STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M23CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M23CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M23CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M23STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M23STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M23STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M23STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M23STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M23STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M24CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M24CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M24CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M24STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M24STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M24STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M24STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M24STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M24STS2_MSG].TimeOut);  
    
       
      com_RxPduTbl[COM_RX_M25CMT_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M25CMT_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M25CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M25STS1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M25STS1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M25STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M25STS2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M25STS2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M25STS2_MSG].TimeOut);  
   
      com_RxPduTbl[COM_RX_M1CV1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M1CV1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M25CMT_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M1CV2_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M1CV2_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M25STS1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_M1CV3_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M1CV3_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M25STS2_MSG].TimeOut);  
          
      com_RxPduTbl[COM_RX_M1CV4_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_M1CV4_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_M25STS2_MSG].TimeOut);  

	  com_RxPduTbl[COM_RX_RESERVE1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_RESERVE1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_RESERVE1_MSG].TimeOut);  
  
   /////////////////////////////////////  
    
    }         
  }
 
  if (com_VehBusRxCurrSts != com_VehBusRxEna)  //��������
  {
    enable = com_VehBusRxEna;
    com_VehBusRxCurrSts = enable;
    
    com_RxPduTbl[COM_RX_MSP1_MSG].Enable = enable; 
    com_RxPduTbl[COM_RX_MSP3_MSG].Enable = enable; 
    com_RxPduTbl[COM_RX_VD_MSG].Enable = enable;
    
    com_RxPduTbl[COM_RX_MB_ST_VMS_3].Enable = enable; //add 20150805  
    com_RxPduTbl[COM_RX_MB_ST_MCU_2].Enable = enable; //add 20151205  
    com_RxPduTbl[COM_RX_MB_ST_VMS_7].Enable = enable; //add 20151205  
    com_RxPduTbl[COM_RX_MB_ST_CMU_5].Enable = enable; //add 20151205  

    if (enable == TRUE)
    {
      com_RxPduTbl[COM_RX_MSP1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_MSP1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_MSP1_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_MSP3_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_MSP3_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_MSP3_MSG].TimeOut); 
      
      com_RxPduTbl[COM_RX_VD_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_VD_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_VD_MSG].TimeOut);     
    }
  }
  
  if (com_SlowChrgrRxCurrSts != com_SlowChrgrRxEna)
  {
    enable = com_SlowChrgrRxEna;
    com_SlowChrgrRxCurrSts = enable;

    com_RxPduTbl[COM_RX_CCP1_MSG].Enable = enable; 
    
    if (enable == TRUE)
    {
      com_RxPduTbl[COM_RX_CCP1_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_CCP1_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_CCP1_MSG].TimeOut);     
    
    }    
  }

  if (com_FastChrgrRxCurrSts != com_FastChrgrRxEna)
  {
    enable = com_FastChrgrRxEna;
    com_FastChrgrRxCurrSts = enable;
    
    com_RxPduTbl[COM_RX_CC_MSG].Enable = enable; 
    com_RxPduTbl[COM_RX_CS_MSG].Enable = enable; 
    //add 2015-7-23
    com_RxPduTbl[COM_RX_CRM_MSG].Enable = com_BRMRxEna; 
    com_RxPduTbl[COM_RX_CTS_MSG].Enable = com_CTSRxEna; 
    com_RxPduTbl[COM_RX_CML_MSG].Enable = com_CMLRxEna; 
    com_RxPduTbl[COM_RX_CRO_MSG].Enable = com_CRORxEna; 
    com_RxPduTbl[COM_RX_CCS_MSG].Enable = com_CCSRxEna; 
    com_RxPduTbl[COM_RX_CST_MSG].Enable = com_CSTRxEna; 
    com_RxPduTbl[COM_RX_CSD_MSG].Enable = com_CSDRxEna; 
    com_RxPduTbl[COM_RX_CEM_MSG].Enable = com_CEMRxEna; 
    if (enable == TRUE)
    {
      com_RxPduTbl[COM_RX_CC_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_CC_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_CC_MSG].TimeOut); 

      com_RxPduTbl[COM_RX_CS_MSG].State = COM_TX_FREE;   
      com_RxPduTbl[COM_RX_CS_MSG].Timer = (COM_RX_STRT_DELAY + com_RxConfig_C[COM_RX_CS_MSG].TimeOut);     
    }
  }
  // Tx 
  if (com_InnerBusTxCurrSts != com_InnerBusTxEna)
  {
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    enable = com_InnerBusTxEna;
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    enable = FALSE;
    #endif
    com_InnerBusTxCurrSts = enable;    
    
    com_TxPduTbl[COM_TX_CMD_MSG_IDX].Enable = enable; 
    com_TxPduTbl[COM_TX_TD_MSG_IDX].Enable = enable;
    com_TxPduTbl[COM_TX_TEST1_MSG_IDX].Enable = enable; 
    com_TxPduTbl[COM_TX_TEST2_MSG_IDX].Enable = enable;
    com_TxPduTbl[COM_TX_RESERVE1_MSG_IDX].Enable = 0;
       
    if (enable == TRUE)
    {
      com_TxPduTbl[COM_TX_CMD_MSG_IDX].Timer = 10;  
      com_TxPduTbl[COM_TX_TD_MSG_IDX].Timer = 20;   
      com_TxPduTbl[COM_TX_TEST1_MSG_IDX].Timer = 30;  
      com_TxPduTbl[COM_TX_TEST2_MSG_IDX].Timer = 40;  
      com_TxPduTbl[COM_TX_RESERVE1_MSG_IDX].Timer = 50;  
    }
    /*
    else
    {
      MemSet(com_TxMsg_CMD,NOT_AVAILABLE,PG_DATALEN);      
    } 
    */
  }
   
  if (com_VehBusTxCurrSts != com_VehBusTxEna)
  {
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    enable = com_VehBusTxEna;
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    enable = FALSE;
    #endif
    com_VehBusTxCurrSts = enable;  
    
    com_TxPduTbl[COM_TX_BPVP1_MSG_IDX].Enable = enable; 
    com_TxPduTbl[COM_TX_BPTP1_MSG_IDX].Enable = enable; 
    com_TxPduTbl[COM_TX_BPC1_MSG_IDX].Enable = 0; 
    com_TxPduTbl[COM_TX_BPS_MSG_IDX].Enable = 0;
    com_TxPduTbl[COM_TX_BCI_MSG_IDX].Enable = 0;
    
    //add 20150805 
    com_TxPduTbl[COM_TX_MB_ST_BMS_1_IDX].Enable = enable; 
    com_TxPduTbl[COM_TX_MB_ST_BMS_2_IDX].Enable = enable; 
    com_TxPduTbl[COM_TX_MB_ST_BMS_3_IDX].Enable = enable;
    com_TxPduTbl[COM_TX_MB_ST_BMS_4_IDX].Enable = enable;
    
    if (enable == TRUE)
    {
      com_TxPduTbl[COM_TX_BPVP1_MSG_IDX].Timer = 10;
      com_TxPduTbl[COM_TX_BPTP1_MSG_IDX].Timer = 20;  
      com_TxPduTbl[COM_TX_BPC1_MSG_IDX].Timer = 30;
      com_TxPduTbl[COM_TX_BPS_MSG_IDX].Timer = 60;
      com_TxPduTbl[COM_TX_BCI_MSG_IDX].Timer = 90;
    
    }
    /* 
    else
    {
      MemSet(com_TxMsg_BPVP1,NOT_AVAILABLE,PG_DATALEN);
      MemSet(com_TxMsg_BPTP1,NOT_AVAILABLE,PG_DATALEN); 
      MemSet(com_TxMsg_BPC1,NOT_AVAILABLE,PG_DATALEN); 
      MemSet(com_TxMsg_BPC2,NOT_AVAILABLE,PG_DATALEN); 
      MemSet(com_TxMsg_BPS,NOT_AVAILABLE,PG_DATALEN);      
    }
    */    
  }
  
  if (com_SlowChrgrTxCurrSts != com_SlowChrgrTxEna)
  {
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    enable = com_SlowChrgrTxEna;
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    enable = FALSE;
    #endif
    com_SlowChrgrTxCurrSts = enable;  
    
    com_TxPduTbl[COM_TX_BPC2_MSG_IDX].Enable = enable; 
    
    if (enable == TRUE)
    {
      com_TxPduTbl[COM_TX_BPC2_MSG_IDX].Timer = 50;  
    }
    /*
    else
    {
      MemSet(com_TxMsg_BPC2,NOT_AVAILABLE,PG_DATALEN);      
    }
    */  
  }

  if (com_FastChrgrTxCurrSts != com_FastChrgrTxEna)  //��䱨��
  {
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    enable = com_FastChrgrTxEna;
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    enable = FALSE;
    #endif
    com_FastChrgrTxCurrSts = enable;  
    
    //com_TxPduTbl[COM_TX_CP_MSG_IDX].Enable = enable; 
    //com_TxPduTbl[COM_TX_SP1_MSG_IDX].Enable = enable; 
    //com_TxPduTbl[COM_TX_SP2_MSG_IDX].Enable = enable; 
    //com_TxPduTbl[COM_TX_SP3_MSG_IDX].Enable = enable; 
    
    //com_TxPduTbl[COM_TX_CANTP_MSG_IDX].Enable = FALSE;//CAN Tp 
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND)//J1939 Tp 
    //com_TxPduTbl[COM_TX_DM1_MSG_IDX].Enable = TRUE;
    com_TxPduTbl[COM_TX_DM1_MSG_IDX].Enable = FALSE;   //2015-08-03, xyl, Turn it off, used only for test
    
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    com_TxPduTbl[COM_TX_DM1_MSG_IDX].Enable = FALSE;
    
    
    #endif



    if (enable == TRUE)
    {
      com_TxPduTbl[COM_TX_CP_MSG_IDX ].Timer = 10;
      com_TxPduTbl[COM_TX_SP1_MSG_IDX].Timer = 20;
      com_TxPduTbl[COM_TX_SP2_MSG_IDX].Timer = 30;
      com_TxPduTbl[COM_TX_SP3_MSG_IDX].Timer = 50;  
    }    
    
  } 
    //add by xql for fast charge Tx Msg,20150708
    com_TxPduTbl[COM_TX_BRM_MSG_IDX].Enable = com_BRMTxEna;
    com_TxPduTbl[COM_TX_BCP_MSG_IDX].Enable = com_BCPTxEna;
    com_TxPduTbl[COM_TX_BRO_MSG_IDX].Enable = com_BROTxEna;
    com_TxPduTbl[COM_TX_BCL_MSG_IDX].Enable = com_BCLTxEna;
    com_TxPduTbl[COM_TX_BCS_MSG_IDX].Enable = com_BCSTxEna;
    com_TxPduTbl[COM_TX_BSM_MSG_IDX].Enable = com_BSMTxEna;
    com_TxPduTbl[COM_TX_BST_MSG_IDX].Enable = com_BSTTxEna;
    com_TxPduTbl[COM_TX_BSD_MSG_IDX].Enable = com_BSDTxEna;
    com_TxPduTbl[COM_TX_BEM_MSG_IDX].Enable = com_BEMTxEna;
    
  if (com_FastChrgrTxEna || com_FastChrgrRxEna)
  {
    ioa_fastChrgSplyCtl = TRUE;  
  }else
  {
    ioa_fastChrgSplyCtl = FALSE;
  }
  
  if (com_VehBusRxCurrSts || com_SlowChrgrRxEna || com_VehBusTxEna || com_SlowChrgrTxEna)
  {
    ioa_vehSplyCtl = TRUE; 
  }else
  {
    ioa_vehSplyCtl = FALSE;
  }

}

/*******************************************************************************
* NAME:             Com_RxIndication
* CALLED BY:        CanIf
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void 
* DESCRIPTION:       
*******************************************************************************/
void COM_CODE Com_RxIndication(PduIdType PduId,/*const*/ PduInfoType* PduInfoPtr)
{
  OneWordUnionType wdata;
  OneLongUnionType ldata;  
  
  if (com_RxPduTbl[PduId].Enable == FALSE)
  {
    return;
  }
  
  com_RxPduTbl[PduId].Timer = com_RxConfig_C[PduId].TimeOut;  //$$$���յ���ָ�����¸�ֵ��ʱ������ֵ

  switch(PduId)
  {
  
#ifdef EJ02   //�˴��ı��Ĳ���Ҫ
    case COM_RX_CCP1_MSG:
    {
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];
      com_CCP1ChrgVolt = wdata.WORD;             

      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];
      com_CCP1ChrgCurrOut = wdata.WORD;   

      com_CCP1HwFault = PduInfoPtr->SduDataPtr[4]&0x01;
      com_CCP1ACConnect = (PduInfoPtr->SduDataPtr[4]&0x04)>>2;
      com_CCP1TempSts = (PduInfoPtr->SduDataPtr[4]&0x02)>>1;
      com_CCP1CommSts = (PduInfoPtr->SduDataPtr[4]&0x10)>>4;
      com_CCP1ChrgrPreReadySts = (PduInfoPtr->SduDataPtr[4]&0x08)>>3;
      com_CCP1ChrgrTemp = PduInfoPtr->SduDataPtr[5];
      com_CCP1ACRange = PduInfoPtr->SduDataPtr[6]&0x07; 
    }
    break; 

    case COM_RX_MSP1_MSG:
    {
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];
      com_MSP1MotorDcVolt = wdata.WORD;             

      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];
      com_MSP1MotorDcCurr = wdata.WORD;   
    }
    break;

    case COM_RX_MSP3_MSG:
    {
      com_MSP3MotorTrq = PduInfoPtr->SduDataPtr[0];             

      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[1];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[2];
      com_MSP3MotorSpd = wdata.WORD;   
    }
    break;
    
    case COM_RX_VD_MSG:
    {      
      ldata.Bytes.Byte0 =  PduInfoPtr->SduDataPtr[0];
      ldata.Bytes.Byte1  = PduInfoPtr->SduDataPtr[1];
      ldata.Bytes.Byte2 =  PduInfoPtr->SduDataPtr[2];
      ldata.Bytes.Byte3  = PduInfoPtr->SduDataPtr[3];
      com_VDTotalOdometer = ldata.Long;  
                 
      ldata.Bytes.Byte0 =  PduInfoPtr->SduDataPtr[4];
      ldata.Bytes.Byte1  = PduInfoPtr->SduDataPtr[5];
      ldata.Bytes.Byte2 =  PduInfoPtr->SduDataPtr[6];
      ldata.Bytes.Byte3  = PduInfoPtr->SduDataPtr[7];
      com_VDTripOdometer = ldata.Long; 
    }
    break;    

/* Rx  From Fast Charger */
    case COM_RX_CC_MSG:
    {           
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];
      com_CCMaxChrgVolt = wdata.WORD;   

      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];
      com_CCMaxChrgCurr = wdata.WORD;   

      com_CCChrgSts = PduInfoPtr->SduDataPtr[4];        
    }
    break;

    case COM_RX_CS_MSG:
    {
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];
      com_CSOutVolt = wdata.WORD;   

      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];
      com_CSOutCurrent = wdata.WORD;
      
      com_CSStatus1 = PduInfoPtr->SduDataPtr[4];  
      com_CSStatus2 = PduInfoPtr->SduDataPtr[5];        

    }
    break;

#endif



/* Rx  From Inner Bus */
    case COM_RX_HVA1_MSG:
    {
      com_hva1Alarm = *((uint16*)(&PduInfoPtr->SduDataPtr[0]));
      com_hva1ModuleSts = PduInfoPtr->SduDataPtr[2];
      
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[4];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[5];
      com_hva1FaultCode = wdata.WORD;      
      
      com_HvcuMsgCnt = PduInfoPtr->SduDataPtr[7]; 
      
      Com_ChkHvcuMsgCnt();
    }
    break; 

    case COM_RX_HVM1_MSG: //��ذ��ܵ������
    {             
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];
      com_BattVoltOrg = wdata.WORD;   

      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];
      com_BattCurr = wdata.WORD; //Ϊ�޷�����  ʵ�ʵ���=com_BattCurr/32-1016

      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[4];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[5];
      com_Resistance = wdata.WORD;   
      
      com_SOC = PduInfoPtr->SduDataPtr[6];               
      
      
      Dem_SetError( DTC_IDX_HVCU_COMERR, 0);   //20150831 ��ѹ��ͨѶOK 
    }
    break;
    
    case  CON_RX_ISO_MSG: //��������Ե��ֵ
    {
		wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
		wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];
		com_ResistancePos = wdata.WORD;   
		
		wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
		wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];
		com_ResistanceNeg = wdata.WORD;   
    }
    break;

/* Module 1 */
    case COM_RX_M1CMT_MSG:
    {
      Com_SetBmuCmtSig(0,PduInfoPtr);
    }
    break;

    case COM_RX_M1STS1_MSG:
    {
      Com_SetBmuSts1Sig(0,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU1_COMERR, 0);   //20150831 BMUͨѶOK 
      BMU_NoActive[0]=0;
    }
    break;    

    
    case COM_RX_M1STS2_MSG:
    {
      Com_SetBmuSts2Sig(0,PduInfoPtr);      
    }
    break;    

/* Module 2 */
    case COM_RX_M2CMT_MSG:
    {
      Com_SetBmuCmtSig(1,PduInfoPtr);
    }
    break;

    case COM_RX_M2STS1_MSG:
    {
      Com_SetBmuSts1Sig(1,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU2_COMERR, 0);   //20150831 BMUͨѶOK 
      BMU_NoActive[1]=0;
    }
    break;    

    
    case COM_RX_M2STS2_MSG:
    {
      Com_SetBmuSts2Sig(1,PduInfoPtr);             
    }
    break;  
 
 /* Module 3 */
    
    case COM_RX_M3CMT_MSG:
    {
      Com_SetBmuCmtSig(2,PduInfoPtr);
    }
    break;

    case COM_RX_M3STS1_MSG:
    {
      Com_SetBmuSts1Sig(2,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU3_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[2]=0;
    }
    break;    

    
    case COM_RX_M3STS2_MSG:
    {
      Com_SetBmuSts2Sig(2,PduInfoPtr);              
    }
    break;  

/* Module 4 */ 
     case COM_RX_M4CMT_MSG:
    {
      Com_SetBmuCmtSig(3,PduInfoPtr); 
    }
    break;

    case COM_RX_M4STS1_MSG:
    {
      Com_SetBmuSts1Sig(3,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU4_COMERR, 0);   //20150831 BMUͨѶOK 
      BMU_NoActive[3]=0;
    }
    break;    

    
    case COM_RX_M4STS2_MSG:
    {
      Com_SetBmuSts2Sig(3,PduInfoPtr);              
    }
    break;         

    case COM_RX_TESTCMD2_MSG:
    {
      com_testCmd = *((uint16*)(&PduInfoPtr->SduDataPtr[0])); 
      com_testAuto = PduInfoPtr->SduDataPtr[2] & 0x03;             
    }
    break;
  //add 20150805 
/* Module 5 */
    case COM_RX_M5CMT_MSG:
    {
      Com_SetBmuCmtSig(4,PduInfoPtr);
      
    }
    break;

    case COM_RX_M5STS1_MSG:
    {    
      Com_SetBmuSts1Sig(4,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU5_COMERR, 0);   //20150831 BMUͨѶOK 
      BMU_NoActive[4]=0;
    }
    break;    

    
    case COM_RX_M5STS2_MSG:
    {
      Com_SetBmuSts2Sig(4,PduInfoPtr);      
    }
    break;    

/* Module 6 */
    case COM_RX_M6CMT_MSG:
    {
      Com_SetBmuCmtSig(5,PduInfoPtr);
      
    }
    break;

    case COM_RX_M6STS1_MSG:
    {    
      Com_SetBmuSts1Sig(5,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU6_COMERR, 0);   //20150831 BMUͨѶOK 
      BMU_NoActive[5]=0;
    }
    break;    

    
    case COM_RX_M6STS2_MSG:
    {
      Com_SetBmuSts2Sig(5,PduInfoPtr);      
    }
    break;    

/* Module 7 */
    case COM_RX_M7CMT_MSG:
    {
      Com_SetBmuCmtSig(6,PduInfoPtr); 
      
    }
    break;

    case COM_RX_M7STS1_MSG:
    {    
      Com_SetBmuSts1Sig(6,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU7_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[6]=0;
    }
    break;    

    
    case COM_RX_M7STS2_MSG:
    {
      Com_SetBmuSts2Sig(6,PduInfoPtr);      
    }
    break;    

/* Module 8 */
    case COM_RX_M8CMT_MSG:
    {
      Com_SetBmuCmtSig(7,PduInfoPtr); 
      
    }
    break;

    case COM_RX_M8STS1_MSG:
    {    
      Com_SetBmuSts1Sig(7,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU8_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[7]=0;
    }
    break;    

    
    case COM_RX_M8STS2_MSG:
    {
      Com_SetBmuSts2Sig(7,PduInfoPtr);      
    }
    break;    

/* Module 9 */
    case COM_RX_M9CMT_MSG:
    {
      Com_SetBmuCmtSig(8,PduInfoPtr); 
      
    }
    break;

    case COM_RX_M9STS1_MSG:
    {    
      Com_SetBmuSts1Sig(8,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU9_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[8]=0;
    }
    break;    

    
    case COM_RX_M9STS2_MSG:
    {
      Com_SetBmuSts2Sig(8,PduInfoPtr);      
    }
    break;    

/* Module 10 */
    case COM_RX_M10CMT_MSG:
    {
      Com_SetBmuCmtSig(9,PduInfoPtr); 
      
    }
    break;

    case COM_RX_M10STS1_MSG:
    {    
      Com_SetBmuSts1Sig(9,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU10_COMERR, 0);   //20150831 BMUͨѶOK 
      BMU_NoActive[9]=0;
    }
    break;    

    
    case COM_RX_M10STS2_MSG:
    {
      Com_SetBmuSts2Sig(9,PduInfoPtr);      
    }
    break;    

/* Module 11 */
    case COM_RX_M11CMT_MSG:
    {
      Com_SetBmuCmtSig(10,PduInfoPtr); 
      
    }
    break;

    case COM_RX_M11STS1_MSG:
    {    
      Com_SetBmuSts1Sig(10,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU11_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[10]=0;
    }
    break;    

    
    case COM_RX_M11STS2_MSG:
    {
      Com_SetBmuSts2Sig(10,PduInfoPtr);      
    }
    break;    

/* Module 12 */
    case COM_RX_M12CMT_MSG:
    {
      Com_SetBmuCmtSig(11,PduInfoPtr);
      
    }
    break;

    case COM_RX_M12STS1_MSG:
    {    
      Com_SetBmuSts1Sig(11,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU12_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[11]=0;
    }
    break;    

    
    case COM_RX_M12STS2_MSG:
    {
      Com_SetBmuSts2Sig(11,PduInfoPtr);      
    }
    break;        

/* Module 13 */
    case COM_RX_M13CMT_MSG:
    {
      Com_SetBmuCmtSig(12,PduInfoPtr);
    }
    break;

    case COM_RX_M13STS1_MSG:
    {    
      Com_SetBmuSts1Sig(12,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU13_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[12]=0;
    }
    break;    

    case COM_RX_M13STS2_MSG:
    {
      Com_SetBmuSts2Sig(12,PduInfoPtr);      
    }
    break;          

/* Module 14 */
    case COM_RX_M14CMT_MSG:
    {
      Com_SetBmuCmtSig(13,PduInfoPtr);
    }
    break;

    case COM_RX_M14STS1_MSG:
    {
      Com_SetBmuSts1Sig(13,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU14_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[13]=0;
    }
    break;    

    case COM_RX_M14STS2_MSG:
    {
      Com_SetBmuSts2Sig(13,PduInfoPtr);      
    }
    break;          

/* Module 15 */
    case COM_RX_M15CMT_MSG:
    {
      Com_SetBmuCmtSig(14,PduInfoPtr);
    }
    break;
                          
    case COM_RX_M15STS1_MSG:
    {    
      Com_SetBmuSts1Sig(14,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU15_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[14]=0;
    }
    break;    

    case COM_RX_M15STS2_MSG:
    {
      Com_SetBmuSts2Sig(14,PduInfoPtr);      
    }
    break;          

/* Module 16 */
    case COM_RX_M16CMT_MSG:
    {
      Com_SetBmuCmtSig(15,PduInfoPtr);
    }
    break;

    case COM_RX_M16STS1_MSG:
    {    
      Com_SetBmuSts1Sig(15,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU16_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[15]=0;
    }
    break;    

    case COM_RX_M16STS2_MSG:
    {
      Com_SetBmuSts2Sig(15,PduInfoPtr);      
    }
    break;          

/* Module 17 */
    case COM_RX_M17CMT_MSG:
    {
      Com_SetBmuCmtSig(16,PduInfoPtr);
    }
    break;

    case COM_RX_M17STS1_MSG:
    {    
      Com_SetBmuSts1Sig(16,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU17_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[16]=0;
    }
    break;    

    case COM_RX_M17STS2_MSG:
    {
      Com_SetBmuSts2Sig(16,PduInfoPtr);      
    }
    break;          

/* Module 18 */
    case COM_RX_M18CMT_MSG:
    {
      Com_SetBmuCmtSig(17,PduInfoPtr);
    }
    break;

    case COM_RX_M18STS1_MSG:
    {    
      Com_SetBmuSts1Sig(17,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU18_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[17]=0;
    }
    break;    

    case COM_RX_M18STS2_MSG:
    {
      Com_SetBmuSts2Sig(17,PduInfoPtr);      
    }
    break;          

/* Module 19 */
    case COM_RX_M19CMT_MSG:
    {
      Com_SetBmuCmtSig(18,PduInfoPtr);
    }
    break;

    case COM_RX_M19STS1_MSG:
    {    
      Com_SetBmuSts1Sig(18,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU19_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[18]=0;
    }
    break;    

    case COM_RX_M19STS2_MSG:
    {
      Com_SetBmuSts2Sig(18,PduInfoPtr);      
    }
    break;          

/* Module 20 */
    case COM_RX_M20CMT_MSG:
    {
      Com_SetBmuCmtSig(19,PduInfoPtr);
    }
    break;

    case COM_RX_M20STS1_MSG:
    {    
      Com_SetBmuSts1Sig(19,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU20_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[19]=0;
    }
    break;    

    case COM_RX_M20STS2_MSG:
    {
      Com_SetBmuSts2Sig(19,PduInfoPtr);      
    }
    break;          

/* Module 21 */
    case COM_RX_M21CMT_MSG:
    {
      Com_SetBmuCmtSig(20,PduInfoPtr);
    }
    break;

    case COM_RX_M21STS1_MSG:
    {    
      Com_SetBmuSts1Sig(20,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU21_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[20]=0;
    }
    break;    

    case COM_RX_M21STS2_MSG:
    {
      Com_SetBmuSts2Sig(20,PduInfoPtr);      
    }
    break;          

/* Module 22 */
    case COM_RX_M22CMT_MSG:
    {
      Com_SetBmuCmtSig(21,PduInfoPtr);
    }
    break;

    case COM_RX_M22STS1_MSG:
    {    
      Com_SetBmuSts1Sig(21,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU22_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[21]=0;
    }
    break;    

    case COM_RX_M22STS2_MSG:
    {
      Com_SetBmuSts2Sig(21,PduInfoPtr);      
    }
    break;          

/* Module 23 */
    case COM_RX_M23CMT_MSG:
    {
      Com_SetBmuCmtSig(22,PduInfoPtr);
    }
    break;

    case COM_RX_M23STS1_MSG:
    {    
      Com_SetBmuSts1Sig(22,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU23_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[22]=0;
    }
    break;    

    case COM_RX_M23STS2_MSG:
    {
      Com_SetBmuSts2Sig(22,PduInfoPtr);      
    }
    break;          

/* Module 24 */
    case COM_RX_M24CMT_MSG:
    {
      Com_SetBmuCmtSig(23,PduInfoPtr);
    }
    break;

    case COM_RX_M24STS1_MSG:
    {    
      Com_SetBmuSts1Sig(23,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU24_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[23]=0;
    }
    break;    

    case COM_RX_M24STS2_MSG:
    {
      Com_SetBmuSts2Sig(23,PduInfoPtr);      
    }
    break;          

/* Module 25 */
    case COM_RX_M25CMT_MSG:
    {
      Com_SetBmuCmtSig(24,PduInfoPtr);
    }
    break;

    case COM_RX_M25STS1_MSG:
    {    
      Com_SetBmuSts1Sig(24,PduInfoPtr);
      Dem_SetError( DTC_IDX_BMU25_COMERR, 0);   //20150831 BMUͨѶOK
      BMU_NoActive[24]=0;
    }
    break;    

    case COM_RX_M25STS2_MSG:
    {
      Com_SetBmuSts2Sig(24,PduInfoPtr);      
    }
    break;    

/* Module 1 */
    case COM_RX_M1CV1_MSG:
    {
      Com_SetBmuCV1(0,PduInfoPtr); 
    }
    break;

    case COM_RX_M1CV2_MSG:
    {    
      Com_SetBmuCV2(0,PduInfoPtr); 
    }
    break;    

    case COM_RX_M1CV3_MSG:
    {
      Com_SetBmuCV3(0,PduInfoPtr);      
    }
    break; 

    case COM_RX_M1CV4_MSG:
    {
      Com_SetBmuCV4(0,PduInfoPtr);       
    }
    break;  
      
    case COM_RX_M2CV1_MSG:
    {
      Com_SetBmuCV1(1,PduInfoPtr); 
    }
    break;

    case COM_RX_M2CV2_MSG:
    {    
      Com_SetBmuCV2(1,PduInfoPtr); 
    }
    break;    

    case COM_RX_M2CV3_MSG:
    {
      Com_SetBmuCV3(1,PduInfoPtr);      
    }
    break; 

    case COM_RX_M2CV4_MSG:
    {
      Com_SetBmuCV4(1,PduInfoPtr);       
    }
    break;  
      
    case COM_RX_M3CV1_MSG:
    {
      Com_SetBmuCV1(2,PduInfoPtr); 
    }
    break;

    case COM_RX_M3CV2_MSG:
    {    
      Com_SetBmuCV2(2,PduInfoPtr); 
    }
    break;    

    case COM_RX_M3CV3_MSG:
    {
      Com_SetBmuCV3(2,PduInfoPtr);      
    }
    break; 

    case COM_RX_M3CV4_MSG:
    {
      Com_SetBmuCV4(2,PduInfoPtr);       
    }
    break;    
          
      
    case COM_RX_M4CV1_MSG:
    {
      Com_SetBmuCV1(3,PduInfoPtr); 
    }
    break;

    case COM_RX_M4CV2_MSG:
    {    
      Com_SetBmuCV2(3,PduInfoPtr); 
    }
    break;    

    case COM_RX_M4CV3_MSG:
    {
      Com_SetBmuCV3(3,PduInfoPtr);      
    }
    break; 

    case COM_RX_M4CV4_MSG:
    {
      Com_SetBmuCV4(3,PduInfoPtr);       
    }
    break;    
          
      
    case COM_RX_M5CV1_MSG:
    {
      Com_SetBmuCV1(4,PduInfoPtr); 
    }
    break;

    case COM_RX_M5CV2_MSG:
    {    
      Com_SetBmuCV2(4,PduInfoPtr); 
    }
    break;    

    case COM_RX_M5CV3_MSG:
    {
      Com_SetBmuCV3(4,PduInfoPtr);      
    }
    break; 

    case COM_RX_M5CV4_MSG:
    {
      Com_SetBmuCV4(4,PduInfoPtr);       
    }
    break;    
          
      
    case COM_RX_M6CV1_MSG:
    {
      Com_SetBmuCV1(5,PduInfoPtr); 
    }
    break;

    case COM_RX_M6CV2_MSG:
    {    
      Com_SetBmuCV2(5,PduInfoPtr); 
    }
    break;    

    case COM_RX_M6CV3_MSG:
    {
      Com_SetBmuCV3(5,PduInfoPtr);      
    }
    break; 

    case COM_RX_M6CV4_MSG:
    {
      Com_SetBmuCV4(5,PduInfoPtr);       
    }
    break;    
          
      
    case COM_RX_M7CV1_MSG:
    {
      Com_SetBmuCV1(6,PduInfoPtr); 
    }
    break;

    case COM_RX_M7CV2_MSG:
    {    
      Com_SetBmuCV2(6,PduInfoPtr); 
    }
    break;    

    case COM_RX_M7CV3_MSG:
    {
      Com_SetBmuCV3(6,PduInfoPtr);      
    }
    break; 

    case COM_RX_M7CV4_MSG:
    {
      Com_SetBmuCV4(6,PduInfoPtr);       
    }
    break;    
          
      
    case COM_RX_M8CV1_MSG:
    {
      Com_SetBmuCV1(7,PduInfoPtr); 
    }
    break;

    case COM_RX_M8CV2_MSG:
    {    
      Com_SetBmuCV2(7,PduInfoPtr); 
    }
    break;    

    case COM_RX_M8CV3_MSG:
    {
      Com_SetBmuCV3(7,PduInfoPtr);      
    }
    break; 

    case COM_RX_M8CV4_MSG:
    {
      Com_SetBmuCV4(7,PduInfoPtr);       
    }
    break;    
          
      
    case COM_RX_M9CV1_MSG:
    {
      Com_SetBmuCV1(8,PduInfoPtr); 
    }
    break;

    case COM_RX_M9CV2_MSG:
    {    
      Com_SetBmuCV2(8,PduInfoPtr); 
    }
    break;    

    case COM_RX_M9CV3_MSG:
    {
      Com_SetBmuCV3(8,PduInfoPtr);      
    }
    break; 

    case COM_RX_M9CV4_MSG:
    {
      Com_SetBmuCV4(8,PduInfoPtr);       
    }
    break;    
          
      
    case COM_RX_M10CV1_MSG:
    {
      Com_SetBmuCV1(9,PduInfoPtr); 
    }
    break;

    case COM_RX_M10CV2_MSG:
    {    
      Com_SetBmuCV2(9,PduInfoPtr); 
    }
    break;    

    case COM_RX_M10CV3_MSG:
    {
      Com_SetBmuCV3(9,PduInfoPtr);      
    }
    break; 

    case COM_RX_M10CV4_MSG:
    {
      Com_SetBmuCV4(9,PduInfoPtr);       
    }
    break;    
          
      
    case COM_RX_M11CV1_MSG:
    {
      Com_SetBmuCV1(10,PduInfoPtr); 
    }
    break;

    case COM_RX_M11CV2_MSG:
    {    
      Com_SetBmuCV2(10,PduInfoPtr); 
    }
    break;    

    case COM_RX_M11CV3_MSG:
    {
      Com_SetBmuCV3(10,PduInfoPtr);
   
    }
    break; 

    case COM_RX_M11CV4_MSG:
    {
      Com_SetBmuCV4(10,PduInfoPtr);       
    }
    break;    
            
	case COM_RX_M12CV1_MSG:
	{
	  Com_SetBmuCV1(11,PduInfoPtr); 
	}
	break;
	
	case COM_RX_M12CV2_MSG:
	{	 
	  Com_SetBmuCV2(11,PduInfoPtr); 
	}
	break;	  
	
	case COM_RX_M12CV3_MSG:
	{
	  Com_SetBmuCV3(11,PduInfoPtr);
	
	}
	break; 
	
	case COM_RX_M12CV4_MSG:
	{
	  Com_SetBmuCV4(11,PduInfoPtr); 	  
	}
	break;	  
					
	case COM_RX_DISRELAYDEBUG_MSG:
	{
		uint8 temp0;
		uint8 temp1;
		uint8 ordnum;
		uint8 ctrlord;
		temp0 = PduInfoPtr->SduDataPtr[0];
		temp1 = PduInfoPtr->SduDataPtr[1];
		if((com_BattCurr == 32512)
			&& (temp0 == 204) && (temp1 == 7))//��֤��ַ7CC�ҵ�ǰ�޵���
		{
			ordnum = PduInfoPtr->SduDataPtr[2];
			ctrlord = PduInfoPtr->SduDataPtr[3];
		
			//��������Ϊ0����1���ɽ���
			if((ctrlord == 0) || (ctrlord == 1))
			{
				switch(ordnum)
				{
					//��������
					case 0:
						DebugMode= ctrlord;
						ioa_ChMRelayCtl= 0;
						ioa_DisChMRelayCtl= 0;
						ioa_PreChargeRelayCtl= 0;
						ioa_NegativeRelayCtl= 0;
						ioa_FanRelayCtl= 0;
						ioa_AirACRelayCtl= 0;
						ioa_AirPTCRelayCtl= 0;
						ioa_PTCRelayCtrl= 0;
						com_BCLTxEna = 0;
						break;
						
					//������̵���
					case 1:
						if(DebugMode == 1)
						{
							ioa_ChMRelayCtl= ctrlord;
						}
						break;
						
					//�ŵ����̵���
					case 2:
						if(DebugMode == 1)
						{
							ioa_DisChMRelayCtl= ctrlord;
						}
						break;
						
					//�ŵ�Ԥ��̵���
					case 3:
						if(DebugMode == 1)
						{
							ioa_PreChargeRelayCtl= ctrlord;
						}
						break;
						
					//�����̵���
					case 4:
						if(DebugMode == 1)
						{
							ioa_NegativeRelayCtl= ctrlord;
						}
						break;
						
					//���ȼ̵���
					case 5:
						if(DebugMode == 1)
						{
							ioa_FanRelayCtl= ctrlord;
						}
						break;
						
					//�յ��̵���
					case 6:
						if(DebugMode == 1)
						{
							ioa_AirACRelayCtl= ctrlord;
						}
						break;
						
					//�յ�PTC�̵���
					case 7:
						if(DebugMode == 1)
						{
							ioa_AirPTCRelayCtl= ctrlord;
						}
						break;
						
					//��ؼ��ȼ̵���
					case 8:
						if(DebugMode == 1)
						{
							ioa_PTCRelayCtrl= ctrlord;
						}
						break;
						
					//���ͨѶ����
					case 20:
						if(DebugMode == 1)
						{
							com_BCLTxEna= ctrlord;
						}
						break;
						
					default:
						break;
				}
			}
		}
		else
		{
			DebugMode = 0;
		}
	}
	break;

	case  COM_RX_RESERVE1_MSG:
	{
		;
	}
	break;

         
//add by xql for fast charge,20150709
    case  COM_RX_CRM_MSG:
    {
      com_RxMsg_CRM = (struct CRM_tag*)PduInfoPtr->SduDataPtr;
      com_CRM_RecResult = (*com_RxMsg_CRM).Byte1.RecResult;
      com_CRM_ChgerNum = (*com_RxMsg_CRM).Byte2.ChgerNum;
      com_CRM_AreaCode[5] = (*com_RxMsg_CRM).Byte3.AreaCode_lo1;
      com_CRM_AreaCode[4] = (*com_RxMsg_CRM).Byte4.AreaCode_lo2;      
      com_CRM_AreaCode[3] = (*com_RxMsg_CRM).Byte5.AreaCode_lo3;
      com_CRM_AreaCode[2] = (*com_RxMsg_CRM).Byte6.AreaCode_hi1;
      com_CRM_AreaCode[1] = (*com_RxMsg_CRM).Byte7.AreaCode_hi2;
      com_CRM_AreaCode[0] = (*com_RxMsg_CRM).Byte8.AreaCode_hi3;      
      com_CRMTimeoutFlag = FALSE;
    }
    break;
    
    case  COM_RX_CTS_MSG:
    {
      com_RxMsg_CTS = (struct CTS_tag*)PduInfoPtr->SduDataPtr;
      com_CTS_Seconds = (*com_RxMsg_CTS).Byte1.Seconds;
      com_CTS_Minute = (*com_RxMsg_CTS).Byte2.Minute;
      com_CTS_Hour = (*com_RxMsg_CTS).Byte3.Hour;
      com_CTS_Day = (*com_RxMsg_CTS).Byte4.Day;
      com_CTS_Month = (*com_RxMsg_CTS).Byte5.Month;
      com_CTS_Year = ((uint16)(*com_RxMsg_CTS).Byte7.Year_hi << 8)|((*com_RxMsg_CTS).Byte6.Year_lo);
      com_CTSTimeoutFlag = FALSE;
    }
    break;    

    case  COM_RX_CML_MSG:
    {
      com_RxMsg_CML = (struct CML_tag*)PduInfoPtr->SduDataPtr;
      com_CML_MaxOutVolt =  ((uint16)(*com_RxMsg_CML).Byte2.MaxOutVolt_hi << 8)|((*com_RxMsg_CML).Byte1.MaxOutVolt_lo);
      com_CML_MinOutVolt =  ((uint16)(*com_RxMsg_CML).Byte4.MinOutVolt_hi << 8)|((*com_RxMsg_CML).Byte3.MinOutVolt_lo);
      com_CML_MaxOutCurrent =  ((uint16)(*com_RxMsg_CML).Byte6.MaxOutCurrent_hi << 8)|((*com_RxMsg_CML).Byte5.MaxOutCurrent_lo);
      com_CMLTimeoutFlag = FALSE;     
    }
    break;

    case  COM_RX_CRO_MSG:
    {
      com_RxMsg_CRO = (struct CRO_tag*)PduInfoPtr->SduDataPtr;
      com_CRO_ChgerReady = (*com_RxMsg_CRO).Byte1.ChgerReady;
      com_CROTimeoutFlag = FALSE;     
    }
    break;
        
    case  COM_RX_CCS_MSG:
    {
      com_RxMsg_CCS = (struct CCS_tag*)PduInfoPtr->SduDataPtr;
      com_CCS_OutVolt =  ((uint16)(*com_RxMsg_CCS).Byte2.OutVolt_hi << 8)|((*com_RxMsg_CCS).Byte1.OutVolt_lo);
      com_CCS_OutCurrent =  ((uint16)(*com_RxMsg_CCS).Byte4.OutCurrent_hi << 8)|((*com_RxMsg_CCS).Byte3.OutCurrent_lo);
      com_CCS_AccChgedTime =  ((uint16)(*com_RxMsg_CCS).Byte6.AccChgedTime_hi << 8)|((*com_RxMsg_CCS).Byte5.AccChgedTime_lo);
      com_CCSTimeoutFlag = FALSE;    
    }
    break;
    
    case  COM_RX_CST_MSG:
    {
      com_RxMsg_CST = (struct CST_tag*)PduInfoPtr->SduDataPtr;
      com_CST_FaultStop = (*com_RxMsg_CST).Byte1.B.FaultStop;
      com_CST_ManualStop = (*com_RxMsg_CST).Byte1.B.ManualStop;
      com_CST_ConditionalStop = (*com_RxMsg_CST).Byte1.B.ConditionalStop;
      com_CST_EnergyTransFault = (*com_RxMsg_CST).Byte2.B.EnergyTransFault;
      com_CST_InnerOverTempFault = (*com_RxMsg_CST).Byte2.B.InnerOverTempFault;
      com_CST_ConnecterFault = (*com_RxMsg_CST).Byte2.B.ConnecterFault;
      com_CST_OverTempFault = (*com_RxMsg_CST).Byte2.B.OverTempFault;
      com_CST_OtherFault = (*com_RxMsg_CST).Byte3.B.OtherFault;
      com_CST_EmergencyFault = (*com_RxMsg_CST).Byte3.B.EmergencyFault;
      com_CST_VoltError = (*com_RxMsg_CST).Byte4.B.VoltError;
      com_CST_CurrentError = (*com_RxMsg_CST).Byte4.B.CurrentError;
      com_CSTTimeoutFlag = FALSE;
    }
    break;

    case  COM_RX_CSD_MSG:
    {
      com_RxMsg_CSD = (struct CSD_tag*)PduInfoPtr->SduDataPtr;
      com_CSD_TotalChgedTime = ((uint16)(*com_RxMsg_CSD).Byte2.TotalChgedTime_hi << 8)|((*com_RxMsg_CSD).Byte1.TotalChgedTime_lo);
      com_CSD_TotalOutEnergy = ((uint16)(*com_RxMsg_CSD).Byte4.TotalOutEnergy_hi << 8)|((*com_RxMsg_CSD).Byte3.TotalOutEnergy_lo);
      com_CSD_ChgerNum = (*com_RxMsg_CSD).Byte5.ChgerNum;
      com_CSDTimeoutFlag = FALSE;
    }
    break;        

    case  COM_RX_CEM_MSG:
    {
      com_RxMsg_CEM = (struct CEM_tag*)PduInfoPtr->SduDataPtr;
      com_CEM_RcvBMSRecedMsg = (*com_RxMsg_CEM).Byte1.B.RcvBMSRecedMsg;
      com_CEM_RcvBMSReadyMsg = (*com_RxMsg_CEM).Byte2.B.RcvBMSReadyMsg;
      com_CEM_RcvChgParMsg = (*com_RxMsg_CEM).Byte2.B.RcvChgParMsg;
      com_CEM_RcvBMSStopMsg = (*com_RxMsg_CEM).Byte3.B.RcvBMSStopMsg;
      com_CEM_RcvBMSReqMsg = (*com_RxMsg_CEM).Byte3.B.RcvBMSReqMsg;
      com_CEM_RcvChgStateMsg = (*com_RxMsg_CEM).Byte3.B.RcvChgStateMsg;
      com_CEM_RcvBMSTotalMsg = (*com_RxMsg_CEM).Byte4.B.RcvBMSTotalMsg;
      com_CEMTimeoutFlag = FALSE;
    }
    break;

    //add by xyl 2015-7-22 for test
    /*case COM_RX_DM1_MSG:
    {
        (uint8*)com_RxMsg_DM1;
    }
    break;

    case COM_RX_BCP_MSG:
    {
        (uint8*)(&com_RxMsg_BCP);
    }
    break;

    case COM_RX_BCS_MSG:
    {
        (uint8*)(&com_RxMsg_BCS);
    }
    break; */
    
  //add 20150805   
  	case COM_RX_MB_ST_VMS_3:
  	{
  		BM_CMD_HV_Power = (PduInfoPtr->SduDataPtr[6]>>2)&0x03;//��ѹ���µ�ָ��	0 "Open HV Switch" 1 "Open HV switchurgently" 2 "Close HV switch" 3 "Keepcurrent state"
  	  com_RelayTimeoutFlag=0;
  	  if((BM_CMD_HV_Power==0)||(BM_CMD_HV_Power==1))//add 20150819  ���ӱ��Ŀ��Ƽ̵���״̬
  	  {
  	    Relay_CZ = 0;    //�Ͽ��̵���  ����������Ҫ����߼�
  	  }
  	  else if(BM_CMD_HV_Power==2)
  	  {
  	    Relay_CZ = 1;    //�պϼ̵���
  	  }
      Dem_SetError(DTC_IDX_VEH_COMERR, 0);   //20150831 ����ͨѶok
  	}
  	break;
  	
  //add 20151205   
  	case COM_RX_MB_ST_MCU_2:
  	{              
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];
      BM_DC_HV_Voltage = wdata.WORD; 
  	  if(BM_DC_HV_Voltage>DC_ReachVolt)//ĸ�ߵ�ѹ����Ƿ�ﵽ
  	  {
  	    DCVolt_Reach = 1;    //�ﵽ
  	  }
  	  else if(BM_DC_HV_Voltage<=1000)//��ѹС��100V
  	  {
  	    DCVolt_Reach = 0;    //
  	  }
  	  else
  	  {
  	    DCVolt_Reach = 2;    //
  	  }
	    com_RelayTimeoutFlag=0;
  	  
      Dem_SetError(DTC_IDX_VEH_COMERR, 0);   //20150831 ����ͨѶok
  	}
  	break; 
  	
  //add 20151205   
  	case COM_RX_MB_ST_VMS_7:
  	{
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];
      BM_VMS_Mil = wdata.WORD; 
	 // AirconCtrlOrder = (PduInfoPtr->SduDataPtr[2] & 0x1);
	  //AirPTCConCtrlOrder = ((PduInfoPtr->SduDataPtr[2] & 0x8) >> 3);
	    com_RelayTimeoutFlag=0;   	
  	}
  	break;
    
  	case COM_RX_MB_ST_CMU_5:
  	{
		/*uint32 temp = 0;
		
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[4];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[5];
      BM_VMS_Mil = wdata.WORD; 
	  
      wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[6];
      wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[7];
      temp = wdata.WORD; 

	  BM_VMS_Mil = (uint16)(((temp << 16) | BM_VMS_Mil) >> 3 / 10);*/
	    com_RelayTimeoutFlag=0;   	
  	}
  	break;
    
    default:
    break;
  }
}

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/
//==========================================================================
//��������:void Com_ChkHvcuMsgCnt(VOID)
//��������:��ѹ��ͨѶ״̬����������
//�������:��
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_ChkHvcuMsgCnt(void)
{
  if (com_RxHvcuFirst == TRUE)
  {
    com_RxHvcuFirst = FALSE;    
  }else
  {
    if (com_HvcuMsgCnt != (com_HvcuMsgCntLast + 1))
    {
      com_RxHvcuMsgCntErr = TRUE; 
      
      if ((com_HvcuMsgCnt == 0)&&(com_HvcuMsgCntLast<0xFE))
      {
        com_RxHvcuMsgCntResetErr = TRUE;  
      }
    }
  }
  com_HvcuMsgCntLast = com_HvcuMsgCnt;  
}

//==========================================================================
//��������:void Com_ChkBmuMsgCnt(VOID)
//��������:�����ͨѶ״̬����������
//�������:��
//�������:��
//��������:��
//==========================================================================
_STATIC_ void COM_CODE Com_ChkBmuMsgCnt(uint8 index)
{
  if (com_RxBmuFirst[index] == TRUE)
  {
    com_RxBmuFirst[index] = FALSE;    
  }else
  {
    if (com_BmuMsgCnt[index] != (com_BmuMsgCntLast[index] + 1))
    {
      com_RxBmuMsgCntErr[index] = TRUE; 
      
      if ((com_BmuMsgCnt[index] == 0)&&(com_BmuMsgCntLast[index]<0xFE))
      {
        com_RxBmuMsgCntResetErr[index] = TRUE;  
      }
    }
  }
  com_BmuMsgCntLast[index] = com_BmuMsgCnt[index];  
}
extern uint8 retVal;  
extern uint8 schm_failCnt;
/*******************************************************************************
* NAME:             Com_TxPreCopy
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void 
* DESCRIPTION:       
*******************************************************************************/
_STATIC_ void COM_CODE Com_TxPreCopy(PduIdType PduId)
{
  OneWordUnionType wdata;
  
  switch (PduId)
  {
    case COM_TX_CMD_MSG_IDX:
    {    
      com_TxMsg_CMD[0] = 0;//(com_BalEnable[0] | (com_BalEnable[1]<<2) |
                        // (com_BalEnable[2]<<4) | (com_BalEnable[3]<<6)); 
                           
      #ifdef EJ02                      
      com_TxMsg_CMD[1] = (com_chrgCellNum) | (com_chrgCmd<<4);
      
      com_TxMsg_CMD[2] = com_chrgDuration;
      #endif
      
      #ifdef MINIBUS   //20150908
      com_TxMsg_CMD[1] = (com_BalEnable[4] | (com_BalEnable[5]<<2) |
                         (com_BalEnable[6]<<4) | (com_BalEnable[7]<<6)); 
	    com_TxMsg_CMD[2] = (com_BalEnable[8] & 0x03 | (com_BalEnable[9]<<2) | (com_BalEnable[10]<<4) | (com_BalEnable[11]<<6));
	    #endif 
	    
      com_TxMsg_CMD[3] = (com_ShutDown<<6) | ecum_State | (eep_Status<<3) | (dem_status<<4)| (trpr_status<<5) ;
      
      com_TxMsg_CMD[4] = com_CurrentSet;
      
      *(uint16*)(&com_TxMsg_CMD[5]) = EEP_REG_ETAG;
      
      com_TxMsg_CMD[7] = com_CmdTxMsgCnt;
      
      com_CmdTxMsgCnt++;

    }
    break;
    
    case COM_TX_TD_MSG_IDX:
    {          
      //BM_VMS_Mil = 18000;                              
      com_TxMsg_TD[0] = (uint8)(BM_VMS_Mil&0x00FF); //add 20151213
      com_TxMsg_TD[7] = (uint8)(BM_VMS_Mil >> 8);
      //com_TxMsg_TD[0] = sd2405_CurTime.second;   
      com_TxMsg_TD[1] = sd2405_CurTime.minute; 
      com_TxMsg_TD[2] = sd2405_CurTime.hour; 
      com_TxMsg_TD[3] = sd2405_CurTime.month; 
      com_TxMsg_TD[4] = sd2405_CurTime.day; 
      com_TxMsg_TD[5] = sd2405_CurTime.year;  
      com_TxMsg_TD[6] =  (com_ShutDown << 7) | PackCurMode; //��ѹ����Ҫ���״̬20151021    
      //com_TxMsg_TD[6] =  retVal;
      //com_TxMsg_TD[7] = CanErrorChannel;//schm_failCnt;                
    }
    break; 
    
    case COM_TX_TEST1_MSG_IDX:
    {    
      /*//wdata.WORD = ioa_T15VoltActRaw;    
      wdata.WORD = SWC_CellVoltMax; 
      com_TxMsg_TEST1[0] = wdata.Bytes.LowByte;   
      com_TxMsg_TEST1[1] = wdata.Bytes.HighByte; 
        
      //wdata.WORD = ioa_chrgVoltActRaw;  
      wdata.WORD = SWC_CellVoltMin;
      com_TxMsg_TEST1[2] = wdata.Bytes.LowByte;   
      com_TxMsg_TEST1[3] = wdata.Bytes.HighByte;              

      wdata.WORD = ioa_battVoltActRaw; 
      com_TxMsg_TEST1[4] = wdata.Bytes.LowByte;   
      com_TxMsg_TEST1[5] = wdata.Bytes.HighByte; 
        
      wdata.WORD = ioa_vccVoltActRaw; 
      com_TxMsg_TEST1[6] = wdata.Bytes.LowByte;   
      com_TxMsg_TEST1[7] = wdata.Bytes.HighByte; */  
      
      
      com_TxMsg_TEST1[0] = com_BPVP1MaxCellNum;//����ѹ��� 
      wdata.WORD = com_BPVP1MaxCellVolt; //����ѹ
      com_TxMsg_TEST1[1] = wdata.Bytes.LowByte;   
      com_TxMsg_TEST1[2] = wdata.Bytes.HighByte;  
      
      com_TxMsg_TEST1[3] = com_BPVP1MinCellNum;//��С��ѹ���  
      wdata.WORD = com_BPVP1MinCellVolt; //��С��ѹ
      com_TxMsg_TEST1[4] = wdata.Bytes.LowByte;   
      com_TxMsg_TEST1[5] = wdata.Bytes.HighByte;
      
      com_TxMsg_TEST1[6] = com_BSM_MaxCTCellNum; //����¶ȱ��
      com_TxMsg_TEST1[7] = com_BPTP1MaxCellTemp; //����¶�
          
    }
    break;

    case COM_TX_TEST2_MSG_IDX:
    {    
      //wdata.WORD = ioa_sensorSplyVoltActRaw; 
      //com_TxMsg_TEST2[0] = wdata.Bytes.LowByte;   
      //com_TxMsg_TEST2[1] = wdata.Bytes.HighByte;  
      com_TxMsg_TEST2[0] = com_BSM_MinCTCellNum;//����¶ȱ��   
      com_TxMsg_TEST2[1] = com_BPTP1MinCellTemp;//����¶� 
        
      com_TxMsg_TEST2[2] = (DebugMode<<4) | O_S_FCCC;   
      com_TxMsg_TEST2[3] = (SID_m_st_DisChMRelay << 1) | (SID_m_st_ChMRelay);              

      //com_TxMsg_TEST2[4] = com_BPVP1MinCellNum;   
      //com_TxMsg_TEST2[5] = (uint8)(com_BPVP1MinCellVolt>>8); 
      //com_TxMsg_TEST2[6] = (uint8)(com_BPVP1MinCellVolt & 0x00FF);
                                              
      com_TxMsg_TEST2[4] = COM_FM1St;//���ϵȼ�1�ı���    
      com_TxMsg_TEST2[5] = COM_FM2St;//���ϵȼ�2�ı���	 
      com_TxMsg_TEST2[6] = COM_FM3St;//���ϵȼ�3�ı���	
      com_TxMsg_TEST2[7] = BMS_FaultState;//���ϵȼ�
      //com_TxMsg_TEST2[6] = (ioa_lowSide3Ctl<<3)|(ioa_lowSide2Ctl<<2)|(ioa_lowSide1Ctl<<1)|(ioa_slowChrgEnaCtl);   
    }
    break;          

    case COM_TX_RESERVE1_MSG_IDX:
    {    
      com_TxMsg_RESERVE1[0] = 0;
      com_TxMsg_RESERVE1[1] = 0;
      com_TxMsg_RESERVE1[2] = 0;
      com_TxMsg_RESERVE1[3] = 0;
      com_TxMsg_RESERVE1[4] = 0;
      com_TxMsg_RESERVE1[5] = 0;
      com_TxMsg_RESERVE1[6] = 0;
      com_TxMsg_RESERVE1[7] = 0;
    }
    break;          

    case COM_TX_BPVP1_MSG_IDX:
    {                           
      com_TxMsg_BPVP1[0] = com_BPVP1MaxCellNum; //���о���
      wdata.WORD = com_BPVP1MaxCellVolt; 
      com_TxMsg_BPVP1[1] = wdata.Bytes.LowByte;   
      com_TxMsg_BPVP1[2] = wdata.Bytes.HighByte;  
                                                
      com_TxMsg_BPVP1[3] = com_BPVP1MinCellNum; //��С��о���
      wdata.WORD = com_BPVP1MinCellVolt; 
      com_TxMsg_BPVP1[4] = wdata.Bytes.LowByte;   
      com_TxMsg_BPVP1[5] = wdata.Bytes.HighByte; 
       
      /*wdata.WORD = com_BPVP1MinCellVolt; 
      com_TxMsg_BPVP1[6] = wdata.Bytes.LowByte;   
      com_TxMsg_BPVP1[7] = wdata.Bytes.HighByte;    */
    }
    break;

    case COM_TX_BPTP1_MSG_IDX:
    {                                   
      com_TxMsg_BPTP1[0] = com_BPTP1MaxCellNum;
      com_TxMsg_BPTP1[1] = com_BPTP1MaxCellTemp; 
      com_TxMsg_BPTP1[2] = com_BPTP1MinCellNum;
      com_TxMsg_BPTP1[3] = com_BPTP1MinCellTemp;
      com_TxMsg_BPTP1[4] = com_BPTP1AvrgCellTemp; 
                  
    }
    break;
        
    case COM_TX_BPC1_MSG_IDX:
    {    
      wdata.WORD = com_BPC1MinDchrgVolt; 
      com_TxMsg_BPC1[0] = wdata.Bytes.LowByte;   
      com_TxMsg_BPC1[1] = wdata.Bytes.HighByte; 

      com_TxMsg_BPC1[2] = com_BPC1CurrChrgVol;   
      
      wdata.WORD = com_BPC1MaxDchrgCurrent; 
      com_TxMsg_BPC1[3] = wdata.Bytes.LowByte;   
      com_TxMsg_BPC1[4] = wdata.Bytes.HighByte; 
                  
    }
    break;

    case COM_TX_BPC2_MSG_IDX:
    {    
      wdata.WORD = com_BPC2MaxChrgVolt; 
      com_TxMsg_BPC2[0] = wdata.Bytes.LowByte;   
      com_TxMsg_BPC2[1] = wdata.Bytes.HighByte; 
      
      wdata.WORD = com_BPC2MaxChrgCurrent; 
      com_TxMsg_BPC2[2] = wdata.Bytes.LowByte;   
      com_TxMsg_BPC2[3] = wdata.Bytes.HighByte; 
      
      com_TxMsg_BPC2[4] = com_BPC2ChrgEnable;
      com_TxMsg_BPC2[5] = com_BPC2ChrgSts | (com_BPC2ChrgrACInput<<2);   
      
      com_TxMsg_BPC2[5] |= (BMS_ChargerDCInput<<3);     //2013-07-03
                 
    }
    break;

    case COM_TX_BPS_MSG_IDX:
    {    
      com_TxMsg_BPS[0] = com_BPSSOC;  
       
      wdata.WORD = com_BPSCurrent; 
      com_TxMsg_BPS[1] = wdata.Bytes.LowByte;   
      com_TxMsg_BPS[2] = wdata.Bytes.HighByte; 
      
      com_TxMsg_BPS[3] = (com_BPSHighVoltSts<<6) | (com_BPSChMRelaySts<<4) | 
                        (com_BPSDisChMRelaySts<<2) | (com_BPSSelfChkSts) ;
      
      com_TxMsg_BPS[5] = (0x80) | (com_BPSOverCurrAlarm<<6) | 
                          (com_BPSBattMaintenanceAlarm<<5) | (com_BPSVolumLowAlarm<<4) |
                         (com_BPSCellVoltLowAlarm<<3) | (com_BPSBattLeakAlarm<<2) | 
                        (com_BPSBattTempHighAlarm<<1) | (com_BPSBattVoltLowAlarm);
      
      com_TxMsg_BPS[4] = com_bpsTxMsgCnt | 0xC0 |(BMS_FaultState<<4);

      wdata.WORD = com_BPSInsulationResistance; 
      com_TxMsg_BPS[6] = wdata.Bytes.LowByte;   
      com_TxMsg_BPS[7] = wdata.Bytes.HighByte; 
            
      com_bpsTxMsgCnt++;
      if (com_bpsTxMsgCnt > 7)
      {
        com_bpsTxMsgCnt = 0;
      }
                  
    }
    break;

    case COM_TX_CP_MSG_IDX:
    {    
       
      wdata.WORD = com_CPMaxChrgVolt; 
      com_TxMsg_CP[0] = wdata.Bytes.LowByte;   
      com_TxMsg_CP[1] = wdata.Bytes.HighByte; 
      
      wdata.WORD = com_CPCmdChrgCurr; 
      com_TxMsg_CP[2] = wdata.Bytes.LowByte;   
      com_TxMsg_CP[3] = wdata.Bytes.HighByte; 
      
      com_TxMsg_CP[4] = com_CPCtl;
      com_TxMsg_CP[5] = com_CPModuleNum;
                  
    }
    break;

    case COM_TX_SP1_MSG_IDX:
    {    
       
      wdata.WORD = com_SP1BattVolt; 
      com_TxMsg_SP1[0] = wdata.Bytes.LowByte;   
      com_TxMsg_SP1[1] = wdata.Bytes.HighByte; 
      
      wdata.WORD = com_SP1BattCurr; 
      com_TxMsg_SP1[2] = wdata.Bytes.LowByte;   
      com_TxMsg_SP1[3] = wdata.Bytes.HighByte; 

      wdata.WORD = com_SP1Soc; 
      com_TxMsg_SP1[4] = wdata.Bytes.LowByte;   
      com_TxMsg_SP1[5] = wdata.Bytes.HighByte; 

      wdata.WORD = com_SP1CellAlarmUpVolt; 
      com_TxMsg_SP1[6] = wdata.Bytes.LowByte;   
      com_TxMsg_SP1[7] = wdata.Bytes.HighByte;       
                        
    }
    break;
    

    case COM_TX_SP2_MSG_IDX:
    {    
       
      wdata.WORD = com_SP2CellShutUpVolt; 
      com_TxMsg_SP2[0] = wdata.Bytes.LowByte;   
      com_TxMsg_SP2[1] = wdata.Bytes.HighByte; 
      
      wdata.WORD = com_SP2CellAlarmLwrVolt; 
      com_TxMsg_SP2[2] = wdata.Bytes.LowByte;   
      com_TxMsg_SP2[3] = wdata.Bytes.HighByte; 

      wdata.WORD = com_SP2CellShutLwrVolt; 
      com_TxMsg_SP2[4] = wdata.Bytes.LowByte;   
      com_TxMsg_SP2[5] = wdata.Bytes.HighByte; 

      wdata.WORD = com_SP2CellDiffAlarm; 
      com_TxMsg_SP2[6] = wdata.Bytes.LowByte;   
      com_TxMsg_SP2[7] = wdata.Bytes.HighByte;       
                        
    }
    break;

    case COM_TX_SP3_MSG_IDX:
    {    
       
      wdata.WORD = com_SP3TempAlarmUpVal; 
      com_TxMsg_SP3[0] = wdata.Bytes.LowByte;   
      com_TxMsg_SP3[1] = wdata.Bytes.HighByte; 
      
      wdata.WORD = com_SP3MaxChrgCurr; 
      com_TxMsg_SP3[2] = wdata.Bytes.LowByte;   
      com_TxMsg_SP3[3] = wdata.Bytes.HighByte; 

      wdata.WORD = com_SP3MaxDchrgCurr; 
      com_TxMsg_SP3[4] = wdata.Bytes.LowByte;   
      com_TxMsg_SP3[5] = wdata.Bytes.HighByte; 

      wdata.WORD = com_SP3Volum; 
      com_TxMsg_SP3[6] = wdata.Bytes.LowByte;   
      com_TxMsg_SP3[7] = wdata.Bytes.HighByte;       
                        
    }

    break;    

    case COM_TX_BCI_MSG_IDX:
    {    
      com_TxMsg_BCI[0] = BMS_SupplierNum; 
      
      com_TxMsg_BCI[1] = (uint8)(BMS_SWVersion & 0xFF); 
      com_TxMsg_BCI[2] = (uint8)((BMS_SWVersion>>8) & 0xFF);
       
      com_TxMsg_BCI[3] = (uint8)(BMS_SWDesignDate & 0xFF); 
      com_TxMsg_BCI[4] = (uint8)((BMS_SWDesignDate>>8) & 0xFF); 
      com_TxMsg_BCI[5] = (uint8)((BMS_SWDesignDate>>16) & 0xFF); 
    }
    break;    

//add by xql for fast charge Tx Msg,20150708
    case COM_TX_BRM_MSG_IDX:
    {         
      com_TxMsg_BRM.Byte1.SubProVersion = com_BRM_SubProVersion;
      com_TxMsg_BRM.Byte2.ProVersion_lo = (uint8)(com_BRM_ProVersion&0x00FF);      
      com_TxMsg_BRM.Byte3.ProVersion_hi = (uint8)(com_BRM_ProVersion >> 8);      
      com_TxMsg_BRM.Byte4.BatType = com_BRM_BatType;
      com_TxMsg_BRM.Byte5.RatedCap_lo = (uint8)(com_BRM_RatedCap&0x00FF);      
      com_TxMsg_BRM.Byte6.RatedCap_hi = (uint8)(com_BRM_RatedCap >> 8);
      com_TxMsg_BRM.Byte7.RatedVolt_lo = (uint8)(com_BRM_RatedVolt&0x00FF);      
      com_TxMsg_BRM.Byte8.RatedVolt_hi = (uint8)(com_BRM_RatedVolt >> 8);
                  
    }
    break;

    case COM_TX_BCP_MSG_IDX:  //�������ϵͳ��������ѹ  ����  ��������Ϣ
    {  
      unsigned int TXPre_Copy = 0;      
      com_TxMsg_BCP.Byte1.MaxCellChgVolt_lo = (uint8)(com_BCP_MaxCellChgVolt&0x00FF);
      com_TxMsg_BCP.Byte2.MaxCellChgVolt_hi = (uint8)(com_BCP_MaxCellChgVolt >> 8);      
      com_TxMsg_BCP.Byte3.MaxChgCurrent_lo = (uint8)(com_BCP_MaxChgCurrent&0x00FF);
      com_TxMsg_BCP.Byte4.MaxChgCurrent_hi = (uint8)(com_BCP_MaxChgCurrent >> 8);
      com_TxMsg_BCP.Byte5.NominalEnergy_lo = (uint8)(com_BCP_NominalEnergy&0x00FF);
      com_TxMsg_BCP.Byte6.NominalEnergy_hi = (uint8)(com_BCP_NominalEnergy >> 8);
      com_TxMsg_BCP.Byte7.MaxPackChgVolt_lo = (uint8)(com_BCP_MaxPackChgVolt&0x00FF);
      com_TxMsg_BCP.Byte8.MaxPackChgVolt_hi = (uint8)(com_BCP_MaxPackChgVolt >> 8);
      com_TxMsg_BCP.Byte9.MaxAllowedTemp = com_BCP_MaxAllowedTemp;
      
      TXPre_Copy = com_BCP_PackSOC*10;
      com_TxMsg_BCP.Byte10.PackSOC_lo = (uint8)(TXPre_Copy&0x00FF);
      com_TxMsg_BCP.Byte11.PackSOC_hi = (uint8)(TXPre_Copy >> 8);
                                                                
      TXPre_Copy = com_BCP_PackVolt*10;
      com_TxMsg_BCP.Byte12.PackVolt_lo = (uint8)(TXPre_Copy&0x00FF);
      com_TxMsg_BCP.Byte13.PackVolt_hi = (uint8)(TXPre_Copy >> 8);            
      
      /*{//only for test
        uint8 i;
        for(i=0; i<com_TxConfig_C[PduId].DataLen; i++)
        {
           com_TxConfig_C[PduId].DataPtr[i] = i;
        }
      }*/
    }
    break;

    case COM_TX_BRO_MSG_IDX:
    {    
      com_TxMsg_BRO.Byte1.BMSReady = com_BRO_BMSReady;  
      com_TxMsg_BRO.Byte2.BRO2 = 0xFF;          
      com_TxMsg_BRO.Byte3.BRO3 = 0xFF;           
      com_TxMsg_BRO.Byte4.BRO4 = 0xFF;           
      com_TxMsg_BRO.Byte5.BRO5 = 0xFF;           
      com_TxMsg_BRO.Byte6.BRO6 = 0xFF;           
      com_TxMsg_BRO.Byte7.BRO7 = 0xFF;           
      com_TxMsg_BRO.Byte8.BRO8 = 0xFF;            
                  
    }
    break;
    
    case COM_TX_BCL_MSG_IDX:
    {    
      com_TxMsg_BCL.Byte1.ReqVolt_lo = (uint8)(com_BCP_MaxPackChgVolt&0x00FF);
      com_TxMsg_BCL.Byte2.ReqVolt_hi = (uint8)(com_BCP_MaxPackChgVolt >> 8);
      //com_TxMsg_BCL.Byte1.ReqVolt_lo = (uint8)(com_BCL_ReqVolt&0x00FF);
      //com_TxMsg_BCL.Byte2.ReqVolt_hi = (uint8)(com_BCL_ReqVolt >> 8);             
      com_TxMsg_BCL.Byte3.ReqCurrent_lo = (uint8)(com_LUC_ReqCurrent&0x00FF); //use lookup_table 20151020
      com_TxMsg_BCL.Byte4.ReqCurrent_hi = (uint8)(com_LUC_ReqCurrent >> 8);    
      //com_TxMsg_BCL.Byte3.ReqCurrent_lo = (uint8)(com_BCL_ReqCurrent&0x00FF); //use lookup_table 20151020
      //com_TxMsg_BCL.Byte4.ReqCurrent_hi = (uint8)(com_BCL_ReqCurrent >> 8);
      com_TxMsg_BCL.Byte5.ChgMode = com_BCL_ChgMode;      
    }
    break;    

    case COM_TX_BCS_MSG_IDX:
    {    
      com_BCS_MeasuredChgVolt = BM_Battery_Voltage*10;//20151023    
      com_BCS_MeasuredChgCurrent = BM_Battery_Current-16000;//20151023  
      if(BM_Battery_Current >= 20000)
      {
		com_BCS_MeasuredChgCurrent = 4000;		
	  }
      //com_BCS_MeasuredChgCurrent = ((BM_Battery_Current/10-2000)+400)*10;//20151023 
      //com_BCS_MaxCVGroupNum = com_BPVP1MaxCellNum;              
      com_TxMsg_BCS.Byte1.MeasuredChgVolt_lo = (uint8)(com_BCS_MeasuredChgVolt&0x00FF);
      com_TxMsg_BCS.Byte2.MeasuredChgVolt_hi = (uint8)(com_BCS_MeasuredChgVolt >> 8);            
      com_TxMsg_BCS.Byte3.MeasuredChgCurrent_lo = (uint8)(com_BCS_MeasuredChgCurrent&0x00FF);
      com_TxMsg_BCS.Byte4.MeasuredChgCurrent_hi = (uint8)(com_BCS_MeasuredChgCurrent >> 8);
      com_TxMsg_BCS.Byte5.MaxCellVolt_lo8 = (uint8)(com_BCS_MaxCellVolt&0x00FF);
      com_TxMsg_BCS.Byte6.B.MaxCellVolt_hi4 = (uint8)(com_BCS_MaxCellVolt >> 8);
      com_TxMsg_BCS.Byte6.B.MaxCVGroupNum = com_BCS_MaxCVGroupNum;
      com_TxMsg_BCS.Byte7.CurSoc = com_BCS_CurSOC;
      com_TxMsg_BCS.Byte8.ChgTimeRemain_lo = (uint8)(com_BCS_ChgTimeRemain&0x00FF);
      com_TxMsg_BCS.Byte9.ChgTimeRemain_hi = (uint8)(com_BCS_ChgTimeRemain >> 8);                                               
      /*{//only for test
        uint8 i;
        for(i=0; i<com_TxConfig_C[PduId].DataLen; i++)
        {
           com_TxConfig_C[PduId].DataPtr[i] = i;
        }
      }*/
    }
    break;

    case COM_TX_BSM_MSG_IDX:
    {       
      //com_BSM_MaxCVCellNum = 
      com_TxMsg_BSM.Byte1.MaxCVCellNum = com_BSM_MaxCVCellNum;
      com_TxMsg_BSM.Byte2.MaxCellTemp = com_BSM_MaxCellTemp;            
      com_TxMsg_BSM.Byte3.MaxCTCellNum = com_BSM_MaxCTCellNum;
      com_TxMsg_BSM.Byte4.MinCellTemp = com_BSM_MinCellTemp;
      com_TxMsg_BSM.Byte5.MinCTCellNum = com_BSM_MinCTCellNum;
      com_TxMsg_BSM.Byte6.B.ChgTempSt = com_BSM_ChgTempSt;
      com_TxMsg_BSM.Byte6.B.ChgCurrentSt = com_BSM_ChgCurrentSt;
      com_TxMsg_BSM.Byte6.B.ChgSOCSt = com_BSM_ChgSOCSt;
      com_TxMsg_BSM.Byte6.B.ChgCVSt = com_BSM_ChgCVSt;
      com_TxMsg_BSM.Byte7.B.ChgAllowed = com_BSM_ChgAllowed;
      com_TxMsg_BSM.Byte7.B.ConnecterSt = com_BSM_ConnecterSt;
      com_TxMsg_BSM.Byte7.B.ISOSt = com_BSM_ISOSt;   
      com_TxMsg_BSM.Byte7.B.rsv = 0;//20151020                
    }
    break;

    case COM_TX_BST_MSG_IDX:
    {    
      com_TxMsg_BST.Byte1.B.SetCVReach = com_BST_SetCVReach;
      com_TxMsg_BST.Byte1.B.SetPVReach = com_BST_SetPVReach;
      com_TxMsg_BST.Byte1.B.SetSOCReach = com_BST_SetSOCReach;
      com_TxMsg_BST.Byte2.B.ConnecterFault = com_BST_ConnecterFault;
      com_TxMsg_BST.Byte2.B.CompOverTempFault = com_BST_CompOverTempFault;
      com_TxMsg_BST.Byte2.B.ConnOverTempFault = com_BST_ConnOverTempFault;
      com_TxMsg_BST.Byte2.B.ISOFault = com_BST_ISOFault;
      com_TxMsg_BST.Byte3.B.OtherFault = com_BST_OtherFault;
      com_TxMsg_BST.Byte3.B.BatOverTempFault = com_BST_BatOverTempFault;
      com_TxMsg_BST.Byte4.B.VoltError = 0;//com_BST_VoltError;
      com_TxMsg_BST.Byte4.B.CurrentError = 0;//com_BST_CurrentError; ��֪��Ϊʲô���������� 20151025    
      com_TxMsg_BST.Byte4.B.rsv = 0;
                            
    }
    break;

    case COM_TX_BSD_MSG_IDX:
    {    
      com_TxMsg_BSD.Byte1.EndSOC = com_BSD_EndSOC;
      com_TxMsg_BSD.Byte2.MinCellVolt_lo = (uint8)(com_BSD_MinCellVolt&0x00FF);
      com_TxMsg_BSD.Byte3.MinCellVolt_hi = (uint8)(com_BSD_MinCellVolt >> 8);                              
      com_TxMsg_BSD.Byte4.MaxCellVolt_lo = (uint8)(com_BSD_MaxCellVolt&0x00FF);
      com_TxMsg_BSD.Byte5.MaxCellVolt_hi = (uint8)(com_BSD_MaxCellVolt >> 8);                              
      com_TxMsg_BSD.Byte6.MinCellTemp = com_BSD_MinCellTemp;
      com_TxMsg_BSD.Byte7.MaxCellTemp = com_BSD_MaxCellTemp;                              
                            
    }
    break;

    case COM_TX_BEM_MSG_IDX:
    {    
      com_TxMsg_BEM.Byte1.B.RcvChgerRecMsg_AA = com_BEM_RcvChgerRecMsg_AA;
      com_TxMsg_BEM.Byte1.B.RcvChgerRecMsg_00 = com_BEM_RcvChgerRecMsg_00;
      com_TxMsg_BEM.Byte2.B.RcvChgerCMLMsg = com_BEM_RcvChgerCMLMsg;
      com_TxMsg_BEM.Byte2.B.RcvChgerReadyMsg = com_BEM_RcvChgerReadyMsg;
      com_TxMsg_BEM.Byte3.B.RcvChgerStopMsg = com_BEM_RcvChgerStopMsg;
      com_TxMsg_BEM.Byte3.B.RcvChgerStateMsg = com_BEM_RcvChgerStateMsg;
      com_TxMsg_BEM.Byte4.B.RcvChgerTotalMsg = com_BEM_RcvChgerTotalMsg;
                            
    }
    break;
    
    //add 20150805    // add 20150806 �޸�IDXΪCOMʹ�õ�   
   case COM_TX_MB_ST_BMS_1_IDX: 
   {
	   if(PackCurMode !=0)
	   {
		   com_TxMsg_MB_ST_BMS_1.Byte2.B.Fault_Level =	(BM_Fault_Level==1)? 0 : BM_Fault_Level;//��ذ����󼶱� 
	   }
	   else
	   {
      com_TxMsg_MB_ST_BMS_1.Byte2.B.Fault_Level =  BM_Fault_Level;//��ذ����󼶱� 
	   }
      com_TxMsg_MB_ST_BMS_1.Byte2.B.Live_BMS_ST_01 =  BM_Live_BMS_ST_01;//����֡
      com_TxMsg_MB_ST_BMS_1.Byte3.Battery_Charge_Power_Available = BM_Battery_Charge_Power_Available;// BM_Battery_Charge_Power_Available; //��ذ������ĳ�繦��1kw �ô�����	��0xFF
      com_TxMsg_MB_ST_BMS_1.Byte4.Battery_Discharge_Power_Available =  BM_Battery_Discharge_Power_Available;//��ذ������ķŵ繦�� 1 KW �ֱ���    
      com_TxMsg_MB_ST_BMS_1.Byte5.Battery_Energy_Available_lo =  (uint8)(BM_Battery_Energry_Avarable&0x00FF);//��ذ�ʣ������ KWH  0.1�ֱ���
      com_TxMsg_MB_ST_BMS_1.Byte6.Battery_Energy_Available_hi =  (uint8)(BM_Battery_Energry_Avarable >> 8);//
      com_TxMsg_MB_ST_BMS_1.Byte7.Battery_SOC =  BM_Battery_SOC;//
      com_TxMsg_MB_ST_BMS_1.Byte8.Battery_User_SOC =  BM_Battery_User_SOC;//��ʾSOC  ��Battery_SOCһ��
	  
	  {
	      uint8 COM_TX_Buff;
	      //COM_TX_Buff=com_TxMsg_MB_ST_BMS_1.Byte1.RB1;//����CRC
	      //COM_TX_Buff=COM_TX_Buff^com_TxMsg_MB_ST_BMS_1.Byte2.RB2;
	      COM_TX_Buff=com_TxMsg_MB_ST_BMS_1.Byte2.RB2;
	      COM_TX_Buff=COM_TX_Buff^com_TxMsg_MB_ST_BMS_1.Byte3.RB3;
	      COM_TX_Buff=COM_TX_Buff^com_TxMsg_MB_ST_BMS_1.Byte4.RB4;
	      COM_TX_Buff=COM_TX_Buff^com_TxMsg_MB_ST_BMS_1.Byte5.RB5;
	      COM_TX_Buff=COM_TX_Buff^com_TxMsg_MB_ST_BMS_1.Byte6.RB6;
	      COM_TX_Buff=COM_TX_Buff^com_TxMsg_MB_ST_BMS_1.Byte7.RB7;
	      COM_TX_Buff=COM_TX_Buff^com_TxMsg_MB_ST_BMS_1.Byte8.RB8;
	      
	      com_TxMsg_MB_ST_BMS_1.Byte1.CRC_BMS_ST_01 =  COM_TX_Buff;//CRCֵ
	      
    	      	  
    	  BM_Live_BMS_ST_01++;                                                  
    	  BM_Live_BMS_ST_01 %= 0x10; //add
	  }      
	  /*////!!!!!!!! $$$ 20150806�������ӵ�8��BMU���ճ����Ƿ���ȷ
    {    
      uint8 *dataPtr = (uint8 *)(&com_TxMsg_MB_ST_BMS_1);
      
       
      dataPtr[0] = com_CellTemp[4][1];  //660 
      dataPtr[1] = com_CellTemp[5][1];  //670
      
      dataPtr[2] = com_CellTemp[6][1];   
      dataPtr[3] = com_CellTemp[7][1]; 

      dataPtr[4] = 0x20;   
      dataPtr[5] = 0x33; 

      dataPtr[6] = com_CellTemp[1][1];  //630 
      dataPtr[7] = com_CellTemp[0][1];  //620     
                        
    }*/ 
      
   }
   break;
   
   case COM_TX_MB_ST_BMS_2_IDX: //
   {
      com_TxMsg_MB_ST_BMS_2.Byte1.Battery_Current_lo =  BM_Battery_Current&0x00FF;//�����Ͱ�λ
      com_TxMsg_MB_ST_BMS_2.Byte2.Battery_Current_hi =  BM_Battery_Current>>8;//�����߰�λ
      com_TxMsg_MB_ST_BMS_2.Byte3.Battery_Voltage_lo =  BM_Battery_Voltage&0xFF;//�ܵ�ѹ�Ͱ�λ
      com_TxMsg_MB_ST_BMS_2.Byte4.Battery_Voltage_hi =  BM_Battery_Voltage>>8;//�ܵ�ѹ�߰�λ
      com_TxMsg_MB_ST_BMS_2.Byte5.Battery_Avg_T =  BM_Battery_Avg_T;//���ƽ���¶�
      com_TxMsg_MB_ST_BMS_2.Byte6.Battery_Max_T =  BM_Battery_Max_T;//�������¶�
      com_TxMsg_MB_ST_BMS_2.Byte7.Battery_Min_T =  BM_Battery_Min_T;//�����С�¶�
      com_TxMsg_MB_ST_BMS_2.Byte8.Battery_SOH =  BM_Battery_SOH;//��������ʹ����
   }
   break;
   
   case COM_TX_MB_ST_BMS_3_IDX: //
   {
	  if(PackCurMode !=0)
	  {
		  com_TxMsg_MB_ST_BMS_3.Byte1.B.ST_ERR_Cell_Under_Voltage =  ((BM_ST_ERR_Cell_Under_Voltage==1)? 0 : BM_ST_ERR_Cell_Under_Voltage);//�����оǷѹ����VCU�ϴ������źš� 0:���� 1:1������ 2:2������ 3:3������ �������� 	  
		  com_TxMsg_MB_ST_BMS_3.Byte1.B.ST_ERR_Cell_Over_Voltage =	((BM_ST_ERR_Cell_Over_Voltage==1)? 0 : BM_ST_ERR_Cell_Over_Voltage);//�����о��ѹ����VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������  
		  com_TxMsg_MB_ST_BMS_3.Byte1.B.ST_ERR_DisCharge_Over_Current =  ((BM_ST_ERR_DisChgrge_Over_Current==1)? 0 : BM_ST_ERR_DisChgrge_Over_Current);//BM_ST_ERR_DisChgrge_Over_Current�ŵ����������VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������	
		  com_TxMsg_MB_ST_BMS_3.Byte1.B.ST_ERR_Charge_Over_Current =  ((BM_ST_ERR_Charge_Over_Current==1)? 0 : BM_ST_ERR_Charge_Over_Current);//������������VCU�ϴ������źš�0:���� 1:��������1������ 2:��������2������ 3 "Charge currentlarge 
		  
		  com_TxMsg_MB_ST_BMS_3.Byte2.B.ST_ERR_Over_Temperature =  ((BM_ST_ERR_Over_Temperature==1)? 0 : BM_ST_ERR_Over_Temperature);//��ذ��¶ȹ��ߣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������  
		  com_TxMsg_MB_ST_BMS_3.Byte2.B.ST_ERR_Battery_Under_Voltage =	((BM_ST_ERR_Battery_Under_Voltage==1)? 0 : BM_ST_ERR_Battery_Under_Voltage);//�ܵ�ѹ���ͣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������	
		  com_TxMsg_MB_ST_BMS_3.Byte2.B.ST_ERR_Battery_Over_Voltage =  ((BM_ST_ERR_Battery_Over_Voltage==1)? 0 : BM_ST_ERR_Battery_Over_Voltage);//�ܵ�ѹ���ߣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������  
		  com_TxMsg_MB_ST_BMS_3.Byte2.B.ST_ERR_Cell_Voltage_Uniformity =  ((BM_ST_ERR_Cell_Voltage_Uniformity==1)? 0 : BM_ST_ERR_Cell_Voltage_Uniformity);//�����о��ѹ�����⣬��VCU�ϴ������ź�.  0:���� 1:1������ 2:2������ 3:3������ �������� 
		  
		  com_TxMsg_MB_ST_BMS_3.Byte3.B.ST_ERR_Insulation_Resistance =	((BM_ST_ERR_Insulation_Resistance==1)? 0 : BM_ST_ERR_Insulation_Resistance);//��Ե����ֵ����, ��VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ �������� 
		  com_TxMsg_MB_ST_BMS_3.Byte3.B.ST_ERR_Low_SOC =  ((BM_ST_ERR_Low_SOC==1)? 0 : BM_ST_ERR_Low_SOC);//SOC����,�ŵ��ʱ���� ��VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ �������� 
		  com_TxMsg_MB_ST_BMS_3.Byte3.B.ST_ERR_Over_SOC =  0;//BM_ST_ERR_Over_SOC;//��û��������,SOC����100,���ǵ�ѹ�ﲻ��???SOC����,����ʱ���� ��VCU�ϴ������ź�.0:���� 1:1������ 2:2������ 3:3������ �������� 
		  com_TxMsg_MB_ST_BMS_3.Byte3.B.ST_ERR_Low_Temperature =  ((BM_ST_ERR_Low_Temperature==1)? 0 : BM_ST_ERR_Low_Temperature);//��ذ��¶ȹ��ͣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ �������� 
		  
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_BatteryVoltage_High_Fault =	0;//BM_ST_ERR_BatteryVoltage_High_Fault;//���ص�ѹ���� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_SysPowerSupply_Fault =	0;//BM_ST_ERR_SysPower_Supply_Fault;//ϵͳ������� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_CellTemp_Unbalance_Fault =	0;//BM_ST_ERR_CellTemp_Unbalance_Fault;//�¶Ȳ����� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_Current_Sensor_Fault =  BM_ST_ERR_Current_Sensor_Fault;//���������������쳣��0:����  1 ���� //	1:������������·  2:������������·	3:�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_Temperature_Sensor_Fault =  BM_ST_ERR_Temperature_Sensor_Fault;//�¶Ȳ����쳣��0 ����  1 ����������
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_Cell_Voltage_Sensor_Fault =	BM_ST_ERR_Cell_Voltage_Sensor_Fault;//�����о��ѹ�����쳣�� 0 ����  1 ����������
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_INNCAN_Communication_Fault =  BM_ST_ERR_INNCAN_Communication_Fault;//�ڲ�CANͨѶ�쳣��0 ����  1 ����
			 
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_VEHCAN_Communication_Fault =  0;//BM_ST_ERR_VEHCAN_Communication_Fault;//����CAN 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_PVoltage_Sensor_Fault =  ((BM_ST_ERR_PVoltage_Sensor_Fault==1)? 0 : BM_ST_ERR_PVoltage_Sensor_Fault);;//�ܵ�ѹ�ɼ��쳣 0--���� 1--һ�� 2--����
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_IsoCalc_Fault =  BM_ST_ERR_ISOCalc_Fault;//��Ե����ɼ��쳣 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_SOCCalc_Fault =  BM_ST_ERR_SOCCalc_Fault;//SOC�ɼ��쳣 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_BatteryVoltage_Low_Fault =  0;//BM_ST_ERR_BatteryVoltage_Low_Fault;//���ص�ѹ���� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_PTC_Fault =  BM_ST_ERR_PTC_Fault;//PTC�쳣 0--���� 1--��· 2--��· 3--����
		  
		  com_TxMsg_MB_ST_BMS_3.Byte6.B.ST_ERR_NegRelaySticky_Fault =  BM_ST_ERR_NegRelaySticky_Fault;//�����̵���ճ�� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte6.B.ST_ERR_OffCur_Fault =  BM_ST_ERR_OffCur_Fault;//�µ�����쳣 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte6.B.ST_ERR_OrigCur_Fault =  BM_ST_ERR_OrigCur_Fault;//��ʼ�����쳣 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte6.B.Reserved =  0;//���� ���� 

		  com_TxMsg_MB_ST_BMS_3.Byte7.Reserved =  0;//���� ����  
		  com_TxMsg_MB_ST_BMS_3.Byte8.Reserved =  PackCurMode;
	  }
	  else
	  {
		  com_TxMsg_MB_ST_BMS_3.Byte1.B.ST_ERR_Cell_Under_Voltage =  BM_ST_ERR_Cell_Under_Voltage;//�����оǷѹ����VCU�ϴ������źš� 0:���� 1:1������ 2:2������ 3:3������ �������� 	  
		  com_TxMsg_MB_ST_BMS_3.Byte1.B.ST_ERR_Cell_Over_Voltage =	BM_ST_ERR_Cell_Over_Voltage;//�����о��ѹ����VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������  
		  com_TxMsg_MB_ST_BMS_3.Byte1.B.ST_ERR_DisCharge_Over_Current =  BM_ST_ERR_DisChgrge_Over_Current;//BM_ST_ERR_DisChgrge_Over_Current�ŵ����������VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������	
		  com_TxMsg_MB_ST_BMS_3.Byte1.B.ST_ERR_Charge_Over_Current =  BM_ST_ERR_Charge_Over_Current;//������������VCU�ϴ������źš�0:���� 1:��������1������ 2:��������2������ 3 "Charge currentlarge 
		  
		  com_TxMsg_MB_ST_BMS_3.Byte2.B.ST_ERR_Over_Temperature =  BM_ST_ERR_Over_Temperature;//��ذ��¶ȹ��ߣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������  
		  com_TxMsg_MB_ST_BMS_3.Byte2.B.ST_ERR_Battery_Under_Voltage =	BM_ST_ERR_Battery_Under_Voltage;//�ܵ�ѹ���ͣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������	
		  com_TxMsg_MB_ST_BMS_3.Byte2.B.ST_ERR_Battery_Over_Voltage =  BM_ST_ERR_Battery_Over_Voltage;//�ܵ�ѹ���ߣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������  
		  com_TxMsg_MB_ST_BMS_3.Byte2.B.ST_ERR_Cell_Voltage_Uniformity =  BM_ST_ERR_Cell_Voltage_Uniformity;//�����о��ѹ�����⣬��VCU�ϴ������ź�.  0:���� 1:1������ 2:2������ 3:3������ �������� 
		  
		  com_TxMsg_MB_ST_BMS_3.Byte3.B.ST_ERR_Insulation_Resistance =	BM_ST_ERR_Insulation_Resistance;//��Ե����ֵ����, ��VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ �������� 
		  com_TxMsg_MB_ST_BMS_3.Byte3.B.ST_ERR_Low_SOC =  BM_ST_ERR_Low_SOC;//SOC����,�ŵ��ʱ���� ��VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ �������� 
		  com_TxMsg_MB_ST_BMS_3.Byte3.B.ST_ERR_Over_SOC =  0;//BM_ST_ERR_Over_SOC;//��û��������,SOC����100,���ǵ�ѹ�ﲻ��???SOC����,����ʱ���� ��VCU�ϴ������ź�.0:���� 1:1������ 2:2������ 3:3������ �������� 
		  com_TxMsg_MB_ST_BMS_3.Byte3.B.ST_ERR_Low_Temperature =  BM_ST_ERR_Low_Temperature;//��ذ��¶ȹ��ͣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ �������� 
		  
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_BatteryVoltage_High_Fault =	BM_ST_ERR_BatteryVoltage_High_Fault;//���ص�ѹ���� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_SysPowerSupply_Fault =	BM_ST_ERR_SysPower_Supply_Fault;//ϵͳ������� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_CellTemp_Unbalance_Fault =	BM_ST_ERR_CellTemp_Unbalance_Fault;//�¶Ȳ����� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_Current_Sensor_Fault =  BM_ST_ERR_Current_Sensor_Fault;//���������������쳣��0:����  1 ���� //	1:������������·  2:������������·	3:�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_Temperature_Sensor_Fault =  BM_ST_ERR_Temperature_Sensor_Fault;//�¶Ȳ����쳣��0 ����  1 ����������
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_Cell_Voltage_Sensor_Fault =	BM_ST_ERR_Cell_Voltage_Sensor_Fault;//�����о��ѹ�����쳣�� 0 ����  1 ����������
		  com_TxMsg_MB_ST_BMS_3.Byte4.B.ST_ERR_INNCAN_Communication_Fault =  BM_ST_ERR_INNCAN_Communication_Fault;//�ڲ�CANͨѶ�쳣��0 ����  1 ����
			 
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_VEHCAN_Communication_Fault =  BM_ST_ERR_VEHCAN_Communication_Fault;//����CAN 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_PVoltage_Sensor_Fault =  BM_ST_ERR_PVoltage_Sensor_Fault;//�ܵ�ѹ�ɼ��쳣 0--���� 1--һ�� 2--����
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_IsoCalc_Fault =  BM_ST_ERR_ISOCalc_Fault;//��Ե����ɼ��쳣 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_SOCCalc_Fault =  BM_ST_ERR_SOCCalc_Fault;//SOC�ɼ��쳣 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_BatteryVoltage_Low_Fault =  BM_ST_ERR_BatteryVoltage_Low_Fault;//���ص�ѹ���� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte5.B.ST_ERR_PTC_Fault =  BM_ST_ERR_PTC_Fault;//PTC�쳣 0--���� 1--��· 2--��· 3--����
		  
		  com_TxMsg_MB_ST_BMS_3.Byte6.B.ST_ERR_NegRelaySticky_Fault =  BM_ST_ERR_NegRelaySticky_Fault;//�����̵���ճ�� 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte6.B.ST_ERR_OffCur_Fault =  BM_ST_ERR_OffCur_Fault;//�µ�����쳣 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte6.B.ST_ERR_OrigCur_Fault =  BM_ST_ERR_OrigCur_Fault;//��ʼ�����쳣 0--���� 1--�쳣
		  com_TxMsg_MB_ST_BMS_3.Byte6.B.Reserved =  0;//���� ���� 

		  com_TxMsg_MB_ST_BMS_3.Byte7.Reserved =  0;//���� ����  
		  com_TxMsg_MB_ST_BMS_3.Byte8.Reserved =  PackCurMode;
	  }
   }
   break;
    
   case COM_TX_MB_ST_BMS_4_IDX: //
   {
    if(ioa_FCCCVoltActRaw<=3000) 
    {
  		BM_ST_Charging_Gun = 1;
    } 
    else
    {
		  BM_ST_Charging_Gun = 0;
    }
	  com_TxMsg_MB_ST_BMS_4.Byte2.B.Reserved =  Relay_CZ;//���� ������ʱ�������ͼ̵�������20150806  
    com_TxMsg_MB_ST_BMS_4.Byte2.B.LIV_ST_BMS_4 =  BM_LIV_ST_BMS_4;//�ܵ�ѹ���ͣ���VCU�ϴ������źš�0:���� 1:1������ 2:2������ 3:3������ ��������  
     
	  com_TxMsg_MB_ST_BMS_4.Byte3.B.ST_Precharge_Relay_lo =  ioa_PreChargeRelayCtl ;//BM_ST_Precharge_RelayԤ��̵���״̬�� 0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"
    com_TxMsg_MB_ST_BMS_4.Byte3.B.ST_HV_Negative_Relay =  ioa_NegativeRelayCtl ;//BM_ST_HV_Negative_Relay�����̵���״̬��0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"
	  com_TxMsg_MB_ST_BMS_4.Byte3.B.ST_HV_Positive_Relay_FaultStatus =  BM_ST_HV_Positive_Relay_FaultStatus;//�����̵�������״̬�� 0 "No faut" 1 "Fault"
    com_TxMsg_MB_ST_BMS_4.Byte3.B.ST_HV_Positive_Relay3 =  0;//BM_ST_HV_Positive_Relay3;//û��  �����̵���3״̬�� 0 "open" 1 "close"
    com_TxMsg_MB_ST_BMS_4.Byte3.B.ST_HV_Positive_Relay2 =  0;//BM_ST_HV_Negative_Relay;//û��  �����̵���2״̬�� 0 "open" 1 "close"
	  com_TxMsg_MB_ST_BMS_4.Byte3.B.ST_HV_Positive_Relay1 =  ioa_DisChMRelayCtl ;//BM_ST_HV_Positive_Relay1�����̵���1״̬�� 0 "open" 1 "close"
    com_TxMsg_MB_ST_BMS_4.Byte3.B.ST_HV_Online =  BM_ST_HV_Online;//��ذ��ϵ�״̬�� 0 "Power Off" 1 "Power On"
      
	  com_TxMsg_MB_ST_BMS_4.Byte4.B.ST_Charging =  BM_ST_Charging;//BM_ST_Charging;//����!!!���״̬�źš� 0"No charging"   1 "Charging"  2 "Chargefinished"  
    com_TxMsg_MB_ST_BMS_4.Byte4.B.ST_Cooling_Relay = 0;// BM_ST_Cooling_Relay;//����  ɢ�ȼ̵���״̬��    0 "Open" 1 "Closed"
	  com_TxMsg_MB_ST_BMS_4.Byte4.B.ST_Heating_Relay = 0;// BM_ST_Healting_Relay;//����  ���ȼ̵���״̬��  0 "Open" 1 "Closed"
    com_TxMsg_MB_ST_BMS_4.Byte4.B.ST_Charge_Negative_Relay =  0;//BM_ST_Charge_Negative_Relay����  �为�̵���״̬(�������乫�ø����̵���)��  0 "Open" 1 "Closed"
	  com_TxMsg_MB_ST_BMS_4.Byte4.B.ST_SCharge_Positive_Relay =  0;//BM_ST_SCharge_Positive_Relay����  �������̵���״̬�� 0 "Open" 1 "Closed"
	  com_TxMsg_MB_ST_BMS_4.Byte4.B.ST_FCharge_Positive_Relay =  ioa_ChMRelayCtl ;//����!!!BM_ST_FCharge_Positive_Relay������̵���״̬�� 0 "Open" 1 "Closed"
    com_TxMsg_MB_ST_BMS_4.Byte4.B.ST_Precharge_Relay_hi =  0;//����  Ԥ��̵���״̬�� 0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"
	     
	  //com_TxMsg_MB_ST_BMS_4.Byte5.Reserved =  0;//���� ��ʱ�������ϵȼ�1�ı���   
	  com_TxMsg_MB_ST_BMS_4.Byte5.B.ST_Charging_Gun =  BM_ST_Charging_Gun;//BM_ST_Charging;//����!!!���״̬�źš� 0"No charging"   1 "Charging"  2 "Chargefinished"  
    com_TxMsg_MB_ST_BMS_4.Byte5.B.ST_Heating = ((HeatingSt==2)? 1 : 0); 
    com_TxMsg_MB_ST_BMS_4.Byte5.B.ST_Cooling = 0; 
    com_TxMsg_MB_ST_BMS_4.Byte5.B.ST_Resistance =  (uint8)(((com_Resistance/100)>31) ? 31 : (com_Resistance/100));

    com_TxMsg_MB_ST_BMS_4.Byte6.Reserved =  COM_FM1St;//���� ��ʱ�������ϵȼ�2�ı���	
	  com_TxMsg_MB_ST_BMS_4.Byte7.Reserved =  COM_FM2St;//���� ��ʱ�������ϵȼ�3�ı���	
	  com_TxMsg_MB_ST_BMS_4.Byte8.Reserved =  COM_FM3St;//���� ��ʱ�������ϵȼ�
	  {
	      uint8*  CRC_temp;
	      uint8   COM_TX_Buff;
	      CRC_temp = (uint8*)(&com_TxMsg_MB_ST_BMS_4);
    	  COM_TX_Buff= CRC_temp[1];//����CRC
    	  COM_TX_Buff=COM_TX_Buff^CRC_temp[2];
    	  COM_TX_Buff=COM_TX_Buff^CRC_temp[3];
    	  COM_TX_Buff=COM_TX_Buff^CRC_temp[4];
    	  COM_TX_Buff=COM_TX_Buff^CRC_temp[5];
    	  COM_TX_Buff=COM_TX_Buff^CRC_temp[6];
    	  COM_TX_Buff=COM_TX_Buff^CRC_temp[7];
	  
      com_TxMsg_MB_ST_BMS_4.Byte1.CRC_ST_BMS_4 =  COM_TX_Buff;//CRCֵ
   }  
   
   
	  BM_LIV_ST_BMS_4++;
	  BM_LIV_ST_BMS_4 %= 0x10;
	  
   break;
   }
/////////////////////////////////////////////////////////////////////////
    default:
    break;
  }

}

/*******************************************************************************
* NAME:             Com_RxTOIndication
* CALLED BY:        Com
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void 
* DESCRIPTION:       
*******************************************************************************/
_STATIC_ void COM_CODE Com_RxTOIndication(PduIdType PduId)   //��ʱ�ص�������ʱ����ô˺��� ����Ĺ����Զ��� ���־λ��1 ���ͱ���
{  
  switch(PduId)
  {
/* Vehicle Bus */
    case COM_RX_CCP1_MSG:
    {
#if (COM_ERROR_VALUE_SET == STD_ON)
      com_CCP1HwFault = COM_SIG_ERR_2BITS;
      com_CCP1ACConnect = COM_SIG_ERR_2BITS;
      com_CCP1TempSts = COM_SIG_ERR_2BITS;
      com_CCP1CommSts = COM_SIG_ERR_2BITS;
      com_CCP1ACRange = COM_SIG_ERR_BYTE;
      com_CCP1ChrgrTemp = COM_SIG_ERR_BYTE;
      com_CCP1ChrgrPreReadySts = COM_SIG_ERR_2BITS; 
      com_CCP1ChrgCurrOut = COM_SIG_ERR_WORD;
      com_CCP1ChrgVolt = COM_SIG_ERR_WORD; 
#endif
    }
    break;
    
    case COM_RX_MSP1_MSG:
    {
#if (COM_ERROR_VALUE_SET == STD_ON)
      com_MSP1MotorDcVolt = COM_SIG_ERR_WORD; 
      com_MSP1MotorDcCurr = COM_SIG_ERR_WORD;
#endif
    }
    break;

    case COM_RX_MSP3_MSG:
    {
#if (COM_ERROR_VALUE_SET == STD_ON)
      com_MSP3MotorTrq = COM_SIG_ERR_BYTE;
      com_MSP3MotorSpd = COM_SIG_ERR_WORD; 
#endif
    }
    break;

    case COM_RX_VD_MSG:
    {
#if (COM_ERROR_VALUE_SET == STD_ON)
      com_VDTotalOdometer = COM_SIG_ERR_LONG;
      com_VDTripOdometer = COM_SIG_ERR_LONG;
#endif
    }
    break;  
    
/* Fast charger */

    case COM_RX_CC_MSG:
    {
#if (COM_ERROR_VALUE_SET == STD_ON)
      com_CCMaxChrgVolt = COM_SIG_ERR_WORD;   

      com_CCMaxChrgCurr = COM_SIG_ERR_WORD;   

      com_CCChrgSts = COM_SIG_ERR_BYTE;  
#endif
    }
    break;  

    case COM_RX_CS_MSG:
    {
#if (COM_ERROR_VALUE_SET == STD_ON)      
      com_CSOutVolt = COM_SIG_ERR_WORD;;
      com_CSOutCurrent = COM_SIG_ERR_WORD;;
      com_CSStatus1 = COM_SIG_ERR_WORD;;
      com_CSStatus2 = COM_SIG_ERR_WORD;;      
#endif
    }
    break;                    
      
/* Inner Bus */
    case COM_RX_HVA1_MSG:
    {
#if (COM_ERROR_VALUE_SET == STD_ON)
      com_hva1Alarm = COM_SIG_ERR_LONG;
      com_hva1ModuleSts = COM_SIG_ERR_BYTE;
      com_hva1FaultCode = COM_SIG_ERR_WORD;   
#endif      
      
      com_RxHvcuFirst = TRUE; 
    }
    break;

    case COM_RX_HVM1_MSG:
    {
#if (COM_ERROR_VALUE_SET == STD_ON)
      com_SOC = COM_SIG_ERR_BYTE;
      com_BattVoltOrg = COM_SIG_ERR_WORD;
      com_BattCurr = COM_SIG_ERR_WORD;   
      com_Resistance = COM_SIG_ERR_WORD; 
      Dem_SetError( DTC_IDX_HVCU_COMERR, 1);   //20150831 ��ѹ��ͨѶ��ʱ
#endif
    }
    break;

	//ISO���� 
	case CON_RX_ISO_MSG:
    {
		com_ResistancePos = COM_SIG_ERR_WORD; 
		com_ResistanceNeg = COM_SIG_ERR_WORD; 
    }
    break;
	//BMU1
    case COM_RX_M1CMT_MSG:
    {
      Com_SetBmuCmtSigErr(0);  
    }
    break;

    case COM_RX_M1STS1_MSG:
    {
      Com_SetBmuSts1SigErr(0);       
      BMU_NoActive[0]=1;
      Dem_SetError( DTC_IDX_BMU1_COMERR, 1);   //20150831 BMU1ͨѶ��ʱ          
    }
    break;
    
    case COM_RX_M1STS2_MSG:
    {
      Com_SetBmuSts2SigErr(0);               
    }
    break;    

    case COM_RX_M2CMT_MSG:
    {
      Com_SetBmuCmtSigErr(1);  
    }
    break;

    case COM_RX_M2STS1_MSG:
    {
      Com_SetBmuSts1SigErr(1);      
      if(Cell_Module_Num>=2) 
      {        
		BMU_NoActive[1]=1;
        Dem_SetError( DTC_IDX_BMU2_COMERR, 1);   //20150831 BMUͨѶ��ʱ 
      }
    }
    break;
    
    case COM_RX_M2STS2_MSG:
    {
      Com_SetBmuSts2SigErr(1);             
    }
    break; 

    case COM_RX_M3CMT_MSG:
    {
      Com_SetBmuCmtSigErr(2); 
    }
    break;

    case COM_RX_M3STS1_MSG:
    {
      Com_SetBmuSts1SigErr(2);       
      if(Cell_Module_Num>=3) 
      {
        BMU_NoActive[2]=1;
        Dem_SetError( DTC_IDX_BMU3_COMERR, 1);   //20150831 BMUͨѶ          
      }
    }
    break;
    
    case COM_RX_M3STS2_MSG:
    {
      Com_SetBmuSts2SigErr(2);           
    }
    break; 
    
    case COM_RX_M4CMT_MSG:
    {
		Com_SetBmuCmtSigErr(3);
    }
    break;

    case COM_RX_M4STS1_MSG:
    {
      Com_SetBmuSts1SigErr(3);
      if(Cell_Module_Num>=4) 
      {            
        BMU_NoActive[3]=1;
        Dem_SetError( DTC_IDX_BMU4_COMERR, 1);   //20150831 BMUͨѶ��ʱ
      }
    }
    break;
    
    case COM_RX_M4STS2_MSG:
    {
      Com_SetBmuSts2SigErr(3);           
    }
    break;     
    
    //add 20150805  BMU5~12
    case COM_RX_M5CMT_MSG:
    {
      Com_SetBmuCmtSigErr(4);
    }
    break;

    case COM_RX_M5STS1_MSG:
    {
      Com_SetBmuSts1SigErr(4);       
      if(Cell_Module_Num>=5) 
      {           
        BMU_NoActive[4]=1;
        Dem_SetError( DTC_IDX_BMU5_COMERR, 1);   //20150831 BMUͨѶ��ʱ  
      }
    }
    break;
    
    case COM_RX_M5STS2_MSG:
    {
      Com_SetBmuSts2SigErr(4);             
    }
    break;  
    case COM_RX_M6CMT_MSG:
    {
      Com_SetBmuCmtSigErr(5); 
    }
    break;

    case COM_RX_M6STS1_MSG:
    {
      Com_SetBmuSts1SigErr(5);       
      if(Cell_Module_Num>=6) 
      {         
        BMU_NoActive[5]=1; 
        Dem_SetError( DTC_IDX_BMU6_COMERR, 1);   //20150831 BMUͨѶ��ʱ 
      }
    }
    break;
    
    case COM_RX_M6STS2_MSG:
    {
      Com_SetBmuSts2SigErr(5);             
    }
    break;  
    case COM_RX_M7CMT_MSG:
    {
      Com_SetBmuCmtSigErr(6);
    }
    break;

    case COM_RX_M7STS1_MSG:
    {
      Com_SetBmuSts1SigErr(6);       
      if(Cell_Module_Num>=7) 
      {         
        BMU_NoActive[6]=1;
        Dem_SetError( DTC_IDX_BMU7_COMERR, 1);   //20150831 BMUͨѶ��ʱ
      }
    }
    break;
    
    case COM_RX_M7STS2_MSG:
    {
      Com_SetBmuSts2SigErr(6);             
    }
    break;  
    case COM_RX_M8CMT_MSG:
    {
      Com_SetBmuCmtSigErr(7); 
    }
    break;

    case COM_RX_M8STS1_MSG:
    {
      Com_SetBmuSts1SigErr(7);       
      if(Cell_Module_Num>=8) 
      {        
        BMU_NoActive[7]=1;
        Dem_SetError( DTC_IDX_BMU8_COMERR, 1);   //20150831 BMUͨѶ��ʱ  
      }
    }
    break;
    
    case COM_RX_M8STS2_MSG:
    {
      Com_SetBmuSts2SigErr(7);             
    }
    break;  
    case COM_RX_M9CMT_MSG:
    {
      Com_SetBmuCmtSigErr(8); 
    }
    break;

    case COM_RX_M9STS1_MSG:
    {
      Com_SetBmuSts1SigErr(8);       
      if(Cell_Module_Num>=9) 
      {        
        BMU_NoActive[8]=1;
        Dem_SetError( DTC_IDX_BMU9_COMERR, 1);   //20150831 BMUͨѶ��ʱ
      }
    }
    break;
    
    case COM_RX_M9STS2_MSG:
    {
      Com_SetBmuSts2SigErr(8);             
    }
    break;  
    case COM_RX_M10CMT_MSG:
    {
      Com_SetBmuCmtSigErr(9);  
    }
    break;

    case COM_RX_M10STS1_MSG:
    {
      Com_SetBmuSts1SigErr(9);       
      if(Cell_Module_Num>=10) 
      {        
        BMU_NoActive[9]=1;
        Dem_SetError( DTC_IDX_BMU10_COMERR, 1);   //20150831 BMUͨѶ��ʱ  
      }
    }
    break;
    
    case COM_RX_M10STS2_MSG:
    {
      Com_SetBmuSts2SigErr(9);             
    }
    break;  
    case COM_RX_M11CMT_MSG:
    {
      Com_SetBmuCmtSigErr(10);  
    }
    break;

    case COM_RX_M11STS1_MSG:
    {
      Com_SetBmuSts1SigErr(10);       
      if(Cell_Module_Num>=11) 
      {        
        BMU_NoActive[10]=1; 
        Dem_SetError( DTC_IDX_BMU11_COMERR, 1);   //20150831 BMUͨѶ��ʱ  
      }
    }
    break;
    
    case COM_RX_M11STS2_MSG:
    {
      Com_SetBmuSts2SigErr(10);             
    }
    break;  
	
    case COM_RX_M12CMT_MSG:
    {
      Com_SetBmuCmtSigErr(11);
    }
    break;

    case COM_RX_M12STS1_MSG:
    {
      Com_SetBmuSts1SigErr(11);       
      if(Cell_Module_Num>=12) 
      {         
        BMU_NoActive[11]=1;  
        Dem_SetError( DTC_IDX_BMU12_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M12STS2_MSG:
    {
      Com_SetBmuSts2SigErr(11);             
    }
    break;  
	
    case COM_RX_M13CMT_MSG:
    {
      Com_SetBmuCmtSigErr(12);
    }
    break;

    case COM_RX_M13STS1_MSG:
    {
      Com_SetBmuSts1SigErr(12);       
      if(Cell_Module_Num>=13) 
      {         
        BMU_NoActive[12]=1;  
        Dem_SetError( DTC_IDX_BMU13_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M13STS2_MSG:
    {
      Com_SetBmuSts2SigErr(12);             
    }
    break;  
	
    case COM_RX_M14CMT_MSG:
    {
      Com_SetBmuCmtSigErr(13);
    }
    break;

    case COM_RX_M14STS1_MSG:
    {
      Com_SetBmuSts1SigErr(13);       
      if(Cell_Module_Num>=14) 
      {         
        BMU_NoActive[13]=1;  
        Dem_SetError( DTC_IDX_BMU14_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M14STS2_MSG:
    {
      Com_SetBmuSts2SigErr(13);             
    }
    break;  
	
    case COM_RX_M15CMT_MSG:
    {
      Com_SetBmuCmtSigErr(14);
    }
    break;

    case COM_RX_M15STS1_MSG:
    {
      Com_SetBmuSts1SigErr(14);       
      if(Cell_Module_Num>=15) 
      {         
        BMU_NoActive[14]=1;  
        Dem_SetError( DTC_IDX_BMU15_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M15STS2_MSG:
    {
      Com_SetBmuSts2SigErr(14);             
    }
    break;  
	
    case COM_RX_M16CMT_MSG:
    {
      Com_SetBmuCmtSigErr(15);
    }
    break;

    case COM_RX_M16STS1_MSG:
    {
      Com_SetBmuSts1SigErr(15);       
      if(Cell_Module_Num>=16) 
      {         
        BMU_NoActive[15]=1;  
        Dem_SetError( DTC_IDX_BMU16_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M16STS2_MSG:
    {
      Com_SetBmuSts2SigErr(15);             
    }
    break;  
	
    case COM_RX_M17CMT_MSG:
    {
      Com_SetBmuCmtSigErr(16);
    }
    break;

    case COM_RX_M17STS1_MSG:
    {
      Com_SetBmuSts1SigErr(16);       
      if(Cell_Module_Num>=17) 
      {         
        BMU_NoActive[16]=1;  
        Dem_SetError( DTC_IDX_BMU17_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M17STS2_MSG:
    {
      Com_SetBmuSts2SigErr(16);             
    }
    break;  
	
    case COM_RX_M18CMT_MSG:
    {
      Com_SetBmuCmtSigErr(17);
    }
    break;

    case COM_RX_M18STS1_MSG:
    {
      Com_SetBmuSts1SigErr(17);       
      if(Cell_Module_Num>=18) 
      {         
        BMU_NoActive[17]=1;  
        Dem_SetError( DTC_IDX_BMU18_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M18STS2_MSG:
    {
      Com_SetBmuSts2SigErr(17);             
    }
    break;  
	
    case COM_RX_M19CMT_MSG:
    {
      Com_SetBmuCmtSigErr(18);
    }
    break;

    case COM_RX_M19STS1_MSG:
    {
      Com_SetBmuSts1SigErr(18);       
      if(Cell_Module_Num>=19) 
      {         
        BMU_NoActive[18]=1;  
        Dem_SetError( DTC_IDX_BMU19_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M19STS2_MSG:
    {
      Com_SetBmuSts2SigErr(18);             
    }
    break;  
	
    case COM_RX_M20CMT_MSG:
    {
      Com_SetBmuCmtSigErr(19);
    }
    break;

    case COM_RX_M20STS1_MSG:
    {
      Com_SetBmuSts1SigErr(19);       
      if(Cell_Module_Num>=20) 
      {         
        BMU_NoActive[19]=1;  
        Dem_SetError( DTC_IDX_BMU20_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M20STS2_MSG:
    {
      Com_SetBmuSts2SigErr(19);             
    }
    break;  
	
    case COM_RX_M21CMT_MSG:
    {
      Com_SetBmuCmtSigErr(20);
    }
    break;

    case COM_RX_M21STS1_MSG:
    {
      Com_SetBmuSts1SigErr(20);       
      if(Cell_Module_Num>=21) 
      {         
        BMU_NoActive[20]=1;  
        Dem_SetError( DTC_IDX_BMU21_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M21STS2_MSG:
    {
      Com_SetBmuSts2SigErr(20);             
    }
    break;  
	
    case COM_RX_M22CMT_MSG:
    {
      Com_SetBmuCmtSigErr(21);
    }
    break;

    case COM_RX_M22STS1_MSG:
    {
      Com_SetBmuSts1SigErr(21);       
      if(Cell_Module_Num>=22) 
      {         
        BMU_NoActive[21]=1;  
        Dem_SetError( DTC_IDX_BMU22_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M22STS2_MSG:
    {
      Com_SetBmuSts2SigErr(21);             
    }
    break;  
	
    case COM_RX_M23CMT_MSG:
    {
      Com_SetBmuCmtSigErr(22);
    }
    break;

    case COM_RX_M23STS1_MSG:
    {
      Com_SetBmuSts1SigErr(22);       
      if(Cell_Module_Num>=23) 
      {         
        BMU_NoActive[22]=1;  
        Dem_SetError( DTC_IDX_BMU23_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M23STS2_MSG:
    {
      Com_SetBmuSts2SigErr(22);             
    }
    break;  
	
    case COM_RX_M24CMT_MSG:
    {
      Com_SetBmuCmtSigErr(23);
    }
    break;

    case COM_RX_M24STS1_MSG:
    {
      Com_SetBmuSts1SigErr(23);       
      if(Cell_Module_Num>=24) 
      {         
        BMU_NoActive[23]=1;  
        Dem_SetError( DTC_IDX_BMU24_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M24STS2_MSG:
    {
      Com_SetBmuSts2SigErr(23);             
    }
    break;  
	
    case COM_RX_M25CMT_MSG:
    {
      Com_SetBmuCmtSigErr(24);
    }
    break;

    case COM_RX_M25STS1_MSG:
    {
      Com_SetBmuSts1SigErr(24);       
      if(Cell_Module_Num>=25) 
      {         
        BMU_NoActive[24]=1;  
        Dem_SetError( DTC_IDX_BMU25_COMERR, 1);   //20150831 BMUͨѶ��ʱ   
      }
    }
    break;
    
    case COM_RX_M25STS2_MSG:
    {
      Com_SetBmuSts2SigErr(24);             
    }
    break;  

  
	case COM_RX_RESERVE1_MSG:
	{
		;
	}
	break;
  
  /////////////////////////////////////      
    case COM_RX_CRM_MSG:
    {
      //com_CRMTimeoutFlag = TRUE; //20150920 cancel                
    }
    break;     

    case COM_RX_CTS_MSG:
    {
      com_CTSTimeoutFlag = TRUE;                            
    }
    break;     

    case COM_RX_CML_MSG:
    {
      com_CMLTimeoutFlag = TRUE;                                  
    }
    break;     

    case COM_RX_CRO_MSG:
    {
      com_CROTimeoutFlag = TRUE;                           
    }
    break;     

    case COM_RX_CCS_MSG:
    {
      com_CCSTimeoutFlag = TRUE;                                  
    }
    break;     

    case COM_RX_CST_MSG:
    {
      com_CSTTimeoutFlag = TRUE;                            
    }
    break;     

    case COM_RX_CSD_MSG:
    {
      com_CSDTimeoutFlag = TRUE;                                  
    }
    break;     

    case COM_RX_CEM_MSG:
    {
      com_CEMTimeoutFlag = TRUE;                            
    }
    break;     
    //add 20150805�����������ĳ�ʱ !!!!!!Ŀǰ����ô��  �����Ľ� ���Ϻܹؼ�
    case COM_RX_MB_ST_VMS_3:
    {
      com_RelayTimeoutFlag = TRUE; //����ʵ��Ҫ��ΪTRUE 
     // Dem_SetError( DTC_IDX_VEH_COMERR, 1);   //Ŀǰ������!!!!!!20150831 ����ͨѶ��ʱ                           
    } 

    default:
    break;
  }
}

//==========================================================================
//��������:void Com_SetBmuCmtSig(VOID)
//��������:����屨�Ľ�������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�PduInfoPtr���ձ���
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuCmtSig(uint8 index,const PduInfoType* PduInfoPtr)
{
  uint8 count;
  
  for (count = 0; count < Temp_Number; count++)
  {
    com_CellTemp[index][count] = PduInfoPtr->SduDataPtr[count]; 
  }  
}
  
  


//==========================================================================
//��������:void Com_SetBmuSts1Sig(VOID)
//��������:����屨�Ľ�������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�PduInfoPtr���ձ���
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuSts1Sig(uint8 index,const PduInfoType* PduInfoPtr)
{
  com_ModuleStatus[index] = PduInfoPtr->SduDataPtr[0] & 0x07;
  com_BalanceSts[index]= (PduInfoPtr->SduDataPtr[0] & 0x70)>>4;
  com_CurSet[index] = PduInfoPtr->SduDataPtr[1];
  com_CellTempAvrg[index] = PduInfoPtr->SduDataPtr[2]; 
  com_CellTempMax[index] = PduInfoPtr->SduDataPtr[3];
  com_CellTempMin[index] = PduInfoPtr->SduDataPtr[4];
  com_CellTempMaxNum[index] = PduInfoPtr->SduDataPtr[5] & 0x0F; 
  com_CellTempMinNum[index]= (PduInfoPtr->SduDataPtr[5] & 0xF0)>>4;

  com_CellAlarm[index] = PduInfoPtr->SduDataPtr[6]; 
  
  com_BmuMsgCnt[index] =  PduInfoPtr->SduDataPtr[7];
  Com_ChkBmuMsgCnt(index);
}

//==========================================================================
//��������:void Com_SetBmuSts2Sig(VOID)
//��������:����屨�Ľ�������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�PduInfoPtr���ձ���
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuSts2Sig(uint8 index,const PduInfoType* PduInfoPtr)
{  
  OneWordUnionType wdata;
  
  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];        
  com_CellVoltAvrg[index] = wdata.WORD;   

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];        
  com_CellVoltMax[index] = wdata.WORD;  

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[4];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[5];        
  com_CellVoltMin[index] = wdata.WORD;  

  com_CellVoltMaxNum[index] = PduInfoPtr->SduDataPtr[6] & 0x0F; 
  com_CellVoltMinNum[index]= (PduInfoPtr->SduDataPtr[6] & 0xF0)>>4;  
}

//==========================================================================
//��������:void Com_SetBmuCV1(VOID)
//��������:����屨�Ľ�������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�PduInfoPtr���ձ���
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuCV1(uint8 index,const PduInfoType* PduInfoPtr)
{
  OneWordUnionType wdata;
  
  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];        
  com_CellVoltCur[index][0] = wdata.WORD;   

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];     
  com_CellVoltCur[index][1] = wdata.WORD;   

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[4];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[5];     
  com_CellVoltCur[index][2] = wdata.WORD;    
  
  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[6];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[7];     
  com_CellVoltCur[index][3] = wdata.WORD;   
}  

//==========================================================================
//��������:void Com_SetBmuCV2(VOID)
//��������:����屨�Ľ�������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�PduInfoPtr���ձ���
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuCV2(uint8 index,const PduInfoType* PduInfoPtr)
{
  OneWordUnionType wdata;
  
  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];        
  com_CellVoltCur[index][4] = wdata.WORD;   

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];     
  com_CellVoltCur[index][5] = wdata.WORD;   

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[4];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[5];     
  com_CellVoltCur[index][6] = wdata.WORD;    
  
  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[6];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[7];     
  com_CellVoltCur[index][7] = wdata.WORD;   
}

//==========================================================================
//��������:void Com_SetBmuCV3(VOID)
//��������:����屨�Ľ�������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�PduInfoPtr���ձ���
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuCV3(uint8 index,const PduInfoType* PduInfoPtr)
{
  OneWordUnionType wdata;
  
  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];        
  com_CellVoltCur[index][8] = wdata.WORD;   

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];     
  com_CellVoltCur[index][9] = wdata.WORD;   

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[4];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[5];     
  com_CellVoltCur[index][10] = wdata.WORD;    
  
  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[6];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[7];     
  com_CellVoltCur[index][11] = wdata.WORD;   
}

//==========================================================================
//��������:void Com_SetBmuCV4(VOID)
//��������:����屨�Ľ�������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�PduInfoPtr���ձ���
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuCV4(uint8 index,const PduInfoType* PduInfoPtr)
{
  /*OneWordUnionType wdata;
  
  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[0];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[1];        
  com_CellVoltCur[index][12] = wdata.WORD;   

  wdata.Bytes.LowByte = PduInfoPtr->SduDataPtr[2];
  wdata.Bytes.HighByte = PduInfoPtr->SduDataPtr[3];     
  com_CellVoltCur[index][13] = wdata.WORD;  */ 
}

//==========================================================================
//��������:void Com_SetBmuCmtSigErr(VOID)
//��������:�����ͨѶ��ʱ������ݳ�ʼ������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuCmtSigErr(uint8 index)
{
  uint8 count;
 
#if (COM_ERROR_VALUE_SET == STD_ON)  
  
  for (count = 0; count < Temp_Number; count++)
  {
    com_CellTemp[index][count] = COM_SIG_ERR_BYTE; 
  } 

#endif
}

//==========================================================================
//��������:void Com_SetBmuSts1SigErr(VOID)
//��������:�����ͨѶ��ʱ������ݳ�ʼ������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuSts1SigErr(uint8 index)
{  
#if (COM_ERROR_VALUE_SET == STD_ON)  
  com_ModuleStatus[index] = COM_SIG_ERR_BYTE;
  com_BalanceSts[index]= COM_SIG_ERR_BYTE;
  com_CurSet[index] = COM_SIG_ERR_BYTE;
  com_CellTempAvrg[index] = COM_SIG_ERR_BYTE; 
  com_CellTempMax[index] = COM_SIG_ERR_BYTE;
  com_CellTempMin[index] = COM_SIG_ERR_BYTE;
  com_CellTempMaxNum[index] = COM_SIG_ERR_BYTE; 
  com_CellTempMinNum[index]= COM_SIG_ERR_BYTE;
  com_CellAlarm[index] = COM_SIG_ERR_BYTE;   
#endif
}

//==========================================================================
//��������:void Com_SetBmuSts2SigErr(VOID)
//��������:�����ͨѶ��ʱ������ݳ�ʼ������������汾����������汾������Ϣ���ڲ���
//�������:index�������ţ�
//�������:��
//��������:Com_RxIndication()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetBmuSts2SigErr(uint8 index)
{ 
#if (COM_ERROR_VALUE_SET == STD_ON)        
  com_CellVoltAvrg[index] = COM_SIG_ERR_WORD;
  com_CellVoltMax[index] = COM_SIG_ERR_WORD;
  com_CellVoltMin[index] = COM_SIG_ERR_WORD;
  com_CellVoltMaxNum[index] = COM_SIG_ERR_BYTE;
  com_CellVoltMinNum[index] = COM_SIG_ERR_BYTE;    
#endif
}

//==========================================================================
//��������:void Com_Setccp1SigNA(VOID)
//��������:ͨѶ���ݳ�ʼ��
//�������:��
//�������:��
//��������:Com_Init()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_Setccp1SigNA(void)
{
  com_CCP1HwFault = COM_SIG_NA_2BITS;
  com_CCP1ACConnect = COM_SIG_NA_2BITS;
  com_CCP1CommSts = COM_SIG_NA_2BITS;
  com_CCP1TempSts = COM_SIG_NA_2BITS;
  com_CCP1ChrgCurrOut = COM_SIG_NA_WORD;
  com_CCP1ChrgVolt = COM_SIG_NA_WORD;  
  com_CCP1ChrgrPreReadySts = COM_SIG_NA_2BITS;  
  com_CCP1ChrgrTemp = COM_SIG_NA_BYTE;  
  com_CCP1ACRange = COM_SIG_NA_BYTE;      
}

//==========================================================================
//��������:void Com_SetVehicleBusSigNA(VOID)
//��������:ͨѶ���ݳ�ʼ��
//�������:��
//�������:��
//��������:Com_Init()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetVehicleBusSigNA(void)
{
  com_MSP3MotorTrq = COM_SIG_NA_BYTE;//8λ 
  com_MSP3MotorSpd = COM_SIG_NA_WORD;//16λ

  com_MSP1MotorDcVolt = COM_SIG_NA_WORD;
  com_MSP1MotorDcCurr = COM_SIG_NA_WORD;

  com_VDTotalOdometer = COM_SIG_NA_LONG;//32λ
  com_VDTripOdometer = COM_SIG_NA_LONG;
  
  // add 20150805 !!!!!!
/* //St_BMS_1
 BM_CRC_BMS_ST_01;//CRCֵ   8λ
 BM_Live_BMS_ST_01;//����֡ 4λ
 BM_Fault_Level;//��ذ����󼶱� ������������ 4λ
 BM_Battery_Charge_Power_Available;//8λ  ��ذ�������繦��  KW  0.5�ֱ���
 BM_Battery_Discharge_Power_Available;//8λ  ��ذ������ķŵ繦��  KW 0.5�ֱ���    
 BM_Battery_Energry_Avarable;//16λ �����ʱ����ڵ��ֽ� ��ذ�ʣ������ KWH  0.1�ֱ���
 BM_Battery_SOC;//SOCֵ  1%
 BM_Battery_User_SOC;//��ʾSOC  ��Battery_SOCһ��

//MB_ST_BMS_2_tag
 BM_Battery_Current;//16λ  ��ذ����� A 0.1�ֱ���
 BM_Battery_Voltage;//16λ  ��ذ��ܵ�ѹ  1V
 BM_Battery_Avg_T;//8λ ���ƽ���¶�
 BM_Battery_Max_T;//8λ �������¶�
 BM_Battery_Min_T;//8λ �������¶�
 BM_Battery_SOH=50;//8λ BMSδʵ�ָù��� ��Ϊ100%

//MB_ST_BMS_3_tag
 BM_ST_ERR_Charge_Over_Current;//2λ ���������󱨾� 0--���� 1--һ�� 2--���� 3--����
 BM_ST_ERR_DisChgrge_Over_Current;//2λ �ŵ�������󱨾� 0--���� 1--һ�� 2--���� 3--����
 BM_ST_ERR_Cell_Over_Voltage;//2λ ��оǷѹ���� 0--���� 1--һ�� 2--����
 BM_ST_ERR_Cell_Under_Voltage;//2λ ��о��ѹ���� 0--���� 1--һ�� 2--���� 
 
 BM_ST_ERR_Battery_Over_Voltage;//2λ �ܵ�ѹ���߱��� 0--���� 1--һ�� 2--����
 BM_ST_ERR_Battery_Under_Voltage;//2λ �ܵ�ѹ���ͱ��� 0--���� 1--һ�� 2--����
 BM_ST_ERR_Cell_Voltage_Uniformity;//2λ �������������
 BM_ST_ERR_Over_Temperature;//2λ �¶ȹ��߱��� 0--���� 1--һ�� 2--����
 
 BM_ST_ERR_Low_Temperature;//2λ �¶ȹ��ͱ��� 0--���� 1--һ�� 2--����
 BM_ST_ERR_Over_SOC;//2λ SOC����  0--���� 1--һ�� 2--����
 BM_ST_ERR_Low_SOC;//2λ SOC����  0--���� 1--һ�� 2--����
 BM_ST_ERR_Insulation_Resistance;//2λ ��Ե���� 
 
 BM_ST_ERR_CAN_Communication_Fault;//1λ �ڲ�CAN
 BM_ST_ERR_Cell_Voltage_Sensor_Fault;//1λ ��������쳣 0--���� 1--�쳣
 BM_ST_ERR_Temperature_Sensor_Fault;//1λ �¶Ȳ����쳣 0--���� 1--�쳣
 BM_ST_ERR_Current_Sensor_Fault;//2λ ���������쳣 0--���� 1--��· 2--��· 3--����

//MB_ST_BMS_4_tag
 BM_CRC_ST_BMS_4; //8λ CRC
 BM_LIV_ST_BMS_4;//4λ ����֡��	ÿ�μ�1  ��15��Ϊ0
 BM_ST_HV_Online;//1λ ��ذ��ϵ�״̬�� 0 "Power Off" 1 "Power On"
 BM_ST_HV_Positive_Relay1;//1λ �����̵���1״̬�� 0 "open" 1 "close"
 BM_ST_HV_Positive_Relay2;//1λ û��  �����̵���2״̬�� 0 "open" 1 "close"
 BM_ST_HV_Positive_Relay3;//1λ û��  �����̵���3״̬�� 0 "open" 1 "close"
 BM_ST_HV_Positive_Relay_FaultStatus;//1λ �����̵�������״̬�� 0 "No faut" 1 "Fault"
 BM_ST_HV_Negative_Relay;//2λ �����̵���״̬��0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"
 BM_ST_Precharge_Relay;//2λ Ŀǰ���ã�Ԥ��̵���״̬�� 0 "Open"  1 "Closed"  2 "Fault"  3 "Reserved"	
 BM_ST_FCharge_Positive_Relay;//1λ ����!!!������̵���״̬�� 0 "Open" 1 "Closed"
 BM_ST_SCharge_Positive_Relay;//1λ ����  �������̵���״̬�� 0 "Open" 1 "Closed"
 BM_ST_Charge_Negative_Relay;//1λ ����  �为�̵���״̬(�������乫�ø����̵���)��  0 "Open" 1 "Closed"
 BM_ST_Healting_Relay;//1λ ����  ���ȼ̵���״̬��  0 "Open" 1 "Closed"
 BM_ST_Charging;   //2λ ����!!!���״̬�źš� 0"No charging"   1 "Charging"  2 "Chargefinished"  
 BM_ST_Cooling_Relay;// 1λ 
 
 
 //MS_3
 BM_CMD_HV_Power;//�������������͵ĸ�ѹ���µ�ָ�0 "Open HV Switch" 1 "Open HV switchurgently" 2 "Close HV switch" 3 "Keepcurrent state"

 */
}

//==========================================================================
//��������:void Com_SetFastChrgrSigNA(VOID)
//��������:ͨѶ���ݳ�ʼ��
//�������:��
//�������:��
//��������:Com_Init()�е���
//==========================================================================
_STATIC_ void COM_CODE Com_SetFastChrgrSigNA(void)
{
  com_CSOutVolt = COM_SIG_NA_WORD;;
  com_CSOutCurrent = COM_SIG_NA_WORD;;
  com_CSStatus1 = COM_SIG_NA_WORD;;
  com_CSStatus2 = COM_SIG_NA_WORD;;

  com_CCMaxChrgVolt = COM_SIG_NA_WORD;;
  com_CCMaxChrgCurr = COM_SIG_NA_WORD;;
  com_CCChrgSts = COM_SIG_NA_BYTE;;

}
