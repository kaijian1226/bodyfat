/*******************************************************************************
*
*  FILE
*     CanIf_Cbk.h
*                
*  DESCRIPTION
*     Can interface call back header file
*      
*                        
*  COPYRIGHT
*     
*     All rights reserved.              
*
*  AUTHOR                      
*    
*
*  VERSION              
*    1.1.0                                               
*
*******************************************************************************/

#ifndef _CANIF_CBK_H_
#define _CANIF_CBK_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/


/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

extern FUNC(void,CANIF_CODE) CanIf_TxConfirmation(Can_CntrlType controller);
extern FUNC(void,CANIF_CODE) CanIf_CancelTxConfirmation(Can_CntrlType controller);


extern FUNC(void,CANIF_CODE) CanIf_RxIndication(uint8 Hrh,Can_IdType CanId,uint8 CanDlc,const uint8* CanSduPtr);

extern FUNC(void,CANIF_CODE) CanIf_ControllerBusOff(Can_CntrlType controller);
extern FUNC(void,CANIF_CODE) CanIf_ControllerWakeup(Can_CntrlType controller);

#endif /* #ifndef _CANIF_CBK_H_ */

