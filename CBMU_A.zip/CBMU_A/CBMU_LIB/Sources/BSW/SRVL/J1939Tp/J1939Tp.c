#include "J1939Tp.h"
#include "CanIf.h"          
#include "J1939Tp_Cbk.h"
#include "J1939Tp_Internal.h"
#include <string.h>
#include "Com_Cbk.h"
#include "Com_Cfg.h"
                                     
#include <assert.h>        
#include "VFB.h"    

//#define J1939_ASSERT( _exp )   if( !(_exp) ) { while (1) {}; }
//#define J1939_ASSERT( _exp )   assert(_exp)//for debug
#define J1939_ASSERT( _exp )    //for release


static J1939Tp_Internal_GlobalStateInfoType globalState = {
		/* .State = */ J1939TP_OFF,
};
static const J1939Tp_ConfigType* J1939Tp_ConfigPtr;
static J1939Tp_Internal_ChannelInfoType channelInfos[J1939TP_CHANNEL_COUNT];
static J1939Tp_Internal_TxChannelInfoType txChannelInfos[J1939TP_TX_CHANNEL_COUNT];
static J1939Tp_Internal_RxChannelInfoType rxChannelInfos[J1939TP_RX_CHANNEL_COUNT];
static J1939Tp_Internal_PgInfoType pgInfos[J1939TP_PG_COUNT];

static J1939Tp_ConfigType* ConfigPtr;


void J1939Tp_Init(void) 
{
	uint8 i;
  uint8 rxCount = 0;
	uint8 txCount = 0;
	
	ConfigPtr = &J1939Tp_Config;
	
	//Ѱ��TP��������
	for (i = 0; i < J1939TP_CHANNEL_COUNT; i++) 
	{
		if (ConfigPtr->Channels[i].Direction == J1939TP_TX) 
		{
			channelInfos[i].ChannelConfPtr = &(ConfigPtr->Channels[i]);
			channelInfos[i].TxState = &(txChannelInfos[txCount]);
			channelInfos[i].TxState->State = J1939TP_TX_IDLE;
			channelInfos[i].RxState = 0;
			txCount++;
		} 
		else if (ConfigPtr->Channels[i].Direction == J1939TP_RX) 
		{
			channelInfos[i].ChannelConfPtr = &(ConfigPtr->Channels[i]);
			channelInfos[i].TxState = 0;
			channelInfos[i].RxState = &(rxChannelInfos[rxCount]);
			channelInfos[i].RxState->State = J1939TP_RX_IDLE;
			rxCount++;
		} 
		else 
		{
			J1939_ASSERT( 0 );
			return; // unexpected
		}
	}
	for (i = 0; i < J1939TP_PG_COUNT; i++) 
	{
	  uint8 channelIndex;
		pgInfos[i].PgConfPtr = &(ConfigPtr->Pgs[i]);
		channelIndex = ConfigPtr->Pgs[i].Channel - ConfigPtr->Channels;
		pgInfos[i].ChannelInfoPtr = &(channelInfos[channelIndex]);
		pgInfos[i].TxState = J1939TP_PG_TX_IDLE;
	}
	J1939Tp_ConfigPtr = ConfigPtr;
	globalState.State = J1939TP_ON; 
}


//������պ���
void J1939Tp_RxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr) 
{
	if (globalState.State == J1939TP_ON) 
	{
		uint8 i;
		const J1939Tp_PduInfoType* RxPduInfo;
		J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr;

    //here fix a big bug in OpenSAR source code,use GetPduInfo instead GetRxPduRelationsInfo
		//if (J1939Tp_Internal_GetPduInfo(RxPduId, RxPduInfo) == E_OK) 
	  for(i=0; i<J1939TP_RX_PDU_COUNT; i++)
    {				
	    if (RxPduId == J1939Tp_ConfigPtr->PduInfo[i].PduId ) 
  	  {
    		RxPduInfo = &(J1939Tp_ConfigPtr->PduInfo[i]);
  	  }
  	  else
  	  {
    		continue;
  	  }
			SuspendAllInterrupts();//modified by xyl 2015-7-17
			//RxPduInfo = RxPduRelationsInfo->RxPdus[i];
			ChannelInfoPtr = J1939Tp_Internal_GetChannelState(RxPduInfo);
			//!<=================================================
			//!<  modified by xyl 2015-7-16 
			//!<  RxIndication have 2 case,  TxChannel and RxChannel
			//!<  2 switch both OK! 
			switch (ChannelInfoPtr->ChannelConfPtr->Direction) 
			{
				case J1939TP_TX:
					J1939Tp_Internal_RxIndication_TxChannel(ChannelInfoPtr, RxPduInfo,PduInfoPtr);
					break;
				case J1939TP_RX:
					J1939Tp_Internal_RxIndication_RxChannel(ChannelInfoPtr, RxPduInfo,PduInfoPtr);
					break;
				default:
					J1939_ASSERT(0);
					break;
			}
			/*switch (RxPduInfo->PacketType ) {
				case J1939TP_REVERSE_CM:
					J1939Tp_Internal_RxIndication_ReverseCm(PduInfoPtr,ChannelInfoPtr);
					break;
				case J1939TP_DT:
					J1939Tp_Internal_RxIndication_Dt(PduInfoPtr,ChannelInfoPtr);
					break;
				case J1939TP_CM:
					J1939Tp_Internal_RxIndication_Cm(PduInfoPtr,ChannelInfoPtr);
					break;
				case J1939TP_DIRECT:
					J1939Tp_Internal_RxIndication_Direct(PduInfoPtr,RxPduInfo);
					break;
				default:
					J1939_ASSERT(0);
					break;
			}*/
			//!<=================================================
			ResumeAllInterrupts();//added by xyl 2015-7-17		
		}
	}
}



void J1939Tp_MainFunction(void) 
{
  uint8 i;

	if (globalState.State == J1939TP_ON) 
	{
		for (i = 0; i < J1939TP_CHANNEL_COUNT; i++) 
		{
			J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr = &(channelInfos[i]); //J1939Tp_Config.J1939Tp_Channels
			const J1939Tp_ChannelType* Channel = ChannelInfoPtr->ChannelConfPtr;
			J1939Tp_Internal_TimerStatusType timer = J1939TP_NOT_EXPIRED;
			if (Channel->Direction == J1939TP_TX)  //Ϊ���͵�
			{
			  SuspendAllInterrupts();//��ͣ�ж�
			  
			  if(ChannelInfoPtr->TxState->State == J1939TP_TX_WAIT_DT_CANIF_CONFIRM)//�ȴ�DT״̬
			  {
          if (J1939Tp_Internal_SendDt(ChannelInfoPtr) == E_NOT_OK) 
          {
						ChannelInfoPtr->TxState->State = J1939TP_TX_IDLE;
					  //Com_TxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
						//���ͺ���
						J1939Tp_Internal_SendConnectionAbort(ChannelInfoPtr->ChannelConfPtr->CmNPdu,ChannelInfoPtr->TxState->CurrentPgPtr->Pgn);
					}
				}//add by xyl 2015-7-20 to send dt not too quick! Have a interval, not once
								  
				timer = J1939Tp_Internal_IncAndCheckTimer(&(ChannelInfoPtr->TxState->TimerInfo));
				if (timer == J1939TP_EXPIRED) 
				{
					J1939Tp_Internal_StopTimer(&(ChannelInfoPtr->TxState->TimerInfo));
					switch (ChannelInfoPtr->TxState->State) 
					{
						case J1939TP_TX_WAITING_FOR_CTS: //׼������
						case J1939TP_TX_WAITING_FOR_END_OF_MSG_ACK: //����Ӧ��
						case J1939TP_TX_WAIT_DT_CANIF_CONFIRM://����
						case J1939TP_TX_WAIT_RTS_CANIF_CONFIRM://������
						case J1939TP_TX_WAIT_BAM_CANIF_CONFIRM://�㲥ģʽ
						
						case J1939TP_TX_WAIT_DT_BAM_CANIF_CONFIRM:
							ChannelInfoPtr->TxState->State = J1939TP_TX_IDLE;
 
							J1939_ASSERT( ChannelInfoPtr->TxState->CurrentPgPtr != 0 );
							J1939Tp_Internal_SendConnectionAbort(Channel->CmNPdu,ChannelInfoPtr->TxState->CurrentPgPtr->Pgn);
							//PduR_J1939TpTxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->NSdu,NTFRSLT_E_NOT_OK);	
							//Com_TxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
							break;
							
						case J1939TP_TX_WAITING_FOR_BAM_DT_SEND_TIMEOUT://���ݷ���ʱ�䵽
							ChannelInfoPtr->TxState->State = J1939TP_TX_WAIT_DT_BAM_CANIF_CONFIRM;

							J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_TX_CONF_TIMEOUT);
							if (J1939Tp_Internal_SendDt(ChannelInfoPtr) == E_NOT_OK) 
							{
								ChannelInfoPtr->TxState->State = J1939TP_TX_IDLE;
								//PduR_J1939TpTxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->NSdu,NTFRSLT_E_NOT_OK);
							  //Com_TxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
								J1939Tp_Internal_SendConnectionAbort(Channel->CmNPdu,ChannelInfoPtr->TxState->CurrentPgPtr->Pgn);
							}
							break;
						case J1939TP_TX_IDLE:
							/* Do nothing */
							break;
						default:
							J1939_ASSERT(0);
						break;
					}
				}
	  		ResumeAllInterrupts();//added by xyl 2015-7-17		
			}
			else if (Channel->Direction == J1939TP_RX) 
			{
	  		SuspendAllInterrupts();//modified by xyl 2015-7-17
				switch (ChannelInfoPtr->RxState->State) 
				{
					case J1939TP_RX_WAIT_CTS_CANIF_CONFIRM:
					case J1939TP_RX_RECEIVING_DT:
					case J1939TP_RX_WAIT_ENDOFMSGACK_CANIF_CONFIRM:
						timer = J1939Tp_Internal_IncAndCheckTimer(&(ChannelInfoPtr->RxState->TimerInfo));
					default:
						break;
				}
				if (timer == J1939TP_EXPIRED) 
				{
					J1939Tp_Internal_StopTimer(&(ChannelInfoPtr->RxState->TimerInfo));
					ChannelInfoPtr->RxState->State = J1939TP_RX_IDLE;
					if (Channel->Protocol == J1939TP_PROTOCOL_CMDT) 
					{
						J1939Tp_Internal_SendConnectionAbort(Channel->FcNPdu,ChannelInfoPtr->RxState->CurrentPgPtr->Pgn);
					}
					//PduR_J1939TpRxIndication(ChannelInfoPtr->RxState->CurrentPgPtr->NSdu,NTFRSLT_E_NOT_OK);
					//Com_TxConfirmation(ChannelInfoPtr->RxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
				}
	  		ResumeAllInterrupts();//added by xyl 2015-7-17		
			} 
			else 
			{
				J1939_ASSERT( 0 );
			}
		}
	}
	for (i = 0; i < J1939TP_PG_COUNT; i++) {
			SuspendAllInterrupts();//modified by xyl 2015-7-17
		if (pgInfos[i].TxState != J1939TP_PG_TX_IDLE) {
			if (J1939Tp_Internal_IncAndCheckTimer(&(pgInfos[i].TimerInfo)) == J1939TP_EXPIRED) {
				pgInfos[i].TxState = J1939TP_PG_TX_IDLE;
			}
		}
			ResumeAllInterrupts();//added by xyl 2015-7-17		
	}
}

//$$$����ȷ��
void J1939Tp_TxConfirmation(PduIdType TxPduId) 
{
	if (globalState.State == J1939TP_ON) 
	{
		uint8 i;
		const J1939Tp_PduInfoType* TxPduInfo;
		J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr;
    //here fix a big bug in OpenSAR source code,use GetPduInfo instead GetRxPduRelationsInfo
		//if (J1939Tp_Internal_GetPduInfo(TxPduId, TxPduInfo) == E_OK) 
	  for(i=0; i<J1939TP_RX_PDU_COUNT; i++)
    {				
	    if (TxPduId == J1939Tp_ConfigPtr->PduInfo[i].PduId ) 
  	  {
    		TxPduInfo = &(J1939Tp_ConfigPtr->PduInfo[i]); //J1939Tp_PduInfos
  	  }
  	  else
  	  {
    		continue;
  	  }
	  	SuspendAllInterrupts();//modified by xyl 2015-7-17
			ChannelInfoPtr = J1939Tp_Internal_GetChannelState(TxPduInfo);
			
			switch (ChannelInfoPtr->ChannelConfPtr->Direction)
			{
				case J1939TP_TX:
					J1939Tp_Internal_TxConfirmation_TxChannel(ChannelInfoPtr, TxPduInfo);
					break;
				case J1939TP_RX:
					J1939Tp_Internal_TxConfirmation_RxChannel(ChannelInfoPtr, TxPduInfo);
					break;
				default:
					J1939_ASSERT(0);
					break;
			}
		  ResumeAllInterrupts();//modified by xyl 2015-7-17
    }
	}
}


static const J1939Tp_ChannelType* J1939Tp_Internal_GetChannel(const J1939Tp_PduInfoType* RxPduInfo) 
{
	return &(J1939Tp_ConfigPtr->Channels[RxPduInfo->ChannelIndex]);
}


static J1939Tp_Internal_ChannelInfoType* J1939Tp_Internal_GetChannelState(const J1939Tp_PduInfoType* RxPduInfo) 
{
	return &(channelInfos[RxPduInfo->ChannelIndex]);
}


static Std_ReturnType J1939Tp_Internal_ValidatePacketType(const J1939Tp_PduInfoType* RxPduInfo) 
{
	const J1939Tp_ChannelType* ChannelPtr = J1939Tp_Internal_GetChannel(RxPduInfo);
	switch (RxPduInfo->PacketType) 
	{
		case J1939TP_REVERSE_CM:
			if (ChannelPtr->Direction != J1939TP_TX ) 
			{
				return E_NOT_OK;
			}
			break;
		case J1939TP_DT:
			if (ChannelPtr->Direction != J1939TP_RX) 
			{
				return E_NOT_OK;
			}
			break;
		case J1939TP_CM:
			if (ChannelPtr->Direction != J1939TP_RX) 
			{
				return E_NOT_OK;
			}
			break;
		default:
			return E_NOT_OK;
	}
	return E_OK;
}


static void J1939Tp_Internal_RxIndication_Direct(PduInfoType* PduInfoPtr, const J1939Tp_PduInfoType* RxPduInfoPtr) 
{
	const J1939Tp_PgType* Pg;
	PduLengthType remainingBuffer;
	BufReq_ReturnType r;
	
	if (PduInfoPtr->SduLength > DIRECT_TRANSMIT_SIZE) 
	{
		return;
	}
	Pg = RxPduInfoPtr->PgPtr;
	//if (PduR_J1939TpStartOfReception(Pg->NSdu, PduInfoPtr->SduLength, &remainingBuffer) == BUFREQ_OK) {
	if (BUFREQ_OK == BUFREQ_OK) 
	{
		//BufReq_ReturnType r = PduR_J1939TpCopyRxData(Pg->NSdu, PduInfoPtr,&remainingBuffer);
	  J1939Tp_CopyRxData(Pg->NSdu, PduInfoPtr,0);
		r = BUFREQ_OK;
		if (r == BUFREQ_OK) 
		{
			//PduR_J1939TpRxIndication(Pg->NSdu,NTFRSLT_OK);
		} else 
		{
			//PduR_J1939TpRxIndication(Pg->NSdu,NTFRSLT_E_NOT_OK);
		}
	}
}

uint8 J1939Tp_Internal_GetDtPacketsInNextCts(uint8 receivedDtPackets, uint8 totalDtPacketsToReceive) 
{
	uint8 packetsLeft = totalDtPacketsToReceive - receivedDtPackets;
	if (packetsLeft < (J1939TP_PACKETS_PER_BLOCK)) 
	{
		return packetsLeft;
	} 
	else 
	{
		return J1939TP_PACKETS_PER_BLOCK;
	}
}


static void J1939Tp_Internal_RxIndication_Dt(PduInfoType* PduInfoPtr, J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr) 
{
	PduIdType PduRSdu;
	/*const*/ J1939Tp_ProtocolType protocol;
	uint8 expectedSeqNumber;
	uint8 seqNumber;
	PduLengthType remainingBytesInRxBuffer = 0;
	PduInfoType PduInfoRxCopy;
	BufReq_ReturnType r;
	if (ChannelInfoPtr->RxState->CurrentPgPtr == 0) 
	{
		return;
	}
	if (ChannelInfoPtr->RxState->State != J1939TP_RX_RECEIVING_DT) 
	{
		return;
	}
	//PduRSdu = ChannelInfoPtr->RxState->CurrentPgPtr->NSdu;
	protocol = ChannelInfoPtr->ChannelConfPtr->Protocol;
	ChannelInfoPtr->RxState->ReceivedDtCount++;
	expectedSeqNumber = ChannelInfoPtr->RxState->ReceivedDtCount;
	seqNumber = PduInfoPtr->SduDataPtr[DT_BYTE_SEQ_NUM];
	if (seqNumber != expectedSeqNumber) 
	{
		ChannelInfoPtr->RxState->State = J1939TP_RX_IDLE;
		if (protocol == J1939TP_PROTOCOL_CMDT) 
		{
  		J1939Tp_PgnType pgn = ChannelInfoPtr->RxState->CurrentPgPtr->Pgn;
			J1939Tp_Internal_SendConnectionAbort(ChannelInfoPtr->ChannelConfPtr->FcNPdu,pgn); //����������ֹ
		}
		//PduR_J1939TpRxIndication(ChannelInfoPtr->RxState->CurrentPgPtr->NSdu,NTFRSLT_E_NOT_OK);
		//Com_TxConfirmation(ChannelInfoPtr->RxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
		return;
	}

	PduInfoRxCopy.SduLength = J1939Tp_Internal_GetDtDataSize(seqNumber,ChannelInfoPtr->RxState->TotalMessageSize);
	PduInfoRxCopy.SduDataPtr = &(PduInfoPtr->SduDataPtr[DT_BYTE_DATA_1]);
	//r = PduR_J1939TpCopyRxData(ChannelInfoPtr->RxState->CurrentPgPtr->NSdu, &PduInfoRxCopy,&remainingBytesInRxBuffer);
	J1939Tp_CopyRxData(ChannelInfoPtr->RxState->CurrentPgPtr->NSdu, &PduInfoRxCopy,(seqNumber-1)*DT_DATA_SIZE);//seqNumber begin with 1
	r = BUFREQ_OK;
	if (r != BUFREQ_OK) {
		if (protocol == J1939TP_PROTOCOL_CMDT) 
		{
  		J1939Tp_PgnType pgn = ChannelInfoPtr->RxState->CurrentPgPtr->Pgn;
			J1939Tp_Internal_SendConnectionAbort(ChannelInfoPtr->ChannelConfPtr->FcNPdu,pgn);//����������ֹ
		}
		ChannelInfoPtr->RxState->State = J1939TP_RX_IDLE;
		return;
	}
	if (protocol == J1939TP_PROTOCOL_CMDT && J1939Tp_Internal_IsLastDtBeforeNextCts(ChannelInfoPtr->RxState)) {
		J1939Tp_PgnType pgn = ChannelInfoPtr->RxState->CurrentPgPtr->Pgn;
		uint8 requestPackets = J1939Tp_Internal_GetDtPacketsInNextCts(ChannelInfoPtr->RxState->ReceivedDtCount,ChannelInfoPtr->RxState->DtToReceiveCount);
		ChannelInfoPtr->RxState->State = J1939TP_RX_WAIT_CTS_CANIF_CONFIRM;
		J1939Tp_Internal_SendCts(ChannelInfoPtr, pgn, ChannelInfoPtr->RxState->ReceivedDtCount+1,requestPackets);
	}
	else if (J1939Tp_Internal_IsLastDt(ChannelInfoPtr->RxState)) 
	{
		if (ChannelInfoPtr->ChannelConfPtr->Protocol == J1939TP_PROTOCOL_CMDT) 
		{
			J1939Tp_Internal_SendEndOfMsgAck(ChannelInfoPtr); //���ͽ���Ӧ��
		}
		ChannelInfoPtr->RxState->State = J1939TP_RX_IDLE;
		//PduR_J1939TpRxIndication(PduRSdu,NTFRSLT_OK);
		//Com_TxConfirmation(ChannelInfoPtr->RxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
	} else {
		J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->RxState->TimerInfo),J1939TP_T1_TIMEOUT_MS);
	}
}

static uint8 J1939Tp_Internal_GetDtDataSize(uint8 currentSeqNum, uint8 totalSize) 
{
	if (currentSeqNum*DT_DATA_SIZE <= totalSize) 
	{
		return DT_DATA_SIZE;
	} else {
		return DT_DATA_SIZE - ((currentSeqNum*DT_DATA_SIZE) - totalSize);
	}
}


static void J1939Tp_Internal_RxIndication_Cm(PduInfoType* PduInfoPtr, J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr) 
{
	const J1939Tp_PgType* pg = 0;
	J1939Tp_PgnType pgn;
	uint8 Command;
	J1939Tp_Internal_DtPayloadSizeType messageSize;
	if (ChannelInfoPtr->RxState->State != J1939TP_RX_IDLE) {
		return;
	}
	pgn = J1939Tp_Internal_GetPgn(&(PduInfoPtr->SduDataPtr[CM_PGN_BYTE_1]));
	if (J1939Tp_Internal_GetPgFromPgn(ChannelInfoPtr->ChannelConfPtr,pgn,&pg) != E_OK) {
		return;
	}
	Command = PduInfoPtr->SduDataPtr[CM_BYTE_CONTROL];

	messageSize = J1939Tp_Internal_GetRtsMessageSize(PduInfoPtr);

	if (Command == RTS_CONTROL_VALUE || Command == BAM_CONTROL_VALUE) {
	    J1939Tp_ProtocolType channelProtocol;
		ChannelInfoPtr->RxState->ReceivedDtCount = 0;
		ChannelInfoPtr->RxState->DtToReceiveCount = PduInfoPtr->SduDataPtr[BAM_RTS_BYTE_NUM_PACKETS];
		ChannelInfoPtr->RxState->TotalMessageSize = messageSize;
		ChannelInfoPtr->RxState->CurrentPgPtr = pg;
		channelProtocol = ChannelInfoPtr->ChannelConfPtr->Protocol;
		if (Command == RTS_CONTROL_VALUE && channelProtocol == J1939TP_PROTOCOL_CMDT) {
			PduLengthType remainingBuffer = 0;
			//if (PduR_J1939TpStartOfReception(pg->NSdu, messageSize, &remainingBuffer) == */BUFREQ_OK) {
			if (BUFREQ_OK == BUFREQ_OK) {
				uint8 receive_packets;
				ChannelInfoPtr->RxState->State = J1939TP_RX_WAIT_CTS_CANIF_CONFIRM;
				J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->RxState->TimerInfo),J1939TP_TX_CONF_TIMEOUT);
				receive_packets = J1939Tp_Internal_GetDtPacketsInNextCts(0,ChannelInfoPtr->RxState->DtToReceiveCount);
				J1939Tp_Internal_SendCts(ChannelInfoPtr,pgn,CTS_START_SEQ_NUM,receive_packets);
			} else {
				//J1939Tp_Internal_SendConnectionAbort(pg->Channel->CmNPdu,pgn);
				//A bug here! CmNPdu is wrong, should be FcNPdu!
				PduIdType CmNPdu = ChannelInfoPtr->ChannelConfPtr->FcNPdu;//OR pg->Channel->FcNPdu
				J1939Tp_Internal_SendConnectionAbort(CmNPdu,pgn);
			}
		} else if (Command == BAM_CONTROL_VALUE && channelProtocol == J1939TP_PROTOCOL_BAM) {
			PduLengthType remainingBuffer = 0;
			//if (PduR_J1939TpStartOfReception(pg->NSdu, messageSize, &remainingBuffer) == BUFREQ_OK) {
			{
				J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->RxState->TimerInfo),J1939TP_T2_TIMEOUT_MS);
				ChannelInfoPtr->RxState->State = J1939TP_RX_RECEIVING_DT;
			}
		}
	} else if (Command == CONNABORT_BYTE_CONTROL) {
		ChannelInfoPtr->RxState->State = J1939TP_RX_IDLE;
	}
}


static void J1939Tp_Internal_RxIndication_ReverseCm(PduInfoType* PduInfoPtr, J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr) 
{
	const J1939Tp_PgType* pg;
	uint8 Command;
	J1939Tp_PgnType pgn = J1939Tp_Internal_GetPgn(&(PduInfoPtr->SduDataPtr[CM_PGN_BYTE_1]));
	if (J1939Tp_Internal_GetPgFromPgn(ChannelInfoPtr->ChannelConfPtr,pgn,&pg) != E_OK) 
	{
		return;
	}
	Command = PduInfoPtr->SduDataPtr[CM_BYTE_CONTROL];
	switch (Command) 
	{
		case CTS_CONTROL_VALUE:
			if (ChannelInfoPtr->TxState->State == J1939TP_TX_WAITING_FOR_CTS) 
			{
				uint8 NumPacketsToSend = PduInfoPtr->SduDataPtr[CTS_BYTE_NUM_PACKETS];
				uint8 NextPacket = PduInfoPtr->SduDataPtr[CTS_BYTE_NEXT_PACKET];
				if (NumPacketsToSend == 0) 
				{
					// Receiver wants to keep the connection open but cant receive packets
					J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_T4_TIMEOUT_MS);
				} 
				else if(J1939Tp_Internal_IsDtPacketAlreadySent(NextPacket,ChannelInfoPtr->TxState->SentDtCount)) 
				{
					//PduR_J1939TpTxConfirmation(pg->NSdu,NTFRSLT_E_NOT_OK);
					//Com_TxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
					J1939Tp_Internal_SendConnectionAbort(ChannelInfoPtr->ChannelConfPtr->CmNPdu,pgn);
					ChannelInfoPtr->TxState->State = J1939TP_TX_IDLE;
				} 
				else 
				{
					ChannelInfoPtr->TxState->DtToSendBeforeCtsCount = NumPacketsToSend;
					ChannelInfoPtr->TxState->State = J1939TP_TX_WAIT_DT_CANIF_CONFIRM;
					if (J1939Tp_Internal_SendDt(ChannelInfoPtr) == E_NOT_OK) 
					{
						ChannelInfoPtr->TxState->State = J1939TP_TX_IDLE;
						//PduR_J1939TpTxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->NSdu,NTFRSLT_E_NOT_OK);
					  //Com_TxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
						J1939Tp_Internal_SendConnectionAbort(ChannelInfoPtr->ChannelConfPtr->CmNPdu,ChannelInfoPtr->TxState->CurrentPgPtr->Pgn);
					} 
					else 
					{
						J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_TX_CONF_TIMEOUT);
					}
				}
			}
			break;
		case ENDOFMSGACK_CONTROL_VALUE:
			if (ChannelInfoPtr->TxState->State == J1939TP_TX_WAITING_FOR_END_OF_MSG_ACK) 
			{
				//PduR_J1939TpTxConfirmation(pg->NSdu,NTFRSLT_OK);
				//Com_TxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
				ChannelInfoPtr->TxState->State = J1939TP_TX_IDLE;
			}
			break;
		case CONNABORT_CONTROL_VALUE:
			if (ChannelInfoPtr->TxState->State != J1939TP_TX_IDLE) 
			{
				//PduR_J1939TpTxConfirmation(pg->NSdu,NTFRSLT_E_NOT_OK);
				//Com_TxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
				ChannelInfoPtr->TxState->State = J1939TP_TX_IDLE;
			}
			break;
		default:
			break;
	}
}

/*Std_ReturnType J1939Tp_ChangeParameterRequest(PduIdType SduId, TPParameterType Parameter, uint16 value) {
	return E_NOT_OK; 
}*/


static void J1939Tp_Internal_TxConfirmation_RxChannel(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr, const J1939Tp_PduInfoType* RxPduInfo) {
	switch (RxPduInfo->PacketType ) 
	{
		case J1939TP_REVERSE_CM:
			if (ChannelInfoPtr->RxState->State == J1939TP_RX_WAIT_CTS_CANIF_CONFIRM) 
			{
				J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->RxState->TimerInfo),J1939TP_T2_TIMEOUT_MS);
				ChannelInfoPtr->RxState->State = J1939TP_RX_RECEIVING_DT;
			}
			break;
		default:
			break;
	}
}


static boolean J1939Tp_Internal_IsDtPacketAlreadySent(uint8 nextPacket, uint8 totalPacketsSent) {
	return nextPacket < totalPacketsSent;
}

//have problem, don't use, comment by xyl 2015-7-17
/*static Std_ReturnType J1939Tp_Internal_GetRxPduRelationsInfo(PduIdType RxPdu,const J1939Tp_RxPduInfoRelationsType** RxPduInfo) {
	if (RxPdu < J1939TP_RX_PDU_COUNT) {
		*RxPduInfo = &(J1939Tp_ConfigPtr->RxPduRelations[RxPdu]);
		return E_OK;
	} else {
		return E_NOT_OK;
	}
}*/

//add by xyl 2015-7-17
static Std_ReturnType J1939Tp_Internal_GetPduInfo(PduIdType PduId,const J1939Tp_PduInfoType* PduInfo) 
{
	uint8 i;
	
	for(i=0; i<J1939TP_RX_PDU_COUNT; i++)
	{
	  if (PduId == J1939Tp_ConfigPtr->PduInfo[i].PduId ) 
	  {
  		PduInfo = &(J1939Tp_ConfigPtr->PduInfo[i]);
  		return E_OK;
	  }
	} 

	return E_NOT_OK;//if been here, PduId not in PduInfo Confirgured(J1939Tp_PduInfos) 
}

Std_ReturnType J1939Tp_Internal_GetPgFromPgn(const J1939Tp_ChannelType* channel, J1939Tp_Internal_PgnType Pgn, const J1939Tp_PgType** Pg) {
	int i;
	for (i = 0; i < channel->PgCount; i++) 
	{
		if (channel->Pgs[i]->Pgn == Pgn) 
		{
			*Pg = channel->Pgs[i];
			return E_OK;
		}
	}
	return E_NOT_OK;
}


static boolean J1939Tp_Internal_IsLastDtBeforeNextCts(J1939Tp_Internal_RxChannelInfoType* rxChannelInfo) 
{
	boolean finalDt = rxChannelInfo->ReceivedDtCount == rxChannelInfo->DtToReceiveCount;
	boolean sendNewCts = rxChannelInfo->ReceivedDtCount % J1939TP_PACKETS_PER_BLOCK == 0;
	return !finalDt && sendNewCts;


}


static boolean J1939Tp_Internal_IsLastDt(J1939Tp_Internal_RxChannelInfoType* rxChannelInfo) 
{
	return (rxChannelInfo->DtToReceiveCount == rxChannelInfo->ReceivedDtCount);
}

//�������ʱ�����ú���
static void J1939Tp_Internal_TxConfirmation_TxChannel(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr, const J1939Tp_PduInfoType* RxPduInfo) 
{
	J1939Tp_Internal_TxChannelStateType State = ChannelInfoPtr->TxState->State;
	J1939Tp_Internal_PgInfoType* PgInfo = J1939Tp_GetPgInfo(RxPduInfo->PgPtr);
	switch (RxPduInfo->PacketType ) 
	{
		case J1939TP_REVERSE_CM:
			break;
		case J1939TP_CM:
			if (State == J1939TP_TX_WAIT_RTS_CANIF_CONFIRM)//�ȴ������� 
			{
				ChannelInfoPtr->TxState->State = J1939TP_TX_WAITING_FOR_CTS;
				J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_T3_TIMEOUT_MS);
			} 
			else if (State == J1939TP_TX_WAIT_BAM_CANIF_CONFIRM)//�ȴ��㲥 
			{
				ChannelInfoPtr->TxState->State = J1939TP_TX_WAITING_FOR_BAM_DT_SEND_TIMEOUT;
				J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_DT_BROADCAST_MIN_INTERVAL);
			} 
			else 
			{
				/* We can actually be in J1939TP_TX_IDLE here if get a TX confirmation
				 * after the Tx confirmation timeout have happened */
			}
			break;
		case J1939TP_DT: //�ȴ�����
			if (State == J1939TP_TX_WAIT_DT_CANIF_CONFIRM) 
			{
				ChannelInfoPtr->TxState->SentDtCount++;//$$$��1  ������һ������
				if (J1939Tp_Internal_LastDtSent(ChannelInfoPtr->TxState)) 
				{
					J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_T3_TIMEOUT_MS);
					ChannelInfoPtr->TxState->State = J1939TP_TX_WAITING_FOR_END_OF_MSG_ACK;
				} 
				else if (J1939Tp_Internal_WaitForCts(ChannelInfoPtr->TxState)) 
				{
					J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_T3_TIMEOUT_MS);
					ChannelInfoPtr->TxState->State = J1939TP_TX_WAITING_FOR_CTS;
				} else 
				{
					//Std_ReturnType rv;
					J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_TX_CONF_TIMEOUT);
					//rv = J1939Tp_Internal_SendDt(ChannelInfoPtr);//masked by xyl 2015-7-21, send in main_function insead
					//J1939_ASSERT( rv == E_OK );
				}
			}
			else if (State == J1939TP_TX_WAIT_DT_BAM_CANIF_CONFIRM) 
			{
				ChannelInfoPtr->TxState->SentDtCount++;
				if (J1939Tp_Internal_LastDtSent(ChannelInfoPtr->TxState)) 
				{
					ChannelInfoPtr->TxState->State = J1939TP_TX_IDLE;
					//PduR_J1939TpTxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->NSdu,NTFRSLT_OK);
					//Com_TxConfirmation(ChannelInfoPtr->TxState->CurrentPgPtr->DirectNPdu);//add by xyl 2015-7-21
				} else 
				{
					ChannelInfoPtr->TxState->State = J1939TP_TX_WAITING_FOR_BAM_DT_SEND_TIMEOUT;
					J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_DT_BROADCAST_MIN_INTERVAL);
				}
			} 
			else 
			{
				/* We can actually be in J1939TP_TX_IDLE here if get a TX confirmation
				 * after the Tx confirmation timeout have happened */
			}
			break;
		case J1939TP_DIRECT:
			if (PgInfo->TxState == J1939TP_PG_TX_WAIT_DIRECT_SEND_CANIF_CONFIRM) 
			{
				PgInfo->TxState = J1939TP_PG_TX_IDLE;
				//PduR_J1939TpTxConfirmation(RxPduInfo->PgPtr->NSdu, NTFRSLT_OK);
			}
			break;
		default:
			J1939_ASSERT( 0 );
			break;
	}
}


//add by xyl					
static void J1939Tp_Internal_RxIndication_TxChannel(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr, const J1939Tp_PduInfoType* RxPduInfo, PduInfoType* PduInfoPtr) 
{
	switch (RxPduInfo->PacketType ) 
	{
		case J1939TP_REVERSE_CM:
			J1939Tp_Internal_RxIndication_ReverseCm(PduInfoPtr,ChannelInfoPtr);
			break;
		case J1939TP_CM:
			break;
		case J1939TP_DT:
			break;
		case J1939TP_DIRECT:
			break;
		default:
			J1939_ASSERT( 0 );
			break;
	}
}

//add by xyl$$$������պ���
static void J1939Tp_Internal_RxIndication_RxChannel(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr, const J1939Tp_PduInfoType* RxPduInfo, PduInfoType* PduInfoPtr) 
{
	switch (RxPduInfo->PacketType ) 
	{
		case J1939TP_REVERSE_CM:
			break;
		case J1939TP_CM:
  		J1939Tp_Internal_RxIndication_Cm(PduInfoPtr,ChannelInfoPtr);
			break;
		case J1939TP_DT:
  		J1939Tp_Internal_RxIndication_Dt(PduInfoPtr,ChannelInfoPtr);
			break;
		case J1939TP_DIRECT:
  		J1939Tp_Internal_RxIndication_Direct(PduInfoPtr,RxPduInfo);
			break;
		default:
			J1939_ASSERT( 0 );
			break;
	}
}



Std_ReturnType J1939Tp_Internal_GetPg(PduIdType TxSduId,J1939Tp_Internal_PgInfoType** PgInfo) 
{
	/*if (TxSduId < J1939TP_PG_COUNT) {
		*PgInfo = &(pgInfos[TxSduId]);
		return E_OK;
	}*/
	uint8 i;
	for (i = 0; i < J1939TP_PG_COUNT; i++) //��ѯ4�������������
	{
	  //�ж�ID�ı��
	  if (TxSduId == (pgInfos[i].PgConfPtr)->DirectNPdu)//����Ƕ������J1939Tp_Pgs��ID.DirectNPdu
	  {
	    *PgInfo = &(pgInfos[i]);   //ȡ���ṹ�� J1939Tp_Config
		  return E_OK;
	  }
	} //modified by xyl 2015-7-14
	
	return E_NOT_OK;
}
/*Std_ReturnType J1939Tp_CancelTransmitRequest(PduIdType TxSduId) {
	J1939Tp_Internal_PgInfoType* PgInfo;
	if (J1939Tp_Internal_GetPg(TxSduId,&PgInfo) == E_NOT_OK) {
		return E_NOT_OK;
	}
	//PduR_J1939TpTxConfirmation(PgInfo->PgConfPtr->NSdu,NTFRSLT_E_CANCELATION_NOT_OK);
	return E_OK;
}
Std_ReturnType J1939Tp_CancelReceiveRequest(PduIdType RxSduId) {
	J1939Tp_Internal_PgInfoType* PgInfo;
	if (J1939Tp_Internal_GetPg(RxSduId,&PgInfo) == E_NOT_OK) {
		return E_NOT_OK;
	}
	//PduR_J1939TpTxConfirmation(PgInfo->PgConfPtr->NSdu,NTFRSLT_E_CANCELATION_NOT_OK);
	return E_OK;
}*/


/* const J1939Tp_ConfigType J1939Tp_Config = {
     .PduInfo =  &J1939Tp_PduInfos,
     .Channels =  J1939Tp_Channels,
     .Pgs =  J1939Tp_Pgs ,  
};*/



//remove DirectTransmit, manage it in COM $$$������ͺ���
Std_ReturnType J1939Tp_Transmit(PduIdType TxSduId, const PduInfoType* TxInfoPtr) 
            //                       ���͵ı��    Pdu�ṹ��Ҫ���͵����ݺͳ���         
{
	Std_ReturnType r = E_OK;
	

	if (globalState.State == J1939TP_ON) 
	{
		J1939Tp_Internal_PgInfoType* PgInfo;   //����ṹ��
		//����Ϊ�ж��Ƿ�Ϊ�����������   ȡ���ṹ�� J1939Tp_Config
		r = J1939Tp_Internal_GetPg(TxSduId,&PgInfo);  //pgInfos[i].ChannelInfoPtr
		if (r == E_OK)
		{
		  //ȡ������ı�����Ϣ ����PGN ��� ��Ҫ���͵ı���
			const J1939Tp_PgType* Pg = PgInfo->PgConfPtr;//ȡ��J1939Tp_Config.J1939Tp_Pgs  
			J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr = PgInfo->ChannelInfoPtr; //��·CAN
			if (TxInfoPtr->SduLength <= 7)//20151001
			{ // direct transmit
				r = J1939Tp_Internal_DirectTransmit(TxInfoPtr, PgInfo);//��ͨ�ĵ�������
			}
			else 
			{
		  	SuspendAllInterrupts();//modified by xyl 2015-7-17
				if (ChannelInfoPtr->TxState->State != J1939TP_TX_IDLE)
				{
					r = E_NOT_OK;
				}
				if (r == E_OK) 
				{
					switch (ChannelInfoPtr->ChannelConfPtr->Protocol) 
					{ 
						case J1939TP_PROTOCOL_BAM:
							ChannelInfoPtr->TxState->State = J1939TP_TX_WAIT_BAM_CANIF_CONFIRM;
							ChannelInfoPtr->TxState->TotalMessageSize = TxInfoPtr->SduLength;
							ChannelInfoPtr->TxState->CurrentPgPtr = Pg;//masked by xyl 2015-7-16 
							ChannelInfoPtr->TxState->SentDtCount = 0;
							//ChannelInfoPtr->TxState->TxInfoPtr = TxInfoPtr;//add by xyl 2015-7-22
							J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_TX_CONF_TIMEOUT);
							r = J1939Tp_Internal_SendBam(ChannelInfoPtr,TxInfoPtr);
							break;
						case J1939TP_PROTOCOL_CMDT:
							ChannelInfoPtr->TxState->State = J1939TP_TX_WAIT_RTS_CANIF_CONFIRM;
							ChannelInfoPtr->TxState->TotalMessageSize = TxInfoPtr->SduLength;
							ChannelInfoPtr->TxState->PduRPdu = TxSduId;
							ChannelInfoPtr->TxState->CurrentPgPtr = Pg;//masked by xyl 2015-7-16 
							ChannelInfoPtr->TxState->SentDtCount = 0;
							//ChannelInfoPtr->TxState->TxInfoPtr = TxInfoPtr;//add by xyl 2015-7-22
							r = J1939Tp_Internal_SendRts(ChannelInfoPtr,TxInfoPtr);
							J1939Tp_Internal_StartTimer(&(ChannelInfoPtr->TxState->TimerInfo),J1939TP_TX_CONF_TIMEOUT);
							break;
						default:
							J1939_ASSERT( 0 );
							break;
					}
				}
			  ResumeAllInterrupts();//added by xyl 2015-7-17		
			}
		}
	}
	return r;
}

//ֱ�ӽ��е������ͳ��� 
//���ͺ���
static Std_ReturnType J1939Tp_Internal_DirectTransmit(const PduInfoType* TxInfoPtr, J1939Tp_Internal_PgInfoType* PgInfo) 
{
	Std_ReturnType r = E_OK;
	SuspendAllInterrupts();//modified by xyl 2015-7-17
	if (PgInfo->TxState == J1939TP_PG_TX_IDLE) 
	{
		PgInfo->TxState = J1939TP_PG_TX_WAIT_DIRECT_SEND_CANIF_CONFIRM;
	} 
	else 
	{
		r = E_NOT_OK;
	}
	ResumeAllInterrupts();//added by xyl 2015-7-17		
	if (r == E_OK) 
	{
		PduInfoType ToSendTxInfoPtr;
		PduLengthType remainingBytes;
		const J1939Tp_PgType* Pg;
		//uint8 dataPtr[TxInfoPtr->SduLength]; //parai:for Non Gcc compiler,this is not supported
		//so How to resolve this problem ?
		uint8 dataPtr[8];//is 8 bytes enough ? As I see CanIf_Transmit(),so I think it is ok.
		ToSendTxInfoPtr.SduLength = TxInfoPtr->SduLength;
		ToSendTxInfoPtr.SduDataPtr = dataPtr;
		Pg = PgInfo->PgConfPtr;
		//if (PduR_J1939TpCopyTxData(Pg->NSdu, &ToSendTxInfoPtr, 0, &remainingBytes) == BUFREQ_OK) {
		J1939Tp_CopyTxData(Pg->NSdu, &ToSendTxInfoPtr, ToSendTxInfoPtr.SduLength/*use it as bytesLeftToSend*/);
		/*if (BUFREQ_OK == BUFREQ_OK)*/ 
		{
			PduIdType CanIfPdu = Pg->DirectNPdu;
			J1939Tp_Internal_StartTimer(&(PgInfo->TimerInfo),J1939TP_TX_CONF_TIMEOUT);
			r = CanIf_Transmit(CanIfPdu,&ToSendTxInfoPtr);
			if (r != E_OK) 
			{
		  	SuspendAllInterrupts();//modified by xyl 2015-7-17
				PgInfo->TxState = J1939TP_PG_TX_IDLE;
			  ResumeAllInterrupts();//modified by xyl 2015-7-17
			}
		} /*else {
			r = E_NOT_OK;
		}*/
	}
	return r;
}



//���ͺ���
static Std_ReturnType J1939Tp_Internal_SendBam(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr,const PduInfoType* TxInfoPtr) {
	Std_ReturnType r;
	J1939Tp_PgnType pgn;
	uint8 cmBamData[BAM_RTS_SIZE];
	PduInfoType cmBamPdu;
	cmBamData[BAM_RTS_BYTE_CONTROL] = BAM_CONTROL_VALUE;
	cmBamData[BAM_RTS_BYTE_LENGTH_1] = (uint8)(TxInfoPtr->SduLength & 0x00FF);
	cmBamData[BAM_RTS_BYTE_LENGTH_2] = (uint8)(TxInfoPtr->SduLength & 0xFF00);

	pgn = ChannelInfoPtr->TxState->CurrentPgPtr->Pgn;
	cmBamData[BAM_RTS_BYTE_NUM_PACKETS] = J1939TP_Internal_GetNumDtPacketsToSend(TxInfoPtr->SduLength);
	cmBamData[BAM_RTS_BYTE_SAE_ASSIGN] = 0xFF;
	J1939Tp_Internal_SetPgn(&(cmBamData[BAM_RTS_BYTE_PGN_1]),pgn);

	cmBamPdu.SduLength = BAM_RTS_SIZE;
	cmBamPdu.SduDataPtr = cmBamData;

	r = CanIf_Transmit(ChannelInfoPtr->ChannelConfPtr->CmNPdu,&cmBamPdu);  
  J1939Tp_TxConfirmation(ChannelInfoPtr->ChannelConfPtr->CmNPdu); //??????20151127
	return r;
}


static uint16 J1939Tp_Internal_GetRtsMessageSize(PduInfoType* pduInfo) 
{
	return (((uint16)pduInfo->SduDataPtr[BAM_RTS_BYTE_LENGTH_2]) << 8) | pduInfo->SduDataPtr[BAM_RTS_BYTE_LENGTH_1];
}

static boolean J1939Tp_Internal_WaitForCts(J1939Tp_Internal_TxChannelInfoType* TxChannelState) 
{
	return TxChannelState->SentDtCount == TxChannelState->DtToSendBeforeCtsCount;
}

static uint8 J1939TP_Internal_GetNumDtPacketsToSend(uint16 messageSize) 
{
	uint8 packetsToSend = 0;
	packetsToSend = messageSize/DT_DATA_SIZE;
	if (messageSize % DT_DATA_SIZE != 0) 
	{
		packetsToSend = packetsToSend + 1;
	}
	return packetsToSend;
}


static boolean J1939Tp_Internal_LastDtSent(J1939Tp_Internal_TxChannelInfoType* TxChannelState) 
{
	return J1939TP_Internal_GetNumDtPacketsToSend(TxChannelState->TotalMessageSize) == TxChannelState->SentDtCount;
}

 /*Std_ReturnType J1939Tp_Internal_ConfGetPg(PduIdType NSduId, const J1939Tp_PgType* Pg) {
	if (NSduId < J1939TP_PG_COUNT) {
		Pg = &(J1939Tp_ConfigPtr->Pgs[NSduId]);
		return E_OK;
	} else {
		return E_NOT_OK;
	}
}*/

static J1939Tp_Internal_TimerStatusType J1939Tp_Internal_IncAndCheckTimer(J1939Tp_Internal_TimerType* TimerInfo) 
{
	if (TimerInfo->Timer == 0 && TimerInfo->TimerExpire == 0) 
	{
		return J1939TP_NOT_EXPIRED;
	}
	TimerInfo->Timer += J1939TP_MAIN_FUNCTION_PERIOD;
	if (TimerInfo->Timer >= TimerInfo->TimerExpire) 
	{
		return J1939TP_EXPIRED;
	}
	return J1939TP_NOT_EXPIRED;
}

static uint8 J1939Tp_Internal_GetPf(J1939Tp_PgnType pgn) 
{
	return  (uint8)(pgn >> 8);
}


//$$$������ͺ��� 
//���ͺ���    ��������
static Std_ReturnType J1939Tp_Internal_SendDt(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr) 
{
	Std_ReturnType rv;
	uint8 requestLength = DT_DATA_SIZE;
	uint8 bytesLeftToSend = ChannelInfoPtr->TxState->TotalMessageSize - ChannelInfoPtr->TxState->SentDtCount * DT_DATA_SIZE;
	// prepare dt message
	uint8 dtBuffer[DT_SIZE] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
	PduInfoType dtPduInfoBuffer;
	BufReq_ReturnType allocateBufferRes;
	PduIdType Pdur_NSdu;
	
	if (bytesLeftToSend < DT_DATA_SIZE)
	{
		requestLength = bytesLeftToSend;
	}	
	
	dtPduInfoBuffer.SduLength = requestLength;
	dtPduInfoBuffer.SduDataPtr = &(dtBuffer[DT_BYTE_DATA_1]);
	
	Pdur_NSdu = ChannelInfoPtr->TxState->CurrentPgPtr->NSdu;
	//allocateBufferRes = PduR_J1939TpCopyTxData(Pdur_NSdu, &dtPduInfoBuffer, 0, &remainingBytes);
  J1939Tp_CopyTxData(Pdur_NSdu, &dtPduInfoBuffer, bytesLeftToSend); 		
	//allocateBufferRes = BUFREQ_OK;
	//if (allocateBufferRes == BUFREQ_OK) 
	{
	  PduIdType CanIf_NSdu;	  
	  dtPduInfoBuffer.SduLength = DT_SIZE;//move here, as it above if condition
	  dtPduInfoBuffer.SduDataPtr = dtBuffer;//move here, as it above if condition
		dtPduInfoBuffer.SduDataPtr[DT_BYTE_SEQ_NUM] = ChannelInfoPtr->TxState->SentDtCount+1;
		CanIf_NSdu = ChannelInfoPtr->ChannelConfPtr->DtNPdu;
		rv = CanIf_Transmit(CanIf_NSdu, &dtPduInfoBuffer);
    J1939Tp_TxConfirmation(CanIf_NSdu); //??????20151127
		return rv;
	} 
	/*else {
		return E_NOT_OK;
	}*/
}

//���ͺ���
static Std_ReturnType J1939Tp_Internal_SendRts(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr, const PduInfoType* TxInfoPtr) {
	uint8 cmRtsData[BAM_RTS_SIZE];
	J1939Tp_PgnType pgn;
	PduInfoType cmRtsPdu;   
	Std_ReturnType rv;
	cmRtsData[BAM_RTS_BYTE_CONTROL] = 16;
	cmRtsData[BAM_RTS_BYTE_LENGTH_1] = (uint8)(TxInfoPtr->SduLength);
	cmRtsData[BAM_RTS_BYTE_LENGTH_2] = (uint8)(TxInfoPtr->SduLength >> 8);

	pgn = ChannelInfoPtr->TxState->CurrentPgPtr->Pgn;
	cmRtsData[BAM_RTS_BYTE_NUM_PACKETS] = J1939TP_Internal_GetNumDtPacketsToSend(TxInfoPtr->SduLength);
	cmRtsData[BAM_RTS_BYTE_SAE_ASSIGN] = 0xFF;
	J1939Tp_Internal_SetPgn(&(cmRtsData[BAM_RTS_BYTE_PGN_1]),pgn);

	cmRtsPdu.SduLength = BAM_RTS_SIZE;
	cmRtsPdu.SduDataPtr = cmRtsData;
  rv = CanIf_Transmit(ChannelInfoPtr->ChannelConfPtr->CmNPdu,&cmRtsPdu);  //���ͺ���
  J1939Tp_TxConfirmation(ChannelInfoPtr->ChannelConfPtr->CmNPdu); //??????20151127	
	return rv; 
}

//���ͺ���
static void J1939Tp_Internal_SendEndOfMsgAck(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr) 
{
	PduInfoType endofmsgInfo;
	uint8 endofmsgData[ENDOFMSGACK_SIZE];
	PduIdType CmNPdu; 
	Std_ReturnType rv;
	endofmsgData[ENDOFMSGACK_BYTE_CONTROL] = ENDOFMSGACK_CONTROL_VALUE;
	endofmsgData[ENDOFMSGACK_BYTE_TOTAL_MSG_SIZE_1] = ((uint8)(ChannelInfoPtr->RxState->TotalMessageSize)) << 8;
	endofmsgData[ENDOFMSGACK_BYTE_TOTAL_MSG_SIZE_2] = ((uint8)(ChannelInfoPtr->RxState->TotalMessageSize));
	endofmsgData[ENDOFMSGACK_BYTE_NUM_PACKETS] = ChannelInfoPtr->RxState->ReceivedDtCount;
	endofmsgData[ENDOFMSGACK_BYTE_SAE_ASSIGN] = 0xFF;

	endofmsgInfo.SduLength = ENDOFMSGACK_SIZE;
	endofmsgInfo.SduDataPtr = endofmsgData;
	J1939Tp_Internal_SetPgn(&(endofmsgData[ENDOFMSGACK_BYTE_PGN_1]),ChannelInfoPtr->RxState->CurrentPgPtr->Pgn);
	CmNPdu = ChannelInfoPtr->ChannelConfPtr->FcNPdu;

	rv = CanIf_Transmit(CmNPdu,&endofmsgInfo); 
  J1939Tp_TxConfirmation(CmNPdu); //??????20151127	
	//return rv; 
}

/**
 * Send a response to the incoming RTS
 * @param NSduId
 * @param RtsPduInfoPtr needs to be a valid RTS message
 */
//���ͺ���
static void J1939Tp_Internal_SendCts(J1939Tp_Internal_ChannelInfoType* ChannelInfoPtr, J1939Tp_PgnType Pgn, uint8 NextPacketSeqNum,uint8 NumPackets) 
{
	PduInfoType ctsInfo;
	uint8 ctsData[CTS_SIZE];
	PduIdType CmNPdu;
	Std_ReturnType rv;
	
	ctsData[CTS_BYTE_CONTROL] = CTS_CONTROL_VALUE;
	ctsData[CTS_BYTE_NUM_PACKETS] = NumPackets;
	ctsData[CTS_BYTE_NEXT_PACKET] = NextPacketSeqNum;
	ctsData[CTS_BYTE_SAE_ASSIGN_1] = 0xFF;
	ctsData[CTS_BYTE_SAE_ASSIGN_2] = 0xFF;

	ctsInfo.SduLength = CTS_SIZE;
	ctsInfo.SduDataPtr = ctsData;

	J1939Tp_Internal_SetPgn(&(ctsData[BAM_RTS_BYTE_PGN_1]),Pgn);
  CmNPdu = ChannelInfoPtr->ChannelConfPtr->FcNPdu;

	rv = CanIf_Transmit(CmNPdu,(PduInfoType*)&ctsInfo);
  J1939Tp_TxConfirmation(CmNPdu); //??????20151127	
	//return rv; 
}


//���ͺ���
static void J1939Tp_Internal_SendConnectionAbort(PduIdType CmNPdu, J1939Tp_PgnType Pgn) 
{
	PduInfoType connAbortInfo;
	uint8 connAbortData[CONNABORT_SIZE];  
	Std_ReturnType rv;
	
	connAbortInfo.SduLength = CONNABORT_SIZE;
	connAbortInfo.SduDataPtr = connAbortData;
	connAbortData[CONNABORT_BYTE_CONTROL] = CONNABORT_CONTROL_VALUE;
	connAbortData[CONNABORT_BYTE_SAE_ASSIGN_1] = 0xFF;
	connAbortData[CONNABORT_BYTE_SAE_ASSIGN_2] = 0xFF;
	connAbortData[CONNABORT_BYTE_SAE_ASSIGN_3] = 0xFF;
	connAbortData[CONNABORT_BYTE_SAE_ASSIGN_4] = 0xFF;
	J1939Tp_Internal_SetPgn(&(connAbortData[CONNABORT_BYTE_PGN_1]),Pgn);
	rv = CanIf_Transmit(CmNPdu,&connAbortInfo); 
  J1939Tp_TxConfirmation(CmNPdu); //??????20151127	
	//return rv; 
}


static void J1939Tp_Internal_StartTimer(J1939Tp_Internal_TimerType* TimerInfo,uint16 TimerExpire) 
{
	TimerInfo->Timer = 0;
	TimerInfo->TimerExpire = TimerExpire;
}


static void J1939Tp_Internal_StopTimer(J1939Tp_Internal_TimerType* TimerInfo) 
{
	TimerInfo->Timer = 0;
	TimerInfo->TimerExpire = 0;
}
/**
 * set three bytes to a 18 bit pgn value
 * @param PgnBytes must be three uint8 bytes
 * @param pgn
 */
 void J1939Tp_Internal_SetPgn(uint8* PgnBytes,J1939Tp_PgnType pgn ) 
{
	PgnBytes[0] = pgn; /* get first byte */
	PgnBytes[1] = pgn >> 8; /* get next byte */
	PgnBytes[2] = (pgn >> 16) & 0x3; /* get next two bits */
}
/**
 * return a 18 bit pgn value from three bytes
 * @param PgnBytes must be three uint8 bytes
 * @return
 */
static J1939Tp_PgnType J1939Tp_Internal_GetPgn(uint8* PgnBytes) 
{
	J1939Tp_PgnType pgn = 0;
	pgn = ((uint32)PgnBytes[2]) << 16;
	pgn = pgn | (((uint32)PgnBytes[1]) << 8);
	pgn = pgn | ((uint32)PgnBytes[0]);
	return pgn;
}


static J1939Tp_Internal_PgInfoType* J1939Tp_GetPgInfo(const J1939Tp_PgType* Pg) 
{
	return &(pgInfos[Pg - J1939Tp_ConfigPtr->Pgs]);
}


static void J1939Tp_Internal_ReportError(uint8 ApiId, uint8 ErrorId) 
{
//#if (CANSM_DEV_ERROR_DETECT == STD_ON)
	//Det_ReportError(MODULE_ID_J1939TP, 0, ApiId, ApiId);
//#endif
}

//add by xyl 
static void J1939Tp_CopyTxData(PduIdType PduId, PduInfoType* PduInfoPtr, PduLengthType bytesLeftToSend) 
{
	PduLengthType i;
	
	SuspendAllInterrupts();
  for(i=0; i<PduInfoPtr->SduLength; i++)
	{
	  PduInfoPtr->SduDataPtr[i] = com_TxConfig_C[PduId].DataPtr[com_TxConfig_C[PduId].DataLen-bytesLeftToSend+i];
	}
  ResumeAllInterrupts();
}

static void J1939Tp_CopyRxData(PduIdType PduId, PduInfoType* PduInfoPtr, PduLengthType bytesHaveRecived) 
{
	PduLengthType i;
	uint8* dataPtr;
	
	SuspendAllInterrupts();
  switch(PduId)
  {

    
    default:
    break;
  }
  ResumeAllInterrupts();
  
  Com_RxIndication(PduId,PduInfoPtr/*no use*/);
}