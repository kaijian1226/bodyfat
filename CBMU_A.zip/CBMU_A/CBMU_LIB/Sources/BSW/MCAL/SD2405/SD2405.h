#ifndef __SD2405_H_
#define __SD2405_H_

#include "IIC.h"
#include "SD2405_CFG.h"
#include "SD2405_Types.h"

#define SD2405_ADDR 0x65

//the real time reg address of IC
#define  SD2405_REG_SECOND        	0x0
#define  SD2405_REG_MINUTE        	0x1
#define  SD2405_REG_HOUR        		0x2
#define  SD2405_REG_WEEK        		0x3
#define  SD2405_REG_DATE        		0x4
#define  SD2405_REG_MONTH        		0x5
#define  SD2405_REG_YEAR        		0x6

//control reg address of IC
#define  SD2405_REG_CTR1        		0x0F
#define  SD2405_REG_CTR2        		0x10
#define  SD2405_REG_CTR3        		0x11
#define  SD2405_REG_TIMEADJ        	0x12
     

//global variable
extern SD2405_TD_TYPE  sd2405_CurTime;
extern SD2405_TD_TYPE  sd2405_SetTime;

//global func
extern Std_ReturnType SD2405_ReadRealTime(void);
extern Std_ReturnType SD2405_SetTime(void);
extern void SD2405_Task(void);
extern  void SD2405_Init(void);

#endif