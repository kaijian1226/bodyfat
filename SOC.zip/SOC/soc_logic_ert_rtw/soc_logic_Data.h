/*******************************************************************************
 *  Real-Time Workshop code generated for Simulink model < soc_logic >
 *
 *  File: soc_logic_Data.h
 *  File Creation Date: 30-Aug-2016
 *  Data generated on : Tue Aug 30 18:03:34 2016
 *  Abstraction:
 *  Notes:
 *
 *  Model Information:
 *  Model Name: soc_logic
 *  Model Version: 1.137
 *  Model Description:
 *  Creation date:	Thu Nov 06 11:14:33 2014
 *  Last Saved Modification:   Tue Aug 30 18:01:52 2016
 *
 *  (c)Copyright 2008-2014��Wuhan Eureka Control System Co., Ltd.
 *******************************************************************************/
/******************************************************************************
 *  Include files
 ******************************************************************************/
#ifndef RTW_HEADER_soc_logic_Data_h_
#define RTW_HEADER_soc_logic_Data_h_
#include "rtwtypes.h"
#include "soc_logic_types.h"

/*****************************************************************************
 *  Defines
 *****************************************************************************/

/*****************************************************************************
 *  Data Types
 *****************************************************************************/

/*****************************************************************************
 *  Calibration Parameter Declarations
 *****************************************************************************/

/* Exported data declaration */
extern const t_Time SOC_ST;
extern const t_Factor1 soc_fac_ChargeDiffCurv[9];
extern const t_Factor1 soc_fac_CurrentCurv[11];
extern const t_Factor1 soc_fac_DisChargeDiffCurv[9];
extern const t_Factor1 soc_fac_SocCurv[9];
extern const t_Factor1 soc_fac_TempCurv[11];
extern const t_Current1 soc_i_CurrentCurvX[11];
extern const t_Voltage1 soc_ocv_TBL[27];
extern const t_Percent1 soc_percent_MAP[135];
extern const t_Capacity1 soc_r_SocCurvX[9];
extern const t_Percent1 soc_soc_ChargeDiffCurvX[9];
extern const t_Percent1 soc_soc_DisChargeDiffCurvX[9];
extern const t_Temp1 soc_t_TempCurvX[11];
extern const t_Temp1 soc_temp_TBL[5];

/*****************************************************************************
 *  Measurement Variable Declarations
 *****************************************************************************/
extern t_Capacity1 soc_capacity;
extern t_Capacity3 soc_capacityChargeCorrect;
extern t_Capacity3 soc_capacityCharging;
extern t_Capacity1 soc_fullCapacity;
extern t_Capacity1 soc_ocvCapacity;
extern t_Percent1 soc_ocvPercent;
extern t_Percent1 soc_percent;

/*****************************************************************************
 *  Global Function Declaration
 *****************************************************************************/
#endif                                 /* RTW_HEADER_soc_logic_Data_h_ */

/*======================== TOOL VERSION INFORMATION ==========================*
 * MATLAB 8.5 (R2015a)09-Feb-2015                                             *
 * Simulink 8.5 (R2015a)09-Feb-2015                                           *
 * Simulink Coder 8.8 (R2015a)09-Feb-2015                                     *
 * Embedded Coder 6.8 (R2015a)09-Feb-2015                                     *
 * Stateflow 8.5 (R2015a)09-Feb-2015                                          *
 * Fixed-Point Designer 5.0 (R2015a)09-Feb-2015                               *
 *============================================================================*/

/*======================= LICENSE IN USE INFORMATION =========================*
 * fixed_point_toolbox                                                        *
 * matlab                                                                     *
 * matlab_coder                                                               *
 * real-time_workshop                                                         *
 * rtw_embedded_coder                                                         *
 * simulink                                                                   *
 *============================================================================*/
