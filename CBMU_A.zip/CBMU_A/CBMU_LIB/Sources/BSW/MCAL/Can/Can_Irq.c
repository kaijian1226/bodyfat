/*******************************************************************************
*
*  FILE
*     Can_Irq.c
*
*  DESCRIPTION
*     CAN interrupt routines
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Can.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

#if (CAN_TXINT_OSCAT2 == STD_ON)
  #define CAN_TX_IRQ_FUNC(Func)           ISR(Func)
#else
  #define CAN_TX_IRQ_FUNC(Func)           IRQFUNC(Func)
#endif

#if (CAN_RXINT_OSCAT2 == STD_ON)
  #define CAN_RX_IRQ_FUNC(Func)           ISR(Func)
#else
  #define CAN_RX_IRQ_FUNC(Func)           IRQFUNC(Func)
#endif

#if (CAN_ERRINT_OSCAT2 == STD_ON)
  #define CAN_ERROR_IRQ_FUNC(Func)        ISR(Func)
#else
  #define CAN_ERROR_IRQ_FUNC(Func)        IRQFUNC(Func)
#endif

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
  #define CAN_WAKEUP_IRQ_FUNC(Func)       ISR(Func)
#else
  #define CAN_WAKEUP_IRQ_FUNC(Func)       IRQFUNC(Func)
#endif

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/



#if (CAN_CHANNEL0 == STD_ON)

#if (CAN_RX_PROCESSING == CAN_INTERRUPT)

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_RX_IRQ_FUNC(Can_RxInterrupt0)
{
  Can_RxIrqHandler(0);
}

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_RX_PROCESSING == CAN_INTERRUPT) */



#if (CAN_TX_PROCESSING == CAN_INTERRUPT)

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif


CAN_TX_IRQ_FUNC(Can_TxInterrupt0)
{
  Can_TxIrqHandler(0);  
}

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_TX_PROCESSING == CAN_INTERRUPT) */

#if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT)

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_WAKEUP_IRQ_FUNC(Can_WakeUpInterrupt0)
{
  Can_WakeUpIrqHandler(0);
}

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT) */


#if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT)

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_ERROR_IRQ_FUNC(Can_ErrorInterrupt0)
{
  Can_ErrorIrqHandler(0);
}

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT) */

#endif /* #if (CAN_CHANNEL0 == STD_ON) */

#if (CAN_CHANNEL1 == STD_ON)

#if (CAN_RX_PROCESSING == CAN_INTERRUPT)

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_RX_IRQ_FUNC(Can_RxInterrupt1)
{
  Can_RxIrqHandler(1);
}

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif  /* #if (CAN_RX_PROCESSING == CAN_INTERRUPT) */

#if (CAN_TX_PROCESSING == CAN_INTERRUPT)

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_TX_IRQ_FUNC(Can_TxInterrupt1)
{
  Can_TxIrqHandler(1);
}

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif  /* #if (CAN_TX_PROCESSING == CAN_INTERRUPT) */

#if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT)

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_WAKEUP_IRQ_FUNC(Can_WakeUpInterrupt1)
{
  Can_WakeUpIrqHandler(1);
}

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT) */


#if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT)

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif


CAN_ERROR_IRQ_FUNC(Can_ErrorInterrupt1)
{
  Can_ErrorIrqHandler(1);
}

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT) */

#endif /* #if (CAN_CHANNEL1 == STD_ON) */

#if (CAN_CHANNEL2 == STD_ON)
#if (CAN_RX_PROCESSING == CAN_INTERRUPT)

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_RX_IRQ_FUNC(Can_RxInterrupt2)
{
  Can_RxIrqHandler(2);
}

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif

#if (CAN_TX_PROCESSING == CAN_INTERRUPT)

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_TX_IRQ_FUNC(Can_TxInterrupt2)
{
  Can_TxIrqHandler(2);
}

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif

#if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT)

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_WAKEUP_IRQ_FUNC(Can_WakeUpInterrupt2)
{
  Can_WakeUpIrqHandler(2);
}

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT) */

#if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT)

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_ERROR_IRQ_FUNC(Can_ErrorInterrupt2)
{
  Can_ErrorIrqHandler(2);
}

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT) */

#endif /* #if (CAN_CHANNEL2 == STD_ON) */

#if (CAN_CHANNEL3 == STD_ON)
#if (CAN_RX_PROCESSING == CAN_INTERRUPT)

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_RX_IRQ_FUNC(Can_RxInterrupt3)
{
  Can_RxIrqHandler(0);
}

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif

#if (CAN_TX_PROCESSING == CAN_INTERRUPT)

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_TX_IRQ_FUNC(Can_TxInterrupt3)
{
  Can_TxIrqHandler(0);
}

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif

#if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT)

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_WAKEUP_IRQ_FUNC(Can_WakeUpInterrupt3)
{
  Can_WakeUpIrqHandler(0);
}

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT) */

#if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT)

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_ERROR_IRQ_FUNC(Can_ErrorInterrupt3)
{
  Can_ErrorIrqHandler(0);
}

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT) */

#endif /* #if (CAN_CHANNEL3 == STD_ON) */

#if (CAN_CHANNEL4 == STD_ON)

#if (CAN_RX_PROCESSING == CAN_INTERRUPT)

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_RX_IRQ_FUNC(Can_RxInterrupt4)
{
  Can_RxIrqHandler(4);
}

#if (CAN_RXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif

#if (CAN_TX_PROCESSING == CAN_INTERRUPT)

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_TX_IRQ_FUNC(Can_TxInterrupt4)
{
  Can_TxIrqHandler(4);
}

#if (CAN_TXINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif

#if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT)

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_WAKEUP_IRQ_FUNC(Can_WakeUpInterrupt4)
{
  Can_WakeUpIrqHandler(4);
}

#if (CAN_WAKEUPINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_WAKEUP_PROCESSING == CAN_INTERRUPT) */

#if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT)

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_START_SEC_CODE_NEAR
#include "MemMap.h"
#endif

CAN_ERROR_IRQ_FUNC(Can_ErrorInterrupt4)
{
  Can_ErrorIrqHandler(4);
}

#if (CAN_ERRINT_OSCAT2 == STD_ON)
#else
#define CAN_STOP_SEC_CODE_NEAR
#include "MemMap.h"
#endif

#endif /* #if (CAN_BUSOFF_PROCESSING == CAN_INTERRUPT) */

#endif /* #if (CAN_CHANNEL4 == STD_ON) */


/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/
