#include "Xcp_CanIf_Cfg.h"

const uint8 Xcp_TxHandle_C = CANIF_TX_XCP_STATIC_MSG;    