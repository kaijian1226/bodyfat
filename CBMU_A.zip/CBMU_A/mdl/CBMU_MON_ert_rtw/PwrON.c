/*
 * File: PwrON.c
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PwrON.h"

/* Include model header file for global data */
#include "CBMU_MON.h"
#include "CBMU_MON_private.h"

/* Named constants for Chart: '<S23>/Chart' */
#define CBMU_MON_IN_ChargePwrON        ((uint8_T)1U)
#define CBMU_MON_IN_Check_e            ((uint8_T)1U)
#define CBMU_MON_IN_CurrentCheck       ((uint8_T)1U)
#define CBMU_MON_IN_ERR                ((uint8_T)1U)
#define CBMU_MON_IN_FCPwrON            ((uint8_T)2U)
#define CBMU_MON_IN_FCSelfCheck        ((uint8_T)3U)
#define CBMU_MON_IN_NO_ACTIVE_CHILD_d  ((uint8_T)0U)
#define CBMU_MON_IN_Normal             ((uint8_T)2U)
#define CBMU_MON_IN_PostOff            ((uint8_T)1U)
#define CBMU_MON_IN_PostRunDeb         ((uint8_T)2U)
#define CBMU_MON_IN_PwrErr             ((uint8_T)2U)
#define CBMU_MON_IN_PwrOFF             ((uint8_T)3U)
#define CBMU_MON_IN_PwrOnStart         ((uint8_T)4U)
#define CBMU_MON_IN_SCPwrON            ((uint8_T)4U)
#define CBMU_MON_IN_SCSelfCheck        ((uint8_T)5U)
#define CBMU_MON_IN_SelfCheckErr       ((uint8_T)1U)
#define CBMU_MON_IN_SelfCheckOk        ((uint8_T)2U)
#define CBMU_MON_IN_T15PwrON           ((uint8_T)5U)
#define CBMU_MON_IN_cnt                ((uint8_T)1U)
#define CBMU_MON_IN_step0_a            ((uint8_T)3U)
#define CBMU_MON_IN_step1              ((uint8_T)4U)
#define CBMU_MON_IN_step2              ((uint8_T)4U)
#define CBMU_MON_IN_step2_k            ((uint8_T)5U)
#define CBMU_MON_IN_step3              ((uint8_T)5U)
#define CBMU_MON_IN_step3_l            ((uint8_T)6U)
#define CBMU_MON_IN_wait               ((uint8_T)2U)
#define CBMU_MON_IN_wait1              ((uint8_T)3U)
#define CBMU_MON_IN_wait2              ((uint8_T)2U)
#define CBMU_MON_IN_wait_g             ((uint8_T)3U)

/* Forward declaration for local functions */
static void CBMU_MON_HVRelayOff(void);
static boolean_T CBMU_M_IsSC_SelfCheckConditonOk(void);
static boolean_T CBMU_M_IsFC_SelfCheckConditonOk(void);
static void CBMU__exit_internal_ChargePwrON(void);
static void CBMU_MON_ChargePwrON(void);
static void CBMU_MO_enter_internal_T15PwrON(void);
static void CBMU_enter_internal_ChargePwrON(void);
static void CBMU_M_exit_internal_PwrOnStart(void);

/* Function for Chart: '<S23>/Chart' */
static void CBMU_MON_HVRelayOff(void)
{
  /* Graphical Function 'HVRelayOff': '<S24>:244' */
  /* Transition: '<S24>:245' */
  com_BPSHighVoltSts = ((uint8_T)RLY_ST_OPEN);
}

/* Function for Chart: '<S23>/Chart' */
static boolean_T CBMU_M_IsSC_SelfCheckConditonOk(void)
{
  boolean_T y;

  /* Inport: '<Root>/com_Resistance' incorporates:
   *  Inport: '<Root>/com_CCP1ACConnect'
   *  Inport: '<Root>/com_CCP1ACRange'
   *  Inport: '<Root>/com_CCP1ChrgCurrOut'
   *  Inport: '<Root>/com_CCP1ChrgPreReadySts'
   *  Inport: '<Root>/com_CCP1ChrgVolt'
   *  Inport: '<Root>/com_CCP1CommSts'
   *  Inport: '<Root>/com_CCP1HwFault'
   *  Inport: '<Root>/com_CCP1TempSts'
   */
  /* Graphical Function 'IsSC_SelfCheckConditonOk': '<S24>:125' */
  /* Transition: '<S24>:166' */
  if (O_S_HVIL && (ScVolt_St == 0) && (BatVolt_St == 0) && ((com_Resistance >
        200U) && (com_Resistance < 6501U)) && (com_CCP1ChrgVolt <= 34548U) &&
      (com_CCP1ChrgCurrOut <= 160U) && (com_CCP1HwFault == 0) &&
      (com_CCP1ACConnect == 0) && (com_CCP1TempSts == 0) && (com_CCP1CommSts ==
       0) && (com_CCP1ACRange == 3) && (com_CCP1ChrgrPreReadySts == 0)) {
    /* Transition: '<S24>:224' */
    /* Transition: '<S24>:130' */
    /* Transition: '<S24>:132' */
    /* Transition: '<S24>:134' */
    /* (PackTempMax < PackTempHigh) &&(PackTempMin > PackTempLow)
       (PackTempMax < 50) &&(PackTempMin > 0) */
    /* Transition: '<S24>:136' */
    /* Transition: '<S24>:138' */
    /* Transition: '<S24>:140' */
    /* Transition: '<S24>:144' */
    /* Transition: '<S24>:147' */
    /* Transition: '<S24>:150' */
    /* Transition: '<S24>:153' */
    /* Transition: '<S24>:156' */
    /* Transition: '<S24>:160' */
    /* Transition: '<S24>:163' */
    y = true;
  } else {
    /* Transition: '<S24>:227' */
    /* Transition: '<S24>:226' */
    /* Transition: '<S24>:168' */
    /* Transition: '<S24>:182' */
    /* Transition: '<S24>:181' */
    /* Transition: '<S24>:183' */
    /* Transition: '<S24>:185' */
    /* Transition: '<S24>:184' */
    /* Transition: '<S24>:188' */
    /* Transition: '<S24>:187' */
    /* Transition: '<S24>:190' */
    /* Transition: '<S24>:189' */
    /* Transition: '<S24>:192' */
    /* Transition: '<S24>:191' */
    /* Transition: '<S24>:194' */
    /* Transition: '<S24>:193' */
    /* Transition: '<S24>:196' */
    /* Transition: '<S24>:195' */
    /* Transition: '<S24>:198' */
    /* Transition: '<S24>:197' */
    /* Transition: '<S24>:200' */
    /* Transition: '<S24>:199' */
    /* Transition: '<S24>:202' */
    /* Transition: '<S24>:201' */
    /* Transition: '<S24>:203' */
    /* Transition: '<S24>:204' */
    y = false;
  }

  /* End of Inport: '<Root>/com_Resistance' */
  return y;
}

/* Function for Chart: '<S23>/Chart' */
static boolean_T CBMU_M_IsFC_SelfCheckConditonOk(void)
{
  boolean_T y;

  /* Inport: '<Root>/com_Resistance' incorporates:
   *  Inport: '<Root>/com_CRM_RecResult'
   */
  /* Graphical Function 'IsFC_SelfCheckConditonOk': '<S24>:296' */
  /* Transition: '<S24>:327' */
  if (O_S_HVIL && (FcVolt_St == 0) && (com_Resistance > 200U) &&
      (com_CRM_RecResult == 0)) {
    /* Transition: '<S24>:329' */
    /* Transition: '<S24>:332' */
    /* Transition: '<S24>:335' */
    /* [BAT_St == 0] */
    /* Transition: '<S24>:338' */
    /* ��Ե���� */
    /* Transition: '<S24>:341' */
    /* (PackTempMax < PackTempHigh) &&(PackTempMin > PackTempLow)
       (PackTempMax < 50) &&(PackTempMin > 0) */
    /* Transition: '<S24>:344' */
    /* [com_CCP1ChrgVolt <= (1780 + 32768)] */
    /* Transition: '<S24>:347' */
    /* [com_CCP1ChrgCurrOut <= 160] */
    /* Transition: '<S24>:351' */
    /* [com_CCP1HwFault == 0] */
    /* Transition: '<S24>:354' */
    /* [com_CCP1ACConnect == 0] */
    /* Transition: '<S24>:357' */
    /* [com_CCP1TempSts == 0] */
    /* Transition: '<S24>:360' */
    /* [com_CCP1CommSts == 0] */
    /* Transition: '<S24>:363' */
    /* [com_CCP1ACRange == 3] */
    /* Transition: '<S24>:366' */
    /* [com_CCP1ChrgrPreReadySts == 0] */
    /* Transition: '<S24>:383' */
    /* Transition: '<S24>:367' */
    y = true;
  } else {
    /* Transition: '<S24>:328' */
    /* Transition: '<S24>:330' */
    /* Transition: '<S24>:331' */
    /* Transition: '<S24>:333' */
    /* Transition: '<S24>:336' */
    /* Transition: '<S24>:337' */
    /* Transition: '<S24>:339' */
    /* Transition: '<S24>:342' */
    /* Transition: '<S24>:345' */
    /* Transition: '<S24>:348' */
    /* Transition: '<S24>:350' */
    /* Transition: '<S24>:353' */
    /* Transition: '<S24>:356' */
    /* Transition: '<S24>:359' */
    /* Transition: '<S24>:362' */
    /* Transition: '<S24>:365' */
    /* Transition: '<S24>:387' */
    /* Transition: '<S24>:385' */
    /* Transition: '<S24>:368' */
    y = false;
  }

  /* End of Inport: '<Root>/com_Resistance' */
  return y;
}

/* Function for Chart: '<S23>/Chart' */
static void CBMU__exit_internal_ChargePwrON(void)
{
  /* Exit Internal 'ChargePwrON': '<S24>:388' */
  switch (CBMU_MON_DWork.bitsForTID0.is_ChargePwrON) {
   case CBMU_MON_IN_CurrentCheck:
    /* Exit Internal 'CurrentCheck': '<S24>:655' */
    /* Exit Internal 'state2': '<S24>:796' */
    CBMU_MON_DWork.bitsForTID0.is_state2_m = CBMU_MON_IN_NO_ACTIVE_CHILD_d;

    /* Exit Internal 'state1': '<S24>:795' */
    CBMU_MON_DWork.bitsForTID0.is_state1_m = CBMU_MON_IN_NO_ACTIVE_CHILD_d;

    /* Exit 'CurrentCheck': '<S24>:655' */
    CBMU_MON_DWork.cnt7 = 0U;
    CBMU_MON_DWork.cnt6 = 0U;
    CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
    break;

   case CBMU_MON_IN_FCSelfCheck:
    /* Exit Internal 'FCSelfCheck': '<S24>:280' */
    switch (CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck) {
     case CBMU_MON_IN_step2:
      /* Exit 'step2': '<S24>:291' */
      CBMU_MON_DWork.pwr_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;

     case CBMU_MON_IN_step3:
      /* Exit 'step3': '<S24>:292' */
      CBMU_MON_DWork.pwr_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;

     default:
      CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;
    }

    CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
    break;

   case CBMU_MON_IN_SCSelfCheck:
    /* Exit Internal 'SCSelfCheck': '<S24>:25' */
    switch (CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck) {
     case CBMU_MON_IN_step2_k:
      /* Exit 'step2': '<S24>:277' */
      CBMU_MON_DWork.pwr_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;

     case CBMU_MON_IN_step3_l:
      /* Exit 'step3': '<S24>:93' */
      CBMU_MON_DWork.pwr_ct = 0UL;
      CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;

     default:
      CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
      break;
    }

    CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
    break;

   default:
    CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
    break;
  }
}

/* Function for Chart: '<S23>/Chart' */
static void CBMU_MON_ChargePwrON(void)
{
  uint32_T qY;
  uint16_T qY_0;

  /* During 'ChargePwrON': '<S24>:388' */
  if ((!I_S_Sc) && (!I_S_Fc)) {
    /* Transition: '<S24>:31' */
    CBMU__exit_internal_ChargePwrON();
    PwrMode = 0U;
    PackCurMode = 0U;
    CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_PwrOFF;

    /* Entry 'PwrOFF': '<S24>:5' */
    /*
       1.disable CAN
       2.Relay OFF
       3.power OFF
       ??? AfterRun() ???

       en:	PowerMode = 0;
       PackCurMode = 0; */
    /* Entry Internal 'PwrOFF': '<S24>:5' */
    /* Transition: '<S24>:237' */
    CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
    CBMU_MON_DWork.bitsForTID0.is_PwrOFF = CBMU_MON_IN_PostRunDeb;

    /* Entry 'PostRunDeb': '<S24>:236' */
    CBMU_MON_HVRelayOff();
    CBMU_MON_B.ContactorEnable = 0U;
    com_VehBusTxEna = false;
    com_SlowChrgrTxEna = false;
    com_FastChrgrTxEna = false;
    com_ShutDown = 1U;
    CBMU_MON_DWork.pwr_ct = 0UL;
  } else {
    switch (CBMU_MON_DWork.bitsForTID0.is_ChargePwrON) {
     case CBMU_MON_IN_CurrentCheck:
      /* During 'CurrentCheck': '<S24>:655' */
      qY_0 = CBMU_MON_DWork.cnt7 + 10U;
      if (qY_0 < CBMU_MON_DWork.cnt7) {
        qY_0 = MAX_uint16_T;
      }

      CBMU_MON_DWork.cnt7 = qY_0;

      /* During 'state1': '<S24>:795' */
      if (CBMU_MON_DWork.bitsForTID0.is_state1_m == CBMU_MON_IN_cnt) {
        /* During 'cnt': '<S24>:851' */
        if ((CBMU_MON_B.DataStoreRead5 > 32448U) && (CBMU_MON_B.DataStoreRead5 <
             32576U)) {
          /* Transition: '<S24>:849' */
          CBMU_MON_DWork.bitsForTID0.is_state1_m = CBMU_MON_IN_wait2;
        } else {
          qY_0 = CBMU_MON_DWork.cnt6 + 10U;
          if (qY_0 < CBMU_MON_DWork.cnt6) {
            qY_0 = MAX_uint16_T;
          }

          CBMU_MON_DWork.cnt6 = qY_0;
        }
      } else {
        /* During 'wait2': '<S24>:850' */
        if ((CBMU_MON_B.DataStoreRead5 <= 32448U) || (CBMU_MON_B.DataStoreRead5 >=
             32576U)) {
          /* Transition: '<S24>:848' */
          /* ����2A */
          CBMU_MON_DWork.bitsForTID0.is_state1_m = CBMU_MON_IN_cnt;
        }
      }

      /* During 'state2': '<S24>:796' */
      switch (CBMU_MON_DWork.bitsForTID0.is_state2_m) {
       case CBMU_MON_IN_ERR:
        /* During 'ERR': '<S24>:717' */
        CBMU_MON_DWork.cnt6 = 0U;

        /* �ϵ�ǰ�����쳣 */
        break;

       case CBMU_MON_IN_Normal:
        /* During 'Normal': '<S24>:724' */
        /* Transition: '<S24>:725' */
        if (I_S_Sc) {
          /* Transition: '<S24>:566' */
          /* Exit Internal 'CurrentCheck': '<S24>:655' */
          /* Exit Internal 'state2': '<S24>:796' */
          CBMU_MON_DWork.bitsForTID0.is_state2_m = CBMU_MON_IN_NO_ACTIVE_CHILD_d;

          /* Exit Internal 'state1': '<S24>:795' */
          CBMU_MON_DWork.bitsForTID0.is_state1_m = CBMU_MON_IN_NO_ACTIVE_CHILD_d;

          /* Exit 'CurrentCheck': '<S24>:655' */
          CBMU_MON_DWork.cnt7 = 0U;
          CBMU_MON_DWork.cnt6 = 0U;
          CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_SCPwrON;

          /* Entry Internal 'SCPwrON': '<S24>:560' */
          /* Transition: '<S24>:564' */
          CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
          PwrMode = 2U;
          PackCurMode = 1U;
          CBMU_MON_B.ContactorEnable = 1U;
        } else {
          if (I_S_Fc) {
            /* Transition: '<S24>:567' */
            /* Exit Internal 'CurrentCheck': '<S24>:655' */
            /* Exit Internal 'state2': '<S24>:796' */
            CBMU_MON_DWork.bitsForTID0.is_state2_m =
              CBMU_MON_IN_NO_ACTIVE_CHILD_d;

            /* Exit Internal 'state1': '<S24>:795' */
            CBMU_MON_DWork.bitsForTID0.is_state1_m =
              CBMU_MON_IN_NO_ACTIVE_CHILD_d;

            /* Exit 'CurrentCheck': '<S24>:655' */
            CBMU_MON_DWork.cnt7 = 0U;
            CBMU_MON_DWork.cnt6 = 0U;
            CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_FCPwrON;

            /* Entry Internal 'FCPwrON': '<S24>:561' */
            /* Transition: '<S24>:562' */
            CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
            PwrMode = 3U;
            PackCurMode = 2U;
            CBMU_MON_B.ContactorEnable = 1U;
          }
        }
        break;

       default:
        /* During 'wait': '<S24>:835' */
        if ((CBMU_MON_DWork.cnt7 >= 5000U) && (CBMU_MON_DWork.cnt6 >= 3500U)) {
          /* Transition: '<S24>:723' */
          CBMU_MON_DWork.bitsForTID0.is_state2_m = CBMU_MON_IN_ERR;

          /* Entry 'ERR': '<S24>:717' */
          CBMU_MON_B.CurError = 1U;
        } else {
          if (CBMU_MON_DWork.cnt7 >= 5000U) {
            /* Transition: '<S24>:837' */
            CBMU_MON_DWork.bitsForTID0.is_state2_m = CBMU_MON_IN_Normal;

            /* Entry 'Normal': '<S24>:724' */
            CBMU_MON_B.CurError = 0U;
          }
        }
        break;
      }
      break;

     case CBMU_MON_IN_FCPwrON:
      /* During 'FCPwrON': '<S24>:561' */
      break;

     case CBMU_MON_IN_FCSelfCheck:
      /* During 'FCSelfCheck': '<S24>:280' */
      if (com_BPSSelfChkSts == 1) {
        /* Transition: '<S24>:550' */
        /* Exit Internal 'FCSelfCheck': '<S24>:280' */
        switch (CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck) {
         case CBMU_MON_IN_step2:
          /* Exit 'step2': '<S24>:291' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;

         case CBMU_MON_IN_step3:
          /* Exit 'step3': '<S24>:292' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;

         default:
          CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;
        }

        CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_CurrentCheck;

        /* Entry 'CurrentCheck': '<S24>:655' */
        CBMU_MON_B.CurError = 0U;
        CBMU_MON_DWork.cnt7 = 0U;
        CBMU_MON_DWork.cnt6 = 0U;

        /* Entry Internal 'CurrentCheck': '<S24>:655' */
        /* Entry Internal 'state1': '<S24>:795' */
        /* Transition: '<S24>:847' */
        CBMU_MON_DWork.bitsForTID0.is_state1_m = CBMU_MON_IN_wait2;

        /* Entry Internal 'state2': '<S24>:796' */
        /* Transition: '<S24>:836' */
        CBMU_MON_DWork.bitsForTID0.is_state2_m = CBMU_MON_IN_wait_g;
      } else {
        switch (CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck) {
         case CBMU_MON_IN_SelfCheckErr:
          com_BEMTxEna = true;
          com_BPSSelfChkSts = 2U;

          /* During 'SelfCheckErr': '<S24>:293' */
          break;

         case CBMU_MON_IN_SelfCheckOk:
          com_BPSSelfChkSts = 1U;

          /* During 'SelfCheckOk': '<S24>:294' */
          break;

         case CBMU_MON_IN_step0_a:
          com_BEM_RcvChgerTotalMsg = 2U;
          com_BEM_RcvChgerStateMsg = 2U;
          com_BEM_RcvChgerReadyMsg = 2U;
          com_BEM_RcvChgerStopMsg = 2U;
          com_BEM_RcvChgerRecMsg_AA = 2U;
          com_BEMTxEna = false;
          com_BSDTxEna = false;
          com_BSTTxEna = false;
          com_BCLTxEna = false;
          com_BPSSelfChkSts = 0U;
          ioa_12VOut = true;
          ioa_5VOut = true;
          com_BEM_RcvChgerCMLMsg = 2U;
          com_BROTxEna = false;
          com_ShutDown = 0U;
          com_BCSTxEna = false;
          com_BRMTxEna = false;
          com_BCPTxEna = false;
          com_BSMTxEna = false;
          ioa_PwrOut = true;

          /* During 'step0': '<S24>:287' */
          /* Transition: '<S24>:413' */
          CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_step2;

          /* Entry 'step2': '<S24>:291' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          break;

         case CBMU_MON_IN_step2:
          /* During 'step2': '<S24>:291' */
          if (CBMU_MON_DWork.pwr_ct > 1000UL) {
            /* Transition: '<S24>:284' */
            /* Exit 'step2': '<S24>:291' */
            CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_step3;

            /* Entry 'step3': '<S24>:292' */
            CBMU_MON_DWork.pwr_ct = 0UL;
          } else {
            qY = CBMU_MON_DWork.pwr_ct + 10UL;
            if (qY < CBMU_MON_DWork.pwr_ct) {
              qY = MAX_uint32_T;
            }

            CBMU_MON_DWork.pwr_ct = qY;
          }
          break;

         default:
          /* Inport: '<Root>/COMM_NA' */
          /* During 'step3': '<S24>:292' */
          if ((!COMM_NA) && (!com_CRMTimeoutFlag) && O_S_FCCC && O_S_HVIL &&
              CBMU_M_IsFC_SelfCheckConditonOk()) {
            /* Transition: '<S24>:286' */
            /* Exit 'step3': '<S24>:292' */
            CBMU_MON_DWork.pwr_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_SelfCheckOk;

            /* Entry 'SelfCheckOk': '<S24>:294' */
            /* com_BPSHighVoltSts = 1; */
            com_BEM_RcvChgerRecMsg_00 = 0U;
            com_BPSSelfChkSts = 1U;
            com_BPSBattMaintenanceAlarm = false;
          } else if (CBMU_MON_DWork.pwr_ct > 65000UL) {
            /* Transition: '<S24>:285' */
            /* �ȴ���������CRM */
            /* Exit 'step3': '<S24>:292' */
            CBMU_MON_DWork.pwr_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_SelfCheckErr;

            /* Entry 'SelfCheckErr': '<S24>:293' */
            com_BPSSelfChkSts = 2U;
            com_BPSBattMaintenanceAlarm = true;
            com_BEM_RcvChgerRecMsg_00 = 1U;

            /* timeout error */
            com_BEMTxEna = true;
          } else {
            qY = CBMU_MON_DWork.pwr_ct + 10UL;
            if (qY < CBMU_MON_DWork.pwr_ct) {
              qY = MAX_uint32_T;
            }

            CBMU_MON_DWork.pwr_ct = qY;
          }
          break;
        }
      }
      break;

     case CBMU_MON_IN_SCPwrON:
      /* During 'SCPwrON': '<S24>:560' */
      break;

     default:
      /* During 'SCSelfCheck': '<S24>:25' */
      if (com_BPSSelfChkSts == 1) {
        /* Transition: '<S24>:549' */
        /* Exit Internal 'SCSelfCheck': '<S24>:25' */
        switch (CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck) {
         case CBMU_MON_IN_step2_k:
          /* Exit 'step2': '<S24>:277' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;

         case CBMU_MON_IN_step3_l:
          /* Exit 'step3': '<S24>:93' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;

         default:
          CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck =
            CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;
        }

        CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_CurrentCheck;

        /* Entry 'CurrentCheck': '<S24>:655' */
        CBMU_MON_B.CurError = 0U;
        CBMU_MON_DWork.cnt7 = 0U;
        CBMU_MON_DWork.cnt6 = 0U;

        /* Entry Internal 'CurrentCheck': '<S24>:655' */
        /* Entry Internal 'state1': '<S24>:795' */
        /* Transition: '<S24>:847' */
        CBMU_MON_DWork.bitsForTID0.is_state1_m = CBMU_MON_IN_wait2;

        /* Entry Internal 'state2': '<S24>:796' */
        /* Transition: '<S24>:836' */
        CBMU_MON_DWork.bitsForTID0.is_state2_m = CBMU_MON_IN_wait_g;
      } else {
        switch (CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck) {
         case CBMU_MON_IN_SelfCheckErr:
          com_BPSSelfChkSts = 2U;

          /* During 'SelfCheckErr': '<S24>:98' */
          break;

         case CBMU_MON_IN_SelfCheckOk:
          com_BPC2MaxChrgCurrent = 160U;
          com_BPSSelfChkSts = 1U;
          com_BPC2MaxChrgVolt = 1700U;

          /* During 'SelfCheckOk': '<S24>:104' */
          break;

         case CBMU_MON_IN_step0_a:
          ioa_12VOut = true;
          ioa_5VOut = true;
          com_ShutDown = 0U;
          ioa_PwrOut = true;

          /* During 'step0': '<S24>:95' */
          /* Transition: '<S24>:102' */
          CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_step1;

          /* Entry 'step1': '<S24>:96' */
          com_BPSSelfChkSts = 0U;

          /* SC_SELFCHECK_NONE */
          com_VehBusTxEna = true;

          /* InitSCParam() */
          com_BPC2MaxChrgVolt = 1700U;
          com_BPC2MaxChrgCurrent = 160U;
          com_BPC2ChrgEnable = true;
          com_BPC2ChrgSts = 0U;
          com_BPC2ChrgrACInput = true;
          BMS_ChargerDCInput = 1U;
          com_SlowChrgrTxEna = true;

          /* send  BPC2 message
             VehPowerMode = PM_VEH_MODE; */
          break;

         case CBMU_MON_IN_step1:
          BMS_ChargerDCInput = 1U;
          com_BPC2ChrgSts = 0U;
          com_BPC2MaxChrgCurrent = 160U;
          com_BPSSelfChkSts = 0U;
          com_BPC2MaxChrgVolt = 1700U;

          /* During 'step1': '<S24>:96' */
          /* Transition: '<S24>:101' */
          CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_step2_k;

          /* Entry 'step2': '<S24>:277' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          break;

         case CBMU_MON_IN_step2_k:
          /* During 'step2': '<S24>:277' */
          if (CBMU_MON_DWork.pwr_ct > 1000UL) {
            /* Transition: '<S24>:278' */
            /* Exit 'step2': '<S24>:277' */
            CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_step3_l;

            /* Entry 'step3': '<S24>:93' */
            CBMU_MON_DWork.pwr_ct = 0UL;
          } else {
            qY = CBMU_MON_DWork.pwr_ct + 10UL;
            if (qY < CBMU_MON_DWork.pwr_ct) {
              qY = MAX_uint32_T;
            }

            CBMU_MON_DWork.pwr_ct = qY;
          }
          break;

         default:
          /* Inport: '<Root>/COMM_NA' incorporates:
           *  Inport: '<Root>/SC_NA'
           */
          /* During 'step3': '<S24>:93' */
          /*   */
          if ((!COMM_NA) && (!CBMU_MON_B.bitsForTID0.HW_Err_n) && (!SC_NA) &&
              O_S_SCCC && O_S_HVIL && CBMU_M_IsSC_SelfCheckConditonOk()) {
            /* Transition: '<S24>:94' */
            /* Exit 'step3': '<S24>:93' */
            CBMU_MON_DWork.pwr_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_SelfCheckOk;

            /* Entry 'SelfCheckOk': '<S24>:104' */
            /* com_BPSHighVoltSts = 1; */
            com_BPC2MaxChrgVolt = 1700U;
            com_BPC2MaxChrgCurrent = 160U;

            /* com_BPC2ChrgEnable = 1;
               com_BPC2ChrgSts = 1; */
            com_BPC2ChrgrACInput = false;
            com_BPSSelfChkSts = 1U;
            com_BPSBattMaintenanceAlarm = false;
          } else if (CBMU_MON_DWork.pwr_ct > 5000UL) {
            /* Transition: '<S24>:103' */
            /* Exit 'step3': '<S24>:93' */
            CBMU_MON_DWork.pwr_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_SelfCheckErr;

            /* Entry 'SelfCheckErr': '<S24>:98' */
            com_BPSSelfChkSts = 2U;
            com_BPSBattMaintenanceAlarm = true;
          } else {
            qY = CBMU_MON_DWork.pwr_ct + 10UL;
            if (qY < CBMU_MON_DWork.pwr_ct) {
              qY = MAX_uint32_T;
            }

            CBMU_MON_DWork.pwr_ct = qY;
          }
          break;
        }
      }
      break;
    }
  }
}

/* Function for Chart: '<S23>/Chart' */
static void CBMU_MO_enter_internal_T15PwrON(void)
{
  /* Entry Internal 'T15PwrON': '<S24>:3' */
  /* Transition: '<S24>:8' */
  CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
  PwrMode = 1U;
  PackCurMode = 0U;
  CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_step0_a;

  /* Entry 'step0': '<S24>:7' */
  ioa_12VOut = true;

  /* HVCU�ϵ� */
  ioa_5VOut = true;

  /* �������ϵ� */
  ioa_PwrOut = true;
  com_ShutDown = 0U;
  com_InnerBusRxEna = true;
  com_InnerBusTxEna = true;

  /* ʹ���ڲ�CAN */
  com_VehBusRxEna = true;
  com_SlowChrgrRxEna = true;
  com_FastChrgrRxEna = true;
}

/* Function for Chart: '<S23>/Chart' */
static void CBMU_enter_internal_ChargePwrON(void)
{
  /* Entry Internal 'ChargePwrON': '<S24>:388' */
  /* Transition: '<S24>:392' */
  if (I_S_Sc) {
    /* Transition: '<S24>:391' */
    CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_SCSelfCheck;

    /* Entry Internal 'SCSelfCheck': '<S24>:25' */
    /* Transition: '<S24>:100' */
    CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
    PwrMode = 2U;
    PackCurMode = 1U;
    CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_step0_a;

    /* Entry 'step0': '<S24>:95' */
    ioa_12VOut = true;

    /* HVCU�ϵ� */
    ioa_5VOut = true;

    /* �������ϵ� */
    ioa_PwrOut = true;
    com_ShutDown = 0U;
    com_InnerBusRxEna = true;
    com_InnerBusTxEna = true;

    /* ʹ���ڲ�CAN */
    com_VehBusRxEna = true;
    com_SlowChrgrRxEna = true;
    com_FastChrgrRxEna = true;
  } else {
    /* Transition: '<S24>:394' */
    if (I_S_Fc) {
      /* Transition: '<S24>:395' */
      CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_FCSelfCheck;

      /* Entry Internal 'FCSelfCheck': '<S24>:280' */
      /* Transition: '<S24>:281' */
      CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
      PwrMode = 3U;
      PackCurMode = 2U;
      CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_step0_a;

      /* Entry 'step0': '<S24>:287' */
      ioa_12VOut = true;

      /* HVCU�ϵ� */
      ioa_5VOut = true;

      /* �������ϵ� */
      ioa_PwrOut = true;
      com_ShutDown = 0U;
      com_InnerBusRxEna = true;
      com_InnerBusTxEna = true;

      /* ʹ���ڲ�CAN */
      com_VehBusRxEna = true;
      com_SlowChrgrRxEna = true;
      com_FastChrgrRxEna = true;
      com_BPSSelfChkSts = 0U;

      /* SC_SELFCHECK_NONE */
      com_VehBusTxEna = true;
      com_FastChrgrTxEna = true;
      com_BRMTxEna = false;
      com_BCPTxEna = false;
      com_BROTxEna = false;
      com_BCLTxEna = false;
      com_BCSTxEna = false;
      com_BSMTxEna = false;
      com_BSTTxEna = false;
      com_BSDTxEna = false;
      com_BEMTxEna = false;
      com_CRMTimeoutFlag = false;

      /* 20150919 trueȫ��Ϊfalse */
      com_CTSTimeoutFlag = false;
      com_CMLTimeoutFlag = false;
      com_CROTimeoutFlag = false;
      com_CCSTimeoutFlag = false;
      com_CSTTimeoutFlag = false;
      com_CSDTimeoutFlag = false;
      com_CEMTimeoutFlag = false;
      com_BEM_RcvChgerRecMsg_AA = 2U;
      com_BEM_RcvChgerRecMsg_00 = 2U;
      com_BEM_RcvChgerCMLMsg = 2U;
      com_BEM_RcvChgerReadyMsg = 2U;
      com_BEM_RcvChgerStopMsg = 2U;
      com_BEM_RcvChgerStateMsg = 2U;
      com_BEM_RcvChgerTotalMsg = 2U;
    }
  }
}

/* Function for Chart: '<S23>/Chart' */
static void CBMU_M_exit_internal_PwrOnStart(void)
{
  /* Exit Internal 'PwrOnStart': '<S24>:231' */
  switch (CBMU_MON_DWork.bitsForTID0.is_PwrOnStart) {
   case CBMU_MON_IN_Check_e:
    /* Exit Internal 'Check': '<S24>:816' */
    /* Exit Internal 'state2': '<S24>:801' */
    CBMU_MON_DWork.bitsForTID0.is_state2 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;

    /* Exit Internal 'state1': '<S24>:807' */
    CBMU_MON_DWork.bitsForTID0.is_state1 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;

    /* Exit 'Check': '<S24>:816' */
    CBMU_MON_DWork.cnt7 = 0U;
    CBMU_MON_DWork.cnt6 = 0U;
    CBMU_MON_DWork.bitsForTID0.is_PwrOnStart = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
    break;

   case CBMU_MON_IN_wait:
    /* Exit 'wait': '<S24>:830' */
    CBMU_MON_DWork.cnt8 = 0U;
    CBMU_MON_DWork.bitsForTID0.is_PwrOnStart = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
    break;

   default:
    CBMU_MON_DWork.bitsForTID0.is_PwrOnStart = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
    break;
  }
}

/* System initialize for atomic system: '<S1>/PwrON' */
void CBMU_MON_PwrON_Init(void)
{
  /* SystemInitialize for Chart: '<S23>/Chart' */
  CBMU_MON_DWork.bitsForTID0.is_ChargePwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_state1_m = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_state2_m = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_FCSelfCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_SCSelfCheck = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_PwrOFF = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_PwrOnStart = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_state1 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_state2 = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.bitsForTID0.is_active_c35_CBMU_MON = 0U;
  CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
  CBMU_MON_DWork.pwr_ct = 0UL;
  CBMU_MON_DWork.cnt6 = 0U;
  CBMU_MON_DWork.cnt7 = 0U;
  CBMU_MON_DWork.cnt8 = 0U;
  ioa_12VOut = false;
  ioa_5VOut = false;
  com_InnerBusRxEna = false;
  com_InnerBusTxEna = false;
  com_VehBusRxEna = false;
  com_SlowChrgrRxEna = false;
  com_FastChrgrRxEna = false;
  com_BPSSelfChkSts = 0U;
  com_VehBusTxEna = false;
  com_BPC2MaxChrgVolt = 0U;
  com_BPC2MaxChrgCurrent = 0U;
  com_BPC2ChrgEnable = false;
  com_BPC2ChrgSts = 0U;
  com_BPC2ChrgrACInput = false;
  BMS_ChargerDCInput = 0U;
  com_SlowChrgrTxEna = false;
  com_BPSBattMaintenanceAlarm = false;
  PwrMode = 0U;
  PackCurMode = 0U;
  ioa_PwrOut = false;
  com_FastChrgrTxEna = false;
  com_ShutDown = 0U;
  com_BPSHighVoltSts = 0U;
  CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
  com_BCLTxEna = false;
  com_BCPTxEna = false;
  com_BCSTxEna = false;
  com_BEMTxEna = false;
  com_BEM_RcvChgerCMLMsg = 0U;
  com_BEM_RcvChgerReadyMsg = 0U;
  com_BEM_RcvChgerRecMsg_00 = 0U;
  com_BEM_RcvChgerRecMsg_AA = 0U;
  com_BEM_RcvChgerStateMsg = 0U;
  com_BEM_RcvChgerStopMsg = 0U;
  com_BEM_RcvChgerTotalMsg = 0U;
  com_BRMTxEna = false;
  com_BROTxEna = false;
  com_BSDTxEna = false;
  com_BSMTxEna = false;
  com_BSTTxEna = false;
  CBMU_MON_B.CurError = 0U;
  CBMU_MON_B.ContactorEnable = 0U;
}

/* Output and update for atomic system: '<S1>/PwrON' */
void CBMU_MON_PwrON(void)
{
  uint8_T rtb_DataTypeConversion6;
  uint32_T qY;
  uint16_T qY_0;
  boolean_T guard1 = false;

  /* Chart: '<S23>/Chart' incorporates:
   *  Inport: '<Root>/BMS_FM2St'
   *  Inport: '<Root>/com_Resistance'
   */
  /* Gateway: Task_10ms/PwrON/PwrON_Check/Chart */
  /* During: Task_10ms/PwrON/PwrON_Check/Chart */
  if (CBMU_MON_DWork.bitsForTID0.is_active_c35_CBMU_MON == 0U) {
    /* Entry: Task_10ms/PwrON/PwrON_Check/Chart */
    CBMU_MON_DWork.bitsForTID0.is_active_c35_CBMU_MON = 1U;

    /* Entry Internal: Task_10ms/PwrON/PwrON_Check/Chart */
    /* Transition: '<S24>:220' */
    CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_PwrOnStart;

    /* Entry Internal 'PwrOnStart': '<S24>:231' */
    /* Transition: '<S24>:774' */
    CBMU_MON_DWork.bitsForTID0.is_PwrOnStart = CBMU_MON_IN_wait;

    /* Entry 'wait': '<S24>:830' */
    CBMU_MON_DWork.cnt8 = 0U;
    ioa_12VOut = true;

    /* HVCU�ϵ� */
    ioa_5VOut = true;

    /* �������ϵ� */
    ioa_PwrOut = true;
    com_ShutDown = 0U;
    com_InnerBusRxEna = true;
    com_InnerBusTxEna = true;

    /* ʹ���ڲ�CAN */
    com_VehBusRxEna = true;
    com_SlowChrgrRxEna = true;
    com_FastChrgrRxEna = true;
  } else {
    guard1 = false;
    switch (CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON) {
     case CBMU_MON_IN_ChargePwrON:
      CBMU_MON_ChargePwrON();
      break;

     case CBMU_MON_IN_PwrErr:
      BMS_ChargerDCInput = 1U;
      com_BPC2ChrgSts = 2U;
      com_BPC2MaxChrgCurrent = 160U;
      com_BPC2MaxChrgVolt = 1700U;

      /* During 'PwrErr': '<S24>:6' */
      if ((!I_S_T15) && (!I_S_Sc) && (!I_S_Fc)) {
        /* Transition: '<S24>:234' */
        CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_PwrOFF;

        /* Entry 'PwrOFF': '<S24>:5' */
        /*
           1.disable CAN
           2.Relay OFF
           3.power OFF
           ??? AfterRun() ???

           en:	PowerMode = 0;
           PackCurMode = 0; */
        /* Entry Internal 'PwrOFF': '<S24>:5' */
        /* Transition: '<S24>:237' */
        CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
        CBMU_MON_DWork.bitsForTID0.is_PwrOFF = CBMU_MON_IN_PostRunDeb;

        /* Entry 'PostRunDeb': '<S24>:236' */
        CBMU_MON_HVRelayOff();
        CBMU_MON_B.ContactorEnable = 0U;
        com_VehBusTxEna = false;
        com_SlowChrgrTxEna = false;
        com_FastChrgrTxEna = false;
        com_ShutDown = 1U;
        CBMU_MON_DWork.pwr_ct = 0UL;
      } else {
        /* Transition: '<S24>:400' */
        if (I_S_T15 && (!I_S_Sc) && (!I_S_Fc)) {
          /* Transition: '<S24>:34' */
          CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_T15PwrON;
          CBMU_MO_enter_internal_T15PwrON();
        }
      }
      break;

     case CBMU_MON_IN_PwrOFF:
      /* During 'PwrOFF': '<S24>:5' */
      /* Transition: '<S24>:235' */
      if (I_S_T15 && (!I_S_Sc) && (!I_S_Fc)) {
        /* Transition: '<S24>:34' */
        /* Exit Internal 'PwrOFF': '<S24>:5' */
        if (CBMU_MON_DWork.bitsForTID0.is_PwrOFF == CBMU_MON_IN_PostRunDeb) {
          /* Exit 'PostRunDeb': '<S24>:236' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_PwrOFF = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
        } else {
          CBMU_MON_DWork.bitsForTID0.is_PwrOFF = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
        }

        CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_T15PwrON;
        CBMU_MO_enter_internal_T15PwrON();
      } else if (CBMU_MON_DWork.bitsForTID0.is_PwrOFF == CBMU_MON_IN_PostOff) {
        ioa_12VOut = false;
        ioa_5VOut = false;
        ioa_PwrOut = false;

        /* During 'PostOff': '<S24>:238' */
      } else {
        com_ShutDown = 1U;

        /* During 'PostRunDeb': '<S24>:236' */
        if (CBMU_MON_DWork.pwr_ct > 5000UL) {
          /* Transition: '<S24>:239' */
          /* Exit 'PostRunDeb': '<S24>:236' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_PwrOFF = CBMU_MON_IN_PostOff;

          /* Entry 'PostOff': '<S24>:238' */
          /* EcuM_AppPostRun(); */
          ioa_12VOut = false;
          ioa_5VOut = false;
          ioa_PwrOut = false;
        } else {
          qY = CBMU_MON_DWork.pwr_ct + 10UL;
          if (qY < CBMU_MON_DWork.pwr_ct) {
            qY = MAX_uint32_T;
          }

          CBMU_MON_DWork.pwr_ct = qY;
        }
      }
      break;

     case CBMU_MON_IN_PwrOnStart:
      /* During 'PwrOnStart': '<S24>:231' */
      switch (CBMU_MON_DWork.bitsForTID0.is_PwrOnStart) {
       case CBMU_MON_IN_Check_e:
        /* During 'Check': '<S24>:816' */
        qY_0 = CBMU_MON_DWork.cnt7 + 10U;
        if (qY_0 < CBMU_MON_DWork.cnt7) {
          qY_0 = MAX_uint16_T;
        }

        CBMU_MON_DWork.cnt7 = qY_0;

        /* During 'state1': '<S24>:807' */
        if (CBMU_MON_DWork.bitsForTID0.is_state1 == CBMU_MON_IN_cnt) {
          /* During 'cnt': '<S24>:845' */
          if ((CBMU_MON_B.DataStoreRead5 > 32464U) && (CBMU_MON_B.DataStoreRead5
               < 32560U)) {
            /* Transition: '<S24>:846' */
            CBMU_MON_DWork.bitsForTID0.is_state1 = CBMU_MON_IN_wait2;
          } else {
            qY_0 = CBMU_MON_DWork.cnt6 + 10U;
            if (qY_0 < CBMU_MON_DWork.cnt6) {
              qY_0 = MAX_uint16_T;
            }

            CBMU_MON_DWork.cnt6 = qY_0;
          }
        } else {
          /* During 'wait2': '<S24>:844' */
          if ((CBMU_MON_B.DataStoreRead5 <= 32464U) ||
              (CBMU_MON_B.DataStoreRead5 >= 32560U)) {
            /* Transition: '<S24>:811' */
            /* ����1.75A */
            CBMU_MON_DWork.bitsForTID0.is_state1 = CBMU_MON_IN_cnt;
          }
        }

        /* During 'state2': '<S24>:801' */
        switch (CBMU_MON_DWork.bitsForTID0.is_state2) {
         case CBMU_MON_IN_ERR:
          /* During 'ERR': '<S24>:812' */
          /* Transition: '<S24>:821' */
          /* Transition: '<S24>:825' */
          if (I_S_T15) {
            /* Transition: '<S24>:29' */
            CBMU_M_exit_internal_PwrOnStart();
            CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_T15PwrON;
            CBMU_MO_enter_internal_T15PwrON();
          } else {
            if (I_S_Sc || I_S_Fc) {
              /* Transition: '<S24>:30' */
              CBMU_M_exit_internal_PwrOnStart();
              CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON =
                CBMU_MON_IN_ChargePwrON;
              CBMU_enter_internal_ChargePwrON();
            }
          }
          break;

         case CBMU_MON_IN_Normal:
          /* During 'Normal': '<S24>:810' */
          /* Transition: '<S24>:822' */
          /* Transition: '<S24>:825' */
          if (I_S_T15) {
            /* Transition: '<S24>:29' */
            CBMU_M_exit_internal_PwrOnStart();
            CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_T15PwrON;
            CBMU_MO_enter_internal_T15PwrON();
          } else {
            if (I_S_Sc || I_S_Fc) {
              /* Transition: '<S24>:30' */
              CBMU_M_exit_internal_PwrOnStart();
              CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON =
                CBMU_MON_IN_ChargePwrON;
              CBMU_enter_internal_ChargePwrON();
            }
          }
          break;

         default:
          /* During 'wait1': '<S24>:839' */
          if ((CBMU_MON_DWork.cnt7 >= 1000U) && (CBMU_MON_DWork.cnt6 >= 950U)) {
            /* Transition: '<S24>:840' */
            CBMU_MON_DWork.bitsForTID0.is_state2 = CBMU_MON_IN_ERR;

            /* Entry 'ERR': '<S24>:812' */
            CBMU_MON_B.CurError = 1U;

            /* �ϵ�ǰ�����쳣 */
          } else {
            if (CBMU_MON_DWork.cnt7 >= 1000U) {
              /* Transition: '<S24>:842' */
              CBMU_MON_DWork.bitsForTID0.is_state2 = CBMU_MON_IN_Normal;

              /* Entry 'Normal': '<S24>:810' */
              CBMU_MON_B.CurError = 0U;
            }
          }
          break;
        }
        break;

       default:
        ioa_12VOut = true;
        ioa_5VOut = true;
        com_ShutDown = 0U;
        ioa_PwrOut = true;

        /* During 'wait': '<S24>:830' */
        if (CBMU_MON_B.DataStoreRead5 < 65000U) {
          /* Transition: '<S24>:818' */
          /* Exit 'wait': '<S24>:830' */
          CBMU_MON_DWork.cnt8 = 0U;
          CBMU_MON_DWork.bitsForTID0.is_PwrOnStart = CBMU_MON_IN_Check_e;

          /* Entry 'Check': '<S24>:816' */
          CBMU_MON_B.CurError = 0U;
          CBMU_MON_DWork.cnt7 = 0U;
          CBMU_MON_DWork.cnt6 = 0U;

          /* Entry Internal 'Check': '<S24>:816' */
          /* Entry Internal 'state1': '<S24>:807' */
          /* Transition: '<S24>:809' */
          CBMU_MON_DWork.bitsForTID0.is_state1 = CBMU_MON_IN_wait2;

          /* Entry Internal 'state2': '<S24>:801' */
          /* Transition: '<S24>:841' */
          CBMU_MON_DWork.bitsForTID0.is_state2 = CBMU_MON_IN_wait1;
        } else if (CBMU_MON_DWork.cnt8 >= 5000U) {
          /* Transition: '<S24>:832' */
          /* Transition: '<S24>:825' */
          if (I_S_T15) {
            /* Transition: '<S24>:29' */
            /* Exit 'wait': '<S24>:830' */
            CBMU_MON_DWork.cnt8 = 0U;
            CBMU_MON_DWork.bitsForTID0.is_PwrOnStart =
              CBMU_MON_IN_NO_ACTIVE_CHILD_d;
            CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_T15PwrON;
            CBMU_MO_enter_internal_T15PwrON();
          } else if (I_S_Sc || I_S_Fc) {
            /* Transition: '<S24>:30' */
            /* Exit 'wait': '<S24>:830' */
            CBMU_MON_DWork.cnt8 = 0U;
            CBMU_MON_DWork.bitsForTID0.is_PwrOnStart =
              CBMU_MON_IN_NO_ACTIVE_CHILD_d;
            CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_ChargePwrON;
            CBMU_enter_internal_ChargePwrON();
          } else {
            guard1 = true;
          }
        } else {
          guard1 = true;
        }
        break;
      }
      break;

     default:
      /* During 'T15PwrON': '<S24>:3' */
      if ((I_S_T15 && I_S_Sc) || (I_S_T15 && I_S_Fc) || (I_S_Fc && I_S_Sc)) {
        /* Transition: '<S24>:32' */
        /* Exit Internal 'T15PwrON': '<S24>:3' */
        switch (CBMU_MON_DWork.bitsForTID0.is_T15PwrON) {
         case CBMU_MON_IN_step2_k:
          /* Exit 'step2': '<S24>:274' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;

         case CBMU_MON_IN_step3_l:
          /* Exit 'step3': '<S24>:59' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;

         default:
          CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;
        }

        CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_PwrErr;

        /* Entry 'PwrErr': '<S24>:6' */
        CBMU_MON_B.bitsForTID0.PwrErrFlag = true;
        PwrMode = 4U;
        PackCurMode = 3U;

        /* SetSCParam() */
        com_BPC2MaxChrgVolt = 1700U;
        com_BPC2MaxChrgCurrent = 160U;
        com_BPC2ChrgEnable = true;

        /* Disable charge */
        com_BPC2ChrgSts = 2U;

        /* Charge Err */
        com_BPC2ChrgrACInput = true;

        /* AC remove */
        BMS_ChargerDCInput = 1U;

        /* DC remove */
      } else if (!I_S_T15) {
        /* Transition: '<S24>:16' */
        /* Exit Internal 'T15PwrON': '<S24>:3' */
        switch (CBMU_MON_DWork.bitsForTID0.is_T15PwrON) {
         case CBMU_MON_IN_step2_k:
          /* Exit 'step2': '<S24>:274' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;

         case CBMU_MON_IN_step3_l:
          /* Exit 'step3': '<S24>:59' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;

         default:
          CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_NO_ACTIVE_CHILD_d;
          break;
        }

        PwrMode = 0U;
        CBMU_MON_DWork.bitsForTID0.is_c35_CBMU_MON = CBMU_MON_IN_PwrOFF;

        /* Entry 'PwrOFF': '<S24>:5' */
        /*
           1.disable CAN
           2.Relay OFF
           3.power OFF
           ??? AfterRun() ???

           en:	PowerMode = 0;
           PackCurMode = 0; */
        /* Entry Internal 'PwrOFF': '<S24>:5' */
        /* Transition: '<S24>:237' */
        CBMU_MON_B.bitsForTID0.PwrErrFlag = false;
        CBMU_MON_DWork.bitsForTID0.is_PwrOFF = CBMU_MON_IN_PostRunDeb;

        /* Entry 'PostRunDeb': '<S24>:236' */
        CBMU_MON_HVRelayOff();
        CBMU_MON_B.ContactorEnable = 0U;
        com_VehBusTxEna = false;
        com_SlowChrgrTxEna = false;
        com_FastChrgrTxEna = false;
        com_ShutDown = 1U;
        CBMU_MON_DWork.pwr_ct = 0UL;
      } else {
        switch (CBMU_MON_DWork.bitsForTID0.is_T15PwrON) {
         case CBMU_MON_IN_SelfCheckErr:
          com_BPSSelfChkSts = 2U;

          /* During 'SelfCheckErr': '<S24>:61' */
          break;

         case CBMU_MON_IN_SelfCheckOk:
          com_BPSSelfChkSts = 1U;

          /* During 'SelfCheckOk': '<S24>:62' */
          break;

         case CBMU_MON_IN_step0_a:
          ioa_12VOut = true;
          ioa_5VOut = true;
          com_ShutDown = 0U;
          ioa_PwrOut = true;

          /* During 'step0': '<S24>:7' */
          /* Transition: '<S24>:39' */
          CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_step1;

          /* Entry 'step1': '<S24>:37' */
          com_BPSSelfChkSts = 0U;

          /* SC_SELFCHECK_NONE */
          com_VehBusTxEna = true;

          /* VehBPC2Param */
          com_BPC2MaxChrgVolt = 0U;
          com_BPC2MaxChrgCurrent = 0U;
          com_BPC2ChrgEnable = true;
          com_BPC2ChrgSts = 0U;
          com_BPC2ChrgrACInput = true;
          BMS_ChargerDCInput = 1U;
          com_SlowChrgrTxEna = true;

          /* send  BPC2 message
             VehPowerMode = PM_VEH_MODE; */
          break;

         case CBMU_MON_IN_step1:
          BMS_ChargerDCInput = 1U;
          com_BPC2ChrgSts = 0U;
          com_BPC2MaxChrgCurrent = 0U;
          com_BPSSelfChkSts = 0U;
          com_BPC2MaxChrgVolt = 0U;

          /* During 'step1': '<S24>:37' */
          /* Transition: '<S24>:60' */
          CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_step2_k;

          /* Entry 'step2': '<S24>:274' */
          CBMU_MON_DWork.pwr_ct = 0UL;
          break;

         case CBMU_MON_IN_step2_k:
          /* During 'step2': '<S24>:274' */
          if (CBMU_MON_DWork.pwr_ct > 1000UL) {
            /* Transition: '<S24>:275' */
            /* Exit 'step2': '<S24>:274' */
            CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_step3_l;

            /* Entry 'step3': '<S24>:59' */
            CBMU_MON_DWork.pwr_ct = 0UL;
          } else {
            qY = CBMU_MON_DWork.pwr_ct + 10UL;
            if (qY < CBMU_MON_DWork.pwr_ct) {
              qY = MAX_uint32_T;
            }

            CBMU_MON_DWork.pwr_ct = qY;
          }
          break;

         default:
          /* During 'step3': '<S24>:59' */
          /*   */
          if ((!CBMU_FM2St) && (!CBMU_MON_B.bitsForTID0.HW_Err_n) && O_S_HVIL &&
              O_S_AirBag && (com_Resistance > 200U)) {
            /* Transition: '<S24>:71' */
            /* &&((COMM_NA == false) &&...(PackTempMin > PackTempLow))(PackTempMax < PackTempHigh) && 20150919 �ȸ�Ϊ53�Ȳ������ϵ� */
            /* Exit 'step3': '<S24>:59' */
            CBMU_MON_DWork.pwr_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_SelfCheckOk;

            /* Entry 'SelfCheckOk': '<S24>:62' */
            /* com_BPSHighVoltSts = 1; */
            com_BPSSelfChkSts = 1U;
            com_BPSBattMaintenanceAlarm = false;
            CBMU_MON_B.ContactorEnable = 1U;
          } else if (CBMU_MON_DWork.pwr_ct > 5000UL) {
            /* Transition: '<S24>:70' */
            /* Exit 'step3': '<S24>:59' */
            CBMU_MON_DWork.pwr_ct = 0UL;
            CBMU_MON_DWork.bitsForTID0.is_T15PwrON = CBMU_MON_IN_SelfCheckErr;

            /* Entry 'SelfCheckErr': '<S24>:61' */
            com_BPSSelfChkSts = 2U;
            com_BPSBattMaintenanceAlarm = true;
          } else {
            qY = CBMU_MON_DWork.pwr_ct + 10UL;
            if (qY < CBMU_MON_DWork.pwr_ct) {
              qY = MAX_uint32_T;
            }

            CBMU_MON_DWork.pwr_ct = qY;
          }
          break;
        }
      }
      break;
    }

    if (guard1) {
      qY_0 = CBMU_MON_DWork.cnt8 + 10U;
      if (qY_0 < CBMU_MON_DWork.cnt8) {
        qY_0 = MAX_uint16_T;
      }

      CBMU_MON_DWork.cnt8 = qY_0;
    }
  }

  /* End of Chart: '<S23>/Chart' */

  /* S-Function (sfun_SetErr): '<S4>/sfun_SetErr_SrcH5' incorporates:
   *  Constant: '<S4>/Constant5'
   */
  Dem_SetError( (uint16_T)90U, (uint8_T)CBMU_MON_B.CurError);

  /* DataTypeConversion: '<S4>/Data Type Conversion6' incorporates:
   *  RelationalOperator: '<S4>/Relational Operator6'
   */
  rtb_DataTypeConversion6 = CBMU_MON_B.bitsForTID0.PwrErrFlag;

  /* S-Function (sfun_SetErr): '<S4>/sfun_SetErr_SrcH6' incorporates:
   *  Constant: '<S4>/Constant10'
   */
  Dem_SetError( (uint16_T)32U, (uint8_T)rtb_DataTypeConversion6);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
