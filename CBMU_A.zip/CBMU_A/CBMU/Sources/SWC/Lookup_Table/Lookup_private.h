/*
 * File: Lookup_private.h
 *
 * Code generated for Simulink model 'Lookup'.
 *
 * Model version                  : 1.488
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Wed Jun 22 13:54:32 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Lookup_private_h_
#define RTW_HEADER_Lookup_private_h_
#include "rtwtypes.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFU) ) || ( INT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFUL) ) || ( LONG_MAX != (0x7FFFFFFFL) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/* Imported (extern) block signals */
extern t_Temp1 SWC_CellTempMax;        /* '<Root>/LUMAX_T' */
extern t_Voltage3 SWC_CellVoltMax;     /* '<Root>/LUMAX_V' */

/* Imported (extern) states */
extern uint8_T CellPNum;               /* '<Root>/Data Store Memory' */
extern uint16_T look2_iu8u16lu32n32tu1_N8UogAJe(uint8_T u0, uint16_T u1, const
  uint8_T bp0[], const uint16_T bp1[], const uint16_T table[], uint32_T
  prevIndex[], const uint32_T maxIndex[], uint32_T stride);
extern uint16_T look2_iu8u8lu32n32tu16_binfcase(uint8_T u0, uint8_T u1, const
  uint8_T bp0[], const uint8_T bp1[], const uint16_T table[], const uint32_T
  maxIndex[], uint32_T stride);
extern uint8_T look2_iu8lu32n32tu8_pbinncane(uint8_T u0, uint8_T u1, const
  uint8_T bp0[], const uint8_T bp1[], const uint8_T table[], uint32_T prevIndex[],
  const uint32_T maxIndex[], uint32_T stride);

#endif                                 /* RTW_HEADER_Lookup_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
