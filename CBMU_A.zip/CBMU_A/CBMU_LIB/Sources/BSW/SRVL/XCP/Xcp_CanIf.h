/*******************************************************************************
*
*  FILE
*     Xcp_CanIf.h
*
*  DESCRIPTION
*     Header File of Can Interface for Xcp Module 
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*                                          
*  AUTHOR
*                         
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

#ifndef _XCP_CANIF_H_
#define _XCP_CANIF_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Xcp_CanIf_Types.h"
#include "Xcp_CanIf_Cfg.h"
#include "Xcp_CanIf_Cbk.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/


/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,XCP_CODE) Xcp_CanIfInit(void);
extern FUNC(uint8*,XCP_CODE) Xcp_CanIfGetReceivePtr(void);
extern FUNC(uint8*,XCP_CODE) Xcp_CanIfGetResCtoPtr(void);
extern FUNC(uint8 * XCP_VAR,XCP_CODE) Xcp_CanIfGetDaqDtoPtr(void);
extern FUNC(void,XCP_CODE) Xcp_CanIfSendDaqDto(uint16 length);

#endif /* #ifndef _XCP_CANIF_H_ */

