/*******************************************************************************
*
*  FILE
*     Dcm_Types.h
*
*  DESCRIPTION
*     The Data Type Header file for Dcm  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/

#ifndef _DCM_TYPES_H_
#define _DCM_TYPES_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

typedef uint8   Dcm_MsgItemType;
typedef uint16  Dcm_MsgLenType;
typedef uint16   Dcm_LocalIdType;


/* Additional error data to be sent with extended negative response */
typedef uint16 Dcm_ExtNRCType;

/* Some groups can have more than 8 states */
typedef uint16 Dcm_StateGroupType;

typedef uint8 Dcm_SvcInstHeadExtIndexType; 

typedef enum
{  
  DCM_E_OK                              = 0x00,
  DCM_E_GENERALREJECT                   = 0x10,
  DCM_E_SERVICENOTSUPPORTED             = 0x11,
  DCM_E_SUBFUNCTIONNOTSUPPORTED         = 0x12,
  DCM_E_INCORRECTREQUESTLENGTH          = 0x13, //add zuo,2103-12-6
  DCM_E_BUSYREPEATREQUEST               = 0x21,
  DCM_E_CONDITIONSNOTCORRECT            = 0x22,
  DCM_E_REQUESTSEQUENCEERROR            = 0x24,
  DCM_E_ROUTINENOTCOMPLETED             = 0x23,
  DCM_E_REQUESTOUTOFRANGE               = 0x31,
  DCM_E_ACCESSDENIED                    = 0x33,
  DCM_E_INVALIDKEY                      = 0x35,
  DCM_E_EXCEEDNUMOFATTEMPTS             = 0x36,
  DCM_E_REQUIREDTIMEDELAYNOTEXPIRED     = 0x37,
  DCM_E_UPLOADDOWNLOADNOTACCEPTED       = 0x40,
  DCM_E_RESPONDPENDING                  = 0x78,
  DCM_E_SERVICENOTSUPPORTEDINACTIVEMODE = 0x80
}Dcm_NRCType;

/* USDT Net result return type */
typedef enum
{
  NETWORK_OK = 0,
  NETWORK_FAILED = 1,
  NETWORK_BUFFER_UNDERRUN = 2,
  NETWORK_ABORT = 3,
  NETWORK_INVALID_CONTEXT = 0xff
} Dcm_NetResultType;

typedef enum
{
  RESPONSE_NONE                   = 0,
  RESPONSE_POSITIVE               = 1,
  RESPONSE_NEGATIVE               = 3,
  RESPONSE_NEGATIVE_RCR_RP        = 4,
  RESPONSE_NEGATIVE_APPL_RCR_RP   = 5,
} Dcm_ResponseType;

typedef enum
{
  ACCESS_LOCKED       = 0x01,
  ACCESS_GRANTED      = 0x02
}Dcm_SecLevelType;

typedef enum
{
  DEFAULT_SESSION       = 0x01,
  PROGRAMMING_SESSION   = 0x02,
  DEVELOPMENT_SESSION   = 0x03,
  EOL_SESSION           = 0x04,
  ALL_SESSION_LEVEL     = 0xff  
}Dcm_SesCtrlType;


/* Context information of a request */
typedef struct 
{
  Dcm_MsgItemType*  reqData;
  Dcm_MsgLenType    reqDataLen; 
  Dcm_MsgItemType*  resData;
  Dcm_MsgLenType    resDataLen; 
  uint8             resOnReq;       /* 0x00: No   0x01: Yes */ 
} Dcm_MsgContextType;

typedef struct 
{
  Dcm_ResponseType    resType;
  uint8               Handle;
  uint16              dataLength;
  uint8*              reqDataPtr;
  uint8*              resDataPtr;
}Dcm_NetInfoPoolType;

/* Buffer management state machine  */
typedef struct 
{
  Dcm_NetResultType     txState;                     
  Dcm_NetInfoPoolType*  infoPoolPtr;
  uint8                 activity;         /* 0x00 - Idle, 0x01 - ActiveRx, 0x02 - ActiveProcess, 0x04 - ActiveTxSingleResponse ,0x08 - ActiveTxPeriodicRes, 0x10 - ActiveTxRoeResponder */
  boolean               isContextLocked;
} Dcm_ContextCtrlType;                          

typedef struct
{
  Dcm_SesCtrlType     stateSession        : 5;
  Dcm_SecLevelType    stateSecurityAccess : 2;
  bittype             stateGap            : 1;
} Dcm_StateInfoType;

/* Main handler function pointer type */
typedef void  (*Dcm_MainHdlFcnPtrType) (Dcm_MsgContextType*);

typedef struct
{
  uint16                    reqLen;
  uint8                     resOnReq;   /* 0x00: No   0x01: Yes */ 
  Dcm_StateInfoType         checkState;
  uint8                     setStateIndex;
  Dcm_MainHdlFcnPtrType     mainHandler;
} Dcm_SvcInstType;

typedef struct
{
  bittype                reqHeadExLen      :4; /* Request HeadEx length up to 7  */
  bittype                resHeadExLen      :4; /* Response HeadEx length up to 7 */
  bittype                resOnReq          :1; /* 0x00: No   0x01: Yes  */ 
  bittype                isReqHeadExtEchoed:1; /* 0x00: No   0x01: Yes  */ 
  bittype                isSubFuncInstanced:1; /* 0x00: No   0x01: Yes  */ 
  bittype                svcHeadPlaceHolder:1; /* Gap holder  */   
  /* State group Session on SId level, the number is depend on the number of State session */
  Dcm_StateGroupType     checkSessionState :5;
  bittype                sessionPlaceHolder:3; /* Gap holder  */   
/* First item in Service Instance table */
  uint8                  svcInstFirstItem;    
  Dcm_SvcInstHeadExtIndexType svcInstHeadExtFirstItem;   
} Dcm_SvcHeadType;

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/


#endif /* #ifndef _DCM_TYPES_H_ */


