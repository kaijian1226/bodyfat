/*******************************************************************************
*
*  FILE
*     Dem_Types.h
*
*  DESCRIPTION
*     The Data Type Header file for Dem Module  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*  DATE: 2014-01-06 
*******************************************************************************/

#ifndef _DEM_TYPES_H_
#define _DEM_TYPES_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"  
#include "Dem_Cfg.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define DEM_ERR_FID_NUM             2U
#define DEM_USR_DEF_DATA_PAR_NUM    1U  
#define DEM_USR_DEF_DATA_MAX_SIZE   4U    

typedef uint16 Dem_ChksumType;
typedef uint8  Dem_ErrStatusLengthType;
typedef uint8  Dem_EventIdType;
//typedef uint16  Dem_EventIdType;  //zuo,2103-12-9
typedef uint8  Dem_FidType;//added for FID by xyl 2015-6-16

typedef enum
{
  DEM_ERRMEM_OK = 0,
  DEM_ERRMEM_CONFIRMED = 1,
  DEM_ERRMEM_HEALING = 2,  
}Dem_ErrMemStatusType;


/*typedef struct {   	    
  uint16 SPN;
  uint8 FMI;
  uint8 ErrorClass;
  uint8 HealingCounter;
}Dem_FaultCodeType;*/

//modified for FID by xyl 2015-6-16
typedef struct {   	    
  uint16 SPN;
  uint8  FMI;
  uint8  ErrorClass;  //1��2 ���ϵȼ�
  uint8  HealingCounter;   //
  uint8  FidPar[DEM_ERR_FID_NUM]; // ��ҪFID��������FID��������д��Ӧ����������Ҫ����DEM_NO_FID
  uint8  UsrDefDataPar[DEM_USR_DEF_DATA_PAR_NUM]; //DEM_NO_PARAMĿǰû���� 
}Dem_FaultCodeType;


typedef struct { 
  Dem_EventIdType EventId;
  uint8 ErrClass;
  Dem_ErrMemStatusType ErrState;                           													
  uint8 HealingCounter;
  uint8 ErrOccurCounter;
  uint16 DTCID;   	                                                           
}Dem_FaultMemType;

typedef enum
{
  ALL_DTC      = 0,
  ACTIVE_DTC   = 1,
  INACTIVE_DTC = 2    
}Dem_DtcType;

typedef enum
{
  REPORT_NUM_DTC = 0,
  REPORT_DTC_STATE = 1,
}Dem_DTCMaskType ;


typedef struct
{
  bittype active:1;
  bittype mem:1;
  bittype resv:6;
}Dem_FaultStatusType;

/*
typedef struct
{
	uint32	mTotalDistance;	
	uint16	mMotorSpeed;	
	uint8	mMotorTorque;	
	uint16	mMotorCurrent;	
	uint16	mPackVoltage;	
	uint8	mPackSOC;	
	uint16	mPackCurrent;	
	uint16	mISOResiatance;	
	uint8	mRunningMode;	
	uint8	mCellVoltageMin;	
	uint8	mCellVoltageMax;	
	uint8	mCellVoltageAverage;	
	uint8	mPackTempMax;	
	uint8	mPackTempMin;	
	uint8	mPackTempAverage;	
	uint8 mAMBStatus;
	uint8 mACBStatus[6];
}Dem_FreezeFrameType;
*/
typedef struct
{	
	uint8	year;	
	uint8	month;	
	uint8	day;	
	uint8	hour;	
	uint8	min;	
	uint8	second;	
}Dem_FreezeFrameType;


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

#endif /* #ifndef _DEM_TYPES_H_ */
