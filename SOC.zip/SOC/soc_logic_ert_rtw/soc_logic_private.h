/*******************************************************************************
 *  Real-Time Workshop code generated for Simulink model < soc_logic >
 *
 *  File: soc_logic_private.h
 *  File Creation Date: 30-Aug-2016
 *  Code generated on : Tue Aug 30 18:03:34 2016
 *  Abstraction:
 *  Notes:
 *
 *  Model Information:
 *  Model Name: soc_logic
 *  Model Version: 1.137
 *  Model Description:
 *  Creation date:	Thu Nov 06 11:14:33 2014
 *  Last Saved Modification:   Tue Aug 30 18:01:52 2016
 *
 *  (c)Copyright 2008-2014��Wuhan Eureka Control System Co., Ltd.
 *******************************************************************************/
/******************************************************************************
 *  Include files
 ******************************************************************************/
#ifndef RTW_HEADER_soc_logic_private_h_
#define RTW_HEADER_soc_logic_private_h_
#include "rtwtypes.h"

/*****************************************************************************
 *  Defines
 *****************************************************************************/
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFU) ) || ( INT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFUL) ) || ( LONG_MAX != (0x7FFFFFFFL) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/*****************************************************************************
 *  Data Types
 *****************************************************************************/

/*****************************************************************************
 *  Definitions
 *****************************************************************************/

/*****************************************************************************
 *  Declarations
 *****************************************************************************/

/* Imported (extern) block signals */
extern t_Factor1 soc_fac_Charging;     /* '<S4>/CurrentMulti' */
extern t_Factor1 soc_fac_Current;      /* '<S4>/Soc_CurrentCurv' */
extern t_Factor1 soc_fac_BatteryTemp;  /* '<S4>/Soc_TempCurv' */
extern t_Factor1 soc_fac_CurrSoc;      /* '<S4>/Soc_SocCurv' */
extern t_Factor1 soc_fac_All;          /* '<S4>/CurrentCorFac' */
extern t_Percent2 soc_soh;             /* '<Root>/soc_soh' */
extern t_Voltage1 soc_ocv;             /* '<Root>/soc_ocv' */
extern t_Temp1 soc_temp;               /* '<Root>/soc_temp' */
extern Boolean soc_fullChrgFlg;        /* '<Root>/soc_fullChrgFlg' */
extern t_Current1 soc_current;         /* '<Root>/soc_current' */
extern t_Capacity1 soc_lastCapacity;   /* '<Root>/soc_lastCapacity' */
void BINARYSEARCH_U16(uint16_T *piLeft, uint16_T *piRght, uint16_T u, const
                      uint16_T *pData, uint16_T iHi);
void BINARYSEARCH_U8(uint16_T *piLeft, uint16_T *piRght, uint8_T u, const
                     uint8_T *pData, uint16_T iHi);
void INTERPOLATE_S16_U8(int16_T *pY, int16_T yL, int16_T yR, uint8_T x, uint8_T
  xL, uint8_T xR);
void INTERPOLATE_S16_U16(int16_T *pY, int16_T yL, int16_T yR, uint16_T x,
  uint16_T xL, uint16_T xR);
void Look2D_S16_U16_U8(int16_T *pY, const int16_T *pYData, uint16_T u0, const
  uint16_T *pU0Data, uint16_T iHiU0, uint8_T u1, const uint8_T *pU1Data,
  uint16_T iHiU1);
extern void mul_wide_s32(int32_T temp_in0, int32_T temp_in1, uint32_T
  *temp_ptrOutBitsHi, uint32_T *temp_ptrOutBitsLo);
extern int32_T mul_s32_s32_s32_sr28_zero(int32_T temp_a, int32_T temp_b);
extern int32_T mul_s32_s32_s32_sr14_zero(int32_T temp_a, int32_T temp_b);
extern int16_T div_repeat_s16s32(int32_T temp_numerator, int32_T
  temp_denominator, uint16_T temp_nRepeatSub);
extern uint32_T div_nzp_repeat_u32(uint32_T temp_numerator, uint32_T
  temp_denominator, uint16_T temp_nRepeatSub);
extern int32_T mul_s32_s32_s32_sr35(int32_T temp_a, int32_T temp_b);
extern int32_T mul_s32_s32_s32_sr10(int32_T temp_a, int32_T temp_b);
extern int16_T div_s16s32_floor(int32_T temp_numerator, int32_T temp_denominator);
extern int16_T look1_is16lu16n16ts16D_c5pSCY2v(int16_T temp_u0, const int16_T
  temp_bp0[], const int16_T temp_table[], uint32_T temp_maxIndex);
extern int16_T look1_iu8lu16n16ts16Ds_FbqVATJM(uint8_T temp_u0, const uint8_T
  temp_bp0[], const int16_T temp_table[], uint32_T temp_maxIndex);
extern int16_T look1_is32lu16n16ts16D_UEUZuoen(int32_T temp_u0, const int32_T
  temp_bp0[], const int16_T temp_table[], uint32_T temp_maxIndex);

/*****************************************************************************
 *  Global Function Declaration
 *****************************************************************************/
#endif                                 /* RTW_HEADER_soc_logic_private_h_ */

/*======================== TOOL VERSION INFORMATION ==========================*
 * MATLAB 8.5 (R2015a)09-Feb-2015                                             *
 * Simulink 8.5 (R2015a)09-Feb-2015                                           *
 * Simulink Coder 8.8 (R2015a)09-Feb-2015                                     *
 * Embedded Coder 6.8 (R2015a)09-Feb-2015                                     *
 * Stateflow 8.5 (R2015a)09-Feb-2015                                          *
 * Fixed-Point Designer 5.0 (R2015a)09-Feb-2015                               *
 *============================================================================*/

/*======================= LICENSE IN USE INFORMATION =========================*
 * fixed_point_toolbox                                                        *
 * matlab                                                                     *
 * matlab_coder                                                               *
 * real-time_workshop                                                         *
 * rtw_embedded_coder                                                         *
 * simulink                                                                   *
 *============================================================================*/
