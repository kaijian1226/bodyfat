/*******************************************************************************
*
*  FILE
*     CanIf.c
*
*  DESCRIPTION
*     Can interface   ���ͽ��մ�������
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*                      
*                       
*  VERSION     
*    1.1.0           
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "CanIf.h"
#include "Dem.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/
#define CANIF_SW_FILTER( idRaw, mask, code)  (((idRaw) & (Can_IdType)~(mask)) == (code) )

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
uint8 CanErrorChannel;	//0��CANͨ���쳣,1�ڲ�CAN��2����CAN��3���CAN
VAR(boolean, CANIF_VAR) canif_RxFlag;
VAR(boolean, CANIF_VAR) canif_TxFlag;

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
/* This Variable used for future extension */
_STATIC_ VAR(CanIf_ControllerModeType,CANIF_VAR) CanIf_Mode;

_STATIC_ VAR(boolean,CANIF_VAR) CanIf_Initialized;

#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS != 0)
  _STATIC_ VAR(Can_IdType,CANIF_VAR)    canif_DynTxId[CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS];
#endif

_STATIC_ VAR(boolean,CANIF_VAR) canif_TxOnline[CAN_USED_NUM_OF_CHANNEL];

_STATIC_ VAR(uint8,CANIF_VAR) canif_BusoffCnt[CAN_USED_NUM_OF_CHANNEL];
_STATIC_ VAR(uint8,CANIF_VAR) canif_BusoffProcessCnt[CAN_USED_NUM_OF_CHANNEL];

//#pragma DATA_SEG PAGED_RAM
_STATIC_ VAR(CanIf_TxBufferType,CANIF_VAR) canif_TxBuffer[CAN_USED_NUM_OF_CHANNEL][CANIF_SIZE_OF_TX_BUFFER];
//#pragma DATA_SEG DEFAULT

_STATIC_ VAR(CanIf_TxBufferStatusType,CANIF_VAR) canif_TxBufferSts[CAN_USED_NUM_OF_CHANNEL];

_STATIC_ VAR(PduIdType,CAN_VAR) canif_CurTxObjHdl[CAN_USED_NUM_OF_CHANNEL];

_STATIC_ VAR(Can_IdType,CANIF_VAR) CanIf_RxCanId[CAN_USED_NUM_OF_CHANNEL];

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

void CanIf_NetManagement(void)
{
  Can_CntrlType controller;
   
  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)
  {
     if( canif_TxOnline[controller] == FALSE  )
     {
         if( canif_BusoffProcessCnt[controller] < 255 )
         {
            canif_BusoffProcessCnt[controller]++;
         }
         
         if( canif_BusoffCnt[controller] < 5 )
         {
            if( canif_BusoffProcessCnt[controller] > 11 )
            {
               canif_TxOnline[controller] = TRUE;
               canif_BusoffProcessCnt[controller] = 0;
            }
         }
         else
         {
            if( canif_BusoffProcessCnt[controller] > 101 )
            {
               canif_TxOnline[controller] = TRUE;
               canif_BusoffProcessCnt[controller] = 0;
            }
         }
     }
  }
}



/*******************************************************************************
* NAME:             CanIf_Init
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: 
* RETURN VALUES:    void
* DESCRIPTION:      Can interface Initialization
*******************************************************************************/
//FUNC(void,CANIF_CODE) CanIf_Init(void)
void CANIF_CODE CanIf_Init(void)
{
  PduIdType index;
  Can_CntrlType controller;
   
  CanIf_Mode = CANIF_CS_STOPPED;
  
  CanIf_Initialized = TRUE;
  
  /* Initialize Can Common Setting */
  Can_Init();
  
  /* Initialize per Hw Handler */
  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)
  {
    canif_CurTxObjHdl[controller] = CANIF_BUFFER_FREE;                   /* MsgObj is free */

  }
  
  /* Initialize per controller */
  for (controller = 0; controller < CAN_USED_NUM_OF_CHANNEL; controller++)
  {   
    
    Can_InitController(controller); 
    
    CanIf_SetPduMode(controller, CANIF_SET_TX_ONLINE); 
       
  }  

  CanIf_Mode = CANIF_CS_STARTED; 
  
  for (index = 0; index < CAN_USED_NUM_OF_CHANNEL; index++)
  {
    canif_TxBufferSts[index].Size = 0;
    canif_TxBufferSts[index].MaxUsedSize = 0;
    canif_TxBufferSts[index].Rp = 0;  
    canif_TxBufferSts[index].Wp = 0;
    canif_BusoffProcessCnt[index] = 0;
  }
}

/*******************************************************************************
* NAME:             CanIf_GetControllerMode
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: 
* RETURN VALUES:    void
* DESCRIPTION:      Get the Controller Mode
*******************************************************************************/
//FUNC(Std_ReturnType,CANIF_CODE) CanIf_GetControllerMode(Can_CntrlType ControllerId,CanIf_ControllerModeType* ControllerModePtr)
Std_ReturnType CANIF_CODE CanIf_GetControllerMode(Can_CntrlType ControllerId,CanIf_ControllerModeType* ControllerModePtr)
{
#if(CANIF_DEV_ERROR_DETECT == STD_ON) 
  if (CanIf_Initialized == FALSE)
  {
    Det_ReportError(CANIF_MODULE_ID,ControllerId,CANIF_API_GETCTLMODE,CANIF_E_UNINIT);      
  }
  
  if (ControllerId >= CAN_USED_NUM_OF_CHANNEL)
  {
    Det_ReportError(CANIF_MODULE_ID,ControllerId,CANIF_API_GETCTLMODE,CANIF_E_PARAM_CONTROLLERID); 
  }
  
  if (ControllerModePtr == NULL_PTR)
  {
    Det_ReportError(CANIF_MODULE_ID,ControllerId,CANIF_API_GETCTLMODE,CANIF_E_POINTER); 
  }
#endif /* #if(CANIF_DEV_ERROR_DETECT == STD_ON)  */  
  return E_OK;
}

/*******************************************************************************
* NAME:             CanIf_SetControllerMode
* CALLED BY:        EcuM
* PRECONDITIONS:    
* INPUT PARAMETERS: 
* RETURN VALUES:    void
* DESCRIPTION:      Set the Controller Mode
*******************************************************************************/
//FUNC(Std_ReturnType,CANIF_CODE) CanIf_SetControllerMode(Can_CntrlType ControllerId,CanIf_ControllerModeType ControllerMode)
Std_ReturnType CANIF_CODE CanIf_SetControllerMode(Can_CntrlType ControllerId,CanIf_ControllerModeType ControllerMode)
{
#if(CANIF_DEV_ERROR_DETECT == STD_ON) 
  if (CanIf_Initialized == FALSE)
  {
    Det_ReportError(CANIF_MODULE_ID,CANIF_INSTATNCE_ID,CANIF_API_SETCTLMODE,CANIF_E_UNINIT);      
  }
  
  if (ControllerId >= CAN_USED_NUM_OF_CHANNEL)
  {
    Det_ReportError(CANIF_MODULE_ID,CANIF_INSTATNCE_ID,CANIF_API_SETCTLMODE,CANIF_E_PARAM_CONTROLLERID); 
  }
  
#endif /* #if(CANIF_DEV_ERROR_DETECT == STD_ON)  */  
  
  if (ControllerMode == CANIF_CS_SLEEP)
  {
    if (Can_SetControllerMode(ControllerId,CAN_T_SLEEP) == CAN_OK)
    {
      return E_OK;
    }else
    {
      return E_NOT_OK;
    }  
  }else
  {
    return E_NOT_OK;
  }
  
}

/*******************************************************************************
* NAME:             CanIf_Transmit
* CALLED BY:        Application
* PRECONDITIONS:    Can driver must be initialized
* INPUT PARAMETERS: PduIdType CanTxPduId
*                   const PduInfoType* PduInfoPtr
* RETURN VALUES:    E_NOT_OK: transmit failed
*                   E_OK    : transmit was succesful or put in a queue
* DESCRIPTION:      
*******************************************************************************/
#if (CANIF_INIT_NUMBER_OF_CANTXPDUIDS != 0)

//FUNC(Std_ReturnType,CANIF_CODE) CanIf_Transmit(PduIdType CanTxPduId, const PduInfoType* PduInfoPtr) 
Std_ReturnType CANIF_CODE CanIf_Transmit(PduIdType CanTxPduId, const PduInfoType* PduInfoPtr)//ֱ�ӵ��õ�Ƭ���ײ�CAN�ķ���   
                                            //���ͱ��ĵı��             Pdu�ṹ��Ҫ���͵����ݺͳ���
{
  
#if ((CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS != 0) && (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS != 0)) //����
  PduIdType dynTxPdu;  
#endif
  Can_PduType canPdu;
  Can_CntrlType controller;
  uint8_least idx;

#if (CANIF_DEV_ERROR_DETECT == STD_ON)  //��   �������������Ӧ�ö���ִ��
  
  if (CanIf_Initialized == FALSE)   //CAN��ʼ��ʧ��   Ӧ�ò����
  {
    Det_ReportError(CANIF_MODULE_ID,CANIF_INSTATNCE_ID,CANIF_API_TRANSMIT_ID,CANIF_E_UNINIT);      
  }
  
  if (CanTxPduId >= CANIF_INIT_NUMBER_OF_CANTXPDUIDS)  //��û�г������屨��ID����   �����    ����Ҫ���߼�
  {
    Det_ReportError(CANIF_MODULE_ID,CANIF_INSTATNCE_ID,CANIF_API_TRANSMIT_ID,CANIF_E_PARAM_TXOBJ);      
  }
  
#endif /* #if (CANIF_DEV_ERROR_DETECT == STD_ON)  */
  
  
#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS == 0) //�޶�̬����  ��

  controller = CanIf_StaticPduTxCfg_C[CanTxPduId].CntrlId;//��̬������ֵ
  canPdu.id  = CanIf_StaticPduTxCfg_C[CanTxPduId].CanId;  

#elif(CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS == 0)  //�޾�̬����  ����

  controller = CanIf_DynamicPduTxCfg_C[CanTxPduId].CntrlId;
  canPdu.id  = canif_DynTxId[CanTxPduId];  

#else //����  

  if (CanTxPduId >= CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS)  //  �ж���û�г�����̬�ķ�Χ ����
  {    
    dynTxPdu = CanTxPduId - CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS;
    controller = CanIf_DynamicPduTxCfg_C[dynTxPdu].CntrlId;
    canPdu.id  = canif_DynTxId[dynTxPdu];
  }else //����
  {
    controller = CanIf_StaticPduTxCfg_C[CanTxPduId].CntrlId; //��·CAN
    canPdu.id  = CanIf_StaticPduTxCfg_C[CanTxPduId].CanId; //PGN
  }  
#endif

  SuspendAllInterrupts();  //��ͣϵͳ�ж�
 
  /* test offline after interrupt disable  */
  //����ǰ���CAN�ڵ��Ƿ�����
  if (canif_TxOnline[controller] == FALSE ) //�Ƿ���Է��� ���ܷ���     /* transmit path switched off */
  {
    ResumeAllInterrupts();  //�ָ������ж� 
    return E_NOT_OK;
  }

  if (canif_TxBufferSts[controller].Size >= CANIF_SIZE_OF_TX_BUFFER)  //>=10 ��������СΪ10
  {
    ResumeAllInterrupts(); //�ָ������ж� 
    return E_NOT_OK;
  }  
  
  if (canif_TxBufferSts[controller].Size == 0) //��ʾ���Ĳ���Ҫ���壬ֱ�ӷ��ͳ�ȥ 
  {
    /* check for transmit message object free  -*/   
    //canif_CurTxObjHdl  ��ʾCAN����ͨ���Ƿ���� Ŀǰ����3·
    if (canif_CurTxObjHdl[controller] == CANIF_BUFFER_FREE)//  ==0xFE //���ͻ��������� 
    {
      canif_CurTxObjHdl[controller] = CanTxPduId; //��ֵid
      canPdu.length = PduInfoPtr->SduLength;      //��ֵ���ݳ���  
      canPdu.sdu = PduInfoPtr->SduDataPtr;        //��ֵ����
      if (Can_Write(controller, &canPdu) == CAN_OK)   // can���ͳɹ�
      {
        ResumeAllInterrupts();  //�ָ������ж� 
        return E_OK;   //$$$���ͳɹ��˳����治��Ҫִ��
      }else
      {
        canif_CurTxObjHdl[controller] = CANIF_BUFFER_FREE;    //���÷��ͻ���������
      }
    }          
  }
    
  canif_TxBuffer[controller][canif_TxBufferSts[controller].Wp].PduId = CanTxPduId;  //���͵ı���pdu id
  canif_TxBuffer[controller][canif_TxBufferSts[controller].Wp].CanId = canPdu.id;   //canid 
  canif_TxBuffer[controller][canif_TxBufferSts[controller].Wp].CanDlc = PduInfoPtr->SduLength; //���ݳ���
 
  for (idx =0; idx <PduInfoPtr->SduLength; idx++)  //����   
  {
    canif_TxBuffer[controller][canif_TxBufferSts[controller].Wp].Data[idx] = *(PduInfoPtr->SduDataPtr + idx);  
  }
  
  canif_TxBufferSts[controller].Size++;  //��С�������1
  
  if (canif_TxBufferSts[controller].Size > canif_TxBufferSts[controller].MaxUsedSize)  //���ݹ����������õĹ��
  {
    canif_TxBufferSts[controller].MaxUsedSize = canif_TxBufferSts[controller].Size;  
  }
    
  canif_TxBufferSts[controller].Wp++;  //��������������1
  
  if (canif_TxBufferSts[controller].Wp == CANIF_SIZE_OF_TX_BUFFER) //==10 ��λWp  ������������������������
  {
    canif_TxBufferSts[controller].Wp = 0;
  }
  
  ResumeAllInterrupts();   //�ָ�ϵͳ�ж�
  
  return (E_OK);

}
#endif
/*******************************************************************************
* NAME:             CanIf_RxIndication
* CALLED BY:        
* PRECONDITIONS:    Can driver must be initialized
* INPUT PARAMETERS: controller
* RETURN VALUES:    void
* DESCRIPTION:      Call indication functions 
*******************************************************************************/
//FUNC(void,CANIF_CODE) CanIf_RxIndication(uint8 Hrh,Can_IdType CanId,uint8 CanDlc,const uint8* CanSduPtr)
void CANIF_CODE CanIf_RxIndication(uint8 Hrh,Can_IdType CanId,uint8 CanDlc,const uint8* CanSduPtr)
{
  PduIdType     index;
  PduInfoType   pduInfo;
  Can_IdType    TrimCanId;
  uint8 swFltIdx;  


  if ((CanId & CANIF_IDTYPE_EXT) == CANIF_IDTYPE_STD)  //�ж��Ƿ�Ϊ��׼֡ 0x00000000
  {
    /*  2013-08-02, lzy, VehBus may use both EXT and STD frame
    if (CanIf_IdChkOrNot_C[Hrh] == TRUE)
    {
      if (CanIf_CntrlIdType_C[Hrh] == CAN_EXT_ID)
      {
        return;
      }
    }
    */
    TrimCanId = CanId & MK_STDID(0x7FF);    //�ӵ�Ƭ���ڶ�����׼֡ID  11λ�ı�ʶ��
    CanIf_RxCanId[Hrh] = GET_ACT_STDID(CanId); //���û���õ�
  }
  else if ((CanId & CANIF_IDTYPE_EXT) == CANIF_IDTYPE_EXT)  //�������չ�� 0x00180000
  {
    if (CanIf_IdChkOrNot_C[Hrh] == TRUE)      //��·CAN�Ƿ�ʹ��
    {
      if (CanIf_CntrlIdType_C[Hrh] == CAN_STD_ID)
      {
        return;
      }
    }
    TrimCanId = CanId & MK_EXTID(0x1FFFFFFF);
    CanIf_RxCanId[Hrh] = GET_ACT_EXTID(CanId);  
  }
  else
  {
    /* Unrecognized can frame */
    return;
  }



#if (CANIF_INIT_NUMBER_OF_CANRXPDUIDS != 0)    // ���յ�����  
  /* search the received id in ROM table:  ( Linear search )*/
  for (index = CanIf_RxStrtIdx_C[Hrh];index < CanIf_RxStrtIdx_C[(Hrh)+1]; index++) //ÿ��ͨ���ı�����
  {
  #if (CANIF_INIT_NUMBER_OF_SW_FILTER != 0) //��Ҫ�� 1!=0

    swFltIdx = CanIf_PduRxCfg_C[index].SwFltIndex; //swFltIdx = 0xFF
    if (swFltIdx != CANIF_INVALID_SW_FILTER) //����
    {
      if (CANIF_SW_FILTER( CanId, CanIf_SwFlt_C[swFltIdx].FltMask, CanIf_SwFlt_C[swFltIdx].FltCode))
      //idRaw&0xE0000000==0x00  ������ߵ�3λ
      {
        break;  
      }
    }else
  #endif /* #if (CANIF_INIT_NUMBER_OF_SW_FILTER != 0)*/
    {
      if(TrimCanId == CanIf_PduRxCfg_C[index].CanId)  //�����Ƭ��������ID���趨��ID��ͬ
      {   
        break;    /* exit loop with index */ 
      }      
    }
  }
  
  if (index < CanIf_RxStrtIdx_C[(Hrh)+1] )    //���������ж������Ƿ���Ҫ���յı���
  {
    canif_RxFlag = TRUE;      //��λ
    /* ID found in table */ 
    pduInfo.SduLength = CanDlc;     //����
    pduInfo.SduDataPtr = CanSduPtr; //ָ������
      
    if (CanIf_PduRxCfg_C[index].IndicationFct != NULL_PTR)  //�ж��Ƿ�Ϊ��ָ��
    {
      CanIf_PduRxCfg_C[index].IndicationFct(index,&pduInfo); //�������
    }
  }           
#endif /* #if (CANIF_INIT_NUMBER_OF_CANRXPDUIDS != 0) */    

  if (0 == Hrh)
  {
    Dem_SetError(INN_CAN_BUS_OFF,DEM_ERR_PASSIVE); 
  }else if (1 == Hrh)
  {
    Dem_SetError(VEH_CAN_BUS_OFF,DEM_ERR_PASSIVE); 
  }else if (2 == Hrh)
  {
    Dem_SetError(CHRG_CAN_BUS_OFF,DEM_ERR_PASSIVE); 
  }

}

/*******************************************************************************
* NAME:             CanIf_TxConfirmation
* CALLED BY:        Tx interrupt or Can_MainFunction_Write
* PRECONDITIONS:    Can driver must be initialized
* INPUT PARAMETERS: controller
* RETURN VALUES:    void
* DESCRIPTION:      Call Confirmation functions 
*******************************************************************************/
#if (CANIF_INIT_NUMBER_OF_CANTXPDUIDS != 0)

//FUNC(void,CANIF_CODE) CanIf_TxConfirmation(Can_CntrlType controller)
void CANIF_CODE CanIf_TxConfirmation(Can_CntrlType controller)   //$$$!!!
{
  
  PduIdType CanTxPduId;
#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS != 0)&&(CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS != 0)
  PduIdType dynTxObj;
#endif   
  Can_PduType canPdu;
  
  canif_TxFlag = TRUE; 
  
  CanTxPduId = canif_CurTxObjHdl[controller];   /* get saved handle */
   
  if (CanTxPduId != CANIF_BUFFER_FREE)
  {       
    if (CanTxPduId != CANIF_BUFFER_CANCEL)
    {   
#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS == 0)

      if (CanIf_StaticPduTxCfg_C[CanTxPduId].ConfirmFct != NULL_PTR )
      {
        (CanIf_StaticPduTxCfg_C[CanTxPduId].ConfirmFct)(CanTxPduId);   /* call completion routine  */
      }

#elif(CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS == 0)

    if (CanIf_DynamicPduTxCfg_C[CanTxPduId].ConfirmFct != NULL_PTR )
    {
      (CanIf_DynamicPduTxCfg_C[CanTxPduId].ConfirmFct)(CanTxPduId);   /* call completion routine  */
    }
#else
    if (CanTxPduId >= CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS)
    {
      dynTxObj = CanTxPduId - CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS;
      if (CanIf_DynamicPduTxCfg_C[dynTxObj].ConfirmFct != NULL_PTR )
      {
        (CanIf_DynamicPduTxCfg_C[dynTxObj].ConfirmFct)(CanTxPduId);   /* call completion routine  */
      }       
    }else
    {
      if (CanIf_StaticPduTxCfg_C[CanTxPduId].ConfirmFct != NULL_PTR )
      {
        (CanIf_StaticPduTxCfg_C[CanTxPduId].ConfirmFct)(CanTxPduId);   /* call completion routine  */
      }      
    }
    
#endif      
    }else
    {
      CanIf_CancelTxConfirmation(controller);
    }
  }
  
  if (canif_TxBufferSts[controller].Size > 0)
  {
    canPdu.id = canif_TxBuffer[controller][canif_TxBufferSts[controller].Rp].CanId;
    canPdu.length = canif_TxBuffer[controller][canif_TxBufferSts[controller].Rp].CanDlc;
    canPdu.sdu = canif_TxBuffer[controller][canif_TxBufferSts[controller].Rp].Data;
     
    if (Can_Write(controller,&canPdu) == E_OK)
    {
      canif_CurTxObjHdl[controller] = canif_TxBuffer[controller][canif_TxBufferSts[controller].Rp].PduId;
      canif_TxBufferSts[controller].Size--;
      canif_TxBufferSts[controller].Rp++;
      
      if (canif_TxBufferSts[controller].Rp == CANIF_SIZE_OF_TX_BUFFER)
      {
        canif_TxBufferSts[controller].Rp = 0;  
      }
      
    }else
    {
      canif_CurTxObjHdl[controller] = CANIF_BUFFER_FREE; 
    }
  }else
  {    
    canif_CurTxObjHdl[controller] = CANIF_BUFFER_FREE;         
  }
  
  if (0 == controller)
  {
    Dem_SetError(INN_CAN_BUS_OFF,DEM_ERR_PASSIVE); 
  }else if (1 == controller)
  {
    Dem_SetError(VEH_CAN_BUS_OFF,DEM_ERR_PASSIVE); 
  }else if (2 == controller)
  {
    Dem_SetError(CHRG_CAN_BUS_OFF,DEM_ERR_PASSIVE); 
  }
    
}

#endif
/*******************************************************************************
* NAME:             CanIf_SetPduMode
* CALLED BY:        netmanagement or application
* PRECONDITIONS:    
* INPUT PARAMETERS: Can_CntrlType controller: controller number
*                   CanIf_PduSetModeType PduModeRequest: request mode
* RETURN VALUES:    E_OK:     Request successful
*                   E_NOT_OK: Request not sucessful
* DESCRIPTION:      
*******************************************************************************/
//FUNC(Std_ReturnType,CANIF_CODE) CanIf_SetPduMode(Can_CntrlType controller, CanIf_PduSetModeType PduModeRequest)
Std_ReturnType CANIF_CODE CanIf_SetPduMode(Can_CntrlType controller, CanIf_PduSetModeType PduModeRequest)
{
  Std_ReturnType retVal;
    
  SuspendAllInterrupts();

  switch (PduModeRequest)
  {
    case (CANIF_SET_TX_ONLINE):
    { 
      canif_TxOnline[controller] = TRUE;
      retVal= E_OK;
    }
    break;

    case (CANIF_SET_TX_OFFLINE):
    {
      /*canif_TxOnline[controller] = FALSE; 
      if( canif_BusoffCnt[controller] < 255 )
      {
        canif_BusoffCnt[controller]++;
      }*///��Ϊ�ⲿ����
      CanErrorChannel = controller+1;
      retVal= E_OK;
    }
    break;
    
    default:
    {
      retVal= E_NOT_OK;
    }
    break;
  }

  ResumeAllInterrupts();
  
  return retVal;
}

/*******************************************************************************
* NAME:             CanIf_ControllerBusOff
* CALLED BY:        CAN error Interrupt
* PRECONDITIONS:    
* INPUT PARAMETERS: uint8 controller: controller number
* RETURN VALUES:    void
* DESCRIPTION:      
*******************************************************************************/
//FUNC(void,CANIF_CODE) CanIf_ControllerBusOff(Can_CntrlType controller)
void CANIF_CODE CanIf_ControllerBusOff(Can_CntrlType controller)
{
  (void)CanIf_SetPduMode(controller,CANIF_SET_TX_OFFLINE); //2013-07-25, use this line for CAN BUSOFF management
  
  if (0 == controller)
  {
    Dem_SetError(INN_CAN_BUS_OFF,DEM_ERR_ACTIVE); 
  }else if (1 == controller)
  {
    Dem_SetError(VEH_CAN_BUS_OFF,DEM_ERR_ACTIVE); 
    
  }else if (2 == controller)
  {
    Dem_SetError(CHRG_CAN_BUS_OFF,DEM_ERR_ACTIVE); 
  }
}

/*******************************************************************************
* NAME:             CanIf_ControllerWakeup
* CALLED BY:        CAN Wakeup Interrupt
* PRECONDITIONS:    
* INPUT PARAMETERS: uint8 controller: controller number
* RETURN VALUES:    void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,CANIF_CODE) CanIf_ControllerWakeup(Can_CntrlType controller)
{

}

/*******************************************************************************
* NAME:             CanIf_CancelTxConfirmation
* CALLED BY:        
* PRECONDITIONS:    
* INPUT PARAMETERS: uint8 controller: controller number
* RETURN VALUES:    void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,CANIF_CODE) CanIf_CancelTxConfirmation(Can_CntrlType controller)
{

}

/*******************************************************************************
* NAME:             CanIf_CancelTransmit
* CALLED BY:        CAN error Interrupt
* PRECONDITIONS:    
* INPUT PARAMETERS: PduIdType CanTxPduId: L-PDU handle
* RETURN VALUES:    void
* DESCRIPTION:      
*******************************************************************************/
#if (CANIF_INIT_NUMBER_OF_CANTXPDUIDS != 0)
//FUNC(void,CANIF_CODE) CanIf_CancelTransmit(PduIdType CanTxPduId)
void CANIF_CODE CanIf_CancelTransmit(PduIdType CanTxPduId)
{
  Can_CntrlType controller; 
#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS != 0)&&(CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS != 0)
  PduIdType dynTxObj;
#endif
  
#if(CANIF_DEV_ERROR_DETECT == STD_ON)
  
  if (CanTxPduId >= CANIF_INIT_NUMBER_OF_CANTXPDUIDS)
  {
    Det_ReportError(CANIF_MODULE_ID,controller,CANIF_API_CANCELTRANSMIT_ID,CANIF_E_PARAM_TXOBJ); 
  }
    
#endif   

#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS == 0)

  controller = CanIf_StaticPduTxCfg_C[CanTxPduId].CntrlId;

#elif(CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS == 0)

  controller = CanIf_DynamicPduTxCfg_C[CanTxPduId].CntrlId;

#else

  if (CanTxPduId >= CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS)
  {
    dynTxObj = CanTxPduId - CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS;
    controller = CanIf_DynamicPduTxCfg_C[dynTxObj].CntrlId;
  }else
  {
    controller = CanIf_StaticPduTxCfg_C[dynTxObj].CntrlId;
  }

#endif

  SuspendAllInterrupts();

  if (canif_CurTxObjHdl[controller] == CanTxPduId)
  {
    canif_CurTxObjHdl[controller] = CANIF_BUFFER_CANCEL;
    Can_CancelTransmit(controller);
  }

  ResumeAllInterrupts();
}
#endif

/*******************************************************************************
* NAME:             CanIf_ClearTxBuffer
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: 
* RETURN VALUES:    void
* DESCRIPTION:      Clear Tx Buffer and cancel the Tx HW transmission
*******************************************************************************/
#if (CANIF_INIT_NUMBER_OF_CANTXPDUIDS != 0)
//FUNC(void,CANIF_CODE) CanIf_ClearTxBuffer(Can_CntrlType controller)
void CANIF_CODE CanIf_ClearTxBuffer(Can_CntrlType controller)
{  
  SuspendAllInterrupts();

  canif_TxBufferSts[controller].Size = 0;
  canif_TxBufferSts[controller].Rp = 0;  
  canif_TxBufferSts[controller].Wp = 0;
  
  if ((canif_CurTxObjHdl[controller] != CANIF_BUFFER_FREE)&&
    (canif_CurTxObjHdl[controller] != CANIF_BUFFER_CANCEL))
  {     
    if (Can_CancelTransmit(controller) == E_OK)
    {
      canif_CurTxObjHdl[controller] = CANIF_BUFFER_CANCEL;  
    }  
  }
  
  ResumeAllInterrupts();
}
#endif
/*******************************************************************************
* NAME:             CanIf_SetDynamicTxId
* CALLED BY:        Service Layer
* PRECONDITIONS:    
* INPUT PARAMETERS: PduIdType CanTxPduId: L-PDU handle
*                   Can_IdType id:   ID
* RETURN VALUES:    void
* DESCRIPTION:      
*******************************************************************************/
#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS != 0)
//FUNC(void,CANIF_CODE) CanIf_SetDynamicTxId(PduIdType CanTxPduId, Can_IdType id)
void CANIF_CODE CanIf_SetDynamicTxId(PduIdType CanTxPduId, Can_IdType id)
{
  PduIdType dynTxObj;
  
  #if(CANIF_DEV_ERROR_DETECT == STD_ON) 
  
  if (CanIf_Initialized == FALSE)
  {
    Det_ReportError(CANIF_MODULE_ID,CANIF_INSTATNCE_ID,CANIF_API_DYNSETSTDID_ID,CANIF_E_UNINIT);      
  }
  
  if (CanTxPduId >= CANIF_INIT_NUMBER_OF_CANTXPDUIDS)
  {
    Det_ReportError(CANIF_MODULE_ID,CANIF_INSTATNCE_ID,CANIF_API_DYNSETSTDID_ID,CANIF_E_PARAM_TXOBJ); 
  }
  
  if (CanTxPduId < CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS)
  {
    Det_ReportError(CANIF_MODULE_ID,CANIF_INSTATNCE_ID,CANIF_API_DYNSETSTDID_ID,CANIF_E_PARAM_TXOBJ);
  }
  
  #endif /* #if(CANIF_DEV_ERROR_DETECT == STD_ON)  */   

  dynTxObj =  CanTxPduId - CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS;

  if (CanIf_DynamicPduTxCfg_C[dynTxObj].idRng == CAN_EXT_ID)
  {    
    canif_DynTxId[dynTxObj]  = MK_EXTID(id);
  }else if (CanIf_DynamicPduTxCfg_C[dynTxObj].idRng == CAN_STD_ID)
  {
    canif_DynTxId[dynTxObj]  = MK_STDID(id);
  }
}
#endif /* #if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS == 0) */

/****************************************************************************
* NAME:             CanIf_GetVersionInfo
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Std_VersionInfoType *versioninfo
* RETURN VALUES:    void
* DESCRIPTION:      Service to get version information     
****************************************************************************/
//FUNC(void,CANIF_CODE) CanIf_GetVersionInfo(Std_VersionInfoType* versioninfo)
void CANIF_CODE CanIf_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
  versioninfo->vendorID = CANIF_VENDOR_ID;
  versioninfo->moduleID = CANIF_MODULE_ID;
  versioninfo->sw_major_version = CANIF_SW_MAJOR_VERSION;
  versioninfo->sw_minor_version = CANIF_SW_MINOR_VERSION;
  versioninfo->sw_patch_version = CANIF_SW_PATCH_VERSION;
} 

/****************************************************************************
* NAME:             CanIf_GetRxCanId
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Can_CntrlType controller
* RETURN VALUES:    Can_IdType
* DESCRIPTION:      Service to get the CAN ID     
****************************************************************************/
//FUNC(Can_IdType,CANIF_CODE) CanIf_GetRxCanId(Can_CntrlType controller)
Can_IdType CANIF_CODE CanIf_GetRxCanId(Can_CntrlType controller)
{
  return (CanIf_RxCanId[controller]);
}
/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/



