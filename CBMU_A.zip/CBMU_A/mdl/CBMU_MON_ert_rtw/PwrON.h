/*
 * File: PwrON.h
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PwrON_h_
#define RTW_HEADER_PwrON_h_
#ifndef CBMU_MON_COMMON_INCLUDES_
# define CBMU_MON_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "SetErr.h"
#endif                                 /* CBMU_MON_COMMON_INCLUDES_ */

#include "CBMU_MON_types.h"

extern void CBMU_MON_PwrON_Init(void);
extern void CBMU_MON_PwrON(void);

#endif                                 /* RTW_HEADER_PwrON_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
