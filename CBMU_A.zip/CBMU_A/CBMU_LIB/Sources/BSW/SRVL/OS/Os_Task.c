#include "SchM.h"
#include "VFB.h"

uint8 os_delayCnt;

void TASK_Init(void)
{
  unsigned char index;
  SchM_Init();
  Swc_Init(); 
  
  os_delayCnt = 0;  
  
  for(index=0;index<=96;index++) 
	{
	  Dem_SetError( index, 0); 
	} //!!!!!!20150928 ��ʼ��Ĭ�϶���OK��״̬

}

void TASK_10MS(void) 
{ 
  SchM_Period10MsOne();
  Swc_Task10ms();
  if (os_delayCnt == 0)
  {
    os_delayCnt = 49;
    SchM_Period500MS(); 
  }else
  {
    os_delayCnt--; 
  } 
  SchM_Period10MsTwo();
}  

 

void TASK_Idle(void)
{
  SchM_MainFunction();
}