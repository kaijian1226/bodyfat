/*******************************************************************************
*
*  FILE
*     Com_Cfg.c
*
*  DESCRIPTION
*     Configuration Source File for Com   ���ͽ��ձ�����������
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Com_Cfg.h"
#include "Dem_Cfg.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

uint8 com_TxMsg_CMD[PG_DATALEN]; 
uint8 com_TxMsg_TD[PG_DATALEN];  
uint8 com_TxMsg_TEST1[PG_DATALEN]; 
uint8 com_TxMsg_TEST2[PG_DATALEN]; 
uint8 com_TxMsg_RESERVE1[PG_DATALEN]; 
uint8 com_TxMsg_BPVP1[PG_DATALEN];  
uint8 com_TxMsg_BPTP1[PG_DATALEN];  
uint8 com_TxMsg_BPC1[PG_DATALEN];  
uint8 com_TxMsg_BPC2[PG_DATALEN];  
uint8 com_TxMsg_BPS[PG_DATALEN]; 
uint8 com_TxMsg_CP[PG_DATALEN];  
uint8 com_TxMsg_SP1[PG_DATALEN];  
uint8 com_TxMsg_SP2[PG_DATALEN];  
uint8 com_TxMsg_SP3[PG_DATALEN];  
uint8 com_TxMsg_BCI[PG_DATALEN]; 
uint8 com_TxMsg_CANTP[CANTP_TEST_DATALEN];//2015-07-07 xyl 
uint8 com_TxMsg_DM1[DM1_DATALEN];//2015-07-10 xyl  



//add by xql for fast charge Tx Msg,20150706
volatile struct BRM_tag 		com_TxMsg_BRM;
volatile struct BCP_tag 		com_TxMsg_BCP;
volatile struct BRO_tag 		com_TxMsg_BRO;
volatile struct BCL_tag 		com_TxMsg_BCL;
volatile struct BCS_tag 		com_TxMsg_BCS;
volatile struct BSM_tag 		com_TxMsg_BSM;
volatile struct BST_tag 		com_TxMsg_BST;
volatile struct BSD_tag 		com_TxMsg_BSD;
volatile struct BEM_tag 		com_TxMsg_BEM;
//add by xql for fast charge Rx Msg,20150709 
volatile struct CRM_tag* 		com_RxMsg_CRM;
volatile struct CTS_tag* 		com_RxMsg_CTS;
volatile struct CML_tag* 		com_RxMsg_CML;
volatile struct CRO_tag* 		com_RxMsg_CRO;
volatile struct CCS_tag* 		com_RxMsg_CCS;
volatile struct CST_tag* 		com_RxMsg_CST;
volatile struct CSD_tag* 		com_RxMsg_CSD;
volatile struct CEM_tag* 		com_RxMsg_CEM;
//add by xyl 2015-7-22 for test
volatile uint8 com_RxMsg_DM1[DM1_DATALEN];//2015-07-23 xyl    
volatile struct BRM_tag 		com_RxMsg_BRM;
volatile struct BCP_tag 		com_RxMsg_BCP;
volatile struct BCS_tag 		com_RxMsg_BCS;



  //add 20150805 
//////////////////////////////////////�ⲿ����	���Ľṹ������	����	Com_Cfg.h//////////////////////////////////////
//////////////����
volatile  struct MB_ST_BMS_1_tag  com_TxMsg_MB_ST_BMS_1;//0x18FF200F,8 bytes,cyc 100ms		BMS->VMS  MB_ST_BMS_3_tag
volatile  struct MB_ST_BMS_2_tag  com_TxMsg_MB_ST_BMS_2;//0x18FF210F,8 bytes,cyc 100ms		BMS->VMS
volatile  struct MB_ST_BMS_3_tag  com_TxMsg_MB_ST_BMS_3;//0x18FF220F,8 bytes,cyc 100ms		BMS->VMS
volatile  struct MB_ST_BMS_4_tag  com_TxMsg_MB_ST_BMS_4;//0x18FF230F,8 bytes,cyc 100ms		BMS->VMS
//////////////����
//volatile  struct MB_ST_VMS_3_tag*  com_RxMsg_MB_ST_VMS_3;//0x18FF132F,8 bytes,cyc 20ms		VMS->BMS


/*******************************************************************************
* Global Constant definition  add 20150805                        
*******************************************************************************/
const uint8 com_TimeOutPosDeb_C = 100;

const uint8 com_TimeOutNegDeb_C = 2;

//���ͱ�����������
const Com_PduTxConfigType com_TxConfig_C[COM_NUMBER_OF_TX_PDU]=
{
  //00
  {
    COM_TT_CYCLIC , 100, com_TxMsg_CMD,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_CMD_MSG
  },
  //01
  {
    COM_TT_CYCLIC , 1000, com_TxMsg_TD,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_TD_MSG
  }, 
  //02
  {
    COM_TT_CYCLIC , 100, com_TxMsg_TEST1,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_TEST1_MSG
  },
  //03
  {
    COM_TT_CYCLIC , 100, com_TxMsg_TEST2,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_TEST2_MSG
  },  
//04
  {
    COM_TT_CYCLIC , 1000, com_TxMsg_RESERVE1,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_RESERVE1_MSG
  },	
  //05    
  {
    COM_TT_CYCLIC , 1000, com_TxMsg_BPVP1,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_BPVP1_MSG
  },
  //06
  {
    COM_TT_CYCLIC , 1000, com_TxMsg_BPTP1,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_BPTP1_MSG,
  },
  //07
  {
    COM_TT_CYCLIC , 100, com_TxMsg_BPC1,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_BPC1_MSG
  },
  //08
  {
    COM_TT_CYCLIC , 500, com_TxMsg_BPC2,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_BPC2_MSG
  },    
  //09
  {
    COM_TT_CYCLIC , 100, com_TxMsg_BPS,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_BPS_MSG
  },
  //10
  {
    COM_TT_CYCLIC , 1000, com_TxMsg_CP,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_CP_MSG
  },
  //11
  {
    COM_TT_CYCLIC , 1000, com_TxMsg_SP1,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_SP1_MSG
  },
  //12
  {
    COM_TT_CYCLIC , 1000, com_TxMsg_SP2,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_SP2_MSG
  },
  //13
  {
    COM_TT_CYCLIC , 1000, com_TxMsg_SP3,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_SP3_MSG
  },
  //14     
  {
    COM_TT_CYCLIC , 10000, com_TxMsg_BCI,8,COM_TP_TYPE_NO,COM_IF_MAP_TX_BCI_MSG
  },      
		
  //15
  {
    COM_TT_CYCLIC , 2000, com_TxMsg_CANTP,CANTP_TEST_DATALEN,COM_TP_TYPE_CANTP,COM_IF_MAP_TX_CANTP_MSG//2015-07-10 xyl
  },
  //16
  {
    COM_TT_CYCLIC , 2000, com_TxMsg_DM1,DM1_DATALEN,COM_TP_TYPE_J1939TP,COM_IF_MAP_TX_DM1_MSG  //2015-07-10 xyl
  },

//add by xql for fast charge Tx Msg,20150706
  //17
  {
    //COM_TT_CYCLIC , 250, (uint8*)(&com_TxMsg_BRM),8,COM_TP_TYPE_NO, COM_IF_MAP_TX_BRM_MSG 
    //20151001
    COM_TT_CYCLIC , 250, (uint8*)(&com_TxMsg_BRM),41,COM_TP_TYPE_J1939TP, COM_IF_MAP_TX_BRM_MSG
  },
  //18
  {
    COM_TT_CYCLIC , 500, (uint8*)(&com_TxMsg_BCP),13,COM_TP_TYPE_J1939TP, COM_IF_MAP_TX_BCP_MSG
  },
  //19
  {
    COM_TT_CYCLIC , 250, (uint8*)(&com_TxMsg_BRO),8,COM_TP_TYPE_NO,COM_IF_MAP_TX_BRO_MSG 
  },
  //20
  {
    COM_TT_CYCLIC , 50, (uint8*)(&com_TxMsg_BCL),5,COM_TP_TYPE_NO,COM_IF_MAP_TX_BCL_MSG
  },
  //21
  {
    COM_TT_CYCLIC , 250, (uint8*)(&com_TxMsg_BCS),9,COM_TP_TYPE_J1939TP, COM_IF_MAP_TX_BCS_MSG
  },
  //22
  {
    COM_TT_CYCLIC , 250, (uint8*)(&com_TxMsg_BSM),7,COM_TP_TYPE_NO,COM_IF_MAP_TX_BSM_MSG
  },
  //23
  {
    COM_TT_CYCLIC , 10, (uint8*)(&com_TxMsg_BST),4,COM_TP_TYPE_NO,COM_IF_MAP_TX_BST_MSG
  }, 
  //24
  {
    COM_TT_CYCLIC , 250, (uint8*)(&com_TxMsg_BSD),7,COM_TP_TYPE_NO,COM_IF_MAP_TX_BSD_MSG
  },
  //25
  {
    COM_TT_CYCLIC , 250, (uint8*)(&com_TxMsg_BEM),4,COM_TP_TYPE_NO,COM_IF_MAP_TX_BEM_MSG
  }, 
   //add 20150805 
  //26
  {
    COM_TT_CYCLIC , 100, (uint8*)(&com_TxMsg_MB_ST_BMS_1),8,COM_TP_TYPE_NO,COM_TX_MB_ST_BMS_1
  }, 
  //27
  {
    COM_TT_CYCLIC , 100, (uint8*)(&com_TxMsg_MB_ST_BMS_2),8,COM_TP_TYPE_NO,COM_TX_MB_ST_BMS_2
  },  
  //28
  {
    COM_TT_CYCLIC , 100, (uint8*)(&com_TxMsg_MB_ST_BMS_3),8,COM_TP_TYPE_NO,COM_TX_MB_ST_BMS_3
  }, 
  //29
  {
    COM_TT_CYCLIC , 100, (uint8*)(&com_TxMsg_MB_ST_BMS_4),8,COM_TP_TYPE_NO,COM_TX_MB_ST_BMS_4
  },            
      
};


//���ձ�����������
const Com_PduRxConfigType com_RxConfig_C[COM_NUMBER_OF_RX_PDU]=
{
/* HVA1, Time Out Setting is the 3 multipler the cycle period*/
  {
    COM_TT_CYCLIC , 3500     //00
  },
/* HVM1 */
  {
    COM_TT_CYCLIC , 2500    //01
  }, 
/* ISO */ 
  {
    COM_TT_CYCLIC , 2500   //02
  },   
/* M1_CMT */
  {
    COM_TT_CYCLIC , 2500	//03
  }, 
/* M1_STS1 */
  {
    COM_TT_CYCLIC , 2500	//04
  }, 
/* M1_STS2 */
  {
    COM_TT_CYCLIC , 2500   //5
  },                 
/* M2_CMT */
  {
    COM_TT_CYCLIC , 2500   //6
  }, 
/* M2_STS1 */
  {
    COM_TT_CYCLIC , 2500     //7
  }, 
/* M2_STS2 */
  {
    COM_TT_CYCLIC , 2500    //8
  }, 
/* M3_CMT */
  {
    COM_TT_CYCLIC , 2500,  //9
  }, 
/* M3_STS1 */
  {
    COM_TT_CYCLIC , 2500,   //10
  }, 
/* M3_STS2 */
  {
    COM_TT_CYCLIC , 2500,   //11
  }, 
/* M4_CMT */
  {
    COM_TT_CYCLIC , 2500,  //12
  }, 
/* M4_STS1 */
  {
    COM_TT_CYCLIC , 2500,   //13
  }, 
/* M4_STS2 */
  {
    COM_TT_CYCLIC , 2500,   //14
  }, 
  
//add 20150805 
/* M5_CMT */
  {
    COM_TT_CYCLIC , 2500    //15
  }, 
/* M5_STS1 */
  {
    COM_TT_CYCLIC , 2500   //16
  }, 
/* M5_STS2 */
  {
    COM_TT_CYCLIC , 2500   //17
  },   
/* M6_CMT */
  {
    COM_TT_CYCLIC , 2500    //18
  }, 
/* M6_STS1 */
  {
    COM_TT_CYCLIC , 2500   //19
  }, 
/* M6_STS2 */
  {
    COM_TT_CYCLIC , 2500   //20
  },          
/* M7_CMT */
  {
    COM_TT_CYCLIC , 2500    //21
  }, 
/* M7_STS1 */
  {
    COM_TT_CYCLIC , 2500   //22
  }, 
/* M7_STS2 */
  {
    COM_TT_CYCLIC , 2500   //23
  },          
/* M8_CMT */
  {
    COM_TT_CYCLIC , 2500    //24
  }, 
/* M8_STS1 */
  {
    COM_TT_CYCLIC , 2500   //25
  }, 
/* M8_STS2 */
  {
    COM_TT_CYCLIC , 2500   //26
  },          
/* M9_CMT */
  {
    COM_TT_CYCLIC , 2500    //27
  }, 
/* M9_STS1 */
  {
    COM_TT_CYCLIC , 2500   //28
  }, 
/* M9_STS2 */
  {
    COM_TT_CYCLIC , 2500   //29
  }, 
/* M10_CMT */
  {
    COM_TT_CYCLIC , 2500    //30
  }, 
/* M10_STS1 */
  {
    COM_TT_CYCLIC , 2500   //31
  }, 
/* M10_STS2 */
  {
    COM_TT_CYCLIC , 2500   //32
  }, 
/* M11_CMT */
  {
    COM_TT_CYCLIC , 2500    //33
  }, 
/* M11_STS1 */
  {
    COM_TT_CYCLIC , 2500   //34
  }, 
/* M11_STS2 */
  {
    COM_TT_CYCLIC , 2500   //35
  }, 
/* M12_CMT */
  {
    COM_TT_CYCLIC , 2500    //36
  }, 
/* M12_STS1 */
  {
    COM_TT_CYCLIC , 2500   //37
  }, 
/* M12_STS2 */
  {
    COM_TT_CYCLIC , 2500   //38
  }, 
/* M13_CMT */
  {
    COM_TT_CYCLIC , 2500    //39
  }, 
/* M13_STS1 */
  {
    COM_TT_CYCLIC , 2500   //40
  }, 
/* M13_STS2 */
  {
    COM_TT_CYCLIC , 2500   //41
  }, 
/* M14_CMT */
  {
    COM_TT_CYCLIC , 2500    //42
  }, 
/* M14_STS1 */
  {
    COM_TT_CYCLIC , 2500   //43
  }, 
/* M14_STS2 */
  {
    COM_TT_CYCLIC , 2500   //44
  }, 
/* M15_CMT */
  {
    COM_TT_CYCLIC , 2500    //45
  }, 
/* M15_STS1 */
  {
    COM_TT_CYCLIC , 2500   //46
  }, 
/* M15_STS2 */
  {
    COM_TT_CYCLIC , 2500   //47
  }, 
/* M16_CMT */
  {
    COM_TT_CYCLIC , 2500    //48
  }, 
/* M16_STS1 */
  {
    COM_TT_CYCLIC , 2500   //49
  }, 
/* M16_STS2 */
  {
    COM_TT_CYCLIC , 2500   //50
  }, 
/* M17_CMT */
  {
    COM_TT_CYCLIC , 2500    //51
  }, 
/* M17_STS1 */
  {
    COM_TT_CYCLIC , 2500   //52
  }, 
/* M17_STS2 */
  {
    COM_TT_CYCLIC , 2500   //53
  }, 
/* M18_CMT */
  {
    COM_TT_CYCLIC , 2500    //54
  }, 
/* M18_STS1 */
  {
    COM_TT_CYCLIC , 2500   //55
  }, 
/* M18_STS2 */
  {
    COM_TT_CYCLIC , 2500   //56
  }, 
/* M19_CMT */
  {
    COM_TT_CYCLIC , 2500    //57
  }, 
/* M19_STS1 */
  {
    COM_TT_CYCLIC , 2500   //58
  }, 
/* M19_STS2 */
  {
    COM_TT_CYCLIC , 2500   //59
  }, 
/* M20_CMT */
  {
    COM_TT_CYCLIC , 2500    //60
  }, 
/* M20_STS1 */
  {
    COM_TT_CYCLIC , 2500   //61
  }, 
/* M20_STS2 */
  {
    COM_TT_CYCLIC , 2500   //62
  }, 
/* M21_CMT */
  {
    COM_TT_CYCLIC , 2500    //63
  }, 
/* M21_STS1 */
  {
    COM_TT_CYCLIC , 2500   //64
  }, 
/* M21_STS2 */
  {
    COM_TT_CYCLIC , 2500   //65
  }, 
/* M22_CMT */
  {
    COM_TT_CYCLIC , 2500    //66
  }, 
/* M22_STS1 */
  {
    COM_TT_CYCLIC , 2500   //67
  }, 
/* M22_STS2 */
  {
    COM_TT_CYCLIC , 2500   //68
  }, 
/* M23_CMT */
  {
    COM_TT_CYCLIC , 2500    //69
  }, 
/* M23_STS1 */
  {
    COM_TT_CYCLIC , 2500   //70
  }, 
/* M23_STS2 */
  {
    COM_TT_CYCLIC , 2500   //71
  }, 
/* M24_CMT */
  {
    COM_TT_CYCLIC , 2500    //72
  }, 
/* M12_STS1 */
  {
    COM_TT_CYCLIC , 2500   //73
  }, 
/* M24_STS2 */
  {
    COM_TT_CYCLIC , 2500   //74
  }, 
/* M25_CMT */
  {
    COM_TT_CYCLIC , 2500    //75
  }, 
/* M25_STS1 */
  {
    COM_TT_CYCLIC , 2500   //76
  }, 
/* M25_STS2 */
  {
    COM_TT_CYCLIC , 2500   //77
  }, 
             
/* M1CV1 */     //add20151210
  {
    COM_TT_CYCLIC , 2500   //78
  }, 
/* M1CV2 */
  {
    COM_TT_CYCLIC , 2500   //79
  },      
/* M1CV3 */
  {
    COM_TT_CYCLIC , 2500   //80
  }, 
/* M1CV4 */
  {
    COM_TT_CYCLIC , 2500   //81
  },   
/* M2CV1 */
  {
    COM_TT_CYCLIC , 2500   //82
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //83
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //84
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //85
  },    
/* M3CV1 */
  {
    COM_TT_CYCLIC , 2500   //86
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //87
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //88
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //89
  },    
/* M4CV1 */
  {
    COM_TT_CYCLIC , 2500   //90
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //91
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //92
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //93
  },    
/* M5CV1 */
  {
    COM_TT_CYCLIC , 2500   //94
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //95
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //96
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //97
  },    
/* M6CV1 */
  {
    COM_TT_CYCLIC , 2500   //98
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //99
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //100
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //
  },    
/* M7CV1 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //
  },    
/* M8CV1 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //
  },    
/* M9CV1 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //
  },    
/* M10CV1 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //
  },              
/* M11CV1 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV2 */
  {
    COM_TT_CYCLIC , 2500   //
  },      
/* MCV3 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
/* MCV4 */
  {
    COM_TT_CYCLIC , 2500   //
  }, 
	/* M12CV1 */
	  {
		COM_TT_CYCLIC , 2500   //122
	  }, 
	/* MCV2 */
	  {
		COM_TT_CYCLIC , 2500   //123
	  },	  
	/* MCV3 */
	  {
		COM_TT_CYCLIC , 2500   //124
	  }, 
	/* MCV4 */
	  {
		COM_TT_CYCLIC , 2500   //125
	  }, 
 /////////////////////////////////////////
  
                  
/* TEST_CMD2 */
  {
    COM_TT_ASYN , 1500,    //126
  }, 
  
/* xcp */
  {
    COM_TT_ASYN , 1500,    //127
  },
 
/* INNRELAYDEBUG */
  {
	COM_TT_ASYN , 2500   //128
  }, 
 
/* Reserve1 */
  {
	COM_TT_ASYN , 2500	 //129
  }, 
 
 
 //////////////////Veh CAN 
  /* CCP1 */
  {
    COM_TT_CYCLIC , 1500,   //130
  }, 
/* MSP1 */
  {
    COM_TT_CYCLIC , 300,    //130
  }, 
/* MSP3 */
  {
    COM_TT_CYCLIC , 150,   //
  }, 
/* VD */
  {
    COM_TT_CYCLIC , 3000,  //
  },
  
  {//VMS_3���� add 20150805 
    COM_TT_CYCLIC , 15000,   //133
  },  
  {//MCU_2���� add 20151205 
    COM_TT_CYCLIC , 15000,   //134
  }, 
  {//VMS_7���� add 20151205 
    COM_TT_CYCLIC , 15000,   //135
  }, 
	{//CMU_5���� add 20160123
	  COM_TT_CYCLIC , 15000,   //136
	}, 
  
         
/* CC */
  {
    COM_TT_ASYN , 150,     //137
  }, 
/* CS */
  {
    COM_TT_CYCLIC , 3000,  //
  },
  
//add by xql for fast charge,20150709
/* CRM */
  {
    COM_TT_CYCLIC , 5000,  //
  },
/* CTS */
  { 
    COM_TT_CYCLIC , 5000,    //
  },
/* CML */  
  {
    COM_TT_CYCLIC , 5000,     //141
  },                          
/* CRO */
  {
    COM_TT_CYCLIC , 5000,     //
  },
/* CCS */
  {
    COM_TT_CYCLIC , 100,      //
  },
/* CST */
  {
    COM_TT_CYCLIC , 5000,      //
  },
/* CSD */
  {
    COM_TT_CYCLIC , 5000,     //
  },
/* CEM */
  {
    COM_TT_CYCLIC , 5000,    //146
  },    
  //add by xyl 2015-7-22 for test
  //dummy
  {
    COM_TT_ASYN , 150,         //
  }, 
  {
    COM_TT_ASYN , 150,         //
  }, 
};

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/


/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

