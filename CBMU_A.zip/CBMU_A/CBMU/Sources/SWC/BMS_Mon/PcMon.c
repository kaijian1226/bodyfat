/*
 * File: PcMon.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PcMon.h"

/* Include model header file for global data */
#include "BMS_MON.h"
#include "BMS_MON_private.h"

/* Named constants for Chart: '<S266>/SRC_Check' */
#define BMS_MON_IN_Defect_p            ((uint8_T)1U)
#define BMS_MON_IN_NO_ACTIVE_CHILD_p   ((uint8_T)0U)
#define BMS_MON_IN_NO_Defect_d         ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Confimed_f ((uint8_T)1U)
#define BMS_MON_IN_SRC_High_Healing_o  ((uint8_T)3U)
#define BMS_MON_IN_SRC_Low_Confimed_c  ((uint8_T)4U)
#define BMS_MON_IN_SRC_Low_Debouncing_p ((uint8_T)5U)
#define BMS_MON_IN_SRC_Low_Healing_df  ((uint8_T)6U)
#define BMS_MO_IN_SRC_High_Debouncing_k ((uint8_T)2U)

/*
 * Initial conditions for atomic system:
 *    '<S265>/SRC_Check'
 *    '<S274>/SRC_Check'
 *    '<S303>/SRC_Check'
 *    '<S312>/SRC_Check'
 *    '<S284>/SRC_Check'
 *    '<S293>/SRC_Check'
 */
void BMS_MON_SRC_Check_nd_Init(rtB_SRC_Check_BMS_MON_c *localB,
  rtDW_SRC_Check_BMS_MON_p *localDW)
{
  /* InitializeConditions for Chart: '<S266>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_p;
  localDW->bitsForTID0.is_active_c59_BMS_MON = 0U;
  localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_NO_ACTIVE_CHILD_p;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
  localB->SRC_Tmp_Def_Flag = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S265>/SRC_Check'
 *    '<S274>/SRC_Check'
 *    '<S303>/SRC_Check'
 *    '<S312>/SRC_Check'
 *    '<S284>/SRC_Check'
 *    '<S293>/SRC_Check'
 */
void BMS_MON_SRC_Check_h5(boolean_T rtu_Clear_Def_Flag, t_Current1 rtu_Sig_Volt,
  t_Current1 rtu_Par_SRC_H_Threshold, t_Current1 rtu_Par_SRC_L_Threshold,
  uint16_T rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_c *localB, rtDW_SRC_Check_BMS_MON_p *
  localDW)
{
  /* Chart: '<S266>/SRC_Check' */
  /* Gateway: Task_100ms/HVCU/HVCU_Mon/PcMon/discharge/CurDsg_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_100ms/HVCU/HVCU_Mon/PcMon/discharge/CurDsg_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c59_BMS_MON == 0U) {
    /* Entry: Task_100ms/HVCU/HVCU_Mon/PcMon/discharge/CurDsg_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c59_BMS_MON = 1U;

    /* Entry Internal: Task_100ms/HVCU/HVCU_Mon/PcMon/discharge/CurDsg_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S267>:9' */
    localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_NO_Defect_d;

    /* Entry 'NO_Defect': '<S267>:1' */
    localB->SRC_Def_Status = SRC_NON_DEF;
  } else if (localDW->bitsForTID0.is_c59_BMS_MON == BMS_MON_IN_Defect_p) {
    /* During 'Defect': '<S267>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S267>:22' */
      /* Exit Internal 'Defect': '<S267>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MO_IN_SRC_High_Debouncing_k:
        /* Exit 'SRC_High_Debouncing': '<S267>:4' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_p;
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_p:
        /* Exit 'SRC_Low_Debouncing': '<S267>:3' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_p;
        break;

       default:
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_p;
        break;
      }

      localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_NO_Defect_d;

      /* Entry 'NO_Defect': '<S267>:1' */
      localB->SRC_Def_Status = SRC_NON_DEF;
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Confimed_f:
        /* During 'SRC_High_Confimed': '<S267>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S267>:13' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Healing_o;

          /* Entry 'SRC_High_Healing': '<S267>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MO_IN_SRC_High_Debouncing_k:
        /* During 'SRC_High_Debouncing': '<S267>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S267>:12' */
          /* Exit 'SRC_High_Debouncing': '<S267>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_p;
          localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_NO_Defect_d;

          /* Entry 'NO_Defect': '<S267>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S267>:14' */
          /* Exit 'SRC_High_Debouncing': '<S267>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_f;

          /* Entry 'SRC_High_Confimed': '<S267>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Healing_o:
        /* During 'SRC_High_Healing': '<S267>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S267>:15' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_p;
          localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_NO_Defect_d;

          /* Entry 'NO_Defect': '<S267>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S267>:17' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_f;

          /* Entry 'SRC_High_Confimed': '<S267>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Confimed_c:
        /* During 'SRC_Low_Confimed': '<S267>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S267>:18' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Healing_df;

          /* Entry 'SRC_Low_Healing': '<S267>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Debouncing_p:
        /* During 'SRC_Low_Debouncing': '<S267>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S267>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S267>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_p;
          localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_NO_Defect_d;

          /* Entry 'NO_Defect': '<S267>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S267>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S267>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_c;

          /* Entry 'SRC_Low_Confimed': '<S267>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S267>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S267>:20' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_p;
          localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_NO_Defect_d;

          /* Entry 'NO_Defect': '<S267>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S267>:19' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_c;

          /* Entry 'SRC_Low_Confimed': '<S267>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    /* During 'NO_Defect': '<S267>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S267>:10' */
      localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_Defect_p;
      localDW->bitsForTID0.is_Defect = BMS_MO_IN_SRC_High_Debouncing_k;

      /* Entry 'SRC_High_Debouncing': '<S267>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
      localB->SRC_Tmp_Def_Flag = 1U;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S267>:11' */
        localDW->bitsForTID0.is_c59_BMS_MON = BMS_MON_IN_Defect_p;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Debouncing_p;

        /* Entry 'SRC_Low_Debouncing': '<S267>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
        localB->SRC_Tmp_Def_Flag = 1U;
      }
    }
  }

  /* End of Chart: '<S266>/SRC_Check' */
}

/*
 * Output and update for action system:
 *    '<S258>/If Abnormal Action Subsystem'
 *    '<S258>/If Normal Action Subsystem'
 *    '<S296>/If Abnormal Action Subsystem'
 *    '<S296>/If Normal Action Subsystem'
 *    '<S277>/If Abnormal Action Subsystem'
 *    '<S277>/If Normal Action Subsystem'
 */
void BMS_IfAbnormalActionSubsystem_e(boolean_T rtu_In1, t_Current1 rtu_In2,
  uint8_T rtu_In3, boolean_T *rty_Out1, t_Current1 *rty_Out2, uint8_T *rty_Out3)
{
  /* Inport: '<S261>/In1' */
  *rty_Out1 = rtu_In1;

  /* Inport: '<S261>/In2' */
  *rty_Out2 = rtu_In2;

  /* Inport: '<S261>/In3' */
  *rty_Out3 = rtu_In3;
}

/* Start for atomic system: '<S227>/PcMon' */
void BMS_MON_PcMon_Start(void)
{
  /* InitializeConditions for IfAction SubSystem: '<S233>/discharge' */

  /* InitializeConditions for Atomic SubSystem: '<S265>/SRC_Check' */
  BMS_MON_SRC_Check_nd_Init(&BMS_MON_B.SRC_Check_h5, &BMS_MON_DWork.SRC_Check_h5);

  /* End of InitializeConditions for SubSystem: '<S265>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S274>/SRC_Check' */
  BMS_MON_SRC_Check_nd_Init(&BMS_MON_B.SRC_Check_o, &BMS_MON_DWork.SRC_Check_o);

  /* End of InitializeConditions for SubSystem: '<S274>/SRC_Check' */

  /* End of InitializeConditions for SubSystem: '<S233>/discharge' */

  /* InitializeConditions for IfAction SubSystem: '<S233>/sc charge' */

  /* InitializeConditions for Atomic SubSystem: '<S303>/SRC_Check' */
  BMS_MON_SRC_Check_nd_Init(&BMS_MON_B.SRC_Check_b, &BMS_MON_DWork.SRC_Check_b);

  /* End of InitializeConditions for SubSystem: '<S303>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S312>/SRC_Check' */
  BMS_MON_SRC_Check_nd_Init(&BMS_MON_B.SRC_Check_a, &BMS_MON_DWork.SRC_Check_a);

  /* End of InitializeConditions for SubSystem: '<S312>/SRC_Check' */

  /* End of InitializeConditions for SubSystem: '<S233>/sc charge' */

  /* InitializeConditions for IfAction SubSystem: '<S233>/fc charge' */

  /* InitializeConditions for Atomic SubSystem: '<S284>/SRC_Check' */
  BMS_MON_SRC_Check_nd_Init(&BMS_MON_B.SRC_Check_c, &BMS_MON_DWork.SRC_Check_c);

  /* End of InitializeConditions for SubSystem: '<S284>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S293>/SRC_Check' */
  BMS_MON_SRC_Check_nd_Init(&BMS_MON_B.SRC_Check_hu, &BMS_MON_DWork.SRC_Check_hu);

  /* End of InitializeConditions for SubSystem: '<S293>/SRC_Check' */

  /* End of InitializeConditions for SubSystem: '<S233>/fc charge' */
}

/* Output and update for atomic system: '<S227>/PcMon' */
void BMS_MON_PcMon(void)
{
  boolean_T rtb_LogicalOperator1;
  uint8_T rtb_Switch;
  uint8_T rtb_Switch_af;
  boolean_T rtb_Merge;
  t_Current1 rtb_Merge1_gj;

  /* SwitchCase: '<S233>/Switch Case' incorporates:
   *  Constant: '<S265>/Constant1'
   *  Constant: '<S265>/Constant2'
   *  Constant: '<S265>/Constant3'
   *  Constant: '<S265>/Constant4'
   *  Constant: '<S265>/Constant5'
   *  Constant: '<S265>/Constant6'
   *  Constant: '<S265>/Constant7'
   *  Constant: '<S265>/Constant8'
   *  Constant: '<S274>/Constant1'
   *  Constant: '<S274>/Constant2'
   *  Constant: '<S274>/Constant3'
   *  Constant: '<S274>/Constant4'
   *  Constant: '<S274>/Constant5'
   *  Constant: '<S274>/Constant6'
   *  Constant: '<S274>/Constant7'
   *  Constant: '<S274>/Constant8'
   *  Constant: '<S284>/Constant1'
   *  Constant: '<S284>/Constant2'
   *  Constant: '<S284>/Constant3'
   *  Constant: '<S284>/Constant4'
   *  Constant: '<S284>/Constant5'
   *  Constant: '<S284>/Constant6'
   *  Constant: '<S284>/Constant7'
   *  Constant: '<S284>/Constant8'
   *  Constant: '<S293>/Constant1'
   *  Constant: '<S293>/Constant2'
   *  Constant: '<S293>/Constant3'
   *  Constant: '<S293>/Constant4'
   *  Constant: '<S293>/Constant5'
   *  Constant: '<S293>/Constant6'
   *  Constant: '<S293>/Constant7'
   *  Constant: '<S293>/Constant8'
   *  Constant: '<S303>/Constant1'
   *  Constant: '<S303>/Constant2'
   *  Constant: '<S303>/Constant3'
   *  Constant: '<S303>/Constant4'
   *  Constant: '<S303>/Constant5'
   *  Constant: '<S303>/Constant6'
   *  Constant: '<S303>/Constant7'
   *  Constant: '<S303>/Constant8'
   *  Constant: '<S312>/Constant1'
   *  Constant: '<S312>/Constant2'
   *  Constant: '<S312>/Constant3'
   *  Constant: '<S312>/Constant4'
   *  Constant: '<S312>/Constant5'
   *  Constant: '<S312>/Constant6'
   *  Constant: '<S312>/Constant7'
   *  Constant: '<S312>/Constant8'
   *  Inport: '<Root>/PackCurMode'
   *  Inport: '<Root>/com_BattCurr'
   */
  switch ((int32_T)PackCurMode) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S233>/discharge' incorporates:
     *  ActionPort: '<S255>/Action Port'
     */

    /* Outputs for Atomic SubSystem: '<S265>/SRC_Check' */
    BMS_MON_SRC_Check_h5(false, com_BattCurr, DsgCurSigASRCHigh,
                         DsgCurSigASRCLow, BmsSigASRCHighPosDeb,
                         BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                         BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_h5,
                         &BMS_MON_DWork.SRC_Check_h5);

    /* End of Outputs for SubSystem: '<S265>/SRC_Check' */

    /* Logic: '<S264>/Logical Operator1' incorporates:
     *  Constant: '<S265>/Constant1'
     *  Constant: '<S265>/Constant2'
     *  Constant: '<S265>/Constant3'
     *  Constant: '<S265>/Constant4'
     *  Constant: '<S265>/Constant5'
     *  Constant: '<S265>/Constant6'
     *  Constant: '<S265>/Constant7'
     *  Constant: '<S265>/Constant8'
     *  DataStoreRead: '<S264>/Data Store Read'
     *  Inport: '<Root>/com_BattCurr'
     *  Logic: '<S264>/Logical Operator4'
     */
    rtb_LogicalOperator1 = ((BMS_MON_B.SRC_Check_h5.SRC_Tmp_Def_Flag != 0) &&
      (!BMS_MON_DWork.Dem_stClear_ho));

    /* Switch: '<S260>/Switch2' incorporates:
     *  Constant: '<S260>/Constant4'
     *  DataStoreRead: '<S260>/Data Store Read1'
     *  Logic: '<S260>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_ho) {
      rtb_Switch = BMS_MON_B.SRC_Check_h5.SRC_Def_Status;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S260>/Switch2' */

    /* Switch: '<S260>/Switch' incorporates:
     *  Constant: '<S260>/Constant4'
     *  RelationalOperator: '<S260>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch_af = BMS_MON_B.SRC_Check_h5.SRC_Def_Status;
    } else {
      rtb_Switch_af = SRC_NON_DEF;
    }

    /* End of Switch: '<S260>/Switch' */

    /* Outputs for Atomic SubSystem: '<S274>/SRC_Check' */
    BMS_MON_SRC_Check_h5(false, com_BattCurr, DsgCurSigASRCTooHigh,
                         DsgCurSigASRCTooLow, BmsSigASRCHighPosDeb,
                         BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                         BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_o,
                         &BMS_MON_DWork.SRC_Check_o);

    /* End of Outputs for SubSystem: '<S274>/SRC_Check' */

    /* SwitchCase: '<S268>/Switch Case' incorporates:
     *  Constant: '<S268>/Constant1'
     *  Constant: '<S268>/Constant2'
     *  Constant: '<S268>/Constant4'
     *  Constant: '<S274>/Constant1'
     *  Constant: '<S274>/Constant2'
     *  Constant: '<S274>/Constant3'
     *  Constant: '<S274>/Constant4'
     *  Constant: '<S274>/Constant5'
     *  Constant: '<S274>/Constant6'
     *  Constant: '<S274>/Constant7'
     *  Constant: '<S274>/Constant8'
     *  Inport: '<Root>/com_BattCurr'
     */
    switch ((int32_T)BMS_MON_B.SRC_Check_o.SRC_Def_Status) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S268>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S271>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_f);

      /* End of Outputs for SubSystem: '<S268>/Switch Case Action Subsystem' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S268>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S272>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_f);

      /* End of Outputs for SubSystem: '<S268>/Switch Case Action Subsystem1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S268>/Switch Case Action Subsystem2' incorporates:
       *  ActionPort: '<S273>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_f);

      /* End of Outputs for SubSystem: '<S268>/Switch Case Action Subsystem2' */
      break;
    }

    /* End of SwitchCase: '<S268>/Switch Case' */

    /* Switch: '<S259>/Switch2' incorporates:
     *  Constant: '<S259>/Constant4'
     *  DataStoreRead: '<S259>/Data Store Read1'
     *  Logic: '<S259>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_l) {
      rtb_Switch = BMS_MON_B.Merge_f;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S259>/Switch2' */

    /* Switch: '<S259>/Switch' incorporates:
     *  Constant: '<S259>/Constant4'
     *  RelationalOperator: '<S259>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch = BMS_MON_B.Merge_f;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S259>/Switch' */

    /* If: '<S258>/If Abnormal' incorporates:
     *  DataStoreRead: '<S270>/Data Store Read'
     *  Inport: '<Root>/com_BattCurr'
     *  Logic: '<S270>/Logical Operator1'
     *  Logic: '<S270>/Logical Operator4'
     */
    if (rtb_Switch != 0) {
      /* Outputs for IfAction SubSystem: '<S258>/If Abnormal Action Subsystem' incorporates:
       *  ActionPort: '<S261>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_e((BMS_MON_B.SRC_Check_o.SRC_Tmp_Def_Flag !=
        0) && (!BMS_MON_DWork.Dem_stClear_l), com_BattCurr, rtb_Switch,
        &rtb_Merge, &rtb_Merge1_gj, &PC_dsg_St);

      /* End of Outputs for SubSystem: '<S258>/If Abnormal Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S258>/If Normal Action Subsystem' incorporates:
       *  ActionPort: '<S262>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_e(rtb_LogicalOperator1, com_BattCurr,
        rtb_Switch_af, &rtb_Merge, &rtb_Merge1_gj, &PC_dsg_St);

      /* End of Outputs for SubSystem: '<S258>/If Normal Action Subsystem' */
    }

    /* End of If: '<S258>/If Abnormal' */
    /* End of Outputs for SubSystem: '<S233>/discharge' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S233>/sc charge' incorporates:
     *  ActionPort: '<S257>/Action Port'
     */

    /* Outputs for Atomic SubSystem: '<S303>/SRC_Check' */
    BMS_MON_SRC_Check_h5(false, com_BattCurr, ScCurSigASRCHigh, ScCurSigASRCLow,
                         BmsSigASRCHighPosDeb, BmsSigASRCHighNegDeb,
                         BmsSigASRCLowPosDeb, BmsSigASRCLowNegDeb, StepTim,
                         &BMS_MON_B.SRC_Check_b, &BMS_MON_DWork.SRC_Check_b);

    /* End of Outputs for SubSystem: '<S303>/SRC_Check' */

    /* Logic: '<S302>/Logical Operator1' incorporates:
     *  Constant: '<S303>/Constant1'
     *  Constant: '<S303>/Constant2'
     *  Constant: '<S303>/Constant3'
     *  Constant: '<S303>/Constant4'
     *  Constant: '<S303>/Constant5'
     *  Constant: '<S303>/Constant6'
     *  Constant: '<S303>/Constant7'
     *  Constant: '<S303>/Constant8'
     *  DataStoreRead: '<S302>/Data Store Read'
     *  Inport: '<Root>/com_BattCurr'
     *  Logic: '<S302>/Logical Operator4'
     */
    rtb_LogicalOperator1 = ((BMS_MON_B.SRC_Check_b.SRC_Tmp_Def_Flag != 0) &&
      (!BMS_MON_DWork.Dem_stClear_c));

    /* Switch: '<S298>/Switch2' incorporates:
     *  Constant: '<S298>/Constant4'
     *  DataStoreRead: '<S298>/Data Store Read1'
     *  Logic: '<S298>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_c) {
      rtb_Switch = BMS_MON_B.SRC_Check_b.SRC_Def_Status;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S298>/Switch2' */

    /* Switch: '<S298>/Switch' incorporates:
     *  Constant: '<S298>/Constant4'
     *  RelationalOperator: '<S298>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch_af = BMS_MON_B.SRC_Check_b.SRC_Def_Status;
    } else {
      rtb_Switch_af = SRC_NON_DEF;
    }

    /* End of Switch: '<S298>/Switch' */

    /* Outputs for Atomic SubSystem: '<S312>/SRC_Check' */
    BMS_MON_SRC_Check_h5(false, com_BattCurr, ScCurSigASRCTooHigh,
                         ScCurSigASRCTooLow, BmsSigASRCHighPosDeb,
                         BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                         BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_a,
                         &BMS_MON_DWork.SRC_Check_a);

    /* End of Outputs for SubSystem: '<S312>/SRC_Check' */

    /* SwitchCase: '<S306>/Switch Case' incorporates:
     *  Constant: '<S306>/Constant1'
     *  Constant: '<S306>/Constant2'
     *  Constant: '<S306>/Constant4'
     *  Constant: '<S312>/Constant1'
     *  Constant: '<S312>/Constant2'
     *  Constant: '<S312>/Constant3'
     *  Constant: '<S312>/Constant4'
     *  Constant: '<S312>/Constant5'
     *  Constant: '<S312>/Constant6'
     *  Constant: '<S312>/Constant7'
     *  Constant: '<S312>/Constant8'
     *  Inport: '<Root>/com_BattCurr'
     */
    switch ((int32_T)BMS_MON_B.SRC_Check_a.SRC_Def_Status) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S306>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S309>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_p);

      /* End of Outputs for SubSystem: '<S306>/Switch Case Action Subsystem' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S306>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S310>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_p);

      /* End of Outputs for SubSystem: '<S306>/Switch Case Action Subsystem1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S306>/Switch Case Action Subsystem2' incorporates:
       *  ActionPort: '<S311>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_p);

      /* End of Outputs for SubSystem: '<S306>/Switch Case Action Subsystem2' */
      break;
    }

    /* End of SwitchCase: '<S306>/Switch Case' */

    /* Switch: '<S297>/Switch2' incorporates:
     *  Constant: '<S297>/Constant4'
     *  DataStoreRead: '<S297>/Data Store Read1'
     *  Logic: '<S297>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_kk) {
      rtb_Switch = BMS_MON_B.Merge_p;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S297>/Switch2' */

    /* Switch: '<S297>/Switch' incorporates:
     *  Constant: '<S297>/Constant4'
     *  RelationalOperator: '<S297>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch = BMS_MON_B.Merge_p;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S297>/Switch' */

    /* If: '<S296>/If Abnormal' incorporates:
     *  DataStoreRead: '<S308>/Data Store Read'
     *  Inport: '<Root>/com_BattCurr'
     *  Logic: '<S308>/Logical Operator1'
     *  Logic: '<S308>/Logical Operator4'
     */
    if (rtb_Switch != 0) {
      /* Outputs for IfAction SubSystem: '<S296>/If Abnormal Action Subsystem' incorporates:
       *  ActionPort: '<S299>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_e((BMS_MON_B.SRC_Check_a.SRC_Tmp_Def_Flag !=
        0) && (!BMS_MON_DWork.Dem_stClear_kk), com_BattCurr, rtb_Switch,
        &rtb_Merge, &rtb_Merge1_gj, &BMS_MON_B.Merge2);

      /* End of Outputs for SubSystem: '<S296>/If Abnormal Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S296>/If Normal Action Subsystem' incorporates:
       *  ActionPort: '<S300>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_e(rtb_LogicalOperator1, com_BattCurr,
        rtb_Switch_af, &rtb_Merge, &rtb_Merge1_gj, &BMS_MON_B.Merge2);

      /* End of Outputs for SubSystem: '<S296>/If Normal Action Subsystem' */
    }

    /* End of If: '<S296>/If Abnormal' */
    /* End of Outputs for SubSystem: '<S233>/sc charge' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S233>/fc charge' incorporates:
     *  ActionPort: '<S256>/Action Port'
     */

    /* Outputs for Atomic SubSystem: '<S284>/SRC_Check' */
    BMS_MON_SRC_Check_h5(false, com_BattCurr, FcCurLimit, FcCurSigASRCLow, 3600U,
                         BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                         BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_c,
                         &BMS_MON_DWork.SRC_Check_c);

    /* End of Outputs for SubSystem: '<S284>/SRC_Check' */

    /* Logic: '<S283>/Logical Operator1' incorporates:
     *  Constant: '<S284>/Constant1'
     *  Constant: '<S284>/Constant2'
     *  Constant: '<S284>/Constant3'
     *  Constant: '<S284>/Constant4'
     *  Constant: '<S284>/Constant5'
     *  Constant: '<S284>/Constant6'
     *  Constant: '<S284>/Constant7'
     *  Constant: '<S284>/Constant8'
     *  DataStoreRead: '<S283>/Data Store Read'
     *  Inport: '<Root>/com_BattCurr'
     *  Logic: '<S283>/Logical Operator4'
     */
    rtb_LogicalOperator1 = ((BMS_MON_B.SRC_Check_c.SRC_Tmp_Def_Flag != 0) &&
      (!BMS_MON_DWork.Dem_stClear_ke));

    /* Switch: '<S279>/Switch2' incorporates:
     *  Constant: '<S279>/Constant4'
     *  DataStoreRead: '<S279>/Data Store Read1'
     *  Logic: '<S279>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_ke) {
      rtb_Switch = BMS_MON_B.SRC_Check_c.SRC_Def_Status;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S279>/Switch2' */

    /* Switch: '<S279>/Switch' incorporates:
     *  Constant: '<S279>/Constant4'
     *  RelationalOperator: '<S279>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch_af = BMS_MON_B.SRC_Check_c.SRC_Def_Status;
    } else {
      rtb_Switch_af = SRC_NON_DEF;
    }

    /* End of Switch: '<S279>/Switch' */

    /* Outputs for Atomic SubSystem: '<S293>/SRC_Check' */
    BMS_MON_SRC_Check_h5(false, com_BattCurr, FcCurSigASRCTooHigh,
                         FcCurSigASRCTooLow, BmsSigASRCHighPosDeb,
                         BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                         BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_hu,
                         &BMS_MON_DWork.SRC_Check_hu);

    /* End of Outputs for SubSystem: '<S293>/SRC_Check' */

    /* SwitchCase: '<S287>/Switch Case' incorporates:
     *  Constant: '<S287>/Constant1'
     *  Constant: '<S287>/Constant2'
     *  Constant: '<S287>/Constant4'
     *  Constant: '<S293>/Constant1'
     *  Constant: '<S293>/Constant2'
     *  Constant: '<S293>/Constant3'
     *  Constant: '<S293>/Constant4'
     *  Constant: '<S293>/Constant5'
     *  Constant: '<S293>/Constant6'
     *  Constant: '<S293>/Constant7'
     *  Constant: '<S293>/Constant8'
     *  Inport: '<Root>/com_BattCurr'
     */
    switch ((int32_T)BMS_MON_B.SRC_Check_hu.SRC_Def_Status) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S287>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S290>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_e);

      /* End of Outputs for SubSystem: '<S287>/Switch Case Action Subsystem' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S287>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S291>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_e);

      /* End of Outputs for SubSystem: '<S287>/Switch Case Action Subsystem1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S287>/Switch Case Action Subsystem2' incorporates:
       *  ActionPort: '<S292>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_e);

      /* End of Outputs for SubSystem: '<S287>/Switch Case Action Subsystem2' */
      break;
    }

    /* End of SwitchCase: '<S287>/Switch Case' */

    /* Switch: '<S278>/Switch2' incorporates:
     *  Constant: '<S278>/Constant4'
     *  DataStoreRead: '<S278>/Data Store Read1'
     *  Logic: '<S278>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_h1) {
      rtb_Switch = BMS_MON_B.Merge_e;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S278>/Switch2' */

    /* Switch: '<S278>/Switch' incorporates:
     *  Constant: '<S278>/Constant4'
     *  RelationalOperator: '<S278>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch = BMS_MON_B.Merge_e;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S278>/Switch' */

    /* If: '<S277>/If Abnormal' incorporates:
     *  DataStoreRead: '<S289>/Data Store Read'
     *  Inport: '<Root>/com_BattCurr'
     *  Logic: '<S289>/Logical Operator1'
     *  Logic: '<S289>/Logical Operator4'
     */
    if (rtb_Switch != 0) {
      /* Outputs for IfAction SubSystem: '<S277>/If Abnormal Action Subsystem' incorporates:
       *  ActionPort: '<S280>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_e((BMS_MON_B.SRC_Check_hu.SRC_Tmp_Def_Flag
        != 0) && (!BMS_MON_DWork.Dem_stClear_h1), com_BattCurr, rtb_Switch,
        &rtb_Merge, &rtb_Merge1_gj, &PC_fc_St);

      /* End of Outputs for SubSystem: '<S277>/If Abnormal Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S277>/If Normal Action Subsystem' incorporates:
       *  ActionPort: '<S281>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_e(rtb_LogicalOperator1, com_BattCurr,
        rtb_Switch_af, &rtb_Merge, &rtb_Merge1_gj, &PC_fc_St);

      /* End of Outputs for SubSystem: '<S277>/If Normal Action Subsystem' */
    }

    /* End of If: '<S277>/If Abnormal' */
    /* End of Outputs for SubSystem: '<S233>/fc charge' */
    break;
  }

  /* End of SwitchCase: '<S233>/Switch Case' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
