/*
 * File: IsoMon.h
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_IsoMon_h_
#define RTW_HEADER_IsoMon_h_
#ifndef BMS_MON_COMMON_INCLUDES_
# define BMS_MON_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "SetErr.h"
#endif                                 /* BMS_MON_COMMON_INCLUDES_ */

#include "BMS_MON_types.h"

/* Child system includes */
#include "rt_sys_BMS_MON_3.h"

/* Block signals for system '<S243>/SRC_Check' */
typedef struct {
  uint8_T SRC_Def_Status;              /* '<S244>/SRC_Check' */
  uint8_T SRC_Tmp_Def_Flag;            /* '<S244>/SRC_Check' */
} rtB_SRC_Check_BMS_MON_p;

/* Block states (auto storage) for system '<S243>/SRC_Check' */
typedef struct {
  uint16_T local_Timer;                /* '<S244>/SRC_Check' */
  struct {
    uint_T is_Defect:3;                /* '<S244>/SRC_Check' */
    uint_T is_c56_BMS_MON:2;           /* '<S244>/SRC_Check' */
    uint_T is_active_c56_BMS_MON:1;    /* '<S244>/SRC_Check' */
  } bitsForTID0;
} rtDW_SRC_Check_BMS_MON_g;

extern void BMS_MON_SRC_Check_f_Init(rtB_SRC_Check_BMS_MON_p *localB,
  rtDW_SRC_Check_BMS_MON_g *localDW);
extern void BMS_MON_SRC_Check_d(boolean_T rtu_Clear_Def_Flag, uint16_T
  rtu_Sig_Volt, uint16_T rtu_Par_SRC_H_Threshold, uint16_T
  rtu_Par_SRC_L_Threshold, uint16_T rtu_Par_SRC_H_PosDeb, uint16_T
  rtu_Par_SRC_H_NegDeb, uint16_T rtu_Par_SRC_L_PosDeb, uint16_T
  rtu_Par_SRC_L_NegDeb, uint8_T rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_p
  *localB, rtDW_SRC_Check_BMS_MON_g *localDW);
extern void BM_IfAbnormalActionSubsystem_ml(boolean_T rtu_In1, uint16_T rtu_In2,
  uint8_T rtu_In3, boolean_T *rty_Out1, uint16_T *rty_Out2, uint8_T *rty_Out3);
extern void BMS_MON_IsoMon_Init(void);
extern void BMS_MON_IsoMon(void);

#endif                                 /* RTW_HEADER_IsoMon_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
