/*******************************************************************************
*
*  FILE
*     Os_Vectors.c
*
*  DESCRIPTION
*     Os Vector Table 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.00
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Os.h"
#include "Can.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#if (OS_BOOTLOADER_SUPPORT == STD_ON)
  #define JUMP 0x06,
#else
  #define JUMP 
#endif
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Type Definition                                                                
*******************************************************************************/
typedef struct
{
#if (OS_BOOTLOADER_SUPPORT == STD_ON)
  uint8 OpCode;
#endif
  CONST(uint16,OS_CONST)VecTab;
}Os_IntVectTableType;
/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/


/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/

/*******************************************************************************
* External Functions prototypes                         
*******************************************************************************/
extern IRQFUNC(Can_ErrorInterrupt0);
extern IRQFUNC(Can_ErrorInterrupt1);
extern IRQFUNC(Can_ErrorInterrupt2);
extern IRQFUNC(Can_ErrorInterrupt3);

extern IRQFUNC(Can_WakeUpInterrupt0);
extern IRQFUNC(Can_WakeUpInterrupt1);
extern IRQFUNC(Can_WakeUpInterrupt2);
extern IRQFUNC(Can_WakeUpInterrupt3);

extern IRQFUNC(Can_TxInterrupt0);
extern IRQFUNC(Can_TxInterrupt1);
extern IRQFUNC(Can_TxInterrupt2);
extern IRQFUNC(Can_TxInterrupt3);

extern IRQFUNC(Can_RxInterrupt0);
extern IRQFUNC(Can_RxInterrupt1);
extern IRQFUNC(Can_RxInterrupt2);
extern IRQFUNC(Can_RxInterrupt3);

extern IRQFUNC(Gpt_RtiInterrupt);

extern IRQFUNC(AirBag_Ect0Interrupt);
extern IRQFUNC(Pbs_Ect2Interrupt);
extern IRQFUNC(Pbs_Ect3Interrupt);
extern IRQFUNC(Pbs_Ect4Interrupt);
extern IRQFUNC(Pbs_Ect5Interrupt);

extern FUNC(void,OS_CODE_ISR) _Startup(void);

uint16 isr_Cnt;

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/
#define OS_START_SEC_CODE_NEAR
#include "MemMap.h"

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt1(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt2(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt3(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt4(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt5(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt6(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt7(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt8(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt9(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt10(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt11(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt12(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt13(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt14(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt15(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt16(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt17(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt18(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt19(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt20(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt21(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt22(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt23(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt24(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt25(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt26(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt27(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt28(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt29(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt30(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt31(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt32(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt33(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt34(void)
{                              
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt35(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt36(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt37(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt38(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt39(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt40(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt41(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt42(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt43(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt44(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt45(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt46(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt47(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt48(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt49(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt50(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt51(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt52(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt53(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt54(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt55(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt56(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt57(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt58(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt59(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt60(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt61(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt62(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt63(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt64(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt65(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt66(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt67(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt68(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt69(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt70(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt71(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt72(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt73(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt74(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt75(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt76(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt77(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt78(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt79(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt80(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt81(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt82(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt83(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt84(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt85(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt86(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt87(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt88(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt89(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt90(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt91(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt92(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt93(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt94(void)
{                              
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt95(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt96(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt97(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt98(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt99(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt100(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt101(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt102(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt103(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt104(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt105(void)
{
   for(;;);
}

IRQFUNC(OS_InvalidInterrupt106)
{
   isr_Cnt++;
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt107(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt108(void)
{
   for(;;);
}

FUNC(void,OS_CODE_ISR) OS_InvalidInterrupt109(void)
{
   isr_Cnt++;
}

#define OS_STOP_SEC_CODE_NEAR
#include "MemMap.h"

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

#if (OS_BOOTLOADER_SUPPORT == STD_ON)
  #define OS_START_SEC_JUMP_TBL
  #include "MemMap.h"
#else
  #define OS_START_SEC_VECT_TBL
  #include "MemMap.h"
#endif
CONST(Os_IntVectTableType,OS_CONST)OS_VectorTable[] = {
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt109, /* 0xFF10 Spurious interrupt              */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt108, /* 0xFF12 System Call Interrupt(SYS)      */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt107, /* 0xFF14 MPU Access Error                */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt106, /* 0xFF16 XGATE software error interrupt  */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt105, /* 0xFF18 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt104, /* 0xFF1A Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt103, /* 0xFF1C Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt102, /* 0xFF1E Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt101, /* 0xFF20 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt100, /* 0xFF22 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt99,  /* 0xFF24 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt98,  /* 0xFF26 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt97,  /* 0xFF28 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt96,  /* 0xFF2A Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt95,  /* 0xFF2C Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt94,  /* 0xFF2E Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt93,  /* 0xFF30 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt92,  /* 0xFF32 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt91,  /* 0xFF34 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt90,  /* 0xFF36 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt89,  /* 0xFF38 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt88,  /* 0xFF3A Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt87,  /* 0xFF3C ATD1 compare Interrupt          */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt86,  /* 0xFF3E ATD0 compare Interrupt          */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt85,  /* 0xFF40 TIM Pulse accumulator A Input   */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt84,  /* 0xFF42 TIM Pulse accumulator A overflow*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt83,  /* 0xFF44 TIM timer overflow              */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt82,  /* 0xFF46 TIM timer channel 7             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt81,  /* 0xFF48 TIM timer channel 6             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt80,  /* 0xFF4A TIM timer channel 5             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt79,  /* 0xFF4C TIM timer channel 4             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt78,  /* 0xFF4E TIM timer channel 3             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt77,  /* 0xFF50 TIM timer channel 2             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt76,  /* 0xFF52 TIM timer channel 1             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt75,  /* 0xFF54 TIM timer channel 0             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt74,  /* 0xFF56 SCI 7                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt73,  /* 0xFF58 Periodic interupt timer channel7*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt72,  /* 0xFF5A Periodic interupt timer channel6*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt71,  /* 0xFF5C Periodic interupt timer channel5*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt70,  /* 0xFF5E Periodic interupt timer channel4*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt69,  /* 0xFF60 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt68,  /* 0xFF62 Reserved                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt67,  /* 0xFF64 XGATE software trigger 7        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt66,  /* 0xFF66 XGATE software trigger 6        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt65,  /* 0xFF68 XGATE software trigger 5        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt64,  /* 0xFF6A XGATE software trigger 4        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt63,  /* 0xFF6C XGATE software trigger 3        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt62,  /* 0xFF6E XGATE software trigger 2        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt61,  /* 0xFF70 XGATE software trigger 1        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt60,  /* 0xFF72 XGATE software trigger 0        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt59,  /* 0xFF74 Periodic interupt timer channel3*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt58,  /* 0xFF76 Periodic interupt timer channel2*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt57,  /* 0xFF78 Periodic interupt timer channel1*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt56,  /* 0xFF7A Periodic interupt timer channel0*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt55,  /* 0xFF7C High temperature Interrupt      */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt54,  /* 0xFF7E Auto.periodical Interrupt(API)  */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt53,  /* 0xFF80 Low-voltage Interrupt(LVI)      */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt52,  /* 0xFF82 IIC1 bus                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt51,  /* 0xFF84 SCI 5                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt50,  /* 0xFF86 SCI 4                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt49,  /* 0xFF88 SCI 3                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt48,  /* 0xFF8A SCI 2                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt47,  /* 0xFF8C PWM emergency shutdown          */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt46,  /* 0xFF8E Port P Interrupt                */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt45,  /* 0xFF90 CAN4 transmit                   */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt44,  /* 0xFF92 CAN4 receive                    */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt43,  /* 0xFF94 CAN4 errors                     */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt42,  /* 0xFF96 CAN4 Wake-up                    */
  
  
  
  
  
  
  
 
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt41,  /* 0xFF98 CAN3 transmit                   */

  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt40,  /* 0xFF9A CAN3 receive                    */

  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt39,  /* 0xFF9C CAN3 errors                     */

  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt38,  /* 0xFF9E CAN3 Wake-up                    */


#if ((CAN_TX_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt37,  /* 0xFFA0 CAN2 transmit                   */
#else
  JUMP (CONST(uint16,OS_CONST))Can_TxInterrupt2,     /* 0xFFA0 CAN2 transmit      */
#endif

#if ((CAN_RX_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt36,  /* 0xFFA2 CAN2 receive                    */
#else
  JUMP (CONST(uint16,OS_CONST))Can_RxInterrupt2,     /* 0xFFA2 CAN2 receive     */
#endif

#if ((CAN_BUSOFF_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt35,  /* 0xFFA4 CAN2 errors                     */
#else
  JUMP (CONST(uint16,OS_CONST))Can_ErrorInterrupt2,  /* 0xFFA4 CAN2 errors     */
#endif

#if ((CAN_WAKEUP_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt34,  /* 0xFFA6 CAN2 Wake-up                    */
#else
  JUMP (CONST(uint16,OS_CONST))Can_WakeUpInterrupt2, /* 0xFFA6 CAN2 Wake-up    */
#endif


#if ((CAN_TX_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt33,  /* 0xFFA8 CAN1 transmit  */
#else
  JUMP (CONST(uint16,OS_CONST))Can_TxInterrupt1,     /* 0xFFA8 CAN1 transmit  */
#endif

#if ((CAN_RX_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt32,  /* 0xFFAA CAN1 receive   */
#else
  JUMP (CONST(uint16,OS_CONST))Can_RxInterrupt1,     /* 0xFFAA CAN1 receive   */
#endif

#if ((CAN_BUSOFF_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt31,  /* 0xFFAC CAN1 errors    */
#else
  JUMP (CONST(uint16,OS_CONST))Can_ErrorInterrupt1,  /* 0xFFAC CAN1 errors    */
#endif

#if ((CAN_WAKEUP_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt30, /* 0xFFAE CAN1 Wake-up   */
#else
  JUMP (CONST(uint16,OS_CONST))Can_WakeUpInterrupt1, /* 0xFFAE CAN1 Wake-up   */
#endif






#if ((CAN_TX_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt31,  /* 0xFFB0 CAN0 transmit  */
#else
  JUMP (CONST(uint16,OS_CONST))Can_TxInterrupt0,     /* 0xFFB0 CAN0 transmit  */
#endif

#if ((CAN_RX_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt30,  /* 0xFFB2 CAN0 receive   */
#else
  JUMP (CONST(uint16,OS_CONST))Can_RxInterrupt0,     /* 0xFFB2 CAN0 receive   */
#endif

#if ((CAN_BUSOFF_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt30,  /* 0xFFB4 CAN0 errors   */
#else
  JUMP (CONST(uint16,OS_CONST))Can_ErrorInterrupt0,  /* 0xFFB4 CAN0 errors    */
#endif

#if ((CAN_WAKEUP_PROCESSING == CAN_POLLING))
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt30, /* 0xFFB6 CAN0 Wake-up   */
#else
  JUMP (CONST(uint16,OS_CONST))Can_WakeUpInterrupt0, /* 0xFFB6 CAN0 Wake-up   */
#endif  




  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt29,  /* 0xFFB8 Flash                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt28,  /* 0xFFBA Flash fault Detect              */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt27,  /* 0xFFBC SPI 2                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt26,  /* 0xFFBE SPI 1                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt25,  /* 0xFFC0 IIC0 bus                        */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt24,  /* 0xFFC2 SCI 6                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt23,  /* 0xFFC4 CRG self-clock mode             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt22,  /* 0xFFC6 CRG PLL lock                    */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt21,  /* 0xFFC8 Pulsse accumulator B overlfow   */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt20,  /* 0xFFCA Modulus down counter underflow  */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt19,  /* 0xFFCC PORT H                          */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt18,  /* 0xFFCE PORT J                          */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt17,  /* 0xFFD0 ATD 1                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt16,  /* 0xFFD2 ATD 0                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt15,  /* 0xFFD4 SCI 2                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt14,  /* 0xFFD6 SCI 1                           */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt13,  /* 0xFFD8 SPI                             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt12,  /* 0xFFDA Pulse accumulator input edge    */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt11,  /* 0xFFDC Pulse accumulator A  overflow   */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt10,  /* 0xFFDE Enhanced capture Timer overflow */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt9,   /* 0xFFE0 Enhanced capture Timer channel 7*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt8,   /* 0xFFE2 Enhanced capture Timer channel 6*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt7,   /* 0xFFE4 Enhanced capture Timer channel 5*/
  JUMP (CONST(uint16,OS_CONST))Pbs_Ect4Interrupt,   /* 0xFFE6 Enhanced capture Timer channel 4*/
  JUMP (CONST(uint16,OS_CONST))Pbs_Ect3Interrupt,   /* 0xFFE8 Enhanced capture Timer channel 3*/
  JUMP (CONST(uint16,OS_CONST))Pbs_Ect2Interrupt,   /* 0xFFEA Enhanced capture Timer channel 2*/
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt3,   /* 0xFFEC Enhanced capture Timer channel 1*/
  JUMP (CONST(uint16,OS_CONST))AirBag_Ect0Interrupt,   /* 0xFFEE Enhanced capture Timer channel 0*/
  JUMP (CONST(uint16,OS_CONST))Gpt_RtiInterrupt,     /* 0xFFF0 Real time Interrupt             */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt1,   /* 0xFFF2 IRQ                             */
  /* Non Mask Interrupt */
  JUMP (CONST(uint16,OS_CONST))_Startup,             /* 0xFFF4 XIRQ - External Interrupt       */
  JUMP (CONST(uint16,OS_CONST))OS_InvalidInterrupt,    /* 0xFFF6 SWI                             */
  JUMP (CONST(uint16,OS_CONST))_Startup,             /* 0xFFF8 Unimplemented instruction trap  */
  JUMP (CONST(uint16,OS_CONST))_Startup,             /* 0xFFFA COP watchdog reset              */
  JUMP (CONST(uint16,OS_CONST))_Startup,             /* 0xFFFC Clock Monitor reset             */
  JUMP (CONST(uint16,OS_CONST))_Startup              /* 0xFFFE Reset                           */
};

#if (OS_BOOTLOADER_SUPPORT == STD_ON)
  #define OS_STOP_SEC_JUMP_TBL
  #include "MemMap.h"
#else
  #define OS_STOP_SEC_VECT_TBL
  #include "MemMap.h"
#endif