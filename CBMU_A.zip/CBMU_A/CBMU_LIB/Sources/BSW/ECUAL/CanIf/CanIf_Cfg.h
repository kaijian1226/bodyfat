/*******************************************************************************
*
*  FILE
*     CanIf_Cfg.h
*
*  DESCRIPTION
*     The Header file for TFT8048-7 Driver  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*                      
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

#ifndef _CANIF_CFG_H_
#define _CANIF_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

#define CANIF_DEV_ERROR_DETECT                            STD_ON

#define CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS           33 //��̬���ķ�������add 20150805 
#define CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS          0  //��̬����

#define CANIF_INIT_NUMBER_OF_CANTXPDUIDS       (CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS + CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS)



/* Range specific Functions for precopy*/
#define CANIF_INIT_NUMBER_OF_SW_FILTER                     1  

#define CANIF_SIZE_OF_TX_BUFFER                          10


/*  Handles of send objects  */
#define CANIF_TX_CMD_STATIC_MSG                   0
#define CANIF_TX_TD_STATIC_MSG                    1
#define CANIF_TX_TEST1_STATIC_MSG                 2
#define CANIF_TX_TEST2_STATIC_MSG                 3
#define CANIF_TX_RESERVE1_STATIC_MSG              4
#define CANIF_TX_BPVP1_STATIC_MSG                 5
#define CANIF_TX_BPTP1_STATIC_MSG                 6
#define CANIF_TX_BPC1_STATIC_MSG                  7
#define CANIF_TX_BPC2_STATIC_MSG                  8
#define CANIF_TX_BPS_STATIC_MSG                   9
#define CANIF_TX_CP_STATIC_MSG                    10
#define CANIF_TX_SP1_STATIC_MSG                   11
#define CANIF_TX_SP2_STATIC_MSG                   12
#define CANIF_TX_SP3_STATIC_MSG                   13
#define CANIF_TX_BCI_STATIC_MSG                   14
#define CANIF_TX_XCP_STATIC_MSG                   15
#define CANIF_TX_CANTP_STATIC_MSG                 16
#define CANIF_TX_TPCM_STATIC_MSG                  17  //add by xyl 2015-7-15
#define CANIF_TX_TPDT_STATIC_MSG                  18  //add by xyl 2015-7-15
#define CANIF_TX_DM1_STATIC_MSG                   19  //add by xyl 2015-7-15
//add by xql for fast charge,20150709
#define CANIF_TX_BRM_STATIC_MSG                  20
#define CANIF_TX_BCP_STATIC_MSG                   21
#define CANIF_TX_BRO_STATIC_MSG                   22
#define CANIF_TX_BCL_STATIC_MSG                   23
#define CANIF_TX_BCS_STATIC_MSG                   24
#define CANIF_TX_BSM_STATIC_MSG                   25
#define CANIF_TX_BST_STATIC_MSG                   26
#define CANIF_TX_BSD_STATIC_MSG                   27
#define CANIF_TX_BEM_STATIC_MSG                   28
//#define CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS           (28)  

                                                                   
//����MINIBUS�������� ���ӱ��  add 20150805                                                
#define CANIF_TX_MB_ST_BMS_1              29  //���͵ĵ�37�� ��0��ʼ 
#define CANIF_TX_MB_ST_BMS_2              30  //
#define CANIF_TX_MB_ST_BMS_3              31  //
#define CANIF_TX_MB_ST_BMS_4              32  //
//#define CANIF_TX_ST_BMS_CHG               33  //Ŀǰû��





/*  Handles of received objects  */
//Inner CAN
#define CANIF_RX_HVA1_MSG                       0
#define CANIF_RX_HVM1_MSG                       1
#define CANIF_RX_ISO_MSG						2//???�ǲ���û����
#define CANIF_RX_M1CMT_MSG                      3
#define CANIF_RX_M1STS1_MSG                     4
#define CANIF_RX_M1STS2_MSG                     5
#define CANIF_RX_M2CMT_MSG                      6
#define CANIF_RX_M2STS1_MSG                     7
#define CANIF_RX_M2STS2_MSG                     8
#define CANIF_RX_M3CMT_MSG                      9
#define CANIF_RX_M3STS1_MSG                     10
#define CANIF_RX_M3STS2_MSG                     11
#define CANIF_RX_M4CMT_MSG                      12
#define CANIF_RX_M4STS1_MSG                     13
#define CANIF_RX_M4STS2_MSG                     14
 //��������5~12��BMU add  20150805 
#define CANIF_RX_M5CMT_MSG                      15
#define CANIF_RX_M5STS1_MSG                     16
#define CANIF_RX_M5STS2_MSG                     17
#define CANIF_RX_M6CMT_MSG                      18
#define CANIF_RX_M6STS1_MSG                     19
#define CANIF_RX_M6STS2_MSG                     20
#define CANIF_RX_M7CMT_MSG                      21
#define CANIF_RX_M7STS1_MSG                     22
#define CANIF_RX_M7STS2_MSG                     23
#define CANIF_RX_M8CMT_MSG                      24
#define CANIF_RX_M8STS1_MSG                     25
#define CANIF_RX_M8STS2_MSG                     26
#define CANIF_RX_M9CMT_MSG                      27
#define CANIF_RX_M9STS1_MSG                     28
#define CANIF_RX_M9STS2_MSG                     29
#define CANIF_RX_M10CMT_MSG                     30
#define CANIF_RX_M10STS1_MSG                    31
#define CANIF_RX_M10STS2_MSG                    32
#define CANIF_RX_M11CMT_MSG                     33
#define CANIF_RX_M11STS1_MSG                    34
#define CANIF_RX_M11STS2_MSG                    35
#define CANIF_RX_M12CMT_MSG                     36
#define CANIF_RX_M12STS1_MSG                    37
#define CANIF_RX_M12STS2_MSG                    38
#define CANIF_RX_M13CMT_MSG                     39
#define CANIF_RX_M13STS1_MSG                    40
#define CANIF_RX_M13STS2_MSG                    41
#define CANIF_RX_M14CMT_MSG                     42
#define CANIF_RX_M14STS1_MSG                    43
#define CANIF_RX_M14STS2_MSG                    44
#define CANIF_RX_M15CMT_MSG                     45
#define CANIF_RX_M15STS1_MSG                    46
#define CANIF_RX_M15STS2_MSG                    47
#define CANIF_RX_M16CMT_MSG                     48
#define CANIF_RX_M16STS1_MSG                    49
#define CANIF_RX_M16STS2_MSG                    50
#define CANIF_RX_M17CMT_MSG                     51
#define CANIF_RX_M17STS1_MSG                    52
#define CANIF_RX_M17STS2_MSG                    53
#define CANIF_RX_M18CMT_MSG                     54
#define CANIF_RX_M18STS1_MSG                    55
#define CANIF_RX_M18STS2_MSG                    56
#define CANIF_RX_M19CMT_MSG                     57
#define CANIF_RX_M19STS1_MSG                    58
#define CANIF_RX_M19STS2_MSG                    59
#define CANIF_RX_M20CMT_MSG                     60
#define CANIF_RX_M20STS1_MSG                    61
#define CANIF_RX_M20STS2_MSG                    62
#define CANIF_RX_M21CMT_MSG                     63
#define CANIF_RX_M21STS1_MSG                    64
#define CANIF_RX_M21STS2_MSG                    65
#define CANIF_RX_M22CMT_MSG                     66
#define CANIF_RX_M22STS1_MSG                    67
#define CANIF_RX_M22STS2_MSG                    68
#define CANIF_RX_M23CMT_MSG                     69
#define CANIF_RX_M23STS1_MSG                    70
#define CANIF_RX_M23STS2_MSG                    71
#define CANIF_RX_M24CMT_MSG                     72
#define CANIF_RX_M24STS1_MSG                    73
#define CANIF_RX_M24STS2_MSG                    74
#define CANIF_RX_M25CMT_MSG                     75
#define CANIF_RX_M25STS1_MSG                    76
#define CANIF_RX_M25STS2_MSG                    77  

#define CANIF_RX_M1CV1_MSG                      78
#define CANIF_RX_M1CV2_MSG                      79  
#define CANIF_RX_M1CV3_MSG                      80
#define CANIF_RX_M1CV4_MSG                      81 
#define CANIF_RX_M2CV1_MSG                      82
#define CANIF_RX_M2CV2_MSG                      83  
#define CANIF_RX_M2CV3_MSG                      84
#define CANIF_RX_M2CV4_MSG                      85 
#define CANIF_RX_M3CV1_MSG                      86
#define CANIF_RX_M3CV2_MSG                      87  
#define CANIF_RX_M3CV3_MSG                      88
#define CANIF_RX_M3CV4_MSG                      89
#define CANIF_RX_M4CV1_MSG                      90
#define CANIF_RX_M4CV2_MSG                      91  
#define CANIF_RX_M4CV3_MSG                      92
#define CANIF_RX_M4CV4_MSG                      93
#define CANIF_RX_M5CV1_MSG                      94
#define CANIF_RX_M5CV2_MSG                      95  
#define CANIF_RX_M5CV3_MSG                      96
#define CANIF_RX_M5CV4_MSG                      97
#define CANIF_RX_M6CV1_MSG                      98
#define CANIF_RX_M6CV2_MSG                      99  
#define CANIF_RX_M6CV3_MSG                      100
#define CANIF_RX_M6CV4_MSG                      101
#define CANIF_RX_M7CV1_MSG                      102
#define CANIF_RX_M7CV2_MSG                      103  
#define CANIF_RX_M7CV3_MSG                      104
#define CANIF_RX_M7CV4_MSG                      105
#define CANIF_RX_M8CV1_MSG                      106
#define CANIF_RX_M8CV2_MSG                      107  
#define CANIF_RX_M8CV3_MSG                      108
#define CANIF_RX_M8CV4_MSG                      109
#define CANIF_RX_M9CV1_MSG                      110
#define CANIF_RX_M9CV2_MSG                      111 
#define CANIF_RX_M9CV3_MSG                      112
#define CANIF_RX_M9CV4_MSG                      113 
#define CANIF_RX_M10CV1_MSG                     114
#define CANIF_RX_M10CV2_MSG                     115 
#define CANIF_RX_M10CV3_MSG                     116
#define CANIF_RX_M10CV4_MSG                     117
#define CANIF_RX_M11CV1_MSG                     118
#define CANIF_RX_M11CV2_MSG                     119
#define CANIF_RX_M11CV3_MSG                     120
#define CANIF_RX_M11CV4_MSG                     121
 
#define CANIF_RX_M12CV1_MSG                     122
#define CANIF_RX_M12CV2_MSG                     123
#define CANIF_RX_M12CV3_MSG                     124
#define CANIF_RX_M12CV4_MSG                     125

#define CANIF_RX_TESTCMD2_MSG                   126
#define CANIF_RX_XCP_MSG                        127

#define CANIF_RX_DISRELAYDEBUG_MSG              128
#define CANIF_RX_RESERVE1_MSG              129



//Veh CAN
#define CANIF_RX_CCP1_MSG                       130
#define CANIF_RX_MSP1_MSG                       131  
#define CANIF_RX_MSP3_MSG                       132  
#define CANIF_RX_VD_MSG                         133
//minibus�������ձ��� add  20150805 
#define CANIF_RX_MB_ST_VMS_3                    134  //  
#define CANIF_RX_MB_ST_MCU_2                    135  //add 20151205 
#define CANIF_RX_MB_ST_VMS_7                    136  //add 20151205
#define CANIF_RX_MB_ST_CMU_5                    137  //add 20151205



//Fast Charge CAN
#define CANIF_RX_CC_MSG                         138    // Charger Control fast charger 
#define CANIF_RX_CS_MSG                         139   // Charger Status

//add by xql for fast charge,20150709
#define CANIF_RX_CRM_MSG                        140
#define CANIF_RX_CTS_MSG                        141
#define CANIF_RX_CML_MSG                        142
#define CANIF_RX_CRO_MSG                        143
#define CANIF_RX_CCS_MSG                        144
#define CANIF_RX_CST_MSG                        145
#define CANIF_RX_CSD_MSG                        146
#define CANIF_RX_CEM_MSG                        147


//add by xyl 2015-7-21 for test
#define CANIF_RX_BCP_MSG                        148  
#define CANIF_RX_BCS_MSG                        149   
#define CANIF_RX_BRM_MSG                        150   
#define CANIF_RX_CANTP_MSG                      151  
#define CANIF_RX_TPCM_MSG                       152
#define CANIF_RX_TPDT_MSG                       153
#define CANIF_RX_DM1_MSG                        154   
//#define CANIF_INIT_NUMBER_OF_CANRXPDUIDS                  (37)

#define CANIF_INIT_NUMBER_OF_CANRXPDUIDS                155 //���ձ��������� add 20151109 

    
///////////////////////////////////////////////////////////  
              


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant declaration                         
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/ 
#endif /* #ifndef _CANIF_CFG_H_ */
