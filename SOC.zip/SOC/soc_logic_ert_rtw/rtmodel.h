/*******************************************************************************
 *  Real-Time Workshop code generated for Simulink model < soc_logic >
 *
 *  File: rtmodel.h
 *  File Creation Date: 30-Aug-2016
 *  Code generated on : Tue Aug 30 18:03:34 2016
 *  Abstraction:
 *  Notes:
 *
 *  Model Information:
 *  Model Name: soc_logic
 *  Model Version: 1.137
 *  Model Description:
 *  Creation date:	Thu Nov 06 11:14:33 2014
 *  Last Saved Modification:   Tue Aug 30 18:01:52 2016
 *
 *  (c)Copyright 2008-2014��Wuhan Eureka Control System Co., Ltd.
 *******************************************************************************/
/******************************************************************************
 *  Include files
 ******************************************************************************/
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "soc_logic.h"

/* Macros generated for backwards compatibility  */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        (NULL)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   (NULL)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif

/*****************************************************************************
 *  Defines
 *****************************************************************************/

/*****************************************************************************
 *  Data Types
 *****************************************************************************/

/*****************************************************************************
 *  Definitions
 *****************************************************************************/

/*****************************************************************************
 *  Declarations
 *****************************************************************************/

/*****************************************************************************
 *  Global Function Declaration
 *****************************************************************************/
#endif                                 /* RTW_HEADER_rtmodel_h_ */

/*======================== TOOL VERSION INFORMATION ==========================*
 * MATLAB 8.5 (R2015a)09-Feb-2015                                             *
 * Simulink 8.5 (R2015a)09-Feb-2015                                           *
 * Simulink Coder 8.8 (R2015a)09-Feb-2015                                     *
 * Embedded Coder 6.8 (R2015a)09-Feb-2015                                     *
 * Stateflow 8.5 (R2015a)09-Feb-2015                                          *
 * Fixed-Point Designer 5.0 (R2015a)09-Feb-2015                               *
 *============================================================================*/

/*======================= LICENSE IN USE INFORMATION =========================*
 * fixed_point_toolbox                                                        *
 * matlab                                                                     *
 * matlab_coder                                                               *
 * real-time_workshop                                                         *
 * rtw_embedded_coder                                                         *
 * simulink                                                                   *
 *============================================================================*/
