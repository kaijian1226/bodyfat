


/*******************************************************************************
*
*  FILE
*     PBS.h
*
*  DESCRIPTION
*      PBS module header file 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.0
*
*******************************************************************************/
#ifndef _PBS_H_
#define _PBS_H_
/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "PBS_Cfg.h"
#include "PBS_Types.h" 
#include "Mcu.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
//----------------------------------------------------------------------

 
#define PTT              (*(volatile uint8*) 0x00000240) 

#define DDRT             (*(volatile uint8*) 0x00000242)                              
#define ECT_TIOS         (*(volatile uint8*) 0x00000040)  /* Timer Input Capture/Output Compare Select; 0x00000040 */
#define ECT_TSCR1        (*(volatile uint8*) 0x00000046)  /* Timer System Control Register1; 0x00000046 */
#define ECT_TCTL1        (*(volatile uint8*) 0x00000048)  /* Timer Control Register 1; 0x00000048 */
#define ECT_TCTL2        (*(volatile uint8*) 0x00000049)  /* Timer Control Register 2; 0x00000049 */
#define ECT_TCTL3        (*(volatile uint8*) 0x0000004A)  /* Timer Control Register 3; 0x0000004A */
#define ECT_TCTL4        (*(volatile uint8*) 0x0000004B)  /* Timer Control Register 4; 0x0000004B */
#define ECT_TIE          (*(volatile uint8*) 0x0000004C)  /* Timer Interrupt Enable Register; 0x0000004C */
#define ECT_TSCR2        (*(volatile uint8*) 0x0000004D)  /* Timer System Control Register 2; 0x0000004D */
#define ECT_TFLG1        (*(volatile uint8*) 0x0000004E)  /* Main Timer Interrupt Flag 1; 0x0000004E */
#define ECT_TFLG2        (*(volatile uint8*) 0x0000004F)  /* Main Timer Interrupt Flag 2; 0x0000004F */

#define ECT_TCNT         (*(volatile uint16*) 0x00000044)  /* Timer Count Register; 0x00000044 */
#define ECT_TC0          (*(volatile uint16*) 0x00000050)  /* Timer Input Capture/Output Compare Register 0; 0x00000050 */
#define ECT_TC1          (*(volatile uint16*) 0x00000052)  /* Timer Input Capture/Output Compare Register 1; 0x00000052 */
#define ECT_TC2          (*(volatile uint16*) 0x00000054)  /* Timer Input Capture/Output Compare Register 2; 0x00000054 */
#define ECT_TC3          (*(volatile uint16*) 0x00000056)  /* Timer Input Capture/Output Compare Register 3; 0x00000056 */
#define ECT_TC4          (*(volatile uint16*) 0x00000058)  /* Timer Input Capture/Output Compare Register 4; 0x00000058 */
#define ECT_TC5          (*(volatile uint16*) 0x0000005A)  /* Timer Input Capture/Output Compare Register 5; 0x0000005A */
#define ECT_TC6          (*(volatile uint16*) 0x0000005C)  /* Timer Input Capture/Output Compare Register 6; 0x0000005C */
#define ECT_TC7          (*(volatile uint16*) 0x0000005E)  /* Timer Input Capture/Output Compare Register 7; 0x0000005E */

#define ECT_DLYCT        (*(volatile uint8*) 0x00000069)
#define ECT_PTPSR        (*(volatile uint8*) 0x0000006E)
#define ECT_PTMCPSR      (*(volatile uint8*) 0x0000006F)

#define CRGFLG_SCM_MASK                 1
#define CRGFLG_SCMIF_MASK               2
#define CRGFLG_ILAF_MASK                4
#define CRGFLG_LOCK_MASK                8
#define CRGFLG_LOCKIF_MASK              16
#define CRGFLG_LVRF_MASK                32
#define CRGFLG_PORF_MASK                64
#define CRGFLG_RTIF_MASK                128


#define ECT_TSCR1_PRNT_MASK          8
#define ECT_TSCR1_TFFCA_MASK        16
#define ECT_TSCR1_TSFRZ_MASK        32
#define ECT_TSCR1_TEN_MASK          128

#define ECT_TIE_C0I_MASK            1
#define ECT_TIE_C1I_MASK            2
#define ECT_TIE_C2I_MASK            4
#define ECT_TIE_C3I_MASK            8
#define ECT_TIE_C4I_MASK            16
#define ECT_TIE_C5I_MASK            32

#define ECT_TFLG1_C0F_MASK          1
#define ECT_TFLG1_C1F_MASK          2
#define ECT_TFLG1_C2F_MASK          4
#define ECT_TFLG1_C3F_MASK          8
#define ECT_TFLG1_C4F_MASK          16
#define ECT_TFLG1_C5F_MASK          32

#define PTT_PTT0_MASK               1
#define PTT_PTT1_MASK               2
#define PTT_PTT2_MASK               4
#define PTT_PTT3_MASK               8
#define PTT_PTT4_MASK               16
#define PTT_PTT5_MASK               32

#define PORTA_PA0_MASK              1
#define PORTA_PA1_MASK              2
#define PORTA_PA2_MASK              4
#define PORTA_PA3_MASK              8
#define PORTA_PA4_MASK              16
#define PORTA_PA5_MASK              32
#define PORTA_PA6_MASK              64
#define PORTA_PA7_MASK              128

/*******************************************************************************
* Macros  read data bits                                                           
*******************************************************************************/
#define  Std_Heart_period     0x0560     // Standard IC Heart signal 1376  4*0x0158
#define  Std_FaultReqsttime   0x54       // fault request overtime
#define  Std_FaultBitWidth    84         // Standard Fault bit width       84
#define  FaultBitWidth_Min    ( 92*Std_FaultBitWidth/100)
#define  FaultBitWidth_Max    (108*Std_FaultBitWidth/100)



#define  Heart_input  (PTT & PTT_PTT2_MASK) //PTT_PTT2   00000100
#define  Fault_input  (PTT & PTT_PTT3_MASK) //PTT_PTT3   00001000

#define  FaultRsq_1   (PTT |=  PTT_PTT1_MASK)
#define  FaultRsq_0   (PTT &=~ PTT_PTT1_MASK)

//#define  PC2_1    
//#define  PC2_0
/*******************************************************************************
* Macros  write data bits                                                           
*******************************************************************************/
#define TIE_C0I_1    (ECT_TIE |= ECT_TIE_C0I_MASK)
#define TIE_C1I_1    (ECT_TIE |= ECT_TIE_C1I_MASK)
#define TIE_C2I_1    (ECT_TIE |= ECT_TIE_C2I_MASK)
#define TIE_C3I_1    (ECT_TIE |= ECT_TIE_C3I_MASK)
#define TIE_C4I_1    (ECT_TIE |= ECT_TIE_C4I_MASK)
#define TIE_C5I_1    (ECT_TIE |= ECT_TIE_C5I_MASK)

#define TIE_C2I_0    (ECT_TIE &= ~ ECT_TIE_C2I_MASK)
#define TIE_C3I_0    (ECT_TIE &= ~ ECT_TIE_C3I_MASK)
#define TIE_C4I_0    (ECT_TIE &= ~ ECT_TIE_C4I_MASK)
#define TIE_C5I_0    (ECT_TIE &= ~ ECT_TIE_C5I_MASK)
/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern  uint16  Fault_array[20];
extern  uint8   Fault_Msg[10];
extern  uint8   Call_fault_rsq;
extern  uint8   Call_fault_rsv_over;
/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
#define   PBS_START_SEC_CODE_NEAR
//#include "MemMap.h"

#define   PBS_STOP_SEC_CODE_NEAR
//#include "MemMap.h"


extern void Pbs_Init(void);
extern void Pbs_HeartSigProcess(void);
extern void Pbs_FaultCodeProcess(void);
extern void Pbs_HeartMonitor(void);
extern void Pbs_FaultMonitor(void);

extern void AirBagSingalCapture(void);

extern  uint8    Fault_Msg[10];
extern  uint8    Fault_Msg_flag;

extern  uint8    Fault_Msg_Step_a (void);
extern  uint8    Fault_Msg_Step_b (void);
extern  uint16   Fault_Msg_Step_c (void);
extern  uint8    Fault_Msg_Step_d (void);
extern  uint8    Final_Result(void);

extern void Pbs_Task(void);
extern void Pbs_Init(void);

extern boolean pbs_heart;
extern uint8 pbs_faultCode;

#endif /* #ifndef _PBS_H_ */

      










 
  


