/*
 * File: Lookup_data.c
 *
 * Code generated for Simulink model 'Lookup'.
 *
 * Model version                  : 1.488
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Wed Jun 22 13:54:32 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Lookup.h"
#include "Lookup_private.h"

/* Constant parameters (auto storage) */
const ConstParam_Lookup Lookup_ConstP = {
  /* Computed Parameter: DLookupTable_maxIndex
   * Referenced by: '<S2>/2-D Lookup Table'
   */
  { 9U, 13U },

  /* Computed Parameter: DLookupTable_maxInd_d
   * Referenced by: '<S3>/2-D Lookup Table'
   */
  { 4U, 4U },

  /* Computed Parameter: DLookupTable_maxInd_l
   * Referenced by: '<S1>/2-D Lookup Table'
   */
  { 1U, 2U },

  /* Computed Parameter: DLookupTable_tableD
   * Referenced by: '<S2>/2-D Lookup Table'
   */
  { 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 25U, 25U, 25U, 25U, 25U, 25U,
    25U, 5U, 0U, 0U, 25U, 25U, 40U, 40U, 40U, 40U, 40U, 5U, 0U, 0U, 40U, 75U,
    100U, 215U, 215U, 215U, 75U, 5U, 0U, 0U, 40U, 75U, 100U, 215U, 215U, 215U,
    75U, 5U, 0U, 0U, 40U, 75U, 100U, 125U, 125U, 125U, 75U, 5U, 0U, 0U, 40U, 75U,
    90U, 90U, 90U, 90U, 75U, 5U, 0U, 0U, 40U, 75U, 75U, 75U, 75U, 75U, 75U, 5U,
    0U, 0U, 40U, 60U, 60U, 60U, 60U, 60U, 60U, 5U, 0U, 0U, 35U, 45U, 45U, 45U,
    45U, 45U, 45U, 5U, 0U, 0U, 30U, 30U, 30U, 30U, 30U, 30U, 30U, 5U, 0U, 0U,
    15U, 15U, 15U, 15U, 15U, 15U, 15U, 5U, 0U, 0U, 5U, 5U, 5U, 5U, 5U, 5U, 5U,
    5U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U },

  /* Computed Parameter: DLookupTable_tableDa
   * Referenced by: '<S3>/2-D Lookup Table'
   */
  { 0U, 0U, 0U, 0U, 0U, 115U, 115U, 0U, 0U, 0U, 172U, 115U, 115U, 0U, 0U, 230U,
    172U, 115U, 115U, 0U, 230U, 230U, 172U, 115U, 0U },

  /* Computed Parameter: DLookupTable_bp02Dat
   * Referenced by: '<S2>/2-D Lookup Table'
   */
  { 0U, 6554U, 8192U, 9175U, 11469U, 11796U, 11878U, 11960U, 12042U, 12124U,
    12206U, 12288U, 12370U, 12452U },

  /* Computed Parameter: DLookupTable_bp01Data
   * Referenced by: '<S3>/2-D Lookup Table'
   */
  { 0U, 70U, 80U, 90U, 100U },

  /* Computed Parameter: DLookupTable_bp01Da_d
   * Referenced by: '<S1>/2-D Lookup Table'
   */
  { 0U, 1U },

  /* Computed Parameter: DLookupTable_bp02Data
   * Referenced by: '<S1>/2-D Lookup Table'
   */
  { 0U, 1U, 2U },

  /* Computed Parameter: DLookupTable_bp01Dat
   * Referenced by: '<S2>/2-D Lookup Table'
   */
  { 10U, 34U, 36U, 40U, 45U, 50U, 78U, 82U, 85U, 86U },

  /* Computed Parameter: DLookupTable_bp02Da_c
   * Referenced by: '<S3>/2-D Lookup Table'
   */
  { 5U, 40U, 50U, 63U, 90U },

  /* Computed Parameter: DLookupTable_tableDat
   * Referenced by: '<S1>/2-D Lookup Table'
   */
  { 32U, 20U, 32U, 32U, 32U, 20U }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
