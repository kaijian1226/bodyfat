/*******************************************************************************
*
*  FILE
*     Dcm.c���ͨѶ����
*
*  DESCRIPTION
*     Source Code File for Dcm(Diagnostic Communication Manager)  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.2.1
*  MODIFY :2013-12-17
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Dcm.h"
#include "CanTp.h"
#include "Det.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/


/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
/* Context information to accompany the complete request processing */
Dcm_MsgContextType DCM_VAR      dcm_MsgContext;

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_  Dcm_NetInfoPoolType DCM_VAR  dcm_NetInfoPool;

_STATIC_  uint8 DCM_VAR dcm_PhysicalBuffer[DCM_BUFFER_LENGTH];

/* Store the service entry index for the current request */
_STATIC_  uint8 DCM_VAR    dcm_CurReqSvr;

/* Store the instance entry index for the current request */
_STATIC_  uint8 DCM_VAR    dcm_CurReqSvrInst;

/* Extra buffer for the "response pending" negative response */
_STATIC_  Dcm_MsgItemType DCM_VAR  dcm_RcrRpBuffer[3]; 

/* State machine of each received request */
_STATIC_  Dcm_ContextCtrlType DCM_VAR  dcm_ContextCtrl;

/* Flag for activating/deactivating the S1 monitoring */
_STATIC_  boolean DCM_VAR   dcm_ReloadS1TimerFlag;

/* T2 timer for response pending support for two context */
_STATIC_  uint16 DCM_VAR  dcm_T2Timer;

/* "Tester present" timer */
_STATIC_  uint16 DCM_VAR   dcm_S1Timer;

/* State machine  */
_STATIC_  Dcm_StateInfoType DCM_VAR  dcm_CurrentState;

/* Store detected diagnostic error */  
//_STATIC_ VAR(Dcm_NRCType,DCM_VAR) dcm_NegResCode;
  Dcm_NRCType DCM_VAR dcm_NegResCode;

/* Additional 2 bytes for the negative response message */
_STATIC_  Dcm_ExtNRCType DCM_VAR  dcm_ExtNegResCode;

/* flag for jump to bootloader */
_STATIC_ boolean dcm_stJmpBootloader;

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/* T2 timer macros */
#define DcmActivateT2Timer()                         (dcm_T2Timer = DCM_P2_TICKS)
#define DcmReloadT2TimerWithP3maxTime()              (dcm_T2Timer = DCM_P3MAX_TICKS)
#define DcmDeactivateT2Timer()                       (dcm_T2Timer = 0)


/* S1 timer macros */
#define DcmReloadS1Timer()                           (dcm_ReloadS1TimerFlag = TRUE)
#define DcmStartS1Timer()                            (dcm_S1Timer = DCM_S1_TICKS)
#define DcmStopS1Timer()                             (dcm_S1Timer = 0)

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
#if (DCM_DEV_ERROR_DETECT == STD_ON)             
_STATIC_ void  DCM_CODE  Dcm_CheckTableConsistency(void);
#endif
_STATIC_ void  DCM_CODE Dcm_TransmitResponse(Dcm_NetInfoPoolType* infoPool);
_STATIC_ void  DCM_CODE Dcm_TransmitRcrRp(void);
_STATIC_ void  DCM_CODE Dcm_ReleaseContext(void);
_STATIC_ void  DCM_CODE Dcm_DcmConfirmation( Dcm_NetResultType status);
_STATIC_ void  DCM_CODE Dcm_DiagServiceDispatcher(void);
_STATIC_ void  DCM_CODE Dcm_SetSesCtrlType(Dcm_StateGroupType sessionState);
_STATIC_ void  DCM_CODE Dcm_SetState(uint8 svcInstHandle);
_STATIC_ void  DCM_CODE Dcm_Timer(void);
_STATIC_ void  DCM_CODE Dcm_State(void);
_STATIC_ void  DCM_CODE Dcm_SetStateSecurityAccess(Dcm_StateGroupType securityState);

_STATIC_ uint8 DCM_CODE Dcm_FindServiceInstance(const Dcm_MsgItemType*  reqHeadPtr, Dcm_SvcHeadType const * pSvcHead);
_STATIC_ uint8 DCM_CODE Dcm_FindServiceID(Dcm_MsgItemType reqSvcId);
_STATIC_ uint8 DCM_CODE Dcm_GetSvcInstHeadExtEntrySize(const Dcm_SvcHeadType* pSvcHead);

_STATIC_ Dcm_NRCType DCM_CODE  Dcm_CheckState(const Dcm_StateInfoType* refState);

_STATIC_ Dcm_NetResultType DCM_CODE  Dcm_StartReception(void);

_STATIC_ Dcm_MsgItemType const * DCM_CODE  Dcm_GetSvcInstReqHeadExt(const Dcm_SvcHeadType* pSvcHead, uint8 svcInstAbsRef);
_STATIC_ Dcm_MsgItemType const * DCM_CODE  Dcm_GetSvcInstResHeadExt(const Dcm_SvcHeadType* pSvcHead, uint8 svcInstAbsRef);


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/
/*******************************************************************************
* NAME:             Dcm_Init
* CALLED BY:        Application
* PRECONDITIONS:    Called On system boot
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Performs time consuming init/checks of the diag module
*******************************************************************************/
 void DCM_CODE Dcm_Init(void)
{
  
  /* Check Table, Only done once at Power On*/
#if (DCM_DEV_ERROR_DETECT == STD_ON) 
  Dcm_CheckTableConsistency();
#endif
  

  dcm_NetInfoPool.Handle = DCM_INVALID_HANDLE;
  dcm_NetInfoPool.reqDataPtr = dcm_PhysicalBuffer;
  dcm_NetInfoPool.resDataPtr = dcm_PhysicalBuffer;
  dcm_NetInfoPool.resType    = RESPONSE_NONE;

  /* Deactivate and reinit the timers */
  dcm_ReloadS1TimerFlag = FALSE;
  DcmStopS1Timer();
  
  /* State Initialization */
  dcm_CurrentState.stateSession = DEFAULT_SESSION;
  dcm_CurrentState.stateSecurityAccess = ACCESS_LOCKED;
  
  /* Init the buffer state mashine */
  dcm_ContextCtrl.txState = NETWORK_OK;

  /* Interrupt context controller */
  dcm_ContextCtrl.activity = DCM_CONTEXT_IDLE;
  dcm_ContextCtrl.isContextLocked = 0;

  /* Prepare for RCR-RP negative response - the SID will be filled 
  when the T2 timer expires */
  dcm_RcrRpBuffer[0] = DCM_NEG_RES_ID;
  dcm_RcrRpBuffer[2] = DCM_E_RESPONDPENDING;
  
  /* Initialize the timer*/
  DcmDeactivateT2Timer();
  
  /* Delete the error registers */
  dcm_NegResCode = DCM_E_OK;
  dcm_ExtNegResCode = DCM_EXT_NRC_NONE;
}

/*******************************************************************************
* NAME:             Dcm_ProvideRxBuffer (Call Back Function)
* CALLED BY:        CanTp
* PRECONDITIONS:
* INPUT PARAMETERS: dataLength: request data length
* RETURN VALUES:    uint8* : buffer data Ptr
* DESCRIPTION:      Provice buffer pointer to calling function. 
*******************************************************************************/
uint8* Dcm_ProvideRxBuffer(uint16 dataLength)
{
  uint8* returnValue;
  Dcm_NetResultType netResult; 
  uint8 sid;
  
  returnValue = NULL_PTR;
  
  if (dcm_NetInfoPool.Handle == DCM_INVALID_HANDLE)
  {
    if(dataLength > DCM_BUFFER_LENGTH)
    {
    } /* discard reception */
    else
    {       
      dcm_NetInfoPool.dataLength    = dataLength;
      dcm_NetInfoPool.Handle        = DCM_USED_HANDLE;

      /* Check if context is locked */
      netResult = Dcm_StartReception();
      
      if(netResult == NETWORK_OK)
      {
        returnValue = dcm_NetInfoPool.reqDataPtr;
      }
      else
      {
        dcm_NetInfoPool.Handle = DCM_INVALID_HANDLE;
      }
    }
  }  
  return returnValue;
}

/*******************************************************************************
* NAME:             Dcm_RxIndication (Call Back Function)
* CALLED BY:        CanTp
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_NetResultType status :Network status (OK/Abort)
* RETURN VALUES:    Void
* DESCRIPTION:      Provice buffer pointer to calling function. 
*******************************************************************************/
 void DCM_CODE Dcm_RxIndication(Dcm_NetResultType status)
{
  uint8 srcAddr;
  
  /* Reception has finished */
  
  /* Clear this state  */
  dcm_ContextCtrl.activity &= (uint8)(~ DCM_CONTEXT_ACTIVE_RX_BEGIN);
  
  if (status == NETWORK_OK)
  {    
    /* Sets indication flag for cyclic task */
    dcm_ContextCtrl.activity |= DCM_CONTEXT_ACTIVE_RX_END;    

    /* Reset the channel */
    CanTp_RxInit(); 
  }
  else
  {
    Dcm_ReleaseContext();
  }
}

/*******************************************************************************
* NAME:             Dcm_TxConfirmation (Call Back Function)
* CALLED BY:        CanTp
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_NetResultType status :Network status (OK/Abort)
* RETURN VALUES:    Void
* DESCRIPTION:      Provides tha post transmission processing.. 
*******************************************************************************/
void DCM_CODE  Dcm_TxConfirmation(Dcm_NetResultType status)
{  

  switch (dcm_NetInfoPool.resType)
  {
    case RESPONSE_POSITIVE:
    case RESPONSE_NEGATIVE:
    {  
      Dcm_DcmConfirmation(status);
    }
    
    break;
    
    default:
    break;
  }
  /* Reset response type */
  dcm_NetInfoPool.resType = RESPONSE_NONE;
}

/*******************************************************************************
* NAME:             Dcm_SetNegResponse
* CALLED BY:        DcmAppl
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_NRCType errorCode: 
* RETURN VALUES:    Void
* DESCRIPTION:       
*******************************************************************************/
 void DCM_CODE  Dcm_SetNegResponse(Dcm_NRCType errorCode)
{
  /* Ignore setting an error if already set */
  if (dcm_NegResCode == DCM_E_OK)
  {
    dcm_NegResCode = errorCode;
  }
}

/*******************************************************************************
* NAME:             Dcm_SetExtNegResponse
* CALLED BY:        DcmAppl
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_NRCType errorCode:
*                   Dcm_ExtNRCType extErrorCode:
* RETURN VALUES:    Void
* DESCRIPTION:       
*******************************************************************************/
 void DCM_CODE  Dcm_SetExtNegResponse(Dcm_NRCType errorCode, Dcm_ExtNRCType extErrorCode)
{
  /* Ignore setting an error if already set */
  if (dcm_NegResCode == DCM_E_OK)
  {
    dcm_ExtNegResCode = extErrorCode;
    dcm_NegResCode = errorCode;
  }
}


/*******************************************************************************
* NAME:             Dcm_Task
* CALLED BY:        Application
* PRECONDITIONS:    Should put in a cyclic task
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Performs cyclic tasking for diagnostic purpouse.
*******************************************************************************/
 void DCM_CODE  Dcm_Task(void)
{
  Dcm_State();  //״̬����
  Dcm_Timer();  //ʱ�����
}

/*******************************************************************************
* NAME:             Dcm_DcmTesterPresent
* CALLED BY:        main handle for Tester Present Service
* PRECONDITIONS:    Should put in a cyclic task
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Keeping the tester present timer and in this way
*                   all activated services alive.
*******************************************************************************/
void DCM_CODE  Dcm_DcmTesterPresent(Dcm_MsgContextType *pMsgContext)
{
   /* check tester present format */
  if(pMsgContext->reqDataLen == 0)
  {
    /* Get out (no processing done) */
  }
  else
  {
    if(pMsgContext->reqDataLen == 1)
    {
      switch(pMsgContext->reqData[0])
      {
//        case 0x02:
//          /* Suppress pos response */
//          pMsgContext->resOnReq = 0;
//          /* Fall through */
//        case 0x01:
//          /* Get out (no processing done) */
//          break;
      case 0x00:
    	  break;
        default:
          dcm_NegResCode = DCM_E_SUBFUNCTIONNOTSUPPORTED;
          break;
      }
    }
    else
    {
      dcm_NegResCode = DCM_E_SUBFUNCTIONNOTSUPPORTED;
    }
  }
  
  Dcm_ProcessingDone();
}



/*******************************************************************************
* NAME:             Dcm_ApplEnableRxAndTx
* CALLED BY:        main handle for CommunicationControl Service
* PRECONDITIONS:     
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Enable ???? 
*******************************************************************************/
void DCM_CODE Dcm_ApplEnableRxAndTx(Dcm_MsgContextType *pMsgContext)
  {
    Dcm_ProcessingDone();
  }


/*******************************************************************************
* NAME:             Dcm_ApplDisableRxAndTx
* CALLED BY:        main handle for CommunicationControl Service
* PRECONDITIONS:     
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Disable ???? 
*******************************************************************************/
void DCM_CODE Dcm_ApplDisableRxAndTx(Dcm_MsgContextType *pMsgContext)
  {
    Dcm_ProcessingDone();
  }








/****************************************************************************
* NAME:             Dcm_GetVersionInfo
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Std_VersionInfoType *versioninfo
* RETURN VALUES:    void
* DESCRIPTION:      Service to get version information     
****************************************************************************/
void DCM_CODE  Dcm_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
  versioninfo->vendorID = DCM_VENDOR_ID;
  versioninfo->moduleID = DCM_MODULE_ID;
  versioninfo->sw_major_version = DCM_SW_MAJOR_VERSION;
  versioninfo->sw_minor_version = DCM_SW_MINOR_VERSION;
  versioninfo->sw_patch_version = DCM_SW_PATCH_VERSION;
} 

/*******************************************************************************
* NAME:             Dcm_ProcessingDone
* CALLED BY:        Dcm internally
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Depending on the current situation, provides the right action 
*******************************************************************************/
void DCM_CODE  Dcm_ProcessingDone(void)
{
  Dcm_MsgItemType*  msg; 

  uint8  resHeadLen;

  /* Make processing done safe */
  if(DCM_CONTEXT_ACTIVE_PROCESS == dcm_ContextCtrl.activity)
  {
    /* Check if there will be a real response onto the bus */
    if ((dcm_MsgContext.resOnReq) !=0 )
    {
      /* Init with the current buffer location */
      msg = dcm_NetInfoPool.reqDataPtr;
      
      /* if there was an error detection - make negative response */
      if(dcm_NegResCode != DCM_E_OK)
      {
        msg[1] = msg[0]; /* Copy the SID */
        msg[0] = DCM_NEG_RES_ID;/* Place 0x7F ...*/
        msg[2] = dcm_NegResCode;/*... and the current error code*/

        if (dcm_ExtNegResCode != DCM_EXT_NRC_NONE)
        {
          msg[3] = ((uint8)(((uint16)(dcm_ExtNegResCode))>>8));/* Place the HI uint8 of the error data */
          msg[4] = ((uint8)(dcm_ExtNegResCode));/* Place the LO uint8 of the error data */
          /* Clear the ext error for the next time */
          dcm_ExtNegResCode = DCM_EXT_NRC_NONE;
          dcm_MsgContext.resDataLen = (uint16)(DCM_NEG_RES_LENGTH + 2);
        }
        else
        {
          dcm_MsgContext.resDataLen = DCM_NEG_RES_LENGTH;     
        }
      }
      else
      {
        /* Create response SID */
        msg[0] += DCM_POS_RES_ID_OFFSET;

        /* Skip SID */
        msg++;

#if (DCM_DEV_ERROR_DETECT == STD_ON) 
        if (dcm_CurReqSvr >= DCM_SVC_HEAD_ITEMS_NUM)
        {
          Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_PROCESSDONE_ID,DCM_E_INVALID_INDEX);
        }
#endif 
        /* Fill header of response */        
        resHeadLen = (uint8)Dcm_SvcHead_C[dcm_CurReqSvr].resHeadExLen;
       
        if (resHeadLen!=0)
        {
           MemCpy2(msg, 
                Dcm_GetSvcInstResHeadExt(&Dcm_SvcHead_C[dcm_CurReqSvr],dcm_CurReqSvrInst),
                (uint16)resHeadLen);
        }
        /* Now consider the SID too */
        resHeadLen++;

        dcm_MsgContext.resDataLen += (uint16)resHeadLen;

      }

      /* Mark that from now on a single response will be sent */
      dcm_ContextCtrl.activity = DCM_CONTEXT_ACTIVE_TX_READY;

    }
    else
    {
      /* Simulate success confirmation */
      Dcm_DcmConfirmation(NETWORK_OK);
    }
  }
  else
  {
#if (DCM_DEV_ERROR_DETECT == STD_ON) 
    Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_PROCESSDONE_ID,DCM_E_NOT_ACTIVE);
#endif   
  }
}

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Dcm_CheckTableConsistency
* CALLED BY:        Dcm_Init
* PRECONDITIONS:
* INPUT PARAMETERS: Void 
* RETURN VALUES:    Void
* DESCRIPTION:      Performs check if the table relations are consistent, and
*                   if all main handler functions are not NULL_PTR.
*******************************************************************************/
#if (DCM_DEV_ERROR_DETECT == STD_ON)
 
_STATIC_  void DCM_CODE  Dcm_CheckTableConsistency(void)
{
  uint8 sidCnt;
  uint8_least idx;

  /* Check SID MAP */

  sidCnt = 0;

  for (idx = 0; idx < DCM_SID_MAP_SIZE; idx++)
  {
    if (Dcm_SidMap_C[idx] != 0xff)
    { 
      /* Will be used for checking if all sid are referenced */
      sidCnt++;

      if (Dcm_SidMap_C[idx] >= (DCM_SVC_HEAD_ITEMS_NUM - 1))
      {
        Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_CHKTBLCONSSIST_ID,DCM_E_INVALID_INDEX);
      }
    }
  }
  
  if (sidCnt != (DCM_SVC_HEAD_ITEMS_NUM - 1))
  {
    Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_CHKTBLCONSSIST_ID,DCM_E_SID_CNT);
  } 
     
  /* Check Service Head Table */
  for (idx = 0; idx < (DCM_SVC_HEAD_ITEMS_NUM - 1); idx++)
  {
    if (Dcm_SvcHead_C[idx].svcInstFirstItem >= DCM_SVC_INSTANCE_ITEMS_NUM)
    {
      Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_CHKTBLCONSSIST_ID,DCM_E_SVRHEAD);
    }
  }
  
  /* Check the dummy line content */
  if (Dcm_SvcHead_C[idx].svcInstFirstItem != DCM_SVC_INSTANCE_ITEMS_NUM) 
  {
    Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_CHKTBLCONSSIST_ID,DCM_E_SVRHEAD_DUMMY);
  }

  /* Check Function handler existence */
  for (idx = 0; idx < DCM_SVC_INSTANCE_ITEMS_NUM; idx++)
  {
    if (Dcm_SvcInst_C[idx].mainHandler == NULL_PTR) 
    {
      Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_CHKTBLCONSSIST_ID,DCM_E_HANDLE);
    }
  }
}
#endif   /* #if (DCM_DEV_ERROR_DETECT == STD_ON)  */

/*******************************************************************************
* NAME:             Dcm_StartReception
* CALLED BY:        Dcm_ProvideRxBuffer
* PRECONDITIONS:
* INPUT PARAMETERS: Void 
* RETURN VALUES:    Void
* DESCRIPTION:      Check if Context is locked.
*******************************************************************************/
_STATIC_  Dcm_NetResultType DCM_CODE  Dcm_StartReception(void)
{
  Dcm_NetResultType returnValue = NETWORK_FAILED;

  if(dcm_ContextCtrl.isContextLocked == 0)
  {
    /* Lock the buffer */
    dcm_ContextCtrl.isContextLocked = 1;
    dcm_ContextCtrl.activity |= DCM_CONTEXT_ACTIVE_RX_BEGIN;

    /* Notify the implementation */
    returnValue = NETWORK_OK;
  }
  return returnValue;
}

/*******************************************************************************
* NAME:             Dcm_TransmitResponse
* CALLED BY:        Dcm_TransmitRcrRp, Dcm_State
* PRECONDITIONS:
* INPUT PARAMETERS: Void 
* RETURN VALUES:    Void
* DESCRIPTION:      Check if Context is locked.
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_TransmitResponse(void)
{
  uint8 result;
  
  result = CanTp_Transmit(dcm_NetInfoPool.resDataPtr, dcm_NetInfoPool.dataLength);
  
  if (result == E_NOT_OK)
  { /* Cancel the transmission */
    Dcm_TxConfirmation(NETWORK_ABORT);
  }
}

/*******************************************************************************
* NAME:             Dcm_ReleaseContext
* CALLED BY:        Dcm_DcmConfirmation,Dcm_RxIndication
* PRECONDITIONS:
* INPUT PARAMETERS: Void 
* RETURN VALUES:    Void
* DESCRIPTION:      releases the RX path and manages the S1 timer
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_ReleaseContext(void)
{
  /* Deactivate the connection */
  DcmReloadS1Timer();
  /* Release context */
  dcm_ContextCtrl.isContextLocked = 0;
  /* Release the network resource */
  dcm_NetInfoPool.Handle = DCM_INVALID_HANDLE;
}

/*******************************************************************************
* NAME:             Dcm_TransmitRcrRp
* CALLED BY:        Dcm_Timer
* PRECONDITIONS:
* INPUT PARAMETERS: Void 
* RETURN VALUES:    Void
* DESCRIPTION:      Transmission of RCR-RP when T2 timer expired.
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_TransmitRcrRp(void)
{
  dcm_NetInfoPool.resDataPtr = dcm_RcrRpBuffer;
  dcm_NetInfoPool.dataLength = DCM_NEG_RES_LENGTH;
  
  Dcm_TransmitResponse();
  DcmReloadT2TimerWithP3maxTime(); 
}

/*******************************************************************************
* NAME:             Dcm_SetSesCtrlType
* CALLED BY:        Dcm_SetState
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_StateGroupType sessionState: new session state 
* RETURN VALUES:    Void
* DESCRIPTION:      set the new Session state and manage S1 timer (tester present) 
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_SetSesCtrlType(Dcm_StateGroupType sessionState)
{
  /* The new state shall not be zero */
#if (DCM_DEV_ERROR_DETECT == STD_ON) 
  if (sessionState == 0)
  {
    Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_SET_SESSION_STATE_ID,DCM_E_STATE_ZERO);
  }
#endif 

  /* S1 Timer managment */
  if(dcm_CurrentState.stateSession == DEFAULT_SESSION)
  {
    if(sessionState != DEFAULT_SESSION)
    {
      DcmStartS1Timer();
    }
  }
  else
  {
    if(sessionState == DEFAULT_SESSION)
    {
      DcmStopS1Timer();
    }
  }  
  dcm_CurrentState.stateSession = sessionState;
}

/*******************************************************************************
* NAME:             Dcm_SetStateSecurityAccess
* CALLED BY:        Dcm_SetState
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_StateGroupType securityState: new security state 
* RETURN VALUES:    Void
* DESCRIPTION:      set the new security state (locked/granted) 
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_SetStateSecurityAccess(Dcm_StateGroupType securityState)
{

#if (DCM_DEV_ERROR_DETECT == STD_ON) 
  /* The new state shall not be zero */
  if (securityState == 0)
  {
    Det_ReportError(DCM_MODULE_ID,DCM_INSTANCE_ID,DCM_API_SET_SECURITY_STATE_ID,DCM_E_STATE_ZERO);
  }
#endif 

  dcm_CurrentState.stateSecurityAccess = securityState;
}

/*******************************************************************************
* NAME:             Dcm_CheckState
* CALLED BY:        Dcm_DiagServiceDispatcher
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_StateInfoType const * refState:
*                     reference to state
* RETURN VALUES:    Dcm_NRCType: NRC
* DESCRIPTION:      Check if request service is allowed in current state
*******************************************************************************/
_STATIC_  Dcm_NRCType DCM_CODE  Dcm_CheckState(const Dcm_StateInfoType * refState)
{
  if((refState->stateSession & dcm_CurrentState.stateSession) == 0)
  {
    return DCM_E_SERVICENOTSUPPORTEDINACTIVEMODE;
  }
  if((refState->stateSecurityAccess & dcm_CurrentState.stateSecurityAccess) == 0)
  {
    return DCM_E_ACCESSDENIED;
  }
  return DCM_E_OK;
}

/*******************************************************************************
* NAME:             Dcm_SetState
* CALLED BY:        Dcm_Timer,Dcm_State 
* PRECONDITIONS:
* INPUT PARAMETERS: uint8 svcInstHandle: service instance handle
* RETURN VALUES:    Dcm_NRCType: NRC
* DESCRIPTION:      Set to new session state and security state 
*                   according to service configuration data
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_SetState(uint8 svcInstHandle)
{
  const Dcm_StateInfoType * curRefState;
  
  if(Dcm_SvcInst_C[svcInstHandle].setStateIndex != DCM_STATE_NO_TRANSITION)
  {
    curRefState = &Dcm_StateGroupTransition_C[Dcm_SvcInst_C[svcInstHandle].setStateIndex][0];
    
    SuspendAllInterrupts();
    
    if((dcm_CurrentState.stateSession & curRefState->stateSession) != 0)
    {
      Dcm_SetSesCtrlType((curRefState+1)->stateSession);
    }
    if((dcm_CurrentState.stateSecurityAccess & curRefState->stateSecurityAccess) != 0)
    {
      Dcm_SetStateSecurityAccess((curRefState+1)->stateSecurityAccess);
    }
    
    ResumeAllInterrupts();
  }
}

/*******************************************************************************
* NAME:             Dcm_GetSvcInstHeadExtEntrySize
* CALLED BY:        Dcm_GetSvcInstReqHeadExt,Dcm_FindServiceInstance
* PRECONDITIONS:
* INPUT PARAMETERS: const Dcm_SvcHeadType* pSvcHead: 
*                   Pointer to service header
* RETURN VALUES:    uint8: Entry Size
* DESCRIPTION:      Get the Service instance Head Entry Size for each service  
*                   Head entry size means the size of one service instance 
*                   occupy in Dcm_SvcInstHeadExt_C
*******************************************************************************/
_STATIC_  uint8 DCM_CODE  Dcm_GetSvcInstHeadExtEntrySize(const Dcm_SvcHeadType* pSvcHead)
{
  uint8 retVal;
  
  if (pSvcHead->isReqHeadExtEchoed != 0)
  {
    retVal = pSvcHead->reqHeadExLen;
  }else
  {
    retVal = pSvcHead->reqHeadExLen + pSvcHead->resHeadExLen;
  }
  return (retVal);
}

/*******************************************************************************
* NAME:             Dcm_GetSvcInstResHeadExt
* CALLED BY:        Dcm_GetSvcInstReqHeadExt,Dcm_FindServiceInstance
* PRECONDITIONS:
* INPUT PARAMETERS: const Dcm_SvcHeadType* pSvcHead: 
*                   Pointer to service header
*                   uint8 svcInstAbsRef: service instance number
* RETURN VALUES:    const Dcm_MsgItemType*: Pointer to Response header ext
* DESCRIPTION:      
*******************************************************************************/
_STATIC_  const Dcm_MsgItemType* DCM_CODE  Dcm_GetSvcInstResHeadExt \
  (const Dcm_SvcHeadType* pSvcHead, uint8 svcInstAbsRef)
{
  uint16 offset = 0;
  if(pSvcHead->isReqHeadExtEchoed == 0) 
  {
    offset = pSvcHead->reqHeadExLen;
  }  
  return (Dcm_GetSvcInstReqHeadExt(pSvcHead, svcInstAbsRef) + offset);
}

/*******************************************************************************
* NAME:             Dcm_GetSvcInstReqHeadExt
* CALLED BY:        Dcm_GetSvcInstResHeadExt
* PRECONDITIONS:
* INPUT PARAMETERS: const Dcm_SvcHeadType* pSvcHead: 
*                   Pointer to service header
*                   uint8 svcInstAbsRef: service instance number
* RETURN VALUES:    const Dcm_MsgItemType*: Pointer to Response header ext
* DESCRIPTION:      Get the service instance header in Dcm_SvcInstHeadExt_C
*******************************************************************************/
_STATIC_  const Dcm_MsgItemType* DCM_CODE  Dcm_GetSvcInstReqHeadExt(const Dcm_SvcHeadType* pSvcHead, uint8 svcInstAbsRef)
{
  uint16 offset = Dcm_GetSvcInstHeadExtEntrySize(pSvcHead);
  offset *= (uint16)(svcInstAbsRef - pSvcHead->svcInstFirstItem);

  return (&Dcm_SvcInstHeadExt_C[pSvcHead->svcInstHeadExtFirstItem + offset]);
}

/*******************************************************************************
* NAME:             Dcm_FindServiceInstance
* CALLED BY:        Dcm_GetSvcInstResHeadExt
* PRECONDITIONS:
* INPUT PARAMETERS: const Dcm_MsgItemType*  reqHeadPtr: 
*                   Pointer to current request header
*                   const Dcm_SvcHeadType* pSvcHead:
*                   Pointer to service header configuration data
* RETURN VALUES:    uint8: service instance Handle
* DESCRIPTION:      Linear search for service instance
*******************************************************************************/
_STATIC_  uint8 DCM_CODE  Dcm_FindServiceInstance \
(const Dcm_MsgItemType*  reqHeadPtr, const Dcm_SvcHeadType* pSvcHead)
{
  Dcm_SvcInstHeadExtIndexType idx;
  uint8        reqSvcInstHandle;
  uint8        offset;
  uint8        currColFound;
  uint8        incStep;
  boolean        isEqual;
 
  incStep = Dcm_GetSvcInstHeadExtEntrySize(pSvcHead);

  /* Mark subserviceInstance handle as invalid */
  reqSvcInstHandle = DCM_INVALID_SVC_INST_HANDLE;
  
  
  offset = 0;

  for(idx = pSvcHead->svcInstHeadExtFirstItem; 
      idx < (pSvcHead + 1)->svcInstHeadExtFirstItem;
      idx+= incStep)
  {
    currColFound = 0;
    do
    {
      isEqual = (boolean)(reqHeadPtr[currColFound] == Dcm_SvcInstHeadExt_C[idx + currColFound]);
      currColFound++;
    }
    while ((currColFound < pSvcHead->reqHeadExLen)&&(isEqual != 0));

    
    if(isEqual != 0)
    {
      reqSvcInstHandle = (uint8)(offset + pSvcHead->svcInstFirstItem);
      break;
    }

    /* Increment the reference */
    offset++;
  }

  return reqSvcInstHandle;
}

/*******************************************************************************
* NAME:             Dcm_FindServiceID
* CALLED BY:        Dcm_ProvideRxBuffer,Dcm_DiagServiceDispatcher
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgItemType reqSvcId: Request service ID
* RETURN VALUES:    uint8: the Service ID index in Dcm_SvcHead_C
* DESCRIPTION:      Search a service ID.
*******************************************************************************/
_STATIC_  uint8 DCM_CODE  Dcm_FindServiceID(Dcm_MsgItemType reqSvcId)
{
  uint8 result;  
  uint8 byteVar;
 
  result = DCM_INVALID_SVC_HANDLE;
  byteVar = 0;
  
  /* check if it is in the correct range (0x00-0x3f or 0x80-bf => bit2 must be 0) */
  /* check if it is not bigger that the maximum defined SID */
  if (((reqSvcId & DCM_POS_RES_ID_OFFSET) == 0)&&
       (reqSvcId <= DCM_MAX_REQ_SID))
  {
    /* find in which response range is the request. */
    if ((reqSvcId & 0x80) != 0)
    {
      byteVar = DCM_POS_RES_ID_OFFSET;
    } 
    
    result = Dcm_SidMap_C[reqSvcId - byteVar];
  }
  return result;
}

/*******************************************************************************
* NAME:             Dcm_DiagServiceDispatcher
* CALLED BY:        Dcm_State
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Provides the kernel of the diagnostic
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_DiagServiceDispatcher(void)
{
  /* Code optimization */
  Dcm_MsgItemType*  msg;

  msg = dcm_NetInfoPool.reqDataPtr;
  
  /* Set default response  */
  dcm_MsgContext.resOnReq = DCM_DEFAULT_RES_ON_REQ;

  /* Request Length must not be zero */
  if(dcm_MsgContext.reqDataLen != 0)
  {
    /* Search service ID */
    dcm_CurReqSvr = Dcm_FindServiceID(msg[0]);
    
    /* Check if service is supported */
    if(dcm_CurReqSvr < DCM_INVALID_SVC_HANDLE)
    {
      const Dcm_SvcHeadType* refDescSvcHead;

      refDescSvcHead = &Dcm_SvcHead_C[dcm_CurReqSvr];

      /* set service head default response */
      dcm_MsgContext.resOnReq = refDescSvcHead->resOnReq;
      
      /* Service related checks  */
      /* Service ID session check if support in current session?  */
      if ((refDescSvcHead->checkSessionState & dcm_CurrentState.stateSession) != 0)
      {
        /* check the request data length, must at least the request header length */
        if(dcm_MsgContext.reqDataLen >= (refDescSvcHead->reqHeadExLen + 1))
        {

          msg++;
          
          /*  Search service instance  */
          if(refDescSvcHead->reqHeadExLen != 0)
          {
            /* Get index from Dcm_SvcHead_C[DCM_SVC_HEAD_ITEMS_NUM].svcInstHeadExtFirstItem */
            dcm_CurReqSvrInst = Dcm_FindServiceInstance(msg, refDescSvcHead);
          }
          else
          {
            dcm_CurReqSvrInst = refDescSvcHead->svcInstFirstItem;
          }

          /* Check if Service Instance is valid*/
          if(dcm_CurReqSvrInst < DCM_INVALID_SVC_INST_HANDLE)
          {
            const Dcm_SvcInstType* refDescSvcInst;
   
            refDescSvcInst = &Dcm_SvcInst_C[dcm_CurReqSvrInst];
            
            /* Set the SvcInst default state for the response sending */
            dcm_MsgContext.resOnReq = refDescSvcInst->resOnReq;

            /* Service instance related checks */

            /* If the table stored length is not zero (zero means don't preform check )- 
            check it for matching with the request length */
            if((refDescSvcInst->reqLen == 0) || (refDescSvcInst->reqLen == dcm_MsgContext.reqDataLen))
            {
              /* Generated state checks */
              dcm_NegResCode = Dcm_CheckState(&(refDescSvcInst->checkState));

              /* If any error was detected - go out */
              if(dcm_NegResCode == DCM_E_OK)
              {
                /* Prepare the application information */
                dcm_MsgContext.reqData    = (Dcm_MsgItemType* )(msg + refDescSvcHead->reqHeadExLen);
                /* This is the extension of the response header (the header without the resposne SID), so for the complete length - add 1 */
                dcm_MsgContext.resData    = (Dcm_MsgItemType* )(msg + refDescSvcHead->resHeadExLen);
                /* The length contains up to now the whole request length, so just substract the header length */
                dcm_MsgContext.reqDataLen -= (uint16)(refDescSvcHead->reqHeadExLen + 1);
                /* Zero the response length - optimization for no data responses */
                dcm_MsgContext.resDataLen = 0;

                /*  P2 timer management    */
                if((dcm_MsgContext.resOnReq) != 0)
                {
                  DcmActivateT2Timer();
                }

                /* Call the main handler function */
                refDescSvcInst->mainHandler(&dcm_MsgContext);

                /* Skip the processing done call if let the application decide when */
                return; 
              }
            }
            else
            {
              //dcm_NegResCode = DCM_E_SUBFUNCTIONNOTSUPPORTED;
              /* Data Length exceed the expect length */
              dcm_NegResCode = DCM_E_INCORRECTREQUESTLENGTH;
            }
          }
          else
          {
            dcm_NegResCode = DCM_E_SUBFUNCTIONNOTSUPPORTED;
          }
        }
        else
        {
          //dcm_NegResCode = DCM_E_SUBFUNCTIONNOTSUPPORTED;
          /* Data Length litter than expection */
          dcm_NegResCode = DCM_E_INCORRECTREQUESTLENGTH;
        }
      }
      else
      {
        dcm_NegResCode = DCM_E_SERVICENOTSUPPORTEDINACTIVEMODE;
      }  
    }
    else
    {
      dcm_NegResCode = DCM_E_SERVICENOTSUPPORTED;
    }
  }
  else
  {
    /* Set any error type (no real response will be sent so never mind what error it is */
    dcm_NegResCode = (Dcm_NRCType)(~DCM_E_OK);
    /* no response must be sent */
    dcm_MsgContext.resOnReq = 0;
  }

  /* flush the current request */
  Dcm_ProcessingDone();  
}

/*******************************************************************************
* NAME:             Dcm_DcmConfirmation
* CALLED BY:        Dcm_TxConfirmation, Dcm_ProcessingDone
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Dcm_NetResultType status: Network result (OK/Abort)
* DESCRIPTION:      Provides finalizing actions
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_DcmConfirmation(Dcm_NetResultType status)
{ 

  /* Deactivate the RCR-RP timer (for no response requests) */
  DcmDeactivateT2Timer();

  dcm_ContextCtrl.txState = status;
  /* Activate the post processing */
  dcm_ContextCtrl.activity = DCM_CONTEXT_ACTIVE_POST_PROCESS;

  /* Release context for next requests */
  Dcm_ReleaseContext();
}

/*******************************************************************************
* NAME:             Dcm_Timer
* CALLED BY:        Dcm_Task
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Performs cyclic tasking for diagnostic purpouse.
*******************************************************************************/
_STATIC_  void DCM_CODE  Dcm_Timer(void)
{


  /* Tester Timeout  */
  if(dcm_S1Timer != 0)
  {
    if(dcm_ReloadS1TimerFlag == TRUE)
    {
      dcm_ReloadS1TimerFlag = FALSE;
      DcmStartS1Timer();
    }
    
    /* Check for currently active requests to decide to decrement or not the counter */
    if(dcm_ContextCtrl.activity == DCM_CONTEXT_IDLE)
    {
      dcm_S1Timer--;
      if(dcm_S1Timer == 0)
      {
        /* Deactivate the timer */
        DcmStopS1Timer();
        /* Simulate the same behavior as it would be done by requesting
         * default session */
        Dcm_SetState(DCM_DEFAULT_SESSION_SVR_ENTRY);
      }
    }
  }

  /* Only during request processing */
  /* RCR-RP only during processing */
  if((dcm_ContextCtrl.activity & (DCM_CONTEXT_ACTIVE_PROCESS|DCM_CONTEXT_ACTIVE_PROCESS_END)) != 0)
  {
    /* TimeoutT2 unequal to 0 means running */
    if(dcm_T2Timer != 0) 
    { 
      dcm_T2Timer--;
      /*Timeout reached?*/
      if(dcm_T2Timer == 0) 
      { 
        /* Check if the TX channel is free */
        if(dcm_NetInfoPool.resType == RESPONSE_NONE)
        {
          /* reserve the TX channel for single frame */
          dcm_NetInfoPool.resType = RESPONSE_NEGATIVE_RCR_RP;        
          Dcm_TransmitRcrRp();
        }
        else
        {
          dcm_T2Timer = 1;
        }
      }     
    }
  }
}

/*******************************************************************************
* NAME:             Dcm_State
* CALLED BY:        Dcm_Task
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Performs cyclic tasking for diagnostic purpouse.
*******************************************************************************/
_STATIC_  void DCM_CODE Dcm_State(void)
{
  /* Check pending post-processing */
  if(dcm_ContextCtrl.activity != DCM_CONTEXT_IDLE)       
  {
    /*  Post processing task - BEGIN  */
    if((dcm_ContextCtrl.activity & DCM_CONTEXT_ACTIVE_POST_PROCESS) != 0)
    {
      uint8 postProcessState;

      SuspendAllInterrupts();
      dcm_ContextCtrl.activity &= (uint8)(~DCM_CONTEXT_ACTIVE_POST_PROCESS);
      ResumeAllInterrupts();
     
      /* By default - ok */
      postProcessState = DCM_POST_HANDLE_STATE_OK;

      /* Check the status of the response */
      if(dcm_ContextCtrl.txState != NETWORK_OK)
      {
        /* Clear ok, set error type */
        postProcessState = DCM_POST_HANDLE_STATE_TX_FAILED;
      }

      /* Add type of the response */
      if(dcm_NegResCode != DCM_E_OK)
      {
        /* Clear ok, set error type */
        postProcessState &= (uint8)(~DCM_POST_HANDLE_STATE_OK);
        postProcessState |= DCM_POST_HANDLE_STATE_NR_SENT;
      }
      
      /*  Post processing task - END  */

      /* Called only in successfully finished request processing */
      if((postProcessState & DCM_POST_HANDLE_STATE_OK) != 0)
      {
        /* Modify state */
        Dcm_SetState(dcm_CurReqSvrInst);
       
        /* Judge if programming session is requested and security access is okay */
        if ((dcm_CurrentState.stateSession == PROGRAMMING_SESSION))
        {
          dcm_stJmpBootloader = TRUE; 
          /* 
          XGATE_Disable(); 
          JumpToEXB();
          */ 
        }          
      }
    }

    /* Rx processing task */
    if(dcm_ContextCtrl.activity == DCM_CONTEXT_ACTIVE_RX_END)
    {
      /* Switch to process state */
      dcm_ContextCtrl.activity = DCM_CONTEXT_ACTIVE_PROCESS;

      /* Copy the SID for RCR-RP response. */
      dcm_RcrRpBuffer[1] = *dcm_NetInfoPool.reqDataPtr;
        
      /* Stores the length */
      dcm_MsgContext.reqDataLen = dcm_NetInfoPool.dataLength;

      /* Clear the error code */
      dcm_NegResCode = DCM_E_OK;
      /* Process the dispatcher */
      Dcm_DiagServiceDispatcher();  
    }
    
    /*  Tx processing task */
    if(dcm_ContextCtrl.activity == DCM_CONTEXT_ACTIVE_TX_READY)
    {
      /* Check if the TX channel is free */
      if(dcm_NetInfoPool.resType == RESPONSE_NONE)
      {
        /* Deactivate the RCR-RP timer */
        DcmDeactivateT2Timer();

        /* Set the new state of CANdesc */
        dcm_ContextCtrl.activity = DCM_CONTEXT_ACTIVE_TX;

        /* reserve the TX channel and set the confirmation type to be expected */
        dcm_NetInfoPool.dataLength = dcm_MsgContext.resDataLen;

        /* Check if the negative response code is set */
        if (dcm_NegResCode == DCM_E_OK)
        {
          dcm_NetInfoPool.resType = RESPONSE_POSITIVE;
        }else
        {
          dcm_NetInfoPool.resType = RESPONSE_NEGATIVE;
        }
        dcm_NetInfoPool.resDataPtr = dcm_NetInfoPool.reqDataPtr;

        Dcm_TransmitResponse();
      }  
    }
  }

}
