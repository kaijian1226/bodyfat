/*
 * File: rt_sys_BMS_MON_3.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rt_sys_BMS_MON_3.h"

/* Include model header file for global data */
#include "BMS_MON.h"
#include "BMS_MON_private.h"

/*
 * Output and update for action system:
 *    '<S28>/Switch Case Action Subsystem'
 *    '<S28>/Switch Case Action Subsystem1'
 *    '<S28>/Switch Case Action Subsystem2'
 *    '<S49>/Switch Case Action Subsystem'
 *    '<S49>/Switch Case Action Subsystem1'
 *    '<S49>/Switch Case Action Subsystem2'
 *    '<S68>/Switch Case Action Subsystem'
 *    '<S68>/Switch Case Action Subsystem1'
 *    '<S68>/Switch Case Action Subsystem2'
 *    '<S102>/Switch Case Action Subsystem'
 *    ...
 */
void BMS_M_SwitchCaseActionSubsystem(uint8_T rtu_In1, uint8_T *rty_Out1)
{
  /* Inport: '<S31>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
