/*******************************************************************************
*
*  FILE
*     Xcp_Appl.h
*
*  DESCRIPTION
*     The Application Header file for Xcp Module
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

#ifndef _XCP_APPL_H_
#define _XCP_APPL_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Xcp_Types.h"
#include "Xcp_Appl_Cfg.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* resources for seed&key mechanism */
#define XCP_SEED_KEY_RESOURCE_CAL_PAG             0x01
#define XCP_SEED_KEY_RESOURCE_DAQ                 0x04
#define XCP_SEED_KEY_RESOURCE_STIM                0x08
#define XCP_SEED_KEY_RESOURCE_PGM                 0x10

/* modes for switching a calibration page */
#define XCP_CAL_PAGE_MODE_ECU                     0x01
#define XCP_CAL_PAGE_MODE_XCP                     0x02
#define XCP_CAL_PAGE_MODE_ALL                     0x80

#define XCP_MEMORY_ACCESS_TYPE_READ               1
#define XCP_MEMORY_ACCESS_TYPE_WRITE              2
#define XCP_MEMORY_ACCESS_TYPE_PGM                3
#define XCP_MEMORY_ACCESS_TYPE_DAQ_STIM           4
#define XCP_MEMORY_ACCESS_TYPE_CAL_PAGE_STIM      5


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern VAR(Xcp_EcuPageOffsetType,XCP_VAR) ecu_page_offset;
/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,XCP_CODE) Xcp_ApplInit(void);
extern FUNC(Xcp_MtaPtrType,XCP_CODE) Xcp_ApplGetAddressPtr(uint32 address, uint8 extension);
extern FUNC(Std_ReturnType,XCP_CODE) Xcp_ApplMemAccessChk(uint32 address, uint8 extension, uint32 length, uint8 type);
extern FUNC(uint8,XCP_CODE) Xcp_ApplGetSeed(uint8* seed, uint8 resource);
extern FUNC(Std_ReturnType,XCP_CODE) Xcp_ApplUnlock(uint8* seed, uint8* key, uint8 resource);
extern FUNC(Std_ReturnType,XCP_CODE) Xcp_ApplSetCalPage(uint8 segment, uint8 page, uint8 mode);
extern FUNC(uint8,XCP_CODE) Xcp_ApplGetCalPage(uint8 segment, uint8 mode);


#endif /* #ifndef _XCP_APPL_H_ */









