/*
 * File: BMS_MON.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "BMS_MON.h"
#include "BMS_MON_private.h"

/* Exported block signals */
uint8_T Soc_St;                        /* '<S335>/Merge2' */
uint8_T Pv_St;                         /* '<S315>/Merge2' */
uint8_T PC_fc_St;                      /* '<S277>/Merge2' */
uint8_T PC_dsg_St;                     /* '<S258>/Merge2' */

/* Exported block states */
uint8_T CV_St;                         /* '<S2>/Data Store Memory' */
uint8_T CTMaxFc_St;                    /* '<S2>/Data Store Memory5' */
uint8_T PC_chrg_St;                    /* '<S3>/Data Store Memory' */
uint8_T ISO_St;                        /* '<S3>/Data Store Memory1' */
uint8_T FCCur_St;                      /* '<S3>/Data Store Memory2' */
uint8_T SOC_St;                        /* '<S3>/Data Store Memory5' */

/* Block signals (auto storage) */
BlockIO_BMS_MON BMS_MON_B;

/* Block states (auto storage) */
D_Work_BMS_MON BMS_MON_DWork;

/* Real-time model */
RT_MODEL_BMS_MON BMS_MON_M_;
RT_MODEL_BMS_MON *const BMS_MON_M = &BMS_MON_M_;

/*
 * Output and update for action system:
 *    '<S5>/High1'
 *    '<S5>/High2'
 *    '<S5>/High4'
 *    '<S5>/High5'
 *    '<S6>/High1'
 *    '<S6>/High2'
 *    '<S229>/High1'
 *    '<S229>/High2'
 *    '<S229>/High3'
 *    '<S229>/High4'
 *    ...
 */
void BMS_MON_High1(uint8_T rtu_H1, uint8_T rtu_H2, uint8_T *rty_H1_St, uint8_T
                   *rty_H2_St)
{
  /* Inport: '<S206>/H1' */
  *rty_H1_St = rtu_H1;

  /* Inport: '<S206>/H2' */
  *rty_H2_St = rtu_H2;
}

/*
 * Output and update for action system:
 *    '<S5>/High3'
 *    '<S5>/High6'
 *    '<S6>/Normal'
 *    '<S229>/Normal'
 *    '<S229>/High7'
 *    '<S229>/High8'
 *    '<S230>/Normal'
 */
void BMS_MON_High3(uint8_T rtu_H1, uint8_T *rty_H1_St, uint8_T *rty_H2_St)
{
  /* Inport: '<S208>/H1' */
  *rty_H1_St = rtu_H1;

  /* Inport: '<S208>/H2' */
  *rty_H2_St = rtu_H1;
}

/*
 * Output and update for action system:
 *    '<S5>/Low1'
 *    '<S5>/Low2'
 *    '<S6>/Low1'
 *    '<S6>/Low2'
 *    '<S6>/Low3'
 *    '<S6>/Low4'
 *    '<S228>/Low1'
 *    '<S228>/Low2'
 *    '<S230>/Low1'
 *    '<S230>/Low2'
 *    ...
 */
void BMS_MON_Low1(uint8_T rtu_L1, uint8_T rtu_L2, uint8_T *rty_L1_St, uint8_T
                  *rty_L2_St)
{
  /* Inport: '<S212>/L1' */
  *rty_L1_St = rtu_L1;

  /* Inport: '<S212>/L2' */
  *rty_L2_St = rtu_L2;
}

/*
 * Output and update for action system:
 *    '<S5>/Low3'
 *    '<S6>/Low5'
 *    '<S6>/Normal '
 *    '<S228>/Low3'
 *    '<S230>/Low5'
 *    '<S231>/Normal'
 */
void BMS_MON_Low3(uint8_T rtu_L1, uint8_T *rty_L1_St, uint8_T *rty_L2_St)
{
  /* Inport: '<S214>/L1' */
  *rty_L1_St = rtu_L1;

  /* Inport: '<S214>/L2' */
  *rty_L2_St = rtu_L1;
}

/*
 * Output and update for action system:
 *    '<S5>/SC Start Check'
 *    '<S5>/SC During Check'
 */
void BMS_MON_SCStartCheck(uint8_T rtu_In1, uint8_T rtu_In2, uint8_T *rty_Out1,
  uint8_T *rty_Out2)
{
  /* Inport: '<S216>/In1' */
  *rty_Out1 = rtu_In1;

  /* Inport: '<S216>/In2' */
  *rty_Out2 = rtu_In2;
}

/* Model step function */
void BMS_MON_step(void)
{
  /* local block i/o variables */
  uint8_T rtb_DataTypeConversion1;
  uint8_T rtb_Merge;
  boolean_T rtb_Compare;
  uint8_T rtb_Merge1_j;

  /* Outputs for Atomic SubSystem: '<S4>/CvMon' */
  BMS_MON_CvMon();

  /* End of Outputs for SubSystem: '<S4>/CvMon' */

  /* DataStoreWrite: '<S2>/Data Store Write' */
  CV_St = BMS_MON_B.Merge2_g;

  /* Outputs for Atomic SubSystem: '<S4>/PtMon' */
  BMS_MON_PtMon();

  /* End of Outputs for SubSystem: '<S4>/PtMon' */

  /* DataStoreWrite: '<S2>/Data Store Write1' */
  CTMaxFc_St = BMS_MON_B.Merge2_h;

  /* SwitchCase: '<S5>/Switch Case' incorporates:
   *  Constant: '<S5>/Constant'
   *  Constant: '<S5>/Constant5'
   */
  switch ((int32_T)BMS_MON_B.Merge_o) {
   case 1L:
    /* Outputs for IfAction SubSystem: '<S5>/High1' incorporates:
     *  ActionPort: '<S206>/Action Port'
     */
    BMS_MON_High1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/High1' */
    break;

   case 3L:
    /* Outputs for IfAction SubSystem: '<S5>/High2' incorporates:
     *  ActionPort: '<S207>/Action Port'
     */
    BMS_MON_High1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/High2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S5>/High3' incorporates:
     *  ActionPort: '<S208>/Action Port'
     */
    BMS_MON_High3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/High3' */
    break;
  }

  /* End of SwitchCase: '<S5>/Switch Case' */

  /* DataTypeConversion: '<S5>/Data Type Conversion3' incorporates:
   *  Constant: '<S5>/Constant1'
   *  RelationalOperator: '<S5>/Relational Operator1'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH1' */
  Dem_SetError( (uint16_T)DTC_IDX_DISCHARGE_CT_HIGH_CLASS1_ID21, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S5>/Data Type Conversion1' incorporates:
   *  Constant: '<S5>/Constant7'
   *  RelationalOperator: '<S5>/Relational Operator2'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH2' */
  Dem_SetError( (uint16_T)DTC_IDX_DISCHARGE_CT_HIGH_CLASS2_ID22, (uint8_T)
               rtb_DataTypeConversion1);

  /* SwitchCase: '<S5>/Switch Case1' incorporates:
   *  Constant: '<S5>/Constant13'
   *  Constant: '<S5>/Constant6'
   */
  switch ((int32_T)BMS_MON_B.Merge3) {
   case 2L:
    /* Outputs for IfAction SubSystem: '<S5>/Low1' incorporates:
     *  ActionPort: '<S212>/Action Port'
     */
    BMS_MON_Low1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/Low1' */
    break;

   case 4L:
    /* Outputs for IfAction SubSystem: '<S5>/Low2' incorporates:
     *  ActionPort: '<S213>/Action Port'
     */
    BMS_MON_Low1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/Low2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S5>/Low3' incorporates:
     *  ActionPort: '<S214>/Action Port'
     */
    BMS_MON_Low3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/Low3' */
    break;
  }

  /* End of SwitchCase: '<S5>/Switch Case1' */

  /* DataTypeConversion: '<S5>/Data Type Conversion2' incorporates:
   *  Constant: '<S5>/Constant9'
   *  RelationalOperator: '<S5>/Relational Operator3'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH3' */
  Dem_SetError( (uint16_T)DTC_IDX_DISCHARGE_CT_LOW_CLASS1_ID23, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S5>/Data Type Conversion4' incorporates:
   *  Constant: '<S5>/Constant12'
   *  RelationalOperator: '<S5>/Relational Operator4'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH4' */
  Dem_SetError( (uint16_T)DTC_IDX_DISCHARGE_CT_LOW_CLASS1_ID24, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
   *  Constant: '<S5>/Constant22'
   *  RelationalOperator: '<S5>/Relational Operator'
   */
  rtb_Merge = (uint8_T)(BMS_MON_B.Merge1 == SRC_HIGH_DEF);

  /* SwitchCase: '<S5>/Switch Case2' incorporates:
   *  Constant: '<S5>/Constant14'
   *  DataStoreRead: '<S5>/Data Store Read'
   */
  switch ((int32_T)com_BPSSelfChkSts) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S5>/SC Start Check' incorporates:
     *  ActionPort: '<S216>/Action Port'
     */
    BMS_MON_SCStartCheck(rtb_Merge, SRC_NON_DEF, &BMS_MON_B.Merge4,
                         &BMS_MON_B.Merge5);

    /* End of Outputs for SubSystem: '<S5>/SC Start Check' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S5>/SC During Check' incorporates:
     *  ActionPort: '<S215>/Action Port'
     */
    BMS_MON_SCStartCheck(SRC_NON_DEF, rtb_Merge, &BMS_MON_B.Merge4,
                         &BMS_MON_B.Merge5);

    /* End of Outputs for SubSystem: '<S5>/SC During Check' */
    break;
  }

  /* End of SwitchCase: '<S5>/Switch Case2' */

  /* DataTypeConversion: '<S5>/Data Type Conversion6' incorporates:
   *  Constant: '<S5>/Constant30'
   *  RelationalOperator: '<S5>/Relational Operator6'
   */
  rtb_DataTypeConversion1 = (uint8_T)(BMS_MON_B.Merge4 != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH6' */
  Dem_SetError( (uint16_T)DTC_IDX_SC_START_CT_HIGH_CLASS1_ID26, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S5>/Data Type Conversion9' incorporates:
   *  Constant: '<S5>/Constant25'
   *  RelationalOperator: '<S5>/Relational Operator9'
   */
  rtb_DataTypeConversion1 = (uint8_T)(BMS_MON_B.Merge5 != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH8' */
  Dem_SetError( (uint16_T)DTC_IDX_SC_CT_HIGH_CLASS1_ID27, (uint8_T)
               rtb_DataTypeConversion1);

  /* Switch: '<S5>/Switch' incorporates:
   *  Constant: '<S5>/Constant15'
   *  Constant: '<S5>/Constant31'
   *  Constant: '<S5>/Constant32'
   *  DataStoreRead: '<S5>/Data Store Read1'
   *  DataTypeConversion: '<S5>/Data Type Conversion7'
   *  RelationalOperator: '<S5>/Relational Operator15'
   *  RelationalOperator: '<S5>/Relational Operator8'
   */
  if (com_BPSSelfChkSts == 1) {
    rtb_DataTypeConversion1 = (uint8_T)(BMS_MON_B.Merge4_i == SRC_LOW_DEF);
  } else {
    rtb_DataTypeConversion1 = SRC_NON_DEF;
  }

  /* End of Switch: '<S5>/Switch' */

  /* DataTypeConversion: '<S5>/Data Type Conversion8' incorporates:
   *  Constant: '<S5>/Constant17'
   *  RelationalOperator: '<S5>/Relational Operator7'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_DataTypeConversion1 != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH7' */
  Dem_SetError( (uint16_T)DTC_IDX_SC_CT_LOW_CLASS1_ID25, (uint8_T)
               rtb_DataTypeConversion1);

  /* SwitchCase: '<S5>/Switch Case3' incorporates:
   *  Constant: '<S5>/Constant18'
   *  Constant: '<S5>/Constant28'
   */
  switch ((int32_T)BMS_MON_B.Merge2_h) {
   case 1L:
    /* Outputs for IfAction SubSystem: '<S5>/High4' incorporates:
     *  ActionPort: '<S209>/Action Port'
     */
    BMS_MON_High1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/High4' */
    break;

   case 3L:
    /* Outputs for IfAction SubSystem: '<S5>/High5' incorporates:
     *  ActionPort: '<S210>/Action Port'
     */
    BMS_MON_High1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/High5' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S5>/High6' incorporates:
     *  ActionPort: '<S211>/Action Port'
     */
    BMS_MON_High3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S5>/High6' */
    break;
  }

  /* End of SwitchCase: '<S5>/Switch Case3' */

  /* DataTypeConversion: '<S5>/Data Type Conversion11' incorporates:
   *  Constant: '<S5>/Constant29'
   *  RelationalOperator: '<S5>/Relational Operator12'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH11' */
  Dem_SetError( (uint16_T)DTC_IDX_FC_CT_HIGH_CLASS1_ID30, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S5>/Data Type Conversion10' incorporates:
   *  Constant: '<S5>/Constant35'
   *  RelationalOperator: '<S5>/Relational Operator10'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH9' */
  Dem_SetError( (uint16_T)DTC_IDX_FC_START_CT_HIGH_CLASS1_ID29, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S5>/Data Type Conversion12' incorporates:
   *  Constant: '<S5>/Constant19'
   *  RelationalOperator: '<S5>/Relational Operator14'
   */
  rtb_DataTypeConversion1 = (uint8_T)(BMS_MON_B.Merge5_b == SRC_LOW_DEF);

  /* DataTypeConversion: '<S5>/Data Type Conversion13' incorporates:
   *  Constant: '<S5>/Constant21'
   *  RelationalOperator: '<S5>/Relational Operator11'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_DataTypeConversion1 != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH10' */
  Dem_SetError( (uint16_T)DTC_IDX_FC_CT_LOW_CLASS1_ID28, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S5>/Data Type Conversion5' incorporates:
   *  Constant: '<S5>/Constant4'
   *  RelationalOperator: '<S5>/Relational Operator5'
   */
  rtb_DataTypeConversion1 = (uint8_T)(BMS_MON_B.Switch != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S5>/sfun_SetErr_SrcH5' */
  Dem_SetError( (uint16_T)DTC_IDX_CT_NOT_BALANCE1_ID31, (uint8_T)
               rtb_DataTypeConversion1);

  /* SwitchCase: '<S6>/Switch Case' incorporates:
   *  Constant: '<S6>/Constant'
   *  Constant: '<S6>/Constant5'
   */
  switch ((int32_T)BMS_MON_B.Merge2_g) {
   case 1L:
    /* Outputs for IfAction SubSystem: '<S6>/High1' incorporates:
     *  ActionPort: '<S218>/Action Port'
     */
    BMS_MON_High1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/High1' */
    break;

   case 3L:
    /* Outputs for IfAction SubSystem: '<S6>/High2' incorporates:
     *  ActionPort: '<S219>/Action Port'
     */
    BMS_MON_High1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/High2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S6>/Normal' incorporates:
     *  ActionPort: '<S225>/Action Port'
     */
    BMS_MON_High3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/Normal' */
    break;
  }

  /* End of SwitchCase: '<S6>/Switch Case' */

  /* DataTypeConversion: '<S6>/Data Type Conversion3' incorporates:
   *  Constant: '<S6>/Constant1'
   *  RelationalOperator: '<S6>/Relational Operator1'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S6>/sfun_SetErr_SrcH1' */
  Dem_SetError( (uint16_T)DTC_IDX_CV_HIGH_CLASS1_ID4, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S6>/Data Type Conversion1' incorporates:
   *  Constant: '<S6>/Constant7'
   *  RelationalOperator: '<S6>/Relational Operator2'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S6>/sfun_SetErr_SrcH2' */
  Dem_SetError( (uint16_T)DTC_IDX_CV_HIGH_CLASS2_ID5, (uint8_T)
               rtb_DataTypeConversion1);

  /* RelationalOperator: '<S217>/Compare' incorporates:
   *  Constant: '<S217>/Constant'
   *  Inport: '<Root>/PackCurMode'
   */
  rtb_Compare = (PackCurMode == 0);

  /* Switch: '<S6>/Switch' incorporates:
   *  Constant: '<S6>/Constant22'
   */
  if (rtb_Compare) {
    rtb_DataTypeConversion1 = BMS_MON_B.Merge2_pa;
  } else {
    rtb_DataTypeConversion1 = SRC_NON_DEF;
  }

  /* End of Switch: '<S6>/Switch' */

  /* SwitchCase: '<S6>/Switch Case1' incorporates:
   *  Constant: '<S6>/Constant13'
   *  Constant: '<S6>/Constant6'
   */
  switch ((int32_T)rtb_DataTypeConversion1) {
   case 2L:
    /* Outputs for IfAction SubSystem: '<S6>/Low1' incorporates:
     *  ActionPort: '<S220>/Action Port'
     */
    BMS_MON_Low1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/Low1' */
    break;

   case 4L:
    /* Outputs for IfAction SubSystem: '<S6>/Low2' incorporates:
     *  ActionPort: '<S221>/Action Port'
     */
    BMS_MON_Low1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/Low2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S6>/Low5' incorporates:
     *  ActionPort: '<S224>/Action Port'
     */
    BMS_MON_Low3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/Low5' */
    break;
  }

  /* End of SwitchCase: '<S6>/Switch Case1' */

  /* DataTypeConversion: '<S6>/Data Type Conversion2' incorporates:
   *  Constant: '<S6>/Constant9'
   *  RelationalOperator: '<S6>/Relational Operator3'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S6>/sfun_SetErr_SrcH3' */
  Dem_SetError( (uint16_T)DTC_IDX_CV_LOW_CLASS1_ID6, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S6>/Data Type Conversion4' incorporates:
   *  Constant: '<S6>/Constant12'
   *  RelationalOperator: '<S6>/Relational Operator4'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S6>/sfun_SetErr_SrcH4' */
  Dem_SetError( (uint16_T)DTC_IDX_CV_LOW_CLASS2_ID7, (uint8_T)
               rtb_DataTypeConversion1);

  /* Switch: '<S6>/Switch1' incorporates:
   *  Constant: '<S6>/Constant23'
   */
  if (rtb_Compare) {
    rtb_DataTypeConversion1 = BMS_MON_B.Merge2_hy;
  } else {
    rtb_DataTypeConversion1 = SRC_NON_DEF;
  }

  /* End of Switch: '<S6>/Switch1' */

  /* SwitchCase: '<S6>/Switch Case2' incorporates:
   *  Constant: '<S6>/Constant17'
   *  Constant: '<S6>/Constant18'
   */
  switch ((int32_T)rtb_DataTypeConversion1) {
   case 2L:
    /* Outputs for IfAction SubSystem: '<S6>/Low3' incorporates:
     *  ActionPort: '<S222>/Action Port'
     */
    BMS_MON_Low1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/Low3' */
    break;

   case 4L:
    /* Outputs for IfAction SubSystem: '<S6>/Low4' incorporates:
     *  ActionPort: '<S223>/Action Port'
     */
    BMS_MON_Low1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/Low4' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S6>/Normal ' incorporates:
     *  ActionPort: '<S226>/Action Port'
     */
    BMS_MON_Low3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S6>/Normal ' */
    break;
  }

  /* End of SwitchCase: '<S6>/Switch Case2' */

  /* DataTypeConversion: '<S6>/Data Type Conversion6' incorporates:
   *  Constant: '<S6>/Constant19'
   *  RelationalOperator: '<S6>/Relational Operator6'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S6>/sfun_SetErr_SrcH6' */
  Dem_SetError( (uint16_T)DTC_IDX_UNDER0DEG_CV_CLASS1_ID9, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S6>/Data Type Conversion7' incorporates:
   *  Constant: '<S6>/Constant16'
   *  RelationalOperator: '<S6>/Relational Operator7'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S6>/sfun_SetErr_SrcH7' */
  Dem_SetError( (uint16_T)DTC_IDX_UNDER0DEG_CV_LOW_CLASS2_ID10, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S6>/Data Type Conversion5' incorporates:
   *  Constant: '<S6>/Constant4'
   *  RelationalOperator: '<S6>/Relational Operator5'
   */
  rtb_DataTypeConversion1 = (uint8_T)(BMS_MON_B.Switch_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S6>/sfun_SetErr_SrcH5' */
  Dem_SetError( (uint16_T)DTC_IDX_CV_DIFF_HIGH_ID8, (uint8_T)
               rtb_DataTypeConversion1);

  /* Outputs for Atomic SubSystem: '<S227>/PcMon' */
  BMS_MON_PcMon();

  /* End of Outputs for SubSystem: '<S227>/PcMon' */

  /* DataStoreWrite: '<S3>/Data Store Write' */
  PC_chrg_St = BMS_MON_B.Merge2;

  /* Outputs for Atomic SubSystem: '<S227>/SocMon' */
  BMS_MON_SocMon();

  /* End of Outputs for SubSystem: '<S227>/SocMon' */

  /* DataStoreWrite: '<S3>/Data Store Write1' */
  SOC_St = Soc_St;

  /* DataStoreWrite: '<S3>/Data Store Write2' */
  FCCur_St = PC_fc_St;

  /* Outputs for Atomic SubSystem: '<S227>/IsoMon' */
  BMS_MON_IsoMon();

  /* End of Outputs for SubSystem: '<S227>/IsoMon' */

  /* DataStoreWrite: '<S3>/Data Store Write3' */
  ISO_St = BMS_MON_B.Merge2_p;

  /* Outputs for Atomic SubSystem: '<S227>/PvMon' */
  BMS_MON_PvMon();

  /* End of Outputs for SubSystem: '<S227>/PvMon' */

  /* SwitchCase: '<S228>/Switch Case1' incorporates:
   *  Constant: '<S228>/Constant1'
   *  Constant: '<S228>/Constant13'
   */
  switch ((int32_T)BMS_MON_B.Merge2_p) {
   case 2L:
    /* Outputs for IfAction SubSystem: '<S228>/Low1' incorporates:
     *  ActionPort: '<S354>/Action Port'
     */
    BMS_MON_Low1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S228>/Low1' */
    break;

   case 4L:
    /* Outputs for IfAction SubSystem: '<S228>/Low2' incorporates:
     *  ActionPort: '<S355>/Action Port'
     */
    BMS_MON_Low1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S228>/Low2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S228>/Low3' incorporates:
     *  ActionPort: '<S356>/Action Port'
     */
    BMS_MON_Low3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S228>/Low3' */
    break;
  }

  /* End of SwitchCase: '<S228>/Switch Case1' */

  /* DataTypeConversion: '<S228>/Data Type Conversion2' incorporates:
   *  Constant: '<S228>/Constant9'
   *  RelationalOperator: '<S228>/Relational Operator3'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S228>/sfun_SetErr_SrcH3' */
  Dem_SetError( (uint16_T)DTC_IDX_ISO_LOW_CLASS1_ID19, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S228>/Data Type Conversion4' incorporates:
   *  Constant: '<S228>/Constant12'
   *  RelationalOperator: '<S228>/Relational Operator4'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S228>/sfun_SetErr_SrcH4' */
  Dem_SetError( (uint16_T)DTC_IDX_ISO_LOW_CLASS2_ID20, (uint8_T)
               rtb_DataTypeConversion1);

  /* SwitchCase: '<S229>/Switch Case1' incorporates:
   *  Constant: '<S229>/Constant4'
   *  Constant: '<S229>/Constant5'
   */
  switch ((int32_T)PC_dsg_St) {
   case 2L:
    /* Outputs for IfAction SubSystem: '<S229>/High1' incorporates:
     *  ActionPort: '<S357>/Action Port'
     */
    BMS_MON_High1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/High1' */
    break;

   case 4L:
    /* Outputs for IfAction SubSystem: '<S229>/High2' incorporates:
     *  ActionPort: '<S358>/Action Port'
     */
    BMS_MON_High1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/High2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S229>/Normal' incorporates:
     *  ActionPort: '<S365>/Action Port'
     */
    BMS_MON_High3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/Normal' */
    break;
  }

  /* End of SwitchCase: '<S229>/Switch Case1' */

  /* DataTypeConversion: '<S229>/Data Type Conversion3' incorporates:
   *  Constant: '<S229>/Constant1'
   *  RelationalOperator: '<S229>/Relational Operator1'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S229>/sfun_SetErr_SrcH1' */
  Dem_SetError( (uint16_T)DTC_IDX_DISCHARGE_CURR_HIGH_CLASS1_ID13, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S229>/Data Type Conversion1' incorporates:
   *  Constant: '<S229>/Constant3'
   *  RelationalOperator: '<S229>/Relational Operator2'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S229>/sfun_SetErr_SrcH2' */
  Dem_SetError( (uint16_T)DTC_IDX_DISCHARGE_CURR_HIGH_CLASS2_ID14, (uint8_T)
               rtb_DataTypeConversion1);

  /* SwitchCase: '<S229>/Switch Case2' incorporates:
   *  Constant: '<S229>/Constant10'
   *  Constant: '<S229>/Constant11'
   */
  switch ((int32_T)BMS_MON_B.Merge2) {
   case 1L:
    /* Outputs for IfAction SubSystem: '<S229>/High3' incorporates:
     *  ActionPort: '<S359>/Action Port'
     */
    BMS_MON_High1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/High3' */
    break;

   case 3L:
    /* Outputs for IfAction SubSystem: '<S229>/High4' incorporates:
     *  ActionPort: '<S360>/Action Port'
     */
    BMS_MON_High1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/High4' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S229>/High7' incorporates:
     *  ActionPort: '<S363>/Action Port'
     */
    BMS_MON_High3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/High7' */
    break;
  }

  /* End of SwitchCase: '<S229>/Switch Case2' */

  /* DataTypeConversion: '<S229>/Data Type Conversion4' incorporates:
   *  Constant: '<S229>/Constant7'
   *  RelationalOperator: '<S229>/Relational Operator3'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S229>/sfun_SetErr_SrcH3' */
  Dem_SetError( (uint16_T)DTC_IDX_SLOW_CHARGE_CURR_HIGH_CLASS1_ID15, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S229>/Data Type Conversion2' incorporates:
   *  Constant: '<S229>/Constant9'
   *  RelationalOperator: '<S229>/Relational Operator4'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S229>/sfun_SetErr_SrcH4' */
  Dem_SetError( (uint16_T)DTC_IDX_SLOW_CHARGE_CURR_HIGH_CLASS2_ID16, (uint8_T)
               rtb_DataTypeConversion1);

  /* SwitchCase: '<S229>/Switch Case3' incorporates:
   *  Constant: '<S229>/Constant13'
   *  Constant: '<S229>/Constant14'
   */
  switch ((int32_T)PC_fc_St) {
   case 1L:
    /* Outputs for IfAction SubSystem: '<S229>/High5' incorporates:
     *  ActionPort: '<S361>/Action Port'
     */
    BMS_MON_High1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/High5' */
    break;

   case 3L:
    /* Outputs for IfAction SubSystem: '<S229>/High6' incorporates:
     *  ActionPort: '<S362>/Action Port'
     */
    BMS_MON_High1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/High6' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S229>/High8' incorporates:
     *  ActionPort: '<S364>/Action Port'
     */
    BMS_MON_High3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S229>/High8' */
    break;
  }

  /* End of SwitchCase: '<S229>/Switch Case3' */

  /* DataTypeConversion: '<S229>/Data Type Conversion6' incorporates:
   *  Constant: '<S229>/Constant16'
   *  RelationalOperator: '<S229>/Relational Operator5'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S229>/sfun_SetErr_SrcH5' */
  Dem_SetError( (uint16_T)DTC_IDX_FAST_CHARGE_CURR_HIGH_CLASS1_ID17, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S229>/Data Type Conversion5' incorporates:
   *  Constant: '<S229>/Constant18'
   *  RelationalOperator: '<S229>/Relational Operator6'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S229>/sfun_SetErr_SrcH6' */
  Dem_SetError( (uint16_T)DTC_IDX_FAST_CHARGE_CURR_HIGH_CLASS2_ID18, (uint8_T)
               rtb_DataTypeConversion1);

  /* SwitchCase: '<S230>/Switch Case' incorporates:
   *  Constant: '<S230>/Constant'
   *  Constant: '<S230>/Constant5'
   */
  switch ((int32_T)Pv_St) {
   case 1L:
    /* Outputs for IfAction SubSystem: '<S230>/High1' incorporates:
     *  ActionPort: '<S366>/Action Port'
     */
    BMS_MON_High1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S230>/High1' */
    break;

   case 3L:
    /* Outputs for IfAction SubSystem: '<S230>/High2' incorporates:
     *  ActionPort: '<S367>/Action Port'
     */
    BMS_MON_High1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S230>/High2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S230>/Normal' incorporates:
     *  ActionPort: '<S371>/Action Port'
     */
    BMS_MON_High3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S230>/Normal' */
    break;
  }

  /* End of SwitchCase: '<S230>/Switch Case' */

  /* DataTypeConversion: '<S230>/Data Type Conversion3' incorporates:
   *  Constant: '<S230>/Constant1'
   *  RelationalOperator: '<S230>/Relational Operator1'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S230>/sfun_SetErr_SrcH1' */
  Dem_SetError( (uint16_T)DTC_IDX_PV_HIGH_CLASS1_ID0, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S230>/Data Type Conversion1' incorporates:
   *  Constant: '<S230>/Constant7'
   *  RelationalOperator: '<S230>/Relational Operator2'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S230>/sfun_SetErr_SrcH2' */
  Dem_SetError( (uint16_T)DTC_IDX_PV_HIGH_CLASS2_ID1, (uint8_T)
               rtb_DataTypeConversion1);

  /* Switch: '<S230>/Switch' incorporates:
   *  Constant: '<S230>/Constant14'
   *  Constant: '<S230>/Constant3'
   *  Constant: '<S230>/Constant4'
   *  Inport: '<Root>/PackCurMode'
   *  Logic: '<S230>/Logical Operator1'
   *  RelationalOperator: '<S230>/Relational Operator'
   *  RelationalOperator: '<S230>/Relational Operator5'
   */
  if ((PackCurMode != 1) && (PackCurMode != 2)) {
    rtb_DataTypeConversion1 = Pv_St;
  } else {
    rtb_DataTypeConversion1 = SRC_NON_DEF;
  }

  /* End of Switch: '<S230>/Switch' */

  /* SwitchCase: '<S230>/Switch Case1' incorporates:
   *  Constant: '<S230>/Constant13'
   *  Constant: '<S230>/Constant6'
   */
  switch ((int32_T)rtb_DataTypeConversion1) {
   case 2L:
    /* Outputs for IfAction SubSystem: '<S230>/Low1' incorporates:
     *  ActionPort: '<S368>/Action Port'
     */
    BMS_MON_Low1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S230>/Low1' */
    break;

   case 4L:
    /* Outputs for IfAction SubSystem: '<S230>/Low2' incorporates:
     *  ActionPort: '<S369>/Action Port'
     */
    BMS_MON_Low1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S230>/Low2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S230>/Low5' incorporates:
     *  ActionPort: '<S370>/Action Port'
     */
    BMS_MON_Low3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S230>/Low5' */
    break;
  }

  /* End of SwitchCase: '<S230>/Switch Case1' */

  /* DataTypeConversion: '<S230>/Data Type Conversion2' incorporates:
   *  Constant: '<S230>/Constant9'
   *  RelationalOperator: '<S230>/Relational Operator3'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S230>/sfun_SetErr_SrcH3' */
  Dem_SetError( (uint16_T)DTC_IDX_PV_LOW_CLASS1_ID2, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S230>/Data Type Conversion4' incorporates:
   *  Constant: '<S230>/Constant12'
   *  RelationalOperator: '<S230>/Relational Operator4'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S230>/sfun_SetErr_SrcH4' */
  Dem_SetError( (uint16_T)DTC_IDX_PV_LOW_CLASS2_ID3, (uint8_T)
               rtb_DataTypeConversion1);

  /* Switch: '<S231>/Switch' incorporates:
   *  Constant: '<S231>/Constant3'
   *  Constant: '<S231>/Constant4'
   *  Constant: '<S231>/Constant5'
   *  Inport: '<Root>/PackCurMode'
   *  Logic: '<S231>/Logical Operator1'
   *  RelationalOperator: '<S231>/Relational Operator'
   *  RelationalOperator: '<S231>/Relational Operator3'
   */
  if ((PackCurMode != 1) && (PackCurMode != 2)) {
    rtb_DataTypeConversion1 = Soc_St;
  } else {
    rtb_DataTypeConversion1 = SRC_NON_DEF;
  }

  /* End of Switch: '<S231>/Switch' */

  /* SwitchCase: '<S231>/Switch Case1' incorporates:
   *  Constant: '<S231>/Constant13'
   *  Constant: '<S231>/Constant6'
   */
  switch ((int32_T)rtb_DataTypeConversion1) {
   case 2L:
    /* Outputs for IfAction SubSystem: '<S231>/Low1' incorporates:
     *  ActionPort: '<S372>/Action Port'
     */
    BMS_MON_Low1(1U, 0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S231>/Low1' */
    break;

   case 4L:
    /* Outputs for IfAction SubSystem: '<S231>/Low2' incorporates:
     *  ActionPort: '<S373>/Action Port'
     */
    BMS_MON_Low1(0U, 1U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S231>/Low2' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S231>/Normal' incorporates:
     *  ActionPort: '<S374>/Action Port'
     */
    BMS_MON_Low3(0U, &rtb_Merge, &rtb_Merge1_j);

    /* End of Outputs for SubSystem: '<S231>/Normal' */
    break;
  }

  /* End of SwitchCase: '<S231>/Switch Case1' */

  /* DataTypeConversion: '<S231>/Data Type Conversion3' incorporates:
   *  Constant: '<S231>/Constant1'
   *  RelationalOperator: '<S231>/Relational Operator1'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S231>/sfun_SetErr_SrcH1' */
  Dem_SetError( (uint16_T)DTC_IDX_SOC_LOW_CLASS1_ID11, (uint8_T)
               rtb_DataTypeConversion1);

  /* DataTypeConversion: '<S231>/Data Type Conversion1' incorporates:
   *  Constant: '<S231>/Constant7'
   *  RelationalOperator: '<S231>/Relational Operator2'
   */
  rtb_DataTypeConversion1 = (uint8_T)(rtb_Merge1_j != SRC_NON_DEF);

  /* S-Function (sfun_SetErr): '<S231>/sfun_SetErr_SrcH2' */
  Dem_SetError( (uint16_T)DTC_IDX_SOC_LOW_CLASS2_ID12, (uint8_T)
               rtb_DataTypeConversion1);
}

/* Model initialize function */
void BMS_MON_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(BMS_MON_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &BMS_MON_B), 0,
                sizeof(BlockIO_BMS_MON));

  /* exported global signals */
  Soc_St = 0U;
  Pv_St = 0U;
  PC_fc_St = 0U;
  PC_dsg_St = 0U;

  /* states (dwork) */
  (void) memset((void *)&BMS_MON_DWork, 0,
                sizeof(D_Work_BMS_MON));

  /* exported global states */
  CV_St = 0U;
  CTMaxFc_St = 0U;
  PC_chrg_St = 0U;
  ISO_St = 0U;
  FCCur_St = 0U;
  SOC_St = 0U;

  /* Start for Atomic SubSystem: '<S4>/CvMon' */
  BMS_MON_CvMon_Start();

  /* End of Start for SubSystem: '<S4>/CvMon' */

  /* Start for Atomic SubSystem: '<S4>/PtMon' */
  BMS_MON_PtMon_Start();

  /* End of Start for SubSystem: '<S4>/PtMon' */

  /* Start for Atomic SubSystem: '<S227>/PcMon' */
  BMS_MON_PcMon_Start();

  /* End of Start for SubSystem: '<S227>/PcMon' */

  /* Start for Atomic SubSystem: '<S227>/SocMon' */
  BMS_MON_SocMon_Start();

  /* End of Start for SubSystem: '<S227>/SocMon' */

  /* InitializeConditions for Atomic SubSystem: '<S4>/CvMon' */
  BMS_MON_CvMon_Init();

  /* End of InitializeConditions for SubSystem: '<S4>/CvMon' */

  /* InitializeConditions for Atomic SubSystem: '<S4>/PtMon' */
  BMS_MON_PtMon_Init();

  /* End of InitializeConditions for SubSystem: '<S4>/PtMon' */

  /* InitializeConditions for Atomic SubSystem: '<S227>/IsoMon' */
  BMS_MON_IsoMon_Init();

  /* End of InitializeConditions for SubSystem: '<S227>/IsoMon' */

  /* InitializeConditions for Atomic SubSystem: '<S227>/PvMon' */
  BMS_MON_PvMon_Init();

  /* End of InitializeConditions for SubSystem: '<S227>/PvMon' */
}

/* Model terminate function */
void BMS_MON_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
