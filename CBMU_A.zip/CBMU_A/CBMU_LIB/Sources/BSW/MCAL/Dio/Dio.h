/*******************************************************************************
*
*  FILE
*     Dio.h
*
*  DESCRIPTION
*      Dio module header file 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.0
*
*******************************************************************************/
#ifndef _DIO_H_
#define _DIO_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Dio_Type.h"
#include "Dio_Cfg.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Vendor ID. */
#define DIO_VENDOR_ID           6666

/* Module ID  */
#define DIO_MODULE_ID           120

/* Version number of the module */
#define DIO_SW_MAJOR_VERSION    1
#define DIO_SW_MINOR_VERSION    0
#define DIO_SW_PATCH_VERSION    0

/*Port Input register*/ 
#define DIO_PORTA_DI     DIO_PORTA
#define DIO_PORTB_DI     DIO_PORTB
#define DIO_PORTC_DI     DIO_PORTC
#define DIO_PORTD_DI     DIO_PORTD
#define DIO_PORTE_DI     DIO_PORTE
#define DIO_PORTH_DI     DIO_PTH
#define DIO_PORTJ_DI     DIO_PTJ
#define DIO_PORTK_DI     DIO_PORTK
#define DIO_PORTM_DI     DIO_PTM
#define DIO_PORTP_DI     DIO_PTP
#define DIO_PORTS_DI     DIO_PTS
#define DIO_PORTT_DI     DIO_PTT

/*Port Output register*/  
#define DIO_PORTA_DO     DIO_PORTA
#define DIO_PORTB_DO     DIO_PORTB
#define DIO_PORTC_DO     DIO_PORTC
#define DIO_PORTD_DO     DIO_PORTD
#define DIO_PORTE_DO     DIO_PORTE
#define DIO_PORTH_DO       DIO_PTH
#define DIO_PPRTJ_DO       DIO_PTJ
#define DIO_PORTK_DO     DIO_PORTK
#define DIO_PORTM_DO       DIO_PTM
#define DIO_PORTP_DO       DIO_PTP
#define DIO_PORTS_DO       DIO_PTS
#define DIO_PORTT_DO       DIO_PTT

/*Pin state register*/  
#define DIO_PORTH_PINS     DIO_PTIH
#define DIO_PORTM_PINS     DIO_PTIM        
#define DIO_PORTP_PINS     DIO_PTIP
#define DIO_PORTS_PINS     DIO_PTIS
#define DIO_PORTT_PINS     DIO_PTIT
#define DIO_PORTJ_PINS     DIO_PTIJ

/*Port Direction register*/  
#define DIO_PORTA_DIR     DIO_DDRA 
#define DIO_PORTB_DIR     DIO_DDRB 
#define DIO_PORTC_DIR     DIO_DDRC 
#define DIO_PORTD_DIR     DIO_DDRD 
#define DIO_PORTE_DIR     DIO_DDRE 
#define DIO_PORTH_DIR     DIO_DDRH 
#define DIO_PORTJ_DIR     DIO_DDRJ 
#define DIO_PORTK_DIR     DIO_DDRK 
#define DIO_PORTP_DIR     DIO_DDRP 
#define DIO_PORTS_DIR     DIO_DDRS
#define DIO_PORTT_DIR     DIO_DDRT                

                                                                        
/*Port register */                                                                                                                               
#define DIO_PORTA  (*(volatile uint8*) 0x00000000)
#define DIO_DDRA   (*(volatile uint8*) 0x00000002) 
 
#define DIO_PORTB  (*(volatile uint8*) 0x00000001)     
#define DIO_DDRB   (*(volatile uint8*) 0x00000003)
                      

#define DIO_PORTC  (*(volatile uint8*) 0x00000004)
#define DIO_DDRC   (*(volatile uint8*) 0x00000006)
 
#define DIO_PORTD  (*(volatile uint8*) 0x00000005)       
#define DIO_DDRD   (*(volatile uint8*) 0x00000007)
    
#define DIO_PORTE  (*(volatile uint8*) 0x00000008)    
#define DIO_DDRE   (*(volatile uint8*) 0x00000009)

#define DIO_PUCR   (*(volatile uint8*) 0x0000000C)
#define DIO_RDRIV  (*(volatile uint8*) 0x0000000D)
    
#define DIO_PTH    (*(volatile uint8*) 0x00000260)    
#define DIO_PTIH   (*(volatile uint8*) 0x00000261)
#define DIO_DDRH   (*(volatile uint8*) 0x00000262)
#define DIO_RDRH   (*(volatile uint8*) 0x00000263) 
#define DIO_PERH   (*(volatile uint8*) 0x00000264)   
#define DIO_PPSH   (*(volatile uint8*) 0x00000265)   
#define DIO_PIEH   (*(volatile uint8*) 0x00000266)     
#define DIO_PIFH   (*(volatile uint8*) 0x00000267)
    
#define DIO_PTJ    (*(volatile uint8*) 0x00000268)    
#define DIO_PTIJ   (*(volatile uint8*) 0x00000269)
#define DIO_DDRJ   (*(volatile uint8*) 0x0000026A)
#define DIO_RDRJ   (*(volatile uint8*) 0x0000026B)    
#define DIO_PERJ   (*(volatile uint8*) 0x0000026C)
#define DIO_PPSJ   (*(volatile uint8*) 0x0000026D) 
#define DIO_PIEJ   (*(volatile uint8*) 0x0000026E)
#define DIO_PIFJ   (*(volatile uint8*) 0x0000026F)
    
#define DIO_PORTK  (*(volatile uint8*) 0x00000032)    
#define DIO_DDRK   (*(volatile uint8*) 0x00000033)
    
#define DIO_PTM    (*(volatile uint8*) 0x00000250) 
#define DIO_PTIM   (*(volatile uint8*) 0x00000251)
#define DIO_DDRM   (*(volatile uint8*) 0x00000252)
#define DIO_RDRM   (*(volatile uint8*) 0x00000253) 
#define DIO_PERM   (*(volatile uint8*) 0x00000254)
#define DIO_PPSM   (*(volatile uint8*) 0x00000255)    
#define DIO_WOMM   (*(volatile uint8*) 0x00000256)
    
#define DIO_PTP    (*(volatile uint8*) 0x00000258)
#define DIO_PTIP   (*(volatile uint8*) 0x00000259)  
#define DIO_DDRP   (*(volatile uint8*) 0x0000025A)
#define DIO_RDRP   (*(volatile uint8*) 0x0000025B)
#define DIO_PERP   (*(volatile uint8*) 0x0000025C) 
#define DIO_PPSP   (*(volatile uint8*) 0x0000025D)
#define DIO_PIEP   (*(volatile uint8*) 0x0000025E)    
#define DIO_PIFP   (*(volatile uint8*) 0x0000025F)
    
#define DIO_PTS    (*(volatile uint8*) 0x00000248)
#define DIO_PTIS   (*(volatile uint8*) 0x00000249)  
#define DIO_DDRS   (*(volatile uint8*) 0x0000024A)
#define DIO_RDRS   (*(volatile uint8*) 0x0000024B)
#define DIO_PERS   (*(volatile uint8*) 0x0000024C) 
#define DIO_PPSS   (*(volatile uint8*) 0x0000024D)
#define DIO_WOMS   (*(volatile uint8*) 0x0000024E)  
    
#define DIO_PTT    (*(volatile uint8*) 0x00000240)
#define DIO_PTIT   (*(volatile uint8*) 0x00000241)  
#define DIO_DDRT   (*(volatile uint8*) 0x00000242)
#define DIO_RDRT   (*(volatile uint8*) 0x00000243)
#define DIO_PERT   (*(volatile uint8*) 0x00000244) 
#define DIO_PPST   (*(volatile uint8*) 0x00000245)
                              
/*******************************************************************************
* Macros                                                                
*******************************************************************************/
#define Dio_WriteChannel(port,channel_id,level)         ((level ==  STD_HIGH)? (port |=( 1 << channel_id)) : (port &=(~( 1 << channel_id))))
#define Dio_ReadChannel(port,channel_id)                ((port & (1<<channel_id))? STD_HIGH : STD_LOW)
#define Dio_GetPinState(port,channel_id)                ((port & (1<<channel_id))? STD_HIGH : STD_LOW)
#define Dio_WriteChannelDir(portDir,channel_id,dir)     ((dir ==  DIO_DIR_OUTPUT)? (portDir |=( 1 << channel_id)) : (portDir &=(~( 1 << channel_id))))
#define Dio_WritePortDir(portDir,value)                 (portDir = value)
#define Dio_WritePort(port,value)                       (port = value)
#define Dio_ReadPort(port)                              (port)
/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/             
extern FUNC(void,DIO_CODE) Dio_GetVersionInfo(Std_VersionInfoType* versioninfo);

#endif/* #ifndef _DIO_H_ */
