/*
 * File: Lookup.c
 *
 * Code generated for Simulink model 'Lookup'.
 *
 * Model version                  : 1.488
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Wed Jun 22 13:54:32 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Lookup.h"
#include "Lookup_private.h"

/* Exported block signals */
uint8_T BM_Battery_SOC;                /* '<Root>/BM_Battery_SOC' */
uint8_T HeatingSt;                     /* '<Root>/HeatingSt' */
uint8_T HeatingEnable;                 /* '<Root>/HeatingEnable' */
uint16_T LPC_CUR;                      /* '<S1>/Product' */
uint16_T LPEC_CUR;                     /* '<S3>/2-D Lookup Table' */
t_Temp1 FcTempTooLow;                  /* '<S1>/2-D Lookup Table' */

/* Block states (auto storage) */
D_Work_Lookup Lookup_DWork;

/* Real-time model */
RT_MODEL_Lookup Lookup_M_;
RT_MODEL_Lookup *const Lookup_M = &Lookup_M_;
uint16_T look2_iu8u16lu32n32tu1_N8UogAJe(uint8_T u0, uint16_T u1, const uint8_T
  bp0[], const uint16_T bp1[], const uint16_T table[], uint32_T prevIndex[],
  const uint32_T maxIndex[], uint32_T stride)
{
  uint32_T bpIndices[2];
  uint32_T startIndex;
  uint32_T iRght;
  uint32_T iLeft;
  uint32_T found;

  /* Lookup 2-D
     Canonical function name: look2_iu8u16lu32n32tu16_pbinfcane
     Search method: 'binary'
     Use previous index: 'on'
     Interpolation method: 'Flat'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'nearest'
   */
  /* Prelookup - Index only
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'on'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0UL]) {
    startIndex = 0UL;
  } else if (u0 < bp0[maxIndex[0UL]]) {
    startIndex = prevIndex[0UL];

    /* Binary Search using Previous Index */
    iLeft = 0UL;
    iRght = maxIndex[0UL];
    found = 0UL;
    while (found == 0UL) {
      if (u0 < bp0[startIndex]) {
        iRght = startIndex - 1UL;
        startIndex = (iRght + iLeft) >> 1UL;
      } else if (u0 < bp0[startIndex + 1UL]) {
        found = 1UL;
      } else {
        iLeft = startIndex + 1UL;
        startIndex = (iRght + iLeft) >> 1UL;
      }
    }
  } else {
    startIndex = maxIndex[0UL];
  }

  prevIndex[0UL] = startIndex;
  bpIndices[0UL] = startIndex;

  /* Prelookup - Index only
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'on'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u1 <= bp1[0UL]) {
    startIndex = 0UL;
  } else if (u1 < bp1[maxIndex[1UL]]) {
    startIndex = prevIndex[1UL];

    /* Binary Search using Previous Index */
    iLeft = 0UL;
    iRght = maxIndex[1UL];
    found = 0UL;
    while (found == 0UL) {
      if (u1 < bp1[startIndex]) {
        iRght = startIndex - 1UL;
        startIndex = (iRght + iLeft) >> 1UL;
      } else if (u1 < bp1[startIndex + 1UL]) {
        found = 1UL;
      } else {
        iLeft = startIndex + 1UL;
        startIndex = (iRght + iLeft) >> 1UL;
      }
    }
  } else {
    startIndex = maxIndex[1UL];
  }

  prevIndex[1UL] = startIndex;
  return table[startIndex * stride + bpIndices[0]];
}

uint16_T look2_iu8u8lu32n32tu16_binfcase(uint8_T u0, uint8_T u1, const uint8_T
  bp0[], const uint8_T bp1[], const uint16_T table[], const uint32_T maxIndex[],
  uint32_T stride)
{
  uint32_T bpIndices[2];
  uint32_T iRght;
  uint32_T bpIdx;
  uint32_T iLeft;

  /* Lookup 2-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Flat'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  /* Prelookup - Index only
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0UL]) {
    iLeft = 0UL;
  } else if (u0 < bp0[maxIndex[0UL]]) {
    /* Binary Search */
    bpIdx = maxIndex[0UL] >> 1UL;
    iLeft = 0UL;
    iRght = maxIndex[0UL];
    while (iRght - iLeft > 1UL) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1UL;
    }
  } else {
    iLeft = maxIndex[0UL];
  }

  bpIndices[0UL] = iLeft;

  /* Prelookup - Index only
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u1 <= bp1[0UL]) {
    iLeft = 0UL;
  } else if (u1 < bp1[maxIndex[1UL]]) {
    /* Binary Search */
    bpIdx = maxIndex[1UL] >> 1UL;
    iLeft = 0UL;
    iRght = maxIndex[1UL];
    while (iRght - iLeft > 1UL) {
      if (u1 < bp1[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1UL;
    }
  } else {
    iLeft = maxIndex[1UL];
  }

  return table[iLeft * stride + bpIndices[0]];
}

uint8_T look2_iu8lu32n32tu8_pbinncane(uint8_T u0, uint8_T u1, const uint8_T bp0[],
  const uint8_T bp1[], const uint8_T table[], uint32_T prevIndex[], const
  uint32_T maxIndex[], uint32_T stride)
{
  uint32_T bpIndices[2];
  uint32_T startIndex;
  uint32_T iRght;
  uint32_T iLeft;
  uint32_T found;

  /* Lookup 2-D
     Search method: 'binary'
     Use previous index: 'on'
     Interpolation method: 'Nearest'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'nearest'
   */
  /* Prelookup - Index only
     Index Search method: 'binary'
     Interpolation method: 'Use nearest'
     Extrapolation method: 'Clip'
     Use previous index: 'on'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0UL]) {
    startIndex = 0UL;
  } else if (u0 < bp0[maxIndex[0UL]]) {
    startIndex = prevIndex[0UL];

    /* Binary Search using Previous Index */
    iLeft = 0UL;
    iRght = maxIndex[0UL];
    found = 0UL;
    while (found == 0UL) {
      if (u0 < bp0[startIndex]) {
        iRght = startIndex - 1UL;
        startIndex = (iRght + iLeft) >> 1UL;
      } else if (u0 < bp0[startIndex + 1UL]) {
        found = 1UL;
      } else {
        iLeft = startIndex + 1UL;
        startIndex = (iRght + iLeft) >> 1UL;
      }
    }

    if ((uint8_T)((uint16_T)bp0[startIndex + 1UL] - u0) <= (uint8_T)((uint16_T)
         u0 - bp0[startIndex])) {
      startIndex++;
    }
  } else {
    startIndex = maxIndex[0UL];
  }

  prevIndex[0UL] = startIndex;
  bpIndices[0UL] = startIndex;

  /* Prelookup - Index only
     Index Search method: 'binary'
     Interpolation method: 'Use nearest'
     Extrapolation method: 'Clip'
     Use previous index: 'on'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u1 <= bp1[0UL]) {
    startIndex = 0UL;
  } else if (u1 < bp1[maxIndex[1UL]]) {
    startIndex = prevIndex[1UL];

    /* Binary Search using Previous Index */
    iLeft = 0UL;
    iRght = maxIndex[1UL];
    found = 0UL;
    while (found == 0UL) {
      if (u1 < bp1[startIndex]) {
        iRght = startIndex - 1UL;
        startIndex = (iRght + iLeft) >> 1UL;
      } else if (u1 < bp1[startIndex + 1UL]) {
        found = 1UL;
      } else {
        iLeft = startIndex + 1UL;
        startIndex = (iRght + iLeft) >> 1UL;
      }
    }

    if ((uint8_T)((uint16_T)bp1[startIndex + 1UL] - u1) <= (uint8_T)((uint16_T)
         u1 - bp1[startIndex])) {
      startIndex++;
    }
  } else {
    startIndex = maxIndex[1UL];
  }

  prevIndex[1UL] = startIndex;
  return table[startIndex * stride + bpIndices[0]];
}

/* Model step function */
void Lookup_step(void)
{
  uint16_T rtb_DLookupTable;

  /* Lookup_n-D: '<S2>/2-D Lookup Table' incorporates:
   *  Inport: '<Root>/LUMAX_T'
   *  Inport: '<Root>/LUMAX_V'
   */
  rtb_DLookupTable = look2_iu8u16lu32n32tu1_N8UogAJe(SWC_CellTempMax,
    SWC_CellVoltMax, Lookup_ConstP.DLookupTable_bp01Dat,
    Lookup_ConstP.DLookupTable_bp02Dat, Lookup_ConstP.DLookupTable_tableD,
    Lookup_DWork.m_bpIndex, Lookup_ConstP.DLookupTable_maxIndex, 10UL);

  /* Product: '<S1>/Product' incorporates:
   *  DataStoreRead: '<Root>/Data Store Read'
   */
  LPC_CUR = rtb_DLookupTable * CellPNum;

  /* Lookup_n-D: '<S3>/2-D Lookup Table' incorporates:
   *  Inport: '<Root>/BM_Battery_SOC'
   *  Inport: '<Root>/LUMAX_T'
   */
  LPEC_CUR = look2_iu8u8lu32n32tu16_binfcase(BM_Battery_SOC, SWC_CellTempMax,
    Lookup_ConstP.DLookupTable_bp01Data, Lookup_ConstP.DLookupTable_bp02Da_c,
    Lookup_ConstP.DLookupTable_tableDa, Lookup_ConstP.DLookupTable_maxInd_d, 5UL);

  /* Lookup_n-D: '<S1>/2-D Lookup Table' incorporates:
   *  Inport: '<Root>/HeatingEnable'
   *  Inport: '<Root>/HeatingSt'
   */
  FcTempTooLow = look2_iu8lu32n32tu8_pbinncane(HeatingEnable, HeatingSt,
    Lookup_ConstP.DLookupTable_bp01Da_d, Lookup_ConstP.DLookupTable_bp02Data,
    Lookup_ConstP.DLookupTable_tableDat, Lookup_DWork.m_bpIndex_b,
    Lookup_ConstP.DLookupTable_maxInd_l, 2UL);
}

/* Model initialize function */
void Lookup_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(Lookup_M, (NULL));

  /* block I/O */

  /* exported global signals */
  LPC_CUR = 0U;
  LPEC_CUR = 0U;
  FcTempTooLow = 40U;

  /* states (dwork) */
  (void) memset((void *)&Lookup_DWork, 0,
                sizeof(D_Work_Lookup));

  /* external inputs */
  BM_Battery_SOC = 0U;
  HeatingSt = 0U;
  HeatingEnable = 0U;
}

/* Model terminate function */
void Lookup_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
