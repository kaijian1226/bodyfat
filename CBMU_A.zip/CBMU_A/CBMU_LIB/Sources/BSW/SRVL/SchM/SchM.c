/*******************************************************************************
*
*  FILE
*     SchM.c
*
*  DESCRIPTION
*     BSW Scheduler 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "SchM.h"

#include "Gpt.h"
#include "Can.h"
#include "SD2405.h"

#include "CanIf.h"
#include "CanTp.h"

#include "Dem.h"
#include "Fim.h"
#include "Dcm.h"
#include "Det.h"
#include "Xcp.h"

#include "Com.h"
#include "Mcu.h"
#include "Ioa.h"

#include "Pbs.h"

#include "Tle8104.h"
#include "Wdg.h"
#include "OsTrace.h"
#include "eep.h"
#include "EcuM.h"

#include "J1939Tp.h"

#include "VFB.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
uint8 schm_failCnt;

#define SCHM_MAX_FAIL_CNT 100U

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/


/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             SchM_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize all BSW modules  
*******************************************************************************/
FUNC(void,SCHM_CODE) SchM_Init(void)
{
  Mcu_Init();
  Wdg_Init(); 

  Gpt_Init();
  
  Ioa_Init();

  Pbs_Init();  
  
  CanIf_Init();
  CanTp_Init();
  
  J1939Tp_Init(); 

  
  Dcm_Init(); 

  EcuM_Init();
    
  Xcp_Init();  
  Com_Init();

  schm_failCnt = 0;

  //2015-07-01, LZY, remove it, Eep_Init(); // Eep should be placed before Dem and TrpR. 
  
  Dem_Init();
  FiM_Init();  
  TrpR_Init();
  Tle8104_Init();
  SD2405_Init();
  
 /*
  if (eep_Status == E_NOT_OK)
  {
    Dem_SetError(EEPROM_ERR,DEM_ERR_ACTIVE);
  }else
  {
    Dem_SetError(EEPROM_ERR,DEM_ERR_PASSIVE);
  }
  */

}

/*******************************************************************************
* NAME:             SchM_MainFunction
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      call BSW MainFunctions
*******************************************************************************/
FUNC(void,SCHM_CODE) SchM_MainFunction(void)
{

  Can_MainFunction_Read();  
  Can_MainFunction_Write();
  Can_MainFunction_BusOff();  
  Can_MainFunction_WakeUp();

  Dcm_Task();
  Xcp_Background();
  
    
}

/*******************************************************************************
* NAME:             SchM_Period10MsOne
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      call Periodically per 10ms 
*******************************************************************************/
FUNC(void,SCHM_CODE) SchM_Period10MsOne(void)
{ 
  Com_MainFunction();
  J1939Tp_MainFunction();//2015-07-07 xyl
  
  Tle8104_ReadDiagDataTask(); 
  Ioa_ReadAdValue();
  Ioa_ReadDigValue();
  
  Pbs_Task(); 
  
  Wdg_Trigger(); 
}

/*******************************************************************************
* NAME:             SchM_Period10MsTwo
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      call Periodically per 10ms 
*******************************************************************************/
FUNC(void,SCHM_CODE) SchM_Period10MsTwo(void)
{
  Com_BusCtrlTask();
  Xcp_Service(0);
  CanTp_MainFunction();
  
  
  Ioa_Output();        
  Ioa_Output_Other();//!!!!!! DCDC MOTOR ��minibus����  20151016
  Tle8104_StartDiagTask(); 
  
  #if(0)   //2015-06-23, lzy, delete EcuM for new MDL code
  EcuM_MainFunction();
  #endif

}



/*******************************************************************************
* NAME:             SchM_Period500MS
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      call Periodically per 500ms 
*******************************************************************************/
FUNC(void,SCHM_CODE) SchM_Period500MS(void)
{
  uint8 index;


  Dem_MainFunction();
  
  if (SD2405_ReadRealTime() == E_NOT_OK)
  {    
    Dem_SetError(CLK_ERR,DEM_ERR_ACTIVE); 
  }else
  {
    Dem_SetError(CLK_ERR,DEM_ERR_PASSIVE);
  }
  
  Ioa_ToggleRedLamp();
  
  /* 2015-07-01, lzy, removed

  for (index = 0; index<TLE8104_MODULE_NUM; index++)
  {
    if (tle8104_SpiSts[index] == TLE8104_SPI_INIT_ERR)
    {
      Dem_SetError(TLE8104_INIT_ERR1+index,DEM_ERR_ACTIVE); 
    }else if(tle8104_SpiSts[index] == TLE8104_SPI_KO)
    {
      Dem_SetError(TLE8104_SPI_ERR1+index,DEM_ERR_ACTIVE);
    }else if(tle8104_SpiSts[index] == TLE8104_SPI_OK)
    {
      Dem_SetError(TLE8104_INIT_ERR1+index,DEM_ERR_PASSIVE);
      Dem_SetError(TLE8104_SPI_ERR1+index,DEM_ERR_PASSIVE);
    }
  }
  
  */
}






/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/
