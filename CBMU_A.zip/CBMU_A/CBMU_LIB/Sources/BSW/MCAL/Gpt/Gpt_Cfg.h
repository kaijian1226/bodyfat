/*******************************************************************************
*
*  FILE
*     Gpt_Cfg.h
*
*  DESCRIPTION
*     The Configuration Header file for Gpt   
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

#ifndef _GPT_CFG_H_
#define _GPT_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Decimal or Binary Divider Select Bit 
 The selection is depend on Osc Freqency to make the 
 generated clock more precise */
#define GPT_RTICTL_RTDEC        1

/* System Counter Intterrupt time  / Unit:ns */
#define GPT_RTI_INT_PERIOD      1   /* Set Real Time interrupt 1ms */

#define GPT_RTI_INT_PERIOD_NS   (GPT_RTI_INT_PERIOD * 1000000)

/* This counter will be used as STOP watch, make it 
equal to Bus frequency, so each tick equal to 1us */
#define GPT_TIM_TCNT_PRESCALER (MCU_BUS_FREQ_MHZ - 1) 

/* OSEK Support */
#define GPT_SUPPORT_OSEK_OS             STD_OFF
#define GPT_RTI_OSCAT2                  STD_OFF

#define GPT_SYSTEM_TIMER_USER_DEFINED   STD_OFF

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/



#endif /* #ifndef _GPT_CFG_H_ */