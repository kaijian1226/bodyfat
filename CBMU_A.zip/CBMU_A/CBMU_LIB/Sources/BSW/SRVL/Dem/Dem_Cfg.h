/*******************************************************************************
*
*  FILE
*     Dem_Cfg.h
*
*  DESCRIPTION
*     The Configuration Header file for Dem Module
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

#ifndef _DEM_CFG_H_
#define _DEM_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Dem_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define DEM_DEV_ERROR_DETECT        STD_ON

#define DEM_EVENT_NUM               100U  //����Ŀ

#define DEM_ERROR_COL_NUM           (DEM_EVENT_NUM/16+1) //�洢???

#define DEM_MEM_ENTRY_NUM           27U  //�洢�������???

#define DEM_CLR_DELAY               10U  //������ʱʱ��???

//added for FID by xyl 2015-6-16
#define DEM_FID_NUM                 2U   //�м���FID�¼�???

#define DEM_NO_FID            	((uint8)0xFF)
#define DEM_FID_RELAY_OFF      	((uint8)0x00)
#define DEM_FID_POWER_OFF      	((uint8)0x01)

#define DEM_NO_PARAM          ((uint8)0xFF)  

/**************************************************************
 * xyl,2015-6-20
 *************************************************************/
/************************ DTC ID ************************
  PV:Pack Voltage     CV:Cell Voltage
  SC:Slow Charge      FC:Fast Charge
  CT:Cell Temperature HV:High Voltage
  BV:Battery Voltage
*********************************************************/
#define DTC_IDX_PV_HIGH_CLASS1						0
#define DTC_IDX_PV_HIGH_CLASS2						1   
#define DTC_IDX_PV_LOW_CLASS1							2
#define DTC_IDX_PV_LOW_CLASS2							3
#define DTC_IDX_CV_HIGH_CLASS1						4
#define DTC_IDX_CV_HIGH_CLASS2						5
#define DTC_IDX_CV_LOW_CLASS1							6
#define DTC_IDX_CV_LOW_CLASS2							7
#define DTC_IDX_CV_DIFF_HIGH							8
#define DTC_IDX_UNDER0DEG_CV_CLASS1					9
#define DTC_IDX_UNDER0DEG_CV_LOW_CLASS2				10
#define DTC_IDX_SOC_LOW_CLASS1						11
#define DTC_IDX_SOC_LOW_CLASS2						12
#define DTC_IDX_DISCHARGE_CURR_HIGH_CLASS1			13
#define DTC_IDX_DISCHARGE_CURR_HIGH_CLASS2			14
#define DTC_IDX_SC_CURR_HIGH_CLASS1					15
#define DTC_IDX_SC_CURR_HIGH_CLASS2					16
#define DTC_IDX_FC_CURR_HIGH_CLASS1					17
#define DTC_IDX_FC_CURR_HIGH_CLASS2					18
#define DTC_IDX_ISO_LOW_CLASS1						19
#define DTC_IDX_ISO_LOW_CLASS2						20
#define DTC_IDX_DISCHARGE_CT_HIGH_CLASS1			21
#define DTC_IDX_DISCHARGE_CT_HIGH_CLASS2			22
#define DTC_IDX_DISCHARGE_CT_LOW_CLASS1				23
#define DTC_IDX_DISCHARGE_CT_LOW_CLASS2 			24
#define DTC_IDX_SC_CT_LOW_CLASS1						25
#define DTC_IDX_SC_START_CT_HIGH_CLASS1				26
#define DTC_IDX_SC_CT_HIGH_CLASS1					27
#define DTC_IDX_FC_CT_LOW_CLASS1						28
#define DTC_IDX_FC_START_CT_HIGH_CLASS1				29
#define DTC_IDX_FC_CT_HIGH_CLASS1					30
#define DTC_IDX_CT_NOT_BALANCE1						31
#define DTC_IDX_SYS_POWER_EERR						32
#define DTC_IDX_HV_INTERLOCK_ERR						33
#define DTC_IDX_CRASH_SW_ERR							34
#define DTC_IDX_RLY_STICKY_FAULT						35
#define DTC_IDX_HARDWARE_FAULT						36
#define DTC_IDX_BV_HIGH									37
#define DTC_IDX_BV_LOW									38 
#define DTC_IDX_HVCU_COMERR							39
#define DTC_IDX_BMU1_COMERR							40
#define DTC_IDX_BMU2_COMERR							41
#define DTC_IDX_BMU3_COMERR							42
#define DTC_IDX_BMU4_COMERR							43
#define DTC_IDX_BMU5_COMERR							44   
#define DTC_IDX_BMU6_COMERR							45
#define DTC_IDX_BMU7_COMERR							46
#define DTC_IDX_BMU8_COMERR							47
#define DTC_IDX_BMU9_COMERR							48
#define DTC_IDX_BMU10_COMERR							49
#define DTC_IDX_BMU11_COMERR							50
#define DTC_IDX_BMU12_COMERR							51
#define DTC_IDX_BMU13_COMERR							52
#define DTC_IDX_BMU14_COMERR							53  
#define DTC_IDX_BMU15_COMERR							54
#define DTC_IDX_BMU16_COMERR							55 
#define DTC_IDX_BMU17_COMERR							56
#define DTC_IDX_BMU18_COMERR							57
#define DTC_IDX_BMU19_COMERR							58
#define DTC_IDX_BMU20_COMERR							59
#define DTC_IDX_BMU21_COMERR							60
#define DTC_IDX_BMU22_COMERR							61
#define DTC_IDX_BMU23_COMERR							62  
#define DTC_IDX_BMU24_COMERR							63
#define DTC_IDX_BMU25_COMERR							64 
#define DTC_IDX_FCHG_COMERR							65
#define DTC_IDX_INNER_COMERR							66
#define DTC_IDX_VEH_COMERR								67
#define DTC_IDX_SOCSAMERR_CLASS2						68  
#define DTC_IDX_ISOSAMERR_CLASS2						69
#define DTC_IDX_TCSAMERR_CLASS2						70 
#define DTC_IDX_TVSAMERR_CLASS1						71
#define DTC_IDX_TVSAMERR_CLASS2						72
#define DTC_IDX_CVSAMABM_CLASS1						73
#define DTC_IDX_CVSAMABM_CLASS2						74
#define DTC_IDX_PTSAMABM_CLASS1						75
#define DTC_IDX_PTSAMABM_CLASS2						76
     

//��������
#define DTC_IDX_CV_HIGH_CLASS3						77
#define DTC_IDX_CV_LOW_CLASS3							78
#define DTC_IDX_DISCHARGE_CT_HIGH_CLASS3			79
#define DTC_IDX_DISCHARGE_CT_LOW_CLASS3				80
#define DTC_IDX_CHARGE_CT_HIGH_CLASS3				81
#define DTC_IDX_CHARGE_CT_LOW_CLASS3				82
#define DTC_IDX_VEH_LOSS								83
#define DTC_IDX_ISO_LOW_CLASS3						84       
#define DTC_IDX_BmuVoltFault_CLASS3						85


//��������
#define DTC_IDX_PTC_BREAK_CLASS1						86
#define DTC_IDX_PTC_SHORT_CLASS3						87
#define DTC_IDX_PTC_BMSFAULT_CLASS1					88
#define DTC_IDX_PTC_HEATFAULT_CLASS1				89
#define DTC_IDX_ORIG_CURFAULT_CLASS3				90       
#define DTC_IDX_NEGRLY_STICKY_CLASS3				91
#define DTC_IDX_OFF_CURFAULT_CLASS2					92
//#define DTC_IDX_EXTERN_UNIT_ERR                       41
//#define DTC_IDX_VEH_TIMEOUT                           69














































    
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
/*  * *****************************************************************************
*   M acros                                                                
**  * ****************************************************************************/
      
/*  * *****************************************************************************
*   G lobal Variables declaration                         
**  * ****************************************************************************/
      
/*  * *****************************************************************************
*   G lobal functions declaration                         
**  * ****************************************************************************/
      
      
      
#endif /* #ifndef _DEM_CFG_H_ */
      
      
      
      
      
      
      
      
      
        
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
