/*
 * File: BMS_Data.h
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BMS_Data_h_
#define RTW_HEADER_BMS_Data_h_
#include "rtwtypes.h"
#include "BMS_MON_types.h"

/* Exported data define */
#define DTC_IDX_CT_NOT_BALANCE1_ID31   31U
#define DTC_IDX_CV_DIFF_HIGH_ID8       8U
#define DTC_IDX_CV_HIGH_CLASS1_ID4     4U
#define DTC_IDX_CV_HIGH_CLASS2_ID5     5U
#define DTC_IDX_CV_LOW_CLASS1_ID6      6U
#define DTC_IDX_CV_LOW_CLASS2_ID7      7U
#define DTC_IDX_DISCHARGE_CT_HIGH_CLASS1_ID21 21U
#define DTC_IDX_DISCHARGE_CT_HIGH_CLASS2_ID22 22U
#define DTC_IDX_DISCHARGE_CT_LOW_CLASS1_ID23 23U
#define DTC_IDX_DISCHARGE_CT_LOW_CLASS1_ID24 24U
#define DTC_IDX_DISCHARGE_CURR_HIGH_CLASS1_ID13 13U
#define DTC_IDX_DISCHARGE_CURR_HIGH_CLASS2_ID14 14U
#define DTC_IDX_FAST_CHARGE_CURR_HIGH_CLASS1_ID17 17U
#define DTC_IDX_FAST_CHARGE_CURR_HIGH_CLASS2_ID18 18U
#define DTC_IDX_FC_CT_HIGH_CLASS1_ID30 30U
#define DTC_IDX_FC_CT_LOW_CLASS1_ID28  28U
#define DTC_IDX_FC_START_CT_HIGH_CLASS1_ID29 29U
#define DTC_IDX_ISO_LOW_CLASS1_ID19    19U
#define DTC_IDX_ISO_LOW_CLASS2_ID20    20U
#define DTC_IDX_PV_HIGH_CLASS1_ID0     0U
#define DTC_IDX_PV_HIGH_CLASS2_ID1     1U
#define DTC_IDX_PV_LOW_CLASS1_ID2      2U
#define DTC_IDX_PV_LOW_CLASS2_ID3      3U
#define DTC_IDX_SC_CT_HIGH_CLASS1_ID27 27U
#define DTC_IDX_SC_CT_LOW_CLASS1_ID25  25U
#define DTC_IDX_SC_START_CT_HIGH_CLASS1_ID26 26U
#define DTC_IDX_SLOW_CHARGE_CURR_HIGH_CLASS1_ID15 15U
#define DTC_IDX_SLOW_CHARGE_CURR_HIGH_CLASS2_ID16 16U
#define DTC_IDX_SOC_LOW_CLASS1_ID11    11U
#define DTC_IDX_SOC_LOW_CLASS2_ID12    12U
#define DTC_IDX_UNDER0DEG_CV_CLASS1_ID9 9U
#define DTC_IDX_UNDER0DEG_CV_LOW_CLASS2_ID10 10U
#define SRC_HIGH_DEF                   ((uint8_T) 1U)
#define SRC_LOW_DEF                    ((uint8_T) 2U)
#define SRC_NON_DEF                    ((uint8_T) 0U)
#define SRC_TOO_HIGH_DEF               ((uint8_T) 3U)
#define SRC_TOO_LOW_DEF                ((uint8_T) 4U)
#define StepTim                        ((uint8_T) 10U)

/* Exported data declaration */
extern const uint16_T BmsSigASRCHighNegDeb;
extern const uint16_T BmsSigASRCHighPosDeb;
extern const uint16_T BmsSigASRCLowNegDeb;
extern const uint16_T BmsSigASRCLowPosDeb;
extern const t_Voltage3 CellVoltDiffSigASRCHigh;
extern const t_Voltage3 CellVoltDiffSigASRCLow;
extern const t_Voltage3 CellVoltSigASRCHigh;
extern const t_Voltage3 CellVoltSigASRCLow;
extern const t_Voltage3 CellVoltSigASRCTooHigh;
extern const t_Voltage3 CellVoltSigASRCTooLow;
extern const t_Temp1 DiffTempSigASRCHigh;
extern const t_Temp1 DiffTempSigASRCLow;
extern const t_Current1 DsgCurSigASRCHigh;
extern const t_Current1 DsgCurSigASRCLow;
extern const t_Current1 DsgCurSigASRCTooHigh;
extern const t_Current1 DsgCurSigASRCTooLow;
extern const t_Temp1 DsgTempSigASRCHigh;
extern const t_Temp1 DsgTempSigASRCLow;
extern const t_Temp1 DsgTempSigASRCTooHigh;
extern const t_Temp1 DsgTempSigASRCTooLow;
extern const t_Current1 FcCurSigASRCLow;
extern const t_Current1 FcCurSigASRCTooHigh;
extern const t_Current1 FcCurSigASRCTooLow;
extern const t_Temp1 FcTempSigASRCHigh;
extern const t_Temp1 FcTempSigASRCLow;
extern const t_Temp1 FcTempSigASRCTooHigh;
extern const t_Temp1 FcTempSigASRCTooLow;
extern const uint16_T IsoSigASRCHigh;
extern const uint16_T IsoSigASRCLow;
extern const uint16_T IsoSigASRCTooHigh;
extern const uint16_T IsoSigASRCTooLow;
extern const t_Voltage3 LTCellVoltSigASRCHigh;
extern const t_Voltage3 LTCellVoltSigASRCLow;
extern const t_Voltage3 LTCellVoltSigASRCTooHigh;
extern const t_Voltage3 LTCellVoltSigASRCTooLow;
extern const t_Temp1 LT_TempPoint;
extern const t_Voltage4 PackVoltSigASRCHigh;
extern const t_Voltage4 PackVoltSigASRCLow;
extern const t_Voltage4 PackVoltSigASRCTooHigh;
extern const t_Voltage4 PackVoltSigASRCTooHighHeal;
extern const t_Voltage4 PackVoltSigASRCTooLow;
extern const t_Voltage4 PackVoltSigASRCTooLowHeal;
extern const t_Current1 ScCurSigASRCHigh;
extern const t_Current1 ScCurSigASRCLow;
extern const t_Current1 ScCurSigASRCTooHigh;
extern const t_Current1 ScCurSigASRCTooLow;
extern const t_Temp1 ScTempSigASRCHigh;
extern const t_Temp1 ScTempSigASRCLow;
extern const t_Temp1 ScTempSigASRCTooHigh;
extern const t_Temp1 ScTempSigASRCTooLow;
extern const t_Soc1 SocSigASRCHigh;
extern const t_Soc1 SocSigASRCLow;
extern const t_Soc1 SocSigASRCTooHigh;
extern const t_Soc1 SocSigASRCTooLow;

#endif                                 /* RTW_HEADER_BMS_Data_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
