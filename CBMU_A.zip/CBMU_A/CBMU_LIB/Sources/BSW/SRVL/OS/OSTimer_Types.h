/*******************************************************************************
*
*  FILE
*     OSTimer_Types.h
*
*  DESCRIPTION
*     The Header file for OSTimer Types  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.00
*
*******************************************************************************/
#ifndef _OSTIMER_TYPES_H_
#define _OSTIMER_TYPES_H_
/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "OsTimer_Cfg.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

#if (OSTIMER_STOPWATCH_32BITS == STD_ON)
  typedef uint32 OsTimer_StopWatchTickType;
#else 
  typedef uint16 OsTimer_StopWatchTickType; 
#endif

typedef uint16 osTimer_MSecondType;        
typedef uint32 osTimer_SecondType;   
typedef uint16 osTime_MSecTickType;     
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

#endif  /* #ifndef _OSTIMER_TYPES_H_ */