/*
 * File: CvMon.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "CvMon.h"

/* Include model header file for global data */
#include "BMS_MON.h"
#include "BMS_MON_private.h"

/* Named constants for Chart: '<S18>/SRC_Check' */
#define BMS_MON_IN_Defect              ((uint8_T)1U)
#define BMS_MON_IN_NO_ACTIVE_CHILD     ((uint8_T)0U)
#define BMS_MON_IN_NO_Defect           ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Confimed   ((uint8_T)1U)
#define BMS_MON_IN_SRC_High_Debouncing ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Healing    ((uint8_T)3U)
#define BMS_MON_IN_SRC_Low_Confimed    ((uint8_T)4U)
#define BMS_MON_IN_SRC_Low_Debouncing  ((uint8_T)5U)
#define BMS_MON_IN_SRC_Low_Healing     ((uint8_T)6U)

/*
 * Initial conditions for atomic system:
 *    '<S17>/SRC_Check'
 *    '<S25>/SRC_Check'
 *    '<S34>/SRC_Check'
 *    '<S46>/SRC_Check'
 *    '<S55>/SRC_Check'
 *    '<S65>/SRC_Check'
 *    '<S74>/SRC_Check'
 */
void BMS_MON_SRC_Check_Init(rtB_SRC_Check_BMS_MON *localB,
  rtDW_SRC_Check_BMS_MON *localDW)
{
  /* InitializeConditions for Chart: '<S18>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD;
  localDW->bitsForTID0.is_active_c20_BMS_MON = 0U;
  localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_NO_ACTIVE_CHILD;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
  localB->SRC_Tmp_Def_Flag = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S17>/SRC_Check'
 *    '<S25>/SRC_Check'
 *    '<S34>/SRC_Check'
 *    '<S46>/SRC_Check'
 *    '<S55>/SRC_Check'
 *    '<S65>/SRC_Check'
 *    '<S74>/SRC_Check'
 */
void BMS_MON_SRC_Check(boolean_T rtu_Clear_Def_Flag, t_Voltage3 rtu_Sig_Volt,
  t_Voltage3 rtu_Par_SRC_H_Threshold, t_Voltage3 rtu_Par_SRC_L_Threshold,
  uint16_T rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON *localB, rtDW_SRC_Check_BMS_MON
  *localDW)
{
  /* Chart: '<S18>/SRC_Check' */
  /* Gateway: Task_100ms/BMU/BMU_Mon/CvMon/CVDiff_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_100ms/BMU/BMU_Mon/CvMon/CVDiff_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c20_BMS_MON == 0U) {
    /* Entry: Task_100ms/BMU/BMU_Mon/CvMon/CVDiff_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c20_BMS_MON = 1U;

    /* Entry Internal: Task_100ms/BMU/BMU_Mon/CvMon/CVDiff_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S19>:9' */
    localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_NO_Defect;

    /* Entry 'NO_Defect': '<S19>:1' */
    localB->SRC_Def_Status = SRC_NON_DEF;
  } else if (localDW->bitsForTID0.is_c20_BMS_MON == BMS_MON_IN_Defect) {
    /* During 'Defect': '<S19>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S19>:22' */
      /* Exit Internal 'Defect': '<S19>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Debouncing:
        /* Exit 'SRC_High_Debouncing': '<S19>:4' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD;
        break;

       case BMS_MON_IN_SRC_Low_Debouncing:
        /* Exit 'SRC_Low_Debouncing': '<S19>:3' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD;
        break;

       default:
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD;
        break;
      }

      localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_NO_Defect;

      /* Entry 'NO_Defect': '<S19>:1' */
      localB->SRC_Def_Status = SRC_NON_DEF;
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Confimed:
        /* During 'SRC_High_Confimed': '<S19>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S19>:13' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Healing;

          /* Entry 'SRC_High_Healing': '<S19>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Debouncing:
        /* During 'SRC_High_Debouncing': '<S19>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S19>:12' */
          /* Exit 'SRC_High_Debouncing': '<S19>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD;
          localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_NO_Defect;

          /* Entry 'NO_Defect': '<S19>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S19>:14' */
          /* Exit 'SRC_High_Debouncing': '<S19>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed;

          /* Entry 'SRC_High_Confimed': '<S19>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Healing:
        /* During 'SRC_High_Healing': '<S19>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S19>:15' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD;
          localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_NO_Defect;

          /* Entry 'NO_Defect': '<S19>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S19>:17' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed;

          /* Entry 'SRC_High_Confimed': '<S19>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Confimed:
        /* During 'SRC_Low_Confimed': '<S19>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S19>:18' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Healing;

          /* Entry 'SRC_Low_Healing': '<S19>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Debouncing:
        /* During 'SRC_Low_Debouncing': '<S19>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S19>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S19>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD;
          localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_NO_Defect;

          /* Entry 'NO_Defect': '<S19>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S19>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S19>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed;

          /* Entry 'SRC_Low_Confimed': '<S19>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S19>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S19>:20' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD;
          localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_NO_Defect;

          /* Entry 'NO_Defect': '<S19>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S19>:19' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed;

          /* Entry 'SRC_Low_Confimed': '<S19>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    /* During 'NO_Defect': '<S19>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S19>:10' */
      localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_Defect;
      localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Debouncing;

      /* Entry 'SRC_High_Debouncing': '<S19>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
      localB->SRC_Tmp_Def_Flag = 1U;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S19>:11' */
        localDW->bitsForTID0.is_c20_BMS_MON = BMS_MON_IN_Defect;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Debouncing;

        /* Entry 'SRC_Low_Debouncing': '<S19>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
        localB->SRC_Tmp_Def_Flag = 1U;
      }
    }
  }

  /* End of Chart: '<S18>/SRC_Check' */
}

/*
 * Output and update for action system:
 *    '<S10>/If Abnormal Action Subsystem'
 *    '<S10>/If Normal Action Subsystem'
 *    '<S39>/If Abnormal Action Subsystem'
 *    '<S39>/If Normal Action Subsystem'
 *    '<S58>/If Abnormal Action Subsystem'
 *    '<S58>/If Normal Action Subsystem'
 */
void BMS_M_IfAbnormalActionSubsystem(boolean_T rtu_In1, t_Voltage3 rtu_In2,
  uint8_T rtu_In3, boolean_T *rty_Out1, t_Voltage3 *rty_Out2, uint8_T *rty_Out3)
{
  /* Inport: '<S21>/In1' */
  *rty_Out1 = rtu_In1;

  /* Inport: '<S21>/In2' */
  *rty_Out2 = rtu_In2;

  /* Inport: '<S21>/In3' */
  *rty_Out3 = rtu_In3;
}

/*
 * Output and update for action system:
 *    '<S12>/If Action Subsystem'
 *    '<S12>/If Action Subsystem1'
 */
void BMS_MON_IfActionSubsystem(t_Voltage3 rtu_In1, t_Voltage3 *rty_Out1)
{
  /* Inport: '<S37>/In1' */
  *rty_Out1 = rtu_In1;
}

/* Initial conditions for atomic system: '<S4>/CvMon' */
void BMS_MON_CvMon_Init(void)
{
  /* InitializeConditions for Atomic SubSystem: '<S17>/SRC_Check' */
  BMS_MON_SRC_Check_Init(&BMS_MON_B.SRC_Check, &BMS_MON_DWork.SRC_Check);

  /* End of InitializeConditions for SubSystem: '<S17>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S25>/SRC_Check' */
  BMS_MON_SRC_Check_Init(&BMS_MON_B.SRC_Check_h, &BMS_MON_DWork.SRC_Check_h);

  /* End of InitializeConditions for SubSystem: '<S25>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S34>/SRC_Check' */
  BMS_MON_SRC_Check_Init(&BMS_MON_B.SRC_Check_g, &BMS_MON_DWork.SRC_Check_g);

  /* End of InitializeConditions for SubSystem: '<S34>/SRC_Check' */
}

/* Start for atomic system: '<S4>/CvMon' */
void BMS_MON_CvMon_Start(void)
{
  /* InitializeConditions for Enabled SubSystem: '<S7>/LowTemp_CV_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S46>/SRC_Check' */
  BMS_MON_SRC_Check_Init(&BMS_MON_B.SRC_Check_h0, &BMS_MON_DWork.SRC_Check_h0);

  /* End of InitializeConditions for SubSystem: '<S46>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S55>/SRC_Check' */
  BMS_MON_SRC_Check_Init(&BMS_MON_B.SRC_Check_i, &BMS_MON_DWork.SRC_Check_i);

  /* End of InitializeConditions for SubSystem: '<S55>/SRC_Check' */

  /* End of InitializeConditions for SubSystem: '<S7>/LowTemp_CV_Check' */

  /* InitializeConditions for Enabled SubSystem: '<S7>/Temp_CV_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S65>/SRC_Check' */
  BMS_MON_SRC_Check_Init(&BMS_MON_B.SRC_Check_p, &BMS_MON_DWork.SRC_Check_p);

  /* End of InitializeConditions for SubSystem: '<S65>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S74>/SRC_Check' */
  BMS_MON_SRC_Check_Init(&BMS_MON_B.SRC_Check_m, &BMS_MON_DWork.SRC_Check_m);

  /* End of InitializeConditions for SubSystem: '<S74>/SRC_Check' */

  /* End of InitializeConditions for SubSystem: '<S7>/Temp_CV_Check' */
}

/* Output and update for atomic system: '<S4>/CvMon' */
void BMS_MON_CvMon(void)
{
  boolean_T rtb_LogicalOperator1;
  uint8_T rtb_Switch_ja;
  uint8_T rtb_Switch;
  boolean_T rtb_LogicalOperator1_a;
  t_Voltage3 rtb_Merge;
  boolean_T rtb_Merge_f;
  boolean_T rtb_Merge_c3;

  /* If: '<S12>/If' incorporates:
   *  Constant: '<S12>/Constant'
   *  Inport: '<Root>/com_CellVoltMax'
   *  Inport: '<Root>/com_CellVoltMin'
   *  RelationalOperator: '<S12>/Relational Operator'
   *  Sum: '<S12>/Add'
   */
  if (SWC_CellVoltMax >= SWC_CellVoltMin) {
    /* Outputs for IfAction SubSystem: '<S12>/If Action Subsystem' incorporates:
     *  ActionPort: '<S37>/Action Port'
     */
    BMS_MON_IfActionSubsystem(SWC_CellVoltMax - SWC_CellVoltMin, &rtb_Merge);

    /* End of Outputs for SubSystem: '<S12>/If Action Subsystem' */
  } else {
    /* Outputs for IfAction SubSystem: '<S12>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S38>/Action Port'
     */
    BMS_MON_IfActionSubsystem(0U, &rtb_Merge);

    /* End of Outputs for SubSystem: '<S12>/If Action Subsystem1' */
  }

  /* End of If: '<S12>/If' */

  /* Outputs for Atomic SubSystem: '<S17>/SRC_Check' */

  /* Constant: '<S17>/Constant1' incorporates:
   *  Constant: '<S17>/Constant2'
   *  Constant: '<S17>/Constant3'
   *  Constant: '<S17>/Constant4'
   *  Constant: '<S17>/Constant5'
   *  Constant: '<S17>/Constant6'
   *  Constant: '<S17>/Constant7'
   *  Constant: '<S17>/Constant8'
   */
  BMS_MON_SRC_Check(false, rtb_Merge, CellVoltDiffSigASRCHigh,
                    CellVoltDiffSigASRCLow, BmsSigASRCHighPosDeb,
                    BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                    BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check,
                    &BMS_MON_DWork.SRC_Check);

  /* End of Outputs for SubSystem: '<S17>/SRC_Check' */

  /* Switch: '<S9>/Switch2' incorporates:
   *  Constant: '<S9>/Constant4'
   *  DataStoreRead: '<S9>/Data Store Read1'
   *  Logic: '<S9>/Logical Operator3'
   */
  if (!BMS_MON_DWork.Dem_stClear_kfh) {
    rtb_Switch_ja = BMS_MON_B.SRC_Check.SRC_Def_Status;
  } else {
    rtb_Switch_ja = SRC_NON_DEF;
  }

  /* End of Switch: '<S9>/Switch2' */

  /* Switch: '<S9>/Switch' incorporates:
   *  Constant: '<S9>/Constant4'
   *  RelationalOperator: '<S9>/Relational Operator1'
   */
  if (rtb_Switch_ja != SRC_NON_DEF) {
    BMS_MON_B.Switch_j = BMS_MON_B.SRC_Check.SRC_Def_Status;
  } else {
    BMS_MON_B.Switch_j = SRC_NON_DEF;
  }

  /* End of Switch: '<S9>/Switch' */

  /* Outputs for Atomic SubSystem: '<S25>/SRC_Check' */

  /* Constant: '<S25>/Constant1' incorporates:
   *  Constant: '<S25>/Constant2'
   *  Constant: '<S25>/Constant3'
   *  Constant: '<S25>/Constant4'
   *  Constant: '<S25>/Constant5'
   *  Constant: '<S25>/Constant6'
   *  Constant: '<S25>/Constant7'
   *  Constant: '<S25>/Constant8'
   *  Inport: '<Root>/com_CellVoltMax'
   */
  BMS_MON_SRC_Check(false, SWC_CellVoltMax, CellVoltSigASRCHigh,
                    CellVoltSigASRCLow, BmsSigASRCHighPosDeb,
                    BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                    BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_h,
                    &BMS_MON_DWork.SRC_Check_h);

  /* End of Outputs for SubSystem: '<S25>/SRC_Check' */

  /* Logic: '<S24>/Logical Operator1' incorporates:
   *  DataStoreRead: '<S24>/Data Store Read'
   *  Logic: '<S24>/Logical Operator4'
   */
  rtb_LogicalOperator1 = ((BMS_MON_B.SRC_Check_h.SRC_Tmp_Def_Flag != 0) &&
    (!BMS_MON_DWork.Dem_stClear_da));

  /* Switch: '<S20>/Switch2' incorporates:
   *  Constant: '<S20>/Constant4'
   *  DataStoreRead: '<S20>/Data Store Read1'
   *  Logic: '<S20>/Logical Operator3'
   */
  if (!BMS_MON_DWork.Dem_stClear_da) {
    rtb_Switch_ja = BMS_MON_B.SRC_Check_h.SRC_Def_Status;
  } else {
    rtb_Switch_ja = SRC_NON_DEF;
  }

  /* End of Switch: '<S20>/Switch2' */

  /* Switch: '<S20>/Switch' incorporates:
   *  Constant: '<S20>/Constant4'
   *  RelationalOperator: '<S20>/Relational Operator1'
   */
  if (rtb_Switch_ja != SRC_NON_DEF) {
    rtb_Switch = BMS_MON_B.SRC_Check_h.SRC_Def_Status;
  } else {
    rtb_Switch = SRC_NON_DEF;
  }

  /* End of Switch: '<S20>/Switch' */

  /* Outputs for Atomic SubSystem: '<S34>/SRC_Check' */

  /* Constant: '<S34>/Constant1' incorporates:
   *  Constant: '<S34>/Constant2'
   *  Constant: '<S34>/Constant3'
   *  Constant: '<S34>/Constant4'
   *  Constant: '<S34>/Constant5'
   *  Constant: '<S34>/Constant6'
   *  Constant: '<S34>/Constant7'
   *  Constant: '<S34>/Constant8'
   *  Inport: '<Root>/com_CellVoltMax'
   */
  BMS_MON_SRC_Check(false, SWC_CellVoltMax, CellVoltSigASRCTooHigh,
                    CellVoltSigASRCTooLow, BmsSigASRCHighPosDeb,
                    BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                    BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_g,
                    &BMS_MON_DWork.SRC_Check_g);

  /* End of Outputs for SubSystem: '<S34>/SRC_Check' */

  /* SwitchCase: '<S28>/Switch Case' incorporates:
   *  Constant: '<S28>/Constant1'
   *  Constant: '<S28>/Constant2'
   *  Constant: '<S28>/Constant4'
   */
  switch ((int32_T)BMS_MON_B.SRC_Check_g.SRC_Def_Status) {
   case 0L:
    /* Outputs for IfAction SubSystem: '<S28>/Switch Case Action Subsystem' incorporates:
     *  ActionPort: '<S31>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_j4);

    /* End of Outputs for SubSystem: '<S28>/Switch Case Action Subsystem' */
    break;

   case 1L:
    /* Outputs for IfAction SubSystem: '<S28>/Switch Case Action Subsystem1' incorporates:
     *  ActionPort: '<S32>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_j4);

    /* End of Outputs for SubSystem: '<S28>/Switch Case Action Subsystem1' */
    break;

   case 2L:
    /* Outputs for IfAction SubSystem: '<S28>/Switch Case Action Subsystem2' incorporates:
     *  ActionPort: '<S33>/Action Port'
     */
    BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_j4);

    /* End of Outputs for SubSystem: '<S28>/Switch Case Action Subsystem2' */
    break;
  }

  /* End of SwitchCase: '<S28>/Switch Case' */

  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/Constant4'
   *  DataStoreRead: '<S11>/Data Store Read1'
   *  Logic: '<S11>/Logical Operator3'
   */
  if (!BMS_MON_DWork.Dem_stClear_i) {
    rtb_Switch_ja = BMS_MON_B.Merge_j4;
  } else {
    rtb_Switch_ja = SRC_NON_DEF;
  }

  /* End of Switch: '<S11>/Switch2' */

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/Constant4'
   *  RelationalOperator: '<S11>/Relational Operator1'
   */
  if (rtb_Switch_ja != SRC_NON_DEF) {
    rtb_Switch_ja = BMS_MON_B.Merge_j4;
  } else {
    rtb_Switch_ja = SRC_NON_DEF;
  }

  /* End of Switch: '<S11>/Switch' */

  /* If: '<S10>/If Abnormal' incorporates:
   *  DataStoreRead: '<S30>/Data Store Read'
   *  Inport: '<Root>/com_CellVoltMax'
   *  Logic: '<S30>/Logical Operator1'
   *  Logic: '<S30>/Logical Operator4'
   */
  if (rtb_Switch_ja != 0) {
    /* Outputs for IfAction SubSystem: '<S10>/If Abnormal Action Subsystem' incorporates:
     *  ActionPort: '<S21>/Action Port'
     */
    BMS_M_IfAbnormalActionSubsystem((BMS_MON_B.SRC_Check_g.SRC_Tmp_Def_Flag != 0)
      && (!BMS_MON_DWork.Dem_stClear_i), SWC_CellVoltMax, rtb_Switch_ja,
      &rtb_Merge_f, &rtb_Merge, &BMS_MON_B.Merge2_g);

    /* End of Outputs for SubSystem: '<S10>/If Abnormal Action Subsystem' */
  } else {
    /* Outputs for IfAction SubSystem: '<S10>/If Normal Action Subsystem' incorporates:
     *  ActionPort: '<S22>/Action Port'
     */
    BMS_M_IfAbnormalActionSubsystem(rtb_LogicalOperator1, SWC_CellVoltMax,
      rtb_Switch, &rtb_Merge_f, &rtb_Merge, &BMS_MON_B.Merge2_g);

    /* End of Outputs for SubSystem: '<S10>/If Normal Action Subsystem' */
  }

  /* End of If: '<S10>/If Abnormal' */

  /* RelationalOperator: '<S7>/Relational Operator' incorporates:
   *  Constant: '<S7>/Constant'
   *  Inport: '<Root>/com_CellTempAvrg'
   */
  rtb_LogicalOperator1 = (SWC_CellTempAvrg >= LT_TempPoint);

  /* RelationalOperator: '<S7>/Relational Operator1' incorporates:
   *  Inport: '<Root>/PackCurMode'
   */
  rtb_Merge_f = (PackCurMode == 0);

  /* Outputs for Enabled SubSystem: '<S7>/LowTemp_CV_Check' incorporates:
   *  EnablePort: '<S13>/Enable'
   */
  /* Logic: '<S7>/Logical Operator1' incorporates:
   *  Constant: '<S46>/Constant1'
   *  Constant: '<S46>/Constant2'
   *  Constant: '<S46>/Constant3'
   *  Constant: '<S46>/Constant4'
   *  Constant: '<S46>/Constant5'
   *  Constant: '<S46>/Constant6'
   *  Constant: '<S46>/Constant7'
   *  Constant: '<S46>/Constant8'
   *  Constant: '<S55>/Constant1'
   *  Constant: '<S55>/Constant2'
   *  Constant: '<S55>/Constant3'
   *  Constant: '<S55>/Constant4'
   *  Constant: '<S55>/Constant5'
   *  Constant: '<S55>/Constant6'
   *  Constant: '<S55>/Constant7'
   *  Constant: '<S55>/Constant8'
   *  Inport: '<Root>/com_CellVoltMin'
   *  Logic: '<S7>/Logical Operator'
   */
  if ((!rtb_LogicalOperator1) && rtb_Merge_f) {
    /* Outputs for Atomic SubSystem: '<S46>/SRC_Check' */
    BMS_MON_SRC_Check(false, SWC_CellVoltMin, LTCellVoltSigASRCHigh,
                      LTCellVoltSigASRCLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_h0,
                      &BMS_MON_DWork.SRC_Check_h0);

    /* End of Outputs for SubSystem: '<S46>/SRC_Check' */

    /* Logic: '<S45>/Logical Operator1' incorporates:
     *  Constant: '<S46>/Constant1'
     *  Constant: '<S46>/Constant2'
     *  Constant: '<S46>/Constant3'
     *  Constant: '<S46>/Constant4'
     *  Constant: '<S46>/Constant5'
     *  Constant: '<S46>/Constant6'
     *  Constant: '<S46>/Constant7'
     *  Constant: '<S46>/Constant8'
     *  DataStoreRead: '<S45>/Data Store Read'
     *  Inport: '<Root>/com_CellVoltMin'
     *  Logic: '<S45>/Logical Operator4'
     */
    rtb_LogicalOperator1_a = ((BMS_MON_B.SRC_Check_h0.SRC_Tmp_Def_Flag != 0) &&
      (!(BMS_MON_DWork.Dem_stClear_g != 0)));

    /* Switch: '<S41>/Switch2' incorporates:
     *  Constant: '<S41>/Constant4'
     *  DataStoreRead: '<S41>/Data Store Read1'
     *  Logic: '<S41>/Logical Operator3'
     */
    if (!(BMS_MON_DWork.Dem_stClear_g != 0)) {
      rtb_Switch_ja = BMS_MON_B.SRC_Check_h0.SRC_Def_Status;
    } else {
      rtb_Switch_ja = SRC_NON_DEF;
    }

    /* End of Switch: '<S41>/Switch2' */

    /* Switch: '<S41>/Switch' incorporates:
     *  Constant: '<S41>/Constant4'
     *  RelationalOperator: '<S41>/Relational Operator1'
     */
    if (rtb_Switch_ja != SRC_NON_DEF) {
      rtb_Switch = BMS_MON_B.SRC_Check_h0.SRC_Def_Status;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S41>/Switch' */

    /* Outputs for Atomic SubSystem: '<S55>/SRC_Check' */
    BMS_MON_SRC_Check(false, SWC_CellVoltMin, LTCellVoltSigASRCTooHigh,
                      LTCellVoltSigASRCTooLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_i,
                      &BMS_MON_DWork.SRC_Check_i);

    /* End of Outputs for SubSystem: '<S55>/SRC_Check' */

    /* SwitchCase: '<S49>/Switch Case' incorporates:
     *  Constant: '<S49>/Constant1'
     *  Constant: '<S49>/Constant2'
     *  Constant: '<S49>/Constant4'
     *  Constant: '<S55>/Constant1'
     *  Constant: '<S55>/Constant2'
     *  Constant: '<S55>/Constant3'
     *  Constant: '<S55>/Constant4'
     *  Constant: '<S55>/Constant5'
     *  Constant: '<S55>/Constant6'
     *  Constant: '<S55>/Constant7'
     *  Constant: '<S55>/Constant8'
     *  Inport: '<Root>/com_CellVoltMin'
     */
    switch ((int32_T)BMS_MON_B.SRC_Check_i.SRC_Def_Status) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S49>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S52>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_g);

      /* End of Outputs for SubSystem: '<S49>/Switch Case Action Subsystem' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S49>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S53>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_g);

      /* End of Outputs for SubSystem: '<S49>/Switch Case Action Subsystem1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S49>/Switch Case Action Subsystem2' incorporates:
       *  ActionPort: '<S54>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_g);

      /* End of Outputs for SubSystem: '<S49>/Switch Case Action Subsystem2' */
      break;
    }

    /* End of SwitchCase: '<S49>/Switch Case' */

    /* Switch: '<S40>/Switch2' incorporates:
     *  Constant: '<S40>/Constant4'
     *  DataStoreRead: '<S40>/Data Store Read1'
     *  Logic: '<S40>/Logical Operator3'
     */
    if (!(BMS_MON_DWork.Dem_stClear_h != 0)) {
      rtb_Switch_ja = BMS_MON_B.Merge_g;
    } else {
      rtb_Switch_ja = SRC_NON_DEF;
    }

    /* End of Switch: '<S40>/Switch2' */

    /* Switch: '<S40>/Switch' incorporates:
     *  Constant: '<S40>/Constant4'
     *  RelationalOperator: '<S40>/Relational Operator1'
     */
    if (rtb_Switch_ja != SRC_NON_DEF) {
      rtb_Switch_ja = BMS_MON_B.Merge_g;
    } else {
      rtb_Switch_ja = SRC_NON_DEF;
    }

    /* End of Switch: '<S40>/Switch' */

    /* If: '<S39>/If Abnormal' incorporates:
     *  DataStoreRead: '<S51>/Data Store Read'
     *  Inport: '<Root>/com_CellVoltMin'
     *  Logic: '<S51>/Logical Operator1'
     *  Logic: '<S51>/Logical Operator4'
     */
    if (rtb_Switch_ja != 0) {
      /* Outputs for IfAction SubSystem: '<S39>/If Abnormal Action Subsystem' incorporates:
       *  ActionPort: '<S42>/Action Port'
       */
      BMS_M_IfAbnormalActionSubsystem((BMS_MON_B.SRC_Check_i.SRC_Tmp_Def_Flag !=
        0) && (!(BMS_MON_DWork.Dem_stClear_h != 0)), SWC_CellVoltMin,
        rtb_Switch_ja, &rtb_Merge_c3, &rtb_Merge, &BMS_MON_B.Merge2_hy);

      /* End of Outputs for SubSystem: '<S39>/If Abnormal Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S39>/If Normal Action Subsystem' incorporates:
       *  ActionPort: '<S43>/Action Port'
       */
      BMS_M_IfAbnormalActionSubsystem(rtb_LogicalOperator1_a, SWC_CellVoltMin,
        rtb_Switch, &rtb_Merge_c3, &rtb_Merge, &BMS_MON_B.Merge2_hy);

      /* End of Outputs for SubSystem: '<S39>/If Normal Action Subsystem' */
    }

    /* End of If: '<S39>/If Abnormal' */
  }

  /* End of Logic: '<S7>/Logical Operator1' */
  /* End of Outputs for SubSystem: '<S7>/LowTemp_CV_Check' */

  /* Outputs for Enabled SubSystem: '<S7>/Temp_CV_Check' incorporates:
   *  EnablePort: '<S14>/Enable'
   */
  /* Logic: '<S7>/Logical Operator2' incorporates:
   *  Constant: '<S65>/Constant1'
   *  Constant: '<S65>/Constant2'
   *  Constant: '<S65>/Constant3'
   *  Constant: '<S65>/Constant4'
   *  Constant: '<S65>/Constant5'
   *  Constant: '<S65>/Constant6'
   *  Constant: '<S65>/Constant7'
   *  Constant: '<S65>/Constant8'
   *  Constant: '<S74>/Constant1'
   *  Constant: '<S74>/Constant2'
   *  Constant: '<S74>/Constant3'
   *  Constant: '<S74>/Constant4'
   *  Constant: '<S74>/Constant5'
   *  Constant: '<S74>/Constant6'
   *  Constant: '<S74>/Constant7'
   *  Constant: '<S74>/Constant8'
   *  Inport: '<Root>/com_CellVoltMin'
   */
  if (rtb_LogicalOperator1 && rtb_Merge_f) {
    /* Outputs for Atomic SubSystem: '<S65>/SRC_Check' */
    BMS_MON_SRC_Check(false, SWC_CellVoltMin, CellVoltSigASRCHigh,
                      CellVoltSigASRCLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_p,
                      &BMS_MON_DWork.SRC_Check_p);

    /* End of Outputs for SubSystem: '<S65>/SRC_Check' */

    /* Logic: '<S64>/Logical Operator1' incorporates:
     *  Constant: '<S65>/Constant1'
     *  Constant: '<S65>/Constant2'
     *  Constant: '<S65>/Constant3'
     *  Constant: '<S65>/Constant4'
     *  Constant: '<S65>/Constant5'
     *  Constant: '<S65>/Constant6'
     *  Constant: '<S65>/Constant7'
     *  Constant: '<S65>/Constant8'
     *  DataStoreRead: '<S64>/Data Store Read'
     *  Inport: '<Root>/com_CellVoltMin'
     *  Logic: '<S64>/Logical Operator4'
     */
    rtb_LogicalOperator1 = ((BMS_MON_B.SRC_Check_p.SRC_Tmp_Def_Flag != 0) &&
      (!BMS_MON_DWork.Dem_stClear_he));

    /* Switch: '<S60>/Switch2' incorporates:
     *  Constant: '<S60>/Constant4'
     *  DataStoreRead: '<S60>/Data Store Read1'
     *  Logic: '<S60>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_he) {
      rtb_Switch_ja = BMS_MON_B.SRC_Check_p.SRC_Def_Status;
    } else {
      rtb_Switch_ja = SRC_NON_DEF;
    }

    /* End of Switch: '<S60>/Switch2' */

    /* Switch: '<S60>/Switch' incorporates:
     *  Constant: '<S60>/Constant4'
     *  RelationalOperator: '<S60>/Relational Operator1'
     */
    if (rtb_Switch_ja != SRC_NON_DEF) {
      rtb_Switch = BMS_MON_B.SRC_Check_p.SRC_Def_Status;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S60>/Switch' */

    /* Outputs for Atomic SubSystem: '<S74>/SRC_Check' */
    BMS_MON_SRC_Check(false, SWC_CellVoltMin, CellVoltSigASRCTooHigh,
                      CellVoltSigASRCTooLow, BmsSigASRCHighPosDeb,
                      BmsSigASRCHighNegDeb, BmsSigASRCLowPosDeb,
                      BmsSigASRCLowNegDeb, StepTim, &BMS_MON_B.SRC_Check_m,
                      &BMS_MON_DWork.SRC_Check_m);

    /* End of Outputs for SubSystem: '<S74>/SRC_Check' */

    /* SwitchCase: '<S68>/Switch Case' incorporates:
     *  Constant: '<S68>/Constant1'
     *  Constant: '<S68>/Constant2'
     *  Constant: '<S68>/Constant4'
     *  Constant: '<S74>/Constant1'
     *  Constant: '<S74>/Constant2'
     *  Constant: '<S74>/Constant3'
     *  Constant: '<S74>/Constant4'
     *  Constant: '<S74>/Constant5'
     *  Constant: '<S74>/Constant6'
     *  Constant: '<S74>/Constant7'
     *  Constant: '<S74>/Constant8'
     *  Inport: '<Root>/com_CellVoltMin'
     */
    switch ((int32_T)BMS_MON_B.SRC_Check_m.SRC_Def_Status) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S68>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S71>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge_c);

      /* End of Outputs for SubSystem: '<S68>/Switch Case Action Subsystem' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S68>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S72>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge_c);

      /* End of Outputs for SubSystem: '<S68>/Switch Case Action Subsystem1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S68>/Switch Case Action Subsystem2' incorporates:
       *  ActionPort: '<S73>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge_c);

      /* End of Outputs for SubSystem: '<S68>/Switch Case Action Subsystem2' */
      break;
    }

    /* End of SwitchCase: '<S68>/Switch Case' */

    /* Switch: '<S59>/Switch2' incorporates:
     *  Constant: '<S59>/Constant4'
     *  DataStoreRead: '<S59>/Data Store Read1'
     *  Logic: '<S59>/Logical Operator3'
     */
    if (!BMS_MON_DWork.Dem_stClear_cy) {
      rtb_Switch_ja = BMS_MON_B.Merge_c;
    } else {
      rtb_Switch_ja = SRC_NON_DEF;
    }

    /* End of Switch: '<S59>/Switch2' */

    /* Switch: '<S59>/Switch' incorporates:
     *  Constant: '<S59>/Constant4'
     *  RelationalOperator: '<S59>/Relational Operator1'
     */
    if (rtb_Switch_ja != SRC_NON_DEF) {
      rtb_Switch_ja = BMS_MON_B.Merge_c;
    } else {
      rtb_Switch_ja = SRC_NON_DEF;
    }

    /* End of Switch: '<S59>/Switch' */

    /* If: '<S58>/If Abnormal' incorporates:
     *  DataStoreRead: '<S70>/Data Store Read'
     *  Inport: '<Root>/com_CellVoltMin'
     *  Logic: '<S70>/Logical Operator1'
     *  Logic: '<S70>/Logical Operator4'
     */
    if (rtb_Switch_ja != 0) {
      /* Outputs for IfAction SubSystem: '<S58>/If Abnormal Action Subsystem' incorporates:
       *  ActionPort: '<S61>/Action Port'
       */
      BMS_M_IfAbnormalActionSubsystem((BMS_MON_B.SRC_Check_m.SRC_Tmp_Def_Flag !=
        0) && (!BMS_MON_DWork.Dem_stClear_cy), SWC_CellVoltMin, rtb_Switch_ja,
        &rtb_Merge_f, &rtb_Merge, &BMS_MON_B.Merge2_pa);

      /* End of Outputs for SubSystem: '<S58>/If Abnormal Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S58>/If Normal Action Subsystem' incorporates:
       *  ActionPort: '<S62>/Action Port'
       */
      BMS_M_IfAbnormalActionSubsystem(rtb_LogicalOperator1, SWC_CellVoltMin,
        rtb_Switch, &rtb_Merge_f, &rtb_Merge, &BMS_MON_B.Merge2_pa);

      /* End of Outputs for SubSystem: '<S58>/If Normal Action Subsystem' */
    }

    /* End of If: '<S58>/If Abnormal' */
  }

  /* End of Logic: '<S7>/Logical Operator2' */
  /* End of Outputs for SubSystem: '<S7>/Temp_CV_Check' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
