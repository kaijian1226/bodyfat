function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/soc_soh */
	this.urlHashMap["soc_logic:2"] = "soc_logic_private.h:95";
	/* <Root>/soc_ocv */
	this.urlHashMap["soc_logic:5"] = "soc_logic_private.h:96";
	/* <Root>/soc_temp */
	this.urlHashMap["soc_logic:6"] = "soc_logic.c:664&soc_logic_private.h:97";
	/* <Root>/soc_fullChrgFlg */
	this.urlHashMap["soc_logic:7"] = "soc_logic.c:698&soc_logic_private.h:98";
	/* <Root>/soc_current */
	this.urlHashMap["soc_logic:8"] = "soc_logic.c:616,635,658,688&soc_logic_private.h:99";
	/* <Root>/soc_lastCapacity */
	this.urlHashMap["soc_logic:251"] = "soc_logic.c:670,705&soc_logic_private.h:100";
	/* <Root>/soc_fullCapacity */
	this.urlHashMap["soc_logic:381"] = "soc_logic.c:697,720,735,741";
	/* <S1>/Soc_Calculation */
	this.urlHashMap["soc_logic:21"] = "soc_logic.c:593,756";
	/* <S2>/Delay */
	this.urlHashMap["soc_logic:325"] = "soc_logic.c:611";
	/* <S2>/OCV_Map */
	this.urlHashMap["soc_logic:47"] = "soc_logic.c:595,596";
	/* <S2>/Product */
	this.urlHashMap["soc_logic:195"] = "msg=rtwMsg_notTraceable&block=soc_logic/Soc/Soc_Calculation/Product";
	/* <S2>/Product1 */
	this.urlHashMap["soc_logic:241"] = "soc_logic.c:734";
	/* <S2>/Product2 */
	this.urlHashMap["soc_logic:254"] = "soc_logic.c:740";
	/* <S2>/Saturation */
	this.urlHashMap["soc_logic:243"] = "soc_logic.c:746,755";
	/* <S2>/Soc_calculation */
	this.urlHashMap["soc_logic:160"] = "soc_logic.c:685,732";
	/* <S2>/Soc_fac_cal */
	this.urlHashMap["soc_logic:262"] = "soc_logic.c:609,683";
	/* <S2>/rate_capacity */
	this.urlHashMap["soc_logic:196"] = "msg=rtwMsg_notTraceable&block=soc_logic/Soc/Soc_Calculation/rate_capacity";
	/* <S3>/Add */
	this.urlHashMap["soc_logic:201"] = "soc_logic.c:703";
	/* <S3>/Capacity_zero */
	this.urlHashMap["soc_logic:327"] = "soc_logic.c:711";
	/* <S3>/CurrentCorFac */
	this.urlHashMap["soc_logic:239"] = "soc_logic.c:692";
	/* <S3>/CurrentMulti */
	this.urlHashMap["soc_logic:223"] = "soc_logic.c:686";
	/* <S3>/Data Type Conversion */
	this.urlHashMap["soc_logic:253"] = "soc_logic.c:704";
	/* <S3>/MinMax */
	this.urlHashMap["soc_logic:228"] = "soc_logic.c:719,728";
	/* <S3>/MinMax1 */
	this.urlHashMap["soc_logic:326"] = "soc_logic.c:710,717";
	/* <S3>/Switch_FullCharg */
	this.urlHashMap["soc_logic:247"] = "soc_logic.c:696,731";
	/* <S3>/sampleTime */
	this.urlHashMap["soc_logic:225"] = "soc_logic.c:687";
	/* <S4>/Add */
	this.urlHashMap["soc_logic:286"] = "soc_logic.c:610";
	/* <S4>/Constant */
	this.urlHashMap["soc_logic:310"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=soc_logic/Soc/Soc_Calculation/Soc_fac_cal/Constant";
	/* <S4>/Constant1 */
	this.urlHashMap["soc_logic:313"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=soc_logic/Soc/Soc_Calculation/Soc_fac_cal/Constant1";
	/* <S4>/Constant2 */
	this.urlHashMap["soc_logic:316"] = "soc_logic.c:646";
	/* <S4>/Constant3 */
	this.urlHashMap["soc_logic:319"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=soc_logic/Soc/Soc_Calculation/Soc_fac_cal/Constant3";
	/* <S4>/Constant4 */
	this.urlHashMap["soc_logic:320"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=soc_logic/Soc/Soc_Calculation/Soc_fac_cal/Constant4";
	/* <S4>/Constant5 */
	this.urlHashMap["soc_logic:324"] = "soc_logic.c:627";
	/* <S4>/CurrentCorFac */
	this.urlHashMap["soc_logic:270"] = "soc_logic.c:675&soc_logic_private.h:94";
	/* <S4>/CurrentMulti */
	this.urlHashMap["soc_logic:271"] = "soc_logic.c:653&soc_logic_private.h:90";
	/* <S4>/Logical
Operator */
	this.urlHashMap["soc_logic:314"] = "soc_logic.c:636";
	/* <S4>/Logical
Operator1 */
	this.urlHashMap["soc_logic:321"] = "soc_logic.c:617";
	/* <S4>/Relational
Operator */
	this.urlHashMap["soc_logic:285"] = "soc_logic.c:637";
	/* <S4>/Relational
Operator1 */
	this.urlHashMap["soc_logic:312"] = "soc_logic.c:638";
	/* <S4>/Relational
Operator2 */
	this.urlHashMap["soc_logic:317"] = "soc_logic.c:618";
	/* <S4>/Relational
Operator3 */
	this.urlHashMap["soc_logic:318"] = "soc_logic.c:619";
	/* <S4>/SocCorFac */
	this.urlHashMap["soc_logic:275"] = "soc_logic.c:676";
	/* <S4>/Soc_ChargeDiffCurv */
	this.urlHashMap["soc_logic:315"] = "soc_logic.c:641,645";
	/* <S4>/Soc_CurrentCurv */
	this.urlHashMap["soc_logic:276"] = "soc_logic.c:657&soc_logic_private.h:91";
	/* <S4>/Soc_DisChargeDiffCurv */
	this.urlHashMap["soc_logic:322"] = "soc_logic.c:622,626";
	/* <S4>/Soc_SocCurv */
	this.urlHashMap["soc_logic:277"] = "soc_logic.c:669&soc_logic_private.h:93";
	/* <S4>/Soc_TempCurv */
	this.urlHashMap["soc_logic:278"] = "soc_logic.c:663&soc_logic_private.h:92";
	/* <S4>/Switch_FullCharg1 */
	this.urlHashMap["soc_logic:311"] = "soc_logic.c:634,651";
	/* <S4>/Switch_FullCharg2 */
	this.urlHashMap["soc_logic:323"] = "soc_logic.c:615,632";
	/* <S4>/TempCorFac */
	this.urlHashMap["soc_logic:280"] = "soc_logic.c:677";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "soc_logic"};
	this.sidHashMap["soc_logic"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "soc_logic:9"};
	this.sidHashMap["soc_logic:9"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "soc_logic:21"};
	this.sidHashMap["soc_logic:21"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "soc_logic:160"};
	this.sidHashMap["soc_logic:160"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "soc_logic:262"};
	this.sidHashMap["soc_logic:262"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<Root>/soc_soh"] = {sid: "soc_logic:2"};
	this.sidHashMap["soc_logic:2"] = {rtwname: "<Root>/soc_soh"};
	this.rtwnameHashMap["<Root>/soc_ocv"] = {sid: "soc_logic:5"};
	this.sidHashMap["soc_logic:5"] = {rtwname: "<Root>/soc_ocv"};
	this.rtwnameHashMap["<Root>/soc_temp"] = {sid: "soc_logic:6"};
	this.sidHashMap["soc_logic:6"] = {rtwname: "<Root>/soc_temp"};
	this.rtwnameHashMap["<Root>/soc_fullChrgFlg"] = {sid: "soc_logic:7"};
	this.sidHashMap["soc_logic:7"] = {rtwname: "<Root>/soc_fullChrgFlg"};
	this.rtwnameHashMap["<Root>/soc_current"] = {sid: "soc_logic:8"};
	this.sidHashMap["soc_logic:8"] = {rtwname: "<Root>/soc_current"};
	this.rtwnameHashMap["<Root>/soc_lastCapacity"] = {sid: "soc_logic:251"};
	this.sidHashMap["soc_logic:251"] = {rtwname: "<Root>/soc_lastCapacity"};
	this.rtwnameHashMap["<Root>/soc_fullCapacity"] = {sid: "soc_logic:381"};
	this.sidHashMap["soc_logic:381"] = {rtwname: "<Root>/soc_fullCapacity"};
	this.rtwnameHashMap["<Root>/Soc"] = {sid: "soc_logic:9"};
	this.sidHashMap["soc_logic:9"] = {rtwname: "<Root>/Soc"};
	this.rtwnameHashMap["<Root>/soc_capacity "] = {sid: "soc_logic:142"};
	this.sidHashMap["soc_logic:142"] = {rtwname: "<Root>/soc_capacity "};
	this.rtwnameHashMap["<Root>/soc_percent"] = {sid: "soc_logic:144"};
	this.sidHashMap["soc_logic:144"] = {rtwname: "<Root>/soc_percent"};
	this.rtwnameHashMap["<Root>/soc_ocvCapacity"] = {sid: "soc_logic:257"};
	this.sidHashMap["soc_logic:257"] = {rtwname: "<Root>/soc_ocvCapacity"};
	this.rtwnameHashMap["<S1>/soc_soh"] = {sid: "soc_logic:11"};
	this.sidHashMap["soc_logic:11"] = {rtwname: "<S1>/soc_soh"};
	this.rtwnameHashMap["<S1>/soc_ocv"] = {sid: "soc_logic:14"};
	this.sidHashMap["soc_logic:14"] = {rtwname: "<S1>/soc_ocv"};
	this.rtwnameHashMap["<S1>/soc_temp"] = {sid: "soc_logic:15"};
	this.sidHashMap["soc_logic:15"] = {rtwname: "<S1>/soc_temp"};
	this.rtwnameHashMap["<S1>/soc_fullChrgFlg"] = {sid: "soc_logic:16"};
	this.sidHashMap["soc_logic:16"] = {rtwname: "<S1>/soc_fullChrgFlg"};
	this.rtwnameHashMap["<S1>/soc_current"] = {sid: "soc_logic:17"};
	this.sidHashMap["soc_logic:17"] = {rtwname: "<S1>/soc_current"};
	this.rtwnameHashMap["<S1>/soc_lastCapacity"] = {sid: "soc_logic:141"};
	this.sidHashMap["soc_logic:141"] = {rtwname: "<S1>/soc_lastCapacity"};
	this.rtwnameHashMap["<S1>/soc_fullCapacity"] = {sid: "soc_logic:379"};
	this.sidHashMap["soc_logic:379"] = {rtwname: "<S1>/soc_fullCapacity"};
	this.rtwnameHashMap["<S1>/Soc_Calculation"] = {sid: "soc_logic:21"};
	this.sidHashMap["soc_logic:21"] = {rtwname: "<S1>/Soc_Calculation"};
	this.rtwnameHashMap["<S1>/Terminator"] = {sid: "soc_logic:252"};
	this.sidHashMap["soc_logic:252"] = {rtwname: "<S1>/Terminator"};
	this.rtwnameHashMap["<S1>/soc_capacity "] = {sid: "soc_logic:145"};
	this.sidHashMap["soc_logic:145"] = {rtwname: "<S1>/soc_capacity "};
	this.rtwnameHashMap["<S1>/soc_percent"] = {sid: "soc_logic:147"};
	this.sidHashMap["soc_logic:147"] = {rtwname: "<S1>/soc_percent"};
	this.rtwnameHashMap["<S1>/soc_ocvCapacity"] = {sid: "soc_logic:256"};
	this.sidHashMap["soc_logic:256"] = {rtwname: "<S1>/soc_ocvCapacity"};
	this.rtwnameHashMap["<S2>/soc_soh"] = {sid: "soc_logic:22"};
	this.sidHashMap["soc_logic:22"] = {rtwname: "<S2>/soc_soh"};
	this.rtwnameHashMap["<S2>/soc_ocv"] = {sid: "soc_logic:25"};
	this.sidHashMap["soc_logic:25"] = {rtwname: "<S2>/soc_ocv"};
	this.rtwnameHashMap["<S2>/soc_temp"] = {sid: "soc_logic:26"};
	this.sidHashMap["soc_logic:26"] = {rtwname: "<S2>/soc_temp"};
	this.rtwnameHashMap["<S2>/soc_fullChrgFlg"] = {sid: "soc_logic:148"};
	this.sidHashMap["soc_logic:148"] = {rtwname: "<S2>/soc_fullChrgFlg"};
	this.rtwnameHashMap["<S2>/soc_current"] = {sid: "soc_logic:149"};
	this.sidHashMap["soc_logic:149"] = {rtwname: "<S2>/soc_current"};
	this.rtwnameHashMap["<S2>/soc_lastCapacity"] = {sid: "soc_logic:150"};
	this.sidHashMap["soc_logic:150"] = {rtwname: "<S2>/soc_lastCapacity"};
	this.rtwnameHashMap["<S2>/soc_fullCapacity"] = {sid: "soc_logic:380"};
	this.sidHashMap["soc_logic:380"] = {rtwname: "<S2>/soc_fullCapacity"};
	this.rtwnameHashMap["<S2>/Delay"] = {sid: "soc_logic:325"};
	this.sidHashMap["soc_logic:325"] = {rtwname: "<S2>/Delay"};
	this.rtwnameHashMap["<S2>/OCV_Map"] = {sid: "soc_logic:47"};
	this.sidHashMap["soc_logic:47"] = {rtwname: "<S2>/OCV_Map"};
	this.rtwnameHashMap["<S2>/Product"] = {sid: "soc_logic:195"};
	this.sidHashMap["soc_logic:195"] = {rtwname: "<S2>/Product"};
	this.rtwnameHashMap["<S2>/Product1"] = {sid: "soc_logic:241"};
	this.sidHashMap["soc_logic:241"] = {rtwname: "<S2>/Product1"};
	this.rtwnameHashMap["<S2>/Product2"] = {sid: "soc_logic:254"};
	this.sidHashMap["soc_logic:254"] = {rtwname: "<S2>/Product2"};
	this.rtwnameHashMap["<S2>/Saturation"] = {sid: "soc_logic:243"};
	this.sidHashMap["soc_logic:243"] = {rtwname: "<S2>/Saturation"};
	this.rtwnameHashMap["<S2>/Soc_calculation"] = {sid: "soc_logic:160"};
	this.sidHashMap["soc_logic:160"] = {rtwname: "<S2>/Soc_calculation"};
	this.rtwnameHashMap["<S2>/Soc_fac_cal"] = {sid: "soc_logic:262"};
	this.sidHashMap["soc_logic:262"] = {rtwname: "<S2>/Soc_fac_cal"};
	this.rtwnameHashMap["<S2>/Terminator"] = {sid: "soc_logic:383"};
	this.sidHashMap["soc_logic:383"] = {rtwname: "<S2>/Terminator"};
	this.rtwnameHashMap["<S2>/rate_capacity"] = {sid: "soc_logic:196"};
	this.sidHashMap["soc_logic:196"] = {rtwname: "<S2>/rate_capacity"};
	this.rtwnameHashMap["<S2>/soc_capacity "] = {sid: "soc_logic:191"};
	this.sidHashMap["soc_logic:191"] = {rtwname: "<S2>/soc_capacity "};
	this.rtwnameHashMap["<S2>/soc_percent"] = {sid: "soc_logic:193"};
	this.sidHashMap["soc_logic:193"] = {rtwname: "<S2>/soc_percent"};
	this.rtwnameHashMap["<S2>/soc_ocvPercent"] = {sid: "soc_logic:198"};
	this.sidHashMap["soc_logic:198"] = {rtwname: "<S2>/soc_ocvPercent"};
	this.rtwnameHashMap["<S2>/soc_ocvCapacity"] = {sid: "soc_logic:255"};
	this.sidHashMap["soc_logic:255"] = {rtwname: "<S2>/soc_ocvCapacity"};
	this.rtwnameHashMap["<S3>/soc_fac_All"] = {sid: "soc_logic:231"};
	this.sidHashMap["soc_logic:231"] = {rtwname: "<S3>/soc_fac_All"};
	this.rtwnameHashMap["<S3>/soc_current"] = {sid: "soc_logic:161"};
	this.sidHashMap["soc_logic:161"] = {rtwname: "<S3>/soc_current"};
	this.rtwnameHashMap["<S3>/soc_lastCapacity"] = {sid: "soc_logic:199"};
	this.sidHashMap["soc_logic:199"] = {rtwname: "<S3>/soc_lastCapacity"};
	this.rtwnameHashMap["<S3>/soc_fullChrgFlg"] = {sid: "soc_logic:248"};
	this.sidHashMap["soc_logic:248"] = {rtwname: "<S3>/soc_fullChrgFlg"};
	this.rtwnameHashMap["<S3>/soc_fullCapacity"] = {sid: "soc_logic:232"};
	this.sidHashMap["soc_logic:232"] = {rtwname: "<S3>/soc_fullCapacity"};
	this.rtwnameHashMap["<S3>/Add"] = {sid: "soc_logic:201"};
	this.sidHashMap["soc_logic:201"] = {rtwname: "<S3>/Add"};
	this.rtwnameHashMap["<S3>/Capacity_zero"] = {sid: "soc_logic:327"};
	this.sidHashMap["soc_logic:327"] = {rtwname: "<S3>/Capacity_zero"};
	this.rtwnameHashMap["<S3>/CurrentCorFac"] = {sid: "soc_logic:239"};
	this.sidHashMap["soc_logic:239"] = {rtwname: "<S3>/CurrentCorFac"};
	this.rtwnameHashMap["<S3>/CurrentMulti"] = {sid: "soc_logic:223"};
	this.sidHashMap["soc_logic:223"] = {rtwname: "<S3>/CurrentMulti"};
	this.rtwnameHashMap["<S3>/Data Type Conversion"] = {sid: "soc_logic:253"};
	this.sidHashMap["soc_logic:253"] = {rtwname: "<S3>/Data Type Conversion"};
	this.rtwnameHashMap["<S3>/MinMax"] = {sid: "soc_logic:228"};
	this.sidHashMap["soc_logic:228"] = {rtwname: "<S3>/MinMax"};
	this.rtwnameHashMap["<S3>/MinMax1"] = {sid: "soc_logic:326"};
	this.sidHashMap["soc_logic:326"] = {rtwname: "<S3>/MinMax1"};
	this.rtwnameHashMap["<S3>/Switch_FullCharg"] = {sid: "soc_logic:247"};
	this.sidHashMap["soc_logic:247"] = {rtwname: "<S3>/Switch_FullCharg"};
	this.rtwnameHashMap["<S3>/sampleTime"] = {sid: "soc_logic:225"};
	this.sidHashMap["soc_logic:225"] = {rtwname: "<S3>/sampleTime"};
	this.rtwnameHashMap["<S3>/soc_chargCapacity"] = {sid: "soc_logic:240"};
	this.sidHashMap["soc_logic:240"] = {rtwname: "<S3>/soc_chargCapacity"};
	this.rtwnameHashMap["<S4>/soc_ocvPercent"] = {sid: "soc_logic:268"};
	this.sidHashMap["soc_logic:268"] = {rtwname: "<S4>/soc_ocvPercent"};
	this.rtwnameHashMap["<S4>/soc_temp"] = {sid: "soc_logic:263"};
	this.sidHashMap["soc_logic:263"] = {rtwname: "<S4>/soc_temp"};
	this.rtwnameHashMap["<S4>/soc_Percent"] = {sid: "soc_logic:267"};
	this.sidHashMap["soc_logic:267"] = {rtwname: "<S4>/soc_Percent"};
	this.rtwnameHashMap["<S4>/soc_lastCapacity"] = {sid: "soc_logic:265"};
	this.sidHashMap["soc_logic:265"] = {rtwname: "<S4>/soc_lastCapacity"};
	this.rtwnameHashMap["<S4>/soc_current"] = {sid: "soc_logic:264"};
	this.sidHashMap["soc_logic:264"] = {rtwname: "<S4>/soc_current"};
	this.rtwnameHashMap["<S4>/Add"] = {sid: "soc_logic:286"};
	this.sidHashMap["soc_logic:286"] = {rtwname: "<S4>/Add"};
	this.rtwnameHashMap["<S4>/Constant"] = {sid: "soc_logic:310"};
	this.sidHashMap["soc_logic:310"] = {rtwname: "<S4>/Constant"};
	this.rtwnameHashMap["<S4>/Constant1"] = {sid: "soc_logic:313"};
	this.sidHashMap["soc_logic:313"] = {rtwname: "<S4>/Constant1"};
	this.rtwnameHashMap["<S4>/Constant2"] = {sid: "soc_logic:316"};
	this.sidHashMap["soc_logic:316"] = {rtwname: "<S4>/Constant2"};
	this.rtwnameHashMap["<S4>/Constant3"] = {sid: "soc_logic:319"};
	this.sidHashMap["soc_logic:319"] = {rtwname: "<S4>/Constant3"};
	this.rtwnameHashMap["<S4>/Constant4"] = {sid: "soc_logic:320"};
	this.sidHashMap["soc_logic:320"] = {rtwname: "<S4>/Constant4"};
	this.rtwnameHashMap["<S4>/Constant5"] = {sid: "soc_logic:324"};
	this.sidHashMap["soc_logic:324"] = {rtwname: "<S4>/Constant5"};
	this.rtwnameHashMap["<S4>/CurrentCorFac"] = {sid: "soc_logic:270"};
	this.sidHashMap["soc_logic:270"] = {rtwname: "<S4>/CurrentCorFac"};
	this.rtwnameHashMap["<S4>/CurrentMulti"] = {sid: "soc_logic:271"};
	this.sidHashMap["soc_logic:271"] = {rtwname: "<S4>/CurrentMulti"};
	this.rtwnameHashMap["<S4>/Logical Operator"] = {sid: "soc_logic:314"};
	this.sidHashMap["soc_logic:314"] = {rtwname: "<S4>/Logical Operator"};
	this.rtwnameHashMap["<S4>/Logical Operator1"] = {sid: "soc_logic:321"};
	this.sidHashMap["soc_logic:321"] = {rtwname: "<S4>/Logical Operator1"};
	this.rtwnameHashMap["<S4>/Relational Operator"] = {sid: "soc_logic:285"};
	this.sidHashMap["soc_logic:285"] = {rtwname: "<S4>/Relational Operator"};
	this.rtwnameHashMap["<S4>/Relational Operator1"] = {sid: "soc_logic:312"};
	this.sidHashMap["soc_logic:312"] = {rtwname: "<S4>/Relational Operator1"};
	this.rtwnameHashMap["<S4>/Relational Operator2"] = {sid: "soc_logic:317"};
	this.sidHashMap["soc_logic:317"] = {rtwname: "<S4>/Relational Operator2"};
	this.rtwnameHashMap["<S4>/Relational Operator3"] = {sid: "soc_logic:318"};
	this.sidHashMap["soc_logic:318"] = {rtwname: "<S4>/Relational Operator3"};
	this.rtwnameHashMap["<S4>/SocCorFac"] = {sid: "soc_logic:275"};
	this.sidHashMap["soc_logic:275"] = {rtwname: "<S4>/SocCorFac"};
	this.rtwnameHashMap["<S4>/Soc_ChargeDiffCurv"] = {sid: "soc_logic:315"};
	this.sidHashMap["soc_logic:315"] = {rtwname: "<S4>/Soc_ChargeDiffCurv"};
	this.rtwnameHashMap["<S4>/Soc_CurrentCurv"] = {sid: "soc_logic:276"};
	this.sidHashMap["soc_logic:276"] = {rtwname: "<S4>/Soc_CurrentCurv"};
	this.rtwnameHashMap["<S4>/Soc_DisChargeDiffCurv"] = {sid: "soc_logic:322"};
	this.sidHashMap["soc_logic:322"] = {rtwname: "<S4>/Soc_DisChargeDiffCurv"};
	this.rtwnameHashMap["<S4>/Soc_SocCurv"] = {sid: "soc_logic:277"};
	this.sidHashMap["soc_logic:277"] = {rtwname: "<S4>/Soc_SocCurv"};
	this.rtwnameHashMap["<S4>/Soc_TempCurv"] = {sid: "soc_logic:278"};
	this.sidHashMap["soc_logic:278"] = {rtwname: "<S4>/Soc_TempCurv"};
	this.rtwnameHashMap["<S4>/Switch_FullCharg1"] = {sid: "soc_logic:311"};
	this.sidHashMap["soc_logic:311"] = {rtwname: "<S4>/Switch_FullCharg1"};
	this.rtwnameHashMap["<S4>/Switch_FullCharg2"] = {sid: "soc_logic:323"};
	this.sidHashMap["soc_logic:323"] = {rtwname: "<S4>/Switch_FullCharg2"};
	this.rtwnameHashMap["<S4>/TempCorFac"] = {sid: "soc_logic:280"};
	this.sidHashMap["soc_logic:280"] = {rtwname: "<S4>/TempCorFac"};
	this.rtwnameHashMap["<S4>/soc_fac_all"] = {sid: "soc_logic:283"};
	this.sidHashMap["soc_logic:283"] = {rtwname: "<S4>/soc_fac_all"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
