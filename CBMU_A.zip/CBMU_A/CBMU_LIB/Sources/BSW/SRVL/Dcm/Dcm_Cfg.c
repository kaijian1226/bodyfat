/*******************************************************************************
*
*  FILE
*     Dcm_Cfg.c���ͨѶ����
*
*  DESCRIPTION
*    Configuration Source File for Dcm   
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.2.1
*  DATE: 2014-01-06  
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Dcm.h"
#include "Dcm_Appl.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/
/* Table of all state transitions  */
CONST(Dcm_StateInfoType,DCM_CONST) Dcm_StateGroupTransition_C[DCM_STATE_NO_TRANSITION][2] = 
{
  { { 0x0F, 0x02, 0x00 }, { 0x01, 0x01, 0x00 } }, 
  { { 0x0F, 0x02, 0x00 }, { 0x08, 0x01, 0x00 } }, 
  { { 0x0F, 0x02, 0x00 }, { 0x02, 0x01, 0x00 } }, 
  { { 0x0F, 0x02, 0x00 }, { 0x04, 0x01, 0x00 } }, 
  { { 0x00, 0x01, 0x00 }, { 0x00, 0x02, 0x00 } }
};

/* Table of reference indexes for fast SID look-up. */


CONST(Dcm_MsgItemType,DCM_CONST) Dcm_SidMap_C[DCM_SID_MAP_SIZE] = 
{
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0x00, 0x01, 0xFF, 0xFF, 0x02, 0xFF, 0xFF, 0x03, 0xFF, 0x04, 0x05, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0x06, 0x07, 0xFF, 0xFF, 0xFF, 0x08, 0x09, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0x0A, 0xFF, 0x0B, 0x0C, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x0D, 0xFF,
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x0E 
};

/* Table of service ID relevant information. */
CONST(Dcm_SvcHeadType,DCM_CONST) Dcm_SvcHead_C[DCM_SVC_HEAD_ITEMS_NUM] = 
{

/* Request HeadEx length up to 7 (After service ID which is subfunction)           */
/*   | Response HeadEx length up to 7                                              */
/*   |   | resOnReq 0x00: No   0x01: Yes                                      */
/*   |   |  |  isReqHeadExtEchoed 0x00: No   0x01: Yes (depend on previous Service) */
/*   |   |  |    | isSubFuncInstanced 0x00: No   0x01: Yes                */
/*   |   |  |    |  | svcHeadPlaceHolder                                  */
/*   |   |  |    |  |   |    checkSessionState                            */
/*   |   |  |    |  |   |      | sessionPlaceHolder                       */
/*   |   |  |    |  |   |      |    |  svcInstFirstItem                   */
/*   |   |  |    |  |   |      |    |     |  svcInstHeadExtFirstItem      */
/*   |   |  |    |  |   |      |    |     |   |                           */
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00,  0,  0 } /* $10 */,
  {  1, 1, 0x01, 1, 0, 0x00, 0x0F, 0x00,  4,  4 } /* $11 */, 
  {  1, 1, 0x01, 1, 0, 0x00, 0x0F, 0x00,  5,  5 } /* $14 */, 
  {  0, 0, 0x01, 1, 0, 0x00, 0x0F, 0x00,  6,  6 } /* $17 */, 
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00,  7,  6 } /* $19 */,
  
  {  0, 0, 0x01, 1, 0, 0x00, 0x0F, 0x00, 10,  9 } /* $1A */, 
  {  0, 0, 0x01, 1, 0, 0x00, 0x0F, 0x00, 11,  9 } /* $22 */, 
  {  0, 0, 0x01, 1, 0, 0x00, 0x0F, 0x00, 12,  9 } /* $23 */, 
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00, 13,  9 }  /* $27 */,
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00, 15,  11 } /* $28 */, //add by zuo 
  
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00, 17,  13 } /* $34 */, //add by zuo,2012-12-16 
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00, 18,  14 } /* $36 */, //add by zuo,2012-12-16 
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00, 19,  15 } /* $37 */, //add by zuo,2012-12-16 
  
  
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00, 20,  16 } /* $3E */, 
  {  1, 1, 0x01, 1, 1, 0x00, 0x0F, 0x00, 21,  17 } /* $85 */, //added
  {  0, 0, 0x00, 1, 0, 0x00, 0x00, 0x00, 23,  19 } /* $FF */
};
/* Table of service (instance) relevant information. */
CONST(Dcm_SvcInstType,DCM_CONST) Dcm_SvcInst_C[DCM_SVC_INSTANCE_ITEMS_NUM] = 
{
/* Req Length,                                                                       */
/*    |     ResOnReq (0x00: No   0x01: Yes)                                          */
/*    |     | stateSession                                                           */
/*    |     |   |    stateSecurityAccess                                             */
/*    |     |   |      |  stateGap_0                                                 */
/*    |     |   |      |     |     setStateIndex,                                    */
/*    |     |   |      |     |        |                          MainHandler         */

  {   2,  0x01, { 0x0F, 0x03, 0x00 }, 0,                        Dcm_ApplStartDefaultSession } /* $10 $01 */, 
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, 1,                        Dcm_ApplStartEOLSession }     /* $10 $83 */, 
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, 2,                        Dcm_ApplStartProgSession }    /* $10 $85 */,// -> $10 $02
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, 3,                        Dcm_ApplStartDevSession }     /* $10 $03 */, 
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplResetPowerOn }        /* $11 $01 */, 
  
  {   4,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplClearFaultMemory }    /* $14 $FF*/,
  {   3,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplReadStatusOfDTC }     /* $17 */,
  {   3,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplReportNumberOfDTC }   /* $19 $1 */, 
  {   3,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplReadAllDTC}           /* $19 $2 */, 
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplReportDTCSnapshotID } /* $19 $3 */, 
  //Not fullfilled and used
  
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplReadECUId }           /* $1A */, 
  {   3,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplReadDataByLocalID }   /* $22 $A0 */, 
  {   5,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplReadMemoryByAddr }    /* $23 */, 
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplReqSeedLvl1 }         /* $27 $1 */, 
  {   6,  0x01, { 0x0F, 0x03, 0x00 }, 4,                        Dcm_ApplSendKeyLvl1 }         /* $27 $2 */,
  
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplEnableRxAndTx }       /* $28 $0 */,
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplDisableRxAndTx }      /* $28 $3 */,
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplRequestDownload }     /* $34 $0 */,
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplTransferData }        /* $36 $0 */,
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_ApplRequestTransferExit } /* $37 $0 */,
  
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_DcmTesterPresent }        /* $3E $0*/,
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_DTCControlSetON }         /* $85 $01 */,
  {   2,  0x01, { 0x0F, 0x03, 0x00 }, DCM_STATE_NO_TRANSITION,  Dcm_DTCControlSetOFF }        /* $85 $01 */
};


/* Table of sub-service protocol information. */

CONST(Dcm_MsgItemType,DCM_CONST) Dcm_SvcInstHeadExt_C[DCM_SVC_HEAD_EXT_ITEMS_NUM] = 
{
 // 0x01, 0x83, 0x85, 0x03 /* $10 */, //modified
  0x01, 0x83, 0x02, 0x03,  /* $10 */
  0x01,                    /* $11 */
  0xFF,                    /* $14 */
  0x01, 0x02, 0x03,        /* $19 */ 
  0x03, 0x04,              /* $27 */
  0x00, 0x03,              /* $28 */
  0x00,                    /* $34 */
  0x00,                    /* $36 */
  0x00,                    /* $37 */ 
  0x00,                    /* $3E */
  0x01,0x02                /* $85, sub-function 0x00~0xFF*/
};




/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/



/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

