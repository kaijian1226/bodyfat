/*******************************************************************************
*
*  FILE
*     Mcu.c
*
*  DESCRIPTION
*     Mcu (Interrupt disable and restore, clock initialization) 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.2
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Mcu.h"
#include "Det.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/  
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
VAR(boolean,MCU_VAR) mcu_ClkInitError;
VAR(uint8,MCU_VAR) mcu_SavedGlbIntBit;
VAR(uint8,MCU_VAR) mcu_SavedGlbIntBitNested;
VAR(uint8,MCU_VAR) mcu_GlbIntDisableCnt;

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ VAR(uint16,MCU_VAR) mcu_PllSetUpTime;
_STATIC_ VAR(uint16,MCU_VAR) mcu_PllHwLoopTimer;

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ FUNC(Std_ReturnType,MCU_CODE) Mcu_InitClock(void);
/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/



/****************************************************************************
* NAME:             Mcu_SuspendAllInterrupt
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    None
* DESCRIPTION:           
****************************************************************************/
#define MCU_START_SEC_CODE_NEAR
#include "MemMap.h"

FUNC(void,MCU_CODE_NEAR) Mcu_SuspendAllInterrupt(void)   //��ͣ�����ж�
{   

#if (MCU_DEV_ERROR_DETECT == STD_ON)  
  if (mcu_GlbIntDisableCnt >= 0xFF)                                                               
  {    
    Det_ReportError(MCU_MODULE_ID,MCU_INSTATNCE_ID,MCU_API_SUSPENDINT_ID,MCU_E_INT_CNT_TOO_BIG);
  }
#endif

   if (mcu_GlbIntDisableCnt == 0)
   {
      asm
      {
         tfr ccr,a
         sei
         staa  mcu_SavedGlbIntBitNested
      }
   }
   mcu_GlbIntDisableCnt++;
}

#define MCU_STOP_SEC_CODE_NEAR
#include "MemMap.h"

/****************************************************************************
* NAME:             Mcu_RestoreGlobalInterrupt
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    None
* DESCRIPTION:           
****************************************************************************/
#define MCU_START_SEC_CODE_NEAR
#include "MemMap.h"

FUNC(void,MCU_CODE_NEAR) Mcu_ResumeAllInterrupt(void)
{  
#if (MCU_DEV_ERROR_DETECT == STD_ON)  
  if (mcu_GlbIntDisableCnt == 0)                                                               
  {    
    Det_ReportError(MCU_MODULE_ID,MCU_INSTATNCE_ID,MCU_API_RESUMEINT_ID,MCU_E_INT_CNT_NOT_CORRECT);
  }
#endif

   mcu_GlbIntDisableCnt--;
   if (mcu_GlbIntDisableCnt == 0)
   {                              
      asm
      {
         ldaa  mcu_SavedGlbIntBitNested
         tfr a, ccr
      }
   }  
}

#define MCU_STOP_SEC_CODE_NEAR
#include "MemMap.h"


/****************************************************************************
* NAME:             Mcu_Init
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* RETURN VALUES:    void
* DESCRIPTION:      Initialize Mcu  
****************************************************************************/
FUNC(void,MCU_CODE)Mcu_Init(void)
{  
#if (MCU_CLOCK_SETTING == MCU_CLOCK_NO_PLL)
  mcu_ClkInitError = E_OK;
#else
  mcu_ClkInitError = Mcu_InitClock();
#endif
  /* must be put after PLL setting, otherwise PLL setting fail */
  MCU_DIRECT = MCU_DIRECT_PAGE;
  
#if (MCU_STOP_MODE_SUPPORT ==  STD_ON)
  
  /* Clear the STOP disable Bit in CCR */
  __asm ANDCC #0x7F;
  
#endif  
}

/****************************************************************************
* NAME:             Mcu_GetVersionInfo
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Std_VersionInfoType *versioninfo
* RETURN VALUES:    void
* DESCRIPTION:      Service to get version information     
****************************************************************************/
FUNC(void,MCU_CODE) Mcu_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
  versioninfo->vendorID = MCU_VENDOR_ID;
  versioninfo->moduleID = MCU_MODULE_ID;
  versioninfo->sw_major_version = MCU_SW_MAJOR_VERSION;
  versioninfo->sw_minor_version = MCU_SW_MINOR_VERSION;
  versioninfo->sw_patch_version = MCU_SW_PATCH_VERSION;
} 

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/


/****************************************************************************
* NAME:             Mcu_InitClock
* CALLED BY:        StartUp
* PRECONDITIONS:    
* INPUT PARAMETERS: None
* RETURN VALUES:    Std_ReturnType
* DESCRIPTION:      Initialize Clock     
****************************************************************************/
_STATIC_ FUNC(Std_ReturnType,MCU_CODE) Mcu_InitClock(void)
{
#if (MCU_CLOCK_SETTING == MCU_CLOCK_PLL_40)
  MCU_SYNR = 0x49;    
  MCU_REFDV = 0x40;   
  MCU_POSTDIV = 0x00;

  for (mcu_PllSetUpTime = 0; mcu_PllSetUpTime < MCU_PLL_SETUP_UPLIMIT; mcu_PllSetUpTime++)
  {  
    mcu_PllHwLoopTimer = 100;
    while ((!(MCU_CRGFLG & MCU_CRGFLG_LOCK_MASK)) && (mcu_PllHwLoopTimer--));
    if (mcu_PllHwLoopTimer != 0)
    {      
      MCU_CLKSEL |= MCU_CLKSEL_PLLSEL_MASK;
    }
    /* it may happen the LOCK status */
    if (MCU_CRGFLG & MCU_CRGFLG_LOCK_MASK)
    {
      break;
    }
  }    

  if (mcu_PllSetUpTime >= MCU_PLL_SETUP_UPLIMIT)
  {
    return (E_NOT_OK); 
  }
  else 
  {
    return (E_OK);
  }              
#else
  return (E_OK);
#endif
}





