/*******************************************************************************
*
*  FILE
*     TLE8104.c
*
*  DESCRIPTION
*      
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "TLE8104.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define TLE8014_ECHO_CMD            0xA0
#define TLE8014_OR_DIAG_CMD         0x30 
#define TLE8014_DIAG_ONLY_CMD       0x00
#define TLE8014_AND_DIAG_CMD        0xF0 
#define TLE8014_RDBK_1BIT_DIAG_CMD  0xC0 

/*******************************************************************************
* Macros                                                                
*******************************************************************************/
#define TLE8104_SENDING_CMD_RB     0
#define TLE8104_RECV_DATA_RB       1
#define TLE8104_SENDING_CMD_DIAG   2
#define TLE8104_RECV_DATA_DIAG     3


#define TLE8104_DIAG_ONLY_STG      0
#define TLE8104_DIAG_ONLY_OC       1
#define TLE8104_DIAG_ONLY_OT       2
#define TLE8104_DIAG_ONLY_NORMAL   3


/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/
const uint8 tle8104_mask[4] = 
{
  0x3,0xC,0x30,0xC0
};

const uint8 tle8104_mask1[4] = 
{
  0x10,0x20,0x40,0x80
};

const uint8 tle8104_ocMask[4]=
{
  0x01,0x04,0x10,0x40
};

const uint8 tle8104_otMask[4]=
{
  0x02,0x08,0x20,0x80
};

const uint8 tle8104_Andmask[4] = 
{
  0xFE,0xFD,0xFB,0xF7
};

const uint8 tle8104_Ormask[4] = 
{
  0x1,0x2,0x4,0x8
};

const uint8 tle8104_ClrAllReq[4] = 
{
  0xEE,0xDD,0xBB,0x77
};

const uint8 tle8104_SetShutDownReq[4] = 
{
  0x01,0x02,0x04,0x08
};

const uint8 tle8104_SetForceOnReq[4] = 
{
  0x10,0x20,0x40,0x80
};

const uint8 tle8104_Priority_C[TLE8104_MODULE_NUM][TLE8104_CH_NUM] =
{
  {
    0x1,0x2,0x3,0x5
  },
  {
   0x1,0x2,0x3,0x5
  },
  {
   0x1,0x2,0x3,0x5
  },    
};

const boolean tle8104_used_C[TLE8104_MODULE_NUM] =
{
  FALSE,TRUE,FALSE    
};

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
uint8 TLE8104_VAR tle8104_ErrorSts[TLE8104_MODULE_NUM][TLE8104_CH_NUM];
uint8 TLE8104_VAR tle8104_ErrRdnsSts[TLE8104_MODULE_NUM][TLE8104_CH_NUM];
uint8 TLE8104_VAR tle8104_InputSts[TLE8104_MODULE_NUM];
uint8 TLE8104_VAR tle8104_OutputSts[TLE8104_MODULE_NUM];
uint8 TLE8104_VAR tle8104_RdSts[TLE8104_MODULE_NUM];
uint8 TLE8104_VAR tle8104_SpiSts[TLE8104_MODULE_NUM];

uint16 tle8104_failCnt[TLE8104_MODULE_NUM];
uint16 tle8104_okCnt[TLE8104_MODULE_NUM];
uint16 tle8104_initCnt[TLE8104_MODULE_NUM];
boolean tle8104_FaultPinSts[TLE8104_MODULE_NUM];


uint8 tle8104_AndOp[TLE8104_MODULE_NUM];
uint8 tle8104_OrOp[TLE8104_MODULE_NUM];

uint8 tle8104_CmdReq[TLE8104_MODULE_NUM];
uint8 tle8104_CmdFinal[TLE8104_MODULE_NUM];
uint8 tle8104_CmdLast[TLE8104_MODULE_NUM];
//boolean tle8104_ShutDownReq[TLE8104_MODULE_NUM][TLE8104_CH_NUM];
//boolean tle8104_ForceOnReq[TLE8104_MODULE_NUM][TLE8104_CH_NUM];

  /* 360 around 100us, */
uint16 tle8104_delayCnt_C = 360;

uint8 tle8104_currSts[TLE8104_MODULE_NUM];


/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ Std_ReturnType TLE8104_CODE Tle8104_Echo(uint8 tleCh,uint8 EchoData);
_STATIC_ Std_ReturnType TLE8104_CODE Tle8104_DiagSimpleCmd(uint8 tleCh,Tle8104_DiagCmdType cmd);
_STATIC_ Std_ReturnType TLE8104_CODE Tle8104_DiagOpCmd(uint8 tleCh,Tle8104_DiagCmdType cmd,uint8 oprtr);

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Tle8104_Init
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: void
* RETURN VALUES:    Std_ReturnType
* DESCRIPTION:      Tle8104 Echo and OR function of SPI   
*******************************************************************************/

void TLE8104_CODE Tle8104_Init(void)
{
  uint8 RxData;
  uint8 index;

  /*Initialize the reset and fault port */
  
  /*
  TLE8104_M0_RESET_DDR |= TLE8104_M0_RESET_MASK;
  TLE8104_M1_RESET_DDR |= TLE8104_M1_RESET_MASK;
  TLE8104_M2_RESET_DDR |= TLE8104_M2_RESET_MASK;

  TLE8104_M0_RESET_PORT |= TLE8104_M0_RESET_MASK;
  TLE8104_M1_RESET_PORT |= TLE8104_M1_RESET_MASK;
  TLE8104_M2_RESET_PORT |= TLE8104_M2_RESET_MASK;
  */
  
  TLE8104_M0_FAULT_DDR &= ~TLE8104_M0_FAULT_MASK;
  TLE8104_M1_FAULT_DDR &= ~TLE8104_M1_FAULT_MASK;
  TLE8104_M2_FAULT_DDR &= ~TLE8104_M2_FAULT_MASK;

  for (index = 0; index <TLE8104_MODULE_NUM; index++)
  {    
    if (tle8104_used_C[index] == TRUE)
    {
      tle8104_AndOp[index] = 0xF;
      tle8104_OrOp[index] = 0x0;

      Spi_Init(index);

      do
      {
        tle8104_initCnt[index]++;
        if(Tle8104_Echo(index,0x55) == E_NOT_OK) 
        {
          tle8104_currSts[index] = TLE8104_INIT_ERR;
        }else if (Tle8104_Echo(index,0xAA) == E_NOT_OK) 
        {
          tle8104_currSts[index] = TLE8104_INIT_ERR;
        }
        // for Echo Command influence, has to call OR command or AND command to resume      
        else if (Tle8104_DiagOpCmd(index,TLE8104_OR_DIAG,0) == E_NOT_OK)
        {
          tle8104_currSts[index] = TLE8104_INIT_ERR;
          break;  
        }
        else if (Spi_RWByte(index,0,&RxData)== E_NOT_OK)
        {
          tle8104_currSts[index] = TLE8104_INIT_ERR;
        }else 
        {          
          tle8104_currSts[index] = TLE8104_SENDING_CMD_RB;
        }
      }while((tle8104_currSts[index] == TLE8104_INIT_ERR)&&(tle8104_initCnt[index]<TLE8104_INIT_MAX_TIME));    
      
      if (tle8104_currSts[index] == TLE8104_INIT_ERR)
      {
        tle8104_SpiSts[index] = TLE8104_SPI_INIT_ERR; 
         
      }
    }
  }
  TLE8104_PORT_INIT();
}
/*
  // delay to read the correct status
  for (count =0; count< tle8104_delayCnt_C; count++)
  {
  }
*/



void TLE8104_CODE Tle8104_ReadDiagDataTask(void)
{
  uint8 index;
  uint16 count;
  uint8 RxData;
   
  for (index = 0; index <TLE8104_MODULE_NUM; index++)
  {
    if (tle8104_used_C[index] == TRUE)
    {
      if (tle8104_currSts[index] == TLE8104_RECV_DATA_DIAG)
      {      
        if (Spi_RWByte(index,0,&RxData)== E_OK)
        {
          for (count = 0; count <TLE8104_CH_NUM; count++)  
          {
            if (tle8104_OutputSts[index] & tle8104_mask1[count]) 
            {
              tle8104_ErrRdnsSts[index][count] |= TLE8104_OT; 
              if ((RxData & tle8104_mask[count]) == tle8104_mask[count])
              {
                tle8104_ErrorSts[index][count]  &= (~TLE8104_OT); 
              }else if ((RxData & tle8104_mask[count]) == tle8104_otMask[count])
              {
                tle8104_ErrorSts[index][count] |= (TLE8104_OT); 
              }
                
            }else
            {
              tle8104_ErrRdnsSts[index][count] |= TLE8104_STG; 
              tle8104_ErrRdnsSts[index][count] |= TLE8104_OC; 
              if ((RxData & tle8104_mask[count]) == tle8104_mask[count])
              {
                tle8104_ErrorSts[index][count] &= (~TLE8104_OC); 
                tle8104_ErrorSts[index][count] &= (~TLE8104_STG); 
              }
              // stg is all zero, so it's special
              else if ((RxData & tle8104_mask[count]) == TLE8104_DIAG_ONLY_STG)
              {
                tle8104_ErrorSts[index][count] |= TLE8104_STG;  
              }else if ((RxData & tle8104_mask[count]) == tle8104_ocMask[count])
              {
                tle8104_ErrorSts[index][count] |= TLE8104_OC; 
              }           
            }
          }
        }//if (Spi_RWByte(index,0,&RxData)== E_OK)
        else
        {
          tle8104_failCnt[index]++;          
        }      
        tle8104_currSts[index] = TLE8104_SENDING_CMD_RB;
      }    
    }
   
  }             
}


void TLE8104_CODE Tle8104_StartDiagTask(void)
{
  uint8 index;
  uint16 count;
  uint8 RxData;
   
  if (TLE8104_M0_FAULT_PORT & TLE8104_M0_FAULT_MASK)
  {
    tle8104_FaultPinSts[0] = TRUE;
  }else
  {
    tle8104_FaultPinSts[0] = FALSE;
  }
  
  if (TLE8104_M1_FAULT_PORT & TLE8104_M1_FAULT_MASK)
  {
    tle8104_FaultPinSts[1] = TRUE;
  }else
  {
    tle8104_FaultPinSts[1] = FALSE;
  }
  
  if (TLE8104_M2_FAULT_PORT & TLE8104_M2_FAULT_MASK)
  {
    tle8104_FaultPinSts[2] = TRUE;
  }else
  {
    tle8104_FaultPinSts[2] = FALSE;
  }  
    
  for (index = 0; index <TLE8104_MODULE_NUM; index++)
  {      
    if (tle8104_used_C[index] == TRUE)
    {
      switch(tle8104_currSts[index])
      {
        case TLE8104_SPI_ERR:
        case TLE8104_INIT_ERR:
        {
          // do nothing if SPI Init Error
        }
        break;

        case TLE8104_SENDING_CMD_RB:
        {          
          // First analyse command request
          if ((tle8104_CmdReq[index]&0xF)&&(tle8104_CmdReq[index]&0xF0))
          {
            uint8 shutDownPriority;
            uint8 forceOnPriority;
            uint8 ch;
            
            shutDownPriority = 0;
            forceOnPriority = 0;
            
            // search the max priority
            for (ch = 0; ch<4; ch++)
            {
              if (tle8104_CmdReq[index]&tle8104_SetShutDownReq[ch])
              {
                if (tle8104_Priority_C[index][ch] > shutDownPriority)
                {
                  shutDownPriority = tle8104_Priority_C[index][ch];  
                }
              }else if (tle8104_CmdReq[index]&tle8104_SetForceOnReq[ch])
              {
                if (tle8104_Priority_C[index][ch] > shutDownPriority)
                {
                  forceOnPriority = tle8104_Priority_C[index][ch];  
                }              
              }
            }
            
            if (shutDownPriority > forceOnPriority)
            {
              tle8104_CmdFinal[index] = tle8104_CmdReq[index] & 0xF;  
            }else if (shutDownPriority < forceOnPriority)
            {
              tle8104_CmdFinal[index] = tle8104_CmdReq[index] & 0xF0;
            }else
            {
              tle8104_CmdFinal[index] = tle8104_CmdReq[index] & TLE8104_DEFAULT_CMD;
            }          
          }else
          {
            tle8104_CmdFinal[index] = tle8104_CmdReq[index];
          }
          
          // Force Output
          if (tle8104_CmdFinal[index] != tle8104_CmdLast[index])
          {
            if (tle8104_CmdFinal[index] == 0)
            {
              if (Tle8104_DiagOpCmd(index,TLE8104_OR_DIAG,0) == E_OK)
              {
                if (Spi_RWByte(index,0,&RxData)== E_OK)
                {
                  tle8104_CmdLast[index] = tle8104_CmdFinal[index];  
                }           
              }
            }
            /* only ShutDown Request*/
            else if (tle8104_CmdReq[index] <= 0xF)
            {
              tle8104_AndOp[index] = ~tle8104_CmdReq[index];
              if (Tle8104_DiagOpCmd(index,TLE8104_AND_DIAG,tle8104_AndOp[index]) == E_OK)
              {
                if (Spi_RWByte(index,0,&RxData)== E_OK)
                {
                  tle8104_CmdLast[index] = tle8104_CmdFinal[index];   
                }           
              }            
            }else
            {
              tle8104_OrOp[index] = tle8104_CmdReq[index]>>4;
              if (Tle8104_DiagOpCmd(index,TLE8104_OR_DIAG,tle8104_OrOp[index]) == E_OK)
              {
                if (Spi_RWByte(index,0,&RxData)== E_OK)
                {
                  tle8104_CmdLast[index] = tle8104_CmdFinal[index];   
                }           
              }             
            }
          }
          
          // Start Diag Cmd
          if (Tle8104_DiagSimpleCmd(index,TLE8104_RDBK_1BIT_DIAG) == E_OK)
          {
            /* Read back input immediately*/
            if (Spi_RWByte(index,0,&tle8104_RdSts[index])== E_OK)
            {
              
              for (count = 0; count <TLE8104_CH_NUM; count++)
              {
                if ((tle8104_RdSts[index] & tle8104_mask1[count]) == (tle8104_InputSts[index] & tle8104_mask1[count])) 
                {              
                  if ((tle8104_InputSts[index] & tle8104_mask1[count])  == 0)
                  {                
                    tle8104_ErrorSts[index][count] &= (~TLE8104_WON); 
                    tle8104_ErrRdnsSts[index][count] |= TLE8104_WON; 
                  }else
                  {
                    tle8104_ErrorSts[index][count] &= (~TLE8104_WOFF);
                    tle8104_ErrRdnsSts[index][count] |= TLE8104_WOFF; 
                  }               
                  
                }else
                {
                  /* clear all other fault bit */
                  tle8104_ErrorSts[index][count] &= 0xF8;
                  if ((tle8104_InputSts[index] & tle8104_mask1[count])  == 0)
                  {                
                    tle8104_ErrorSts[index][count] |= (TLE8104_WON);
                    tle8104_ErrRdnsSts[index][count] |= TLE8104_WON;   
                  }else
                  {
                    tle8104_ErrorSts[index][count] |= (TLE8104_WOFF);
                    tle8104_ErrRdnsSts[index][count] |= TLE8104_WOFF;  
                  }
                }              
              }
              tle8104_OutputSts[index] = (tle8104_RdSts[index] & (tle8104_AndOp[index]<<4)) |(tle8104_OrOp[index]<<4); 
                

              /* send diag only command */
              if (Tle8104_DiagSimpleCmd(index,TLE8104_DIAG_ONLY) == E_OK)
              {
                tle8104_currSts[index] = TLE8104_RECV_DATA_DIAG;  
                
                tle8104_okCnt[index]++;

              }//if (Tle8104_DiagSimpleCmd(index,TLE8104_DIAG_ONLY) == E_OK)


            }//if (Spi_RWByte(index,0,&RxData)== E_OK)             
            else
            {
              tle8104_failCnt[index]++;          
            }   

          }//if (Tle8104_DiagSimpleCmd(index,TLE8104_RDBK_1BIT_DIAG) == E_OK)
          
          // if the SPI fault count is too much, change to error state
          if (tle8104_failCnt[index] > TLE8104_SPI_ERR_LIMIT)
          {
            tle8104_currSts[index] = TLE8104_SPI_ERR; 
            tle8104_SpiSts[index] = TLE8104_SPI_KO;
          }else if (tle8104_failCnt[index] == 0)
          {
            
            if (tle8104_okCnt[index] > TLE8104_SPI_OK_LIMIT)
            {
              tle8104_SpiSts[index] = TLE8104_SPI_OK;
            }
            
          }

        }
        break;
            
        default:
        break;
      
      }//switch
    
    }
    
  }//for

      
}

void TLE8104_CODE Tle8104_Output(uint8 moduleNum, uint8 ChSts)
{
  /*
  if ((tle8104_currSts[moduleNum] & TLE8104_FAULT_MASK) != 0)
  {
    return;
  }
  */
  tle8104_InputSts[moduleNum] = ChSts;
   
  if (moduleNum == 0)
  {
    if (ChSts & tle8104_mask1[0])
    {
      TLE8104_ACTIVATE_M0C0(); 
    }else
    {
      TLE8104_DEACTIVATE_M0C0();
    }
    
    if (ChSts & tle8104_mask1[1])
    {
      TLE8104_ACTIVATE_M0C1(); 
    }else
    {
      TLE8104_DEACTIVATE_M0C1();
    }

    if (ChSts & tle8104_mask1[2])
    {
      TLE8104_ACTIVATE_M0C2(); 
    }else
    {
      TLE8104_DEACTIVATE_M0C2();
    }

    if (ChSts & tle8104_mask1[3])
    {
      TLE8104_ACTIVATE_M0C3(); 
    }else
    {
      TLE8104_DEACTIVATE_M0C3();
    }
    
  }else if (moduleNum == 1)
  {
    if (ChSts & tle8104_mask1[0])
    {
      TLE8104_ACTIVATE_M1C0(); 
    }else
    {
      TLE8104_DEACTIVATE_M1C0();
    }
    
    if (ChSts & tle8104_mask1[1])
    {
      TLE8104_ACTIVATE_M1C1(); 
    }else
    {
      TLE8104_DEACTIVATE_M1C1();
    }

    if (ChSts & tle8104_mask1[2])
    {
      TLE8104_ACTIVATE_M1C2(); 
    }else
    {
      TLE8104_DEACTIVATE_M1C2();
    }

    if (ChSts & tle8104_mask1[3])
    {
      TLE8104_ACTIVATE_M1C3(); 
    }else
    {
      TLE8104_DEACTIVATE_M1C3();
    }  
  }else if (moduleNum == 2)
  {
    if (ChSts & tle8104_mask1[0])
    {
      TLE8104_ACTIVATE_M2C0(); 
    }else
    {
      TLE8104_DEACTIVATE_M2C0();
    }
    
    if (ChSts & tle8104_mask1[1])
    {
      TLE8104_ACTIVATE_M2C1(); 
    }else
    {
      TLE8104_DEACTIVATE_M2C1();
    }

    if (ChSts & tle8104_mask1[2])
    {
      TLE8104_ACTIVATE_M2C2(); 
    }else
    {
      TLE8104_DEACTIVATE_M2C2();
    }

    if (ChSts & tle8104_mask1[3])
    {
      TLE8104_ACTIVATE_M2C3(); 
    }else
    {
      TLE8104_DEACTIVATE_M2C3();
    } 
  }
}

Std_ReturnType TLE8104_CODE Tle8104_CmdReq(uint8 tleCh,uint8 ch,uint8 cmd)
{
  if ((tle8104_currSts[tleCh] & TLE8104_FAULT_MASK) != 0)
  {
    return E_NOT_OK;
  }
  
  if (cmd == TLE8104_CMD_RESUME)
  {
    tle8104_CmdReq[tleCh] &= tle8104_ClrAllReq[ch];
  }else if (cmd == TLE8104_CMD_SHUTDOWN)
  {
    tle8104_CmdReq[tleCh] |= tle8104_SetShutDownReq[ch]; 
    tle8104_CmdReq[tleCh] &= (~tle8104_SetForceOnReq[ch]);      
  }else if (cmd == TLE8104_CMD_FORCEON)
  {
    tle8104_CmdReq[tleCh] |= tle8104_SetForceOnReq[ch]; 
    tle8104_CmdReq[tleCh] &= (~tle8104_SetShutDownReq[ch]);     
  }else
  {
    return E_NOT_OK;
  }
  
  return E_OK;
    
}



/*******************************************************************************
* NAME:             Tle8104_DiagCmd
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Tle8104_DiagCmdType cmd
*                   uint8* DiagDataPtr
*                   uint8 oprtr
* RETURN VALUES:    E_OK or E_NOT_OK
* DESCRIPTION:      Tle8104 Diagnosis function 
*******************************************************************************/
_STATIC_ Std_ReturnType TLE8104_CODE Tle8104_DiagSimpleCmd(uint8 tleCh,Tle8104_DiagCmdType cmd) 
{
  uint8 Rxdata;

  switch (cmd)
  {
    case TLE8104_DIAG_ONLY:
    {
      if(Spi_RWByte(tleCh,TLE8014_DIAG_ONLY_CMD,&Rxdata) == E_NOT_OK) 
      {
        tle8104_failCnt[tleCh]++;
        return E_NOT_OK;
      }    
    }
    break;
    
    case TLE8104_RDBK_1BIT_DIAG:
    {
      if(Spi_RWByte(tleCh,TLE8014_RDBK_1BIT_DIAG_CMD,&Rxdata) == E_NOT_OK) 
      {
        tle8104_failCnt[tleCh]++;
        return E_NOT_OK;
      }     
    }break;

    default:
      return E_NOT_OK;
    break;    
  }
   
  return E_OK;    
}


_STATIC_ Std_ReturnType TLE8104_CODE Tle8104_DiagOpCmd(uint8 tleCh,Tle8104_DiagCmdType cmd,uint8 oprtr) 
{
  uint8 Rxdata;

  switch (cmd)
  {
    case TLE8104_OR_DIAG:
    {
      if(Spi_RWByte(tleCh,TLE8014_OR_DIAG_CMD | oprtr,&Rxdata) == E_NOT_OK) 
      {
        tle8104_failCnt[tleCh]++;
        return E_NOT_OK;
      }
    }
    break;
    
    case TLE8104_AND_DIAG:
    {
      if(Spi_RWByte(tleCh,TLE8014_AND_DIAG_CMD | oprtr,&Rxdata) == E_NOT_OK) 
      {
        tle8104_failCnt[tleCh]++;
        return E_NOT_OK;
      }
    }break;

    default:
      return E_NOT_OK;
    break;    
  }
    
  return E_OK;    
}

/*******************************************************************************
* NAME:             Tle8104_Echo
* CALLED BY:        Tle8104_Init
* PRECONDITIONS:    
* INPUT PARAMETERS: uint8 EchoData 
* RETURN VALUES:    E_OK or E_NOT_OK
* DESCRIPTION:      Tle8104 Echo function of SPI   
*******************************************************************************/
_STATIC_ Std_ReturnType TLE8104_CODE Tle8104_Echo(uint8 tleCh,uint8 EchoData)
{ 
  uint8 RxData;
    
  if(Spi_RWByte(tleCh,TLE8014_ECHO_CMD,&RxData) == E_NOT_OK)
  {
    return E_NOT_OK;
  } 

  if(Spi_RWByte(tleCh,EchoData,&RxData) == E_NOT_OK)
  {
    return E_NOT_OK;
  }  

  if(RxData != EchoData) 
  {
    return E_NOT_OK;
  } 
  
  return E_OK; 
}

