/*******************************************************************************
*
*  FILE
*     Eep_Cfg.h
*
*  DESCRIPTION
*     The Header file for  Eep Configuration  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.2
*
*******************************************************************************/

#ifndef _EEP_CFG_H_
#define _EEP_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

#define EEP_DEV_ERROR_DETECT                            STD_ON
/* SET THE SIZE OF THE EEE HERE */ 

/* x256 bytes ~ can be 0 to 16 */
#define EEP_EEE_SECTORS 16          

#if(EEP_EEE_SECTORS == 1)
   #define EEP_DFPART (128 - 12)
#else
   #define EEP_DFPART (128 - (8 * EEP_EEE_SECTORS))
#endif

/* flash clock divider for 4MHz crystal 
Ref Page 843 of datasheet */
#define EEP_FCLK_DIV   3

#define EEP_DELAY_CNT  50

#define EEP_WAIT_CMD_COMPLETE_TIME    1000
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

#endif   /* #ifndef _EEP_CFG_H_ */