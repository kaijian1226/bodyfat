/*******************************************************************************
*
*  FILE
*     Adc.h
*
*  DESCRIPTION
*      ADC module header file 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.1
*
*******************************************************************************/
#ifndef _ADC_H_
#define _ADC_H_
/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Adc_Cfg.h"
#include "Adc_Types.h" 
/*******************************************************************************
* Defines                                                                
*******************************************************************************/


/* Vendor ID. */
#define ADC_VENDOR_ID           6666

/* Module ID */
#define ADC_MODULE_ID         123

/* Version number of the module */
#define ADC_SW_MAJOR_VERSION    1
#define ADC_SW_MINOR_VERSION    0
#define ADC_SW_PATCH_VERSION    0

#define ADC_INSTANCE_ID       1

#define ADC_API_INITCLK_ID    1

#define ADC_E_WRONG_PARAM     1

#define ATD0CTL1_ETRIGCH0_MASK      1
#define ATD0CTL1_ETRIGCH1_MASK      2
#define ATD0CTL1_ETRIGCH2_MASK      4
#define ATD0CTL1_ETRIGCH3_MASK      8
#define ATD0CTL1_SMP_DIS_MASK       16
#define ATD0CTL1_SRES0_MASK         32
#define ATD0CTL1_SRES1_MASK         64
#define ATD0CTL1_ETRIGSEL_MASK      128
#define ATD0CTL1_ETRIGCH_MASK       15
#define ATD0CTL1_ETRIGCH_BITNUM     0
#define ATD0CTL1_SRES_MASK          96
#define ATD0CTL1_SRES_BITNUM        5

#define ATD1CTL1_ETRIGCH0_MASK      1
#define ATD1CTL1_ETRIGCH1_MASK      2
#define ATD1CTL1_ETRIGCH2_MASK      4
#define ATD1CTL1_ETRIGCH3_MASK      8
#define ATD1CTL1_SMP_DIS_MASK       16
#define ATD1CTL1_SRES0_MASK         32
#define ATD1CTL1_SRES1_MASK         64
#define ATD1CTL1_ETRIGSEL_MASK      128
#define ATD1CTL1_ETRIGCH_MASK       15
#define ATD1CTL1_ETRIGCH_BITNUM     0
#define ATD1CTL1_SRES_MASK          96
#define ATD1CTL1_SRES_BITNUM        5

#define ADC_ATD0CTL0      (*(volatile uint8*) 0x000002C0)    
#define ADC_ATD1CTL0      (*(volatile uint8*) 0x00000080)  
#define ADC_ATD0CTL1      (*(volatile uint8*) 0x000002C1) 
#define ADC_ATD1CTL1      (*(volatile uint8*) 0x00000081)  
#define ADC_ATD0CTL2      (*(volatile uint8*) 0x000002C2)   
#define ADC_ATD1CTL2      (*(volatile uint8*) 0x00000082)  
#define ADC_ATD0CTL3      (*(volatile uint8*) 0x000002C3)   
#define ADC_ATD1CTL3      (*(volatile uint8*) 0x00000083)    
#define ADC_ATD0CTL5      (*(volatile uint8*) 0x000002C5)   
#define ADC_ATD1CTL5      (*(volatile uint8*) 0x00000085)                                  
#define ADC_ATD0DR0_ADDR  ((volatile uint16*) 0x000002D0)
#define ADC_ATD1DR0_ADDR  ((volatile uint16*) 0x00000090)

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
#define ADC_START_SEC_CODE_NEAR
#include "MemMap.h"

extern FUNC(Adc_ResultType,ADC_CODE_NEAR) Adc_Read(Adc_ChannelType channel_id);

#define ADC_STOP_SEC_CODE_NEAR
#include "MemMap.h"

extern FUNC(void,ADC_CODE) Adc_Init(void);

#endif /* #ifndef _ADC_H_ */

      
