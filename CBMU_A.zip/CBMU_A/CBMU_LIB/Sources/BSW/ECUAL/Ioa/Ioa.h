/*******************************************************************************
*
*  FILE
*     Ioa.h
*
*  DESCRIPTION
*     The Header file for IO abstraction
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    0.01
*
*******************************************************************************/

#ifndef _IOA_H_
#define _IOA_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Ioa_Cfg.h"
#include "Ioa_Types.h"

#include "Mcu.h"
#include "Dio.h"
#include "TLE8104.h"
#include "Adc.h"
#include "CanIf.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define CTL_OFF                        0U
#define CTL_ON                         1U
#define CTL_PWM                        2U

#define SHUTDWN_ACTIVE                 0U
#define SHUTDWN_INACTIVE               1U
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern boolean ioa_DisChMRelayCtl;         
extern boolean ioa_ChMRelayCtl;
extern boolean ioa_NegativeRelayCtl;
extern boolean ioa_Resvd1RelayCtl;
extern boolean ioa_Resvd2RelayCtl;

extern boolean ioa_slowChrgEnaCtl;
extern boolean ioa_lowSide1Ctl;
extern boolean ioa_lowSide2Ctl;
extern boolean ioa_lowSide3Ctl;

extern uint16 ioa_T15VoltRaw;
extern uint16 ioa_T15VoltActRaw;
extern uint16 ioa_chrgVoltRaw;
extern uint16 ioa_chrgVoltActRaw;
extern uint16 ioa_battVoltRaw;
extern uint16 ioa_battVoltActRaw;
extern uint16 ioa_vccVoltRaw;
extern uint16 ioa_vccVoltActRaw;
extern uint16 ioa_sensorSplyVoltRaw;
extern uint16 ioa_sensorSplyVoltActRaw;
//new added for B sample 
extern uint16 ioa_12VOutVoltRaw;
extern uint16 ioa_12VOutVoltActRaw;
//new added for B sample 

/* 2013-09-18, Add for C Sample */
extern uint16  ioa_FC12VVoltRaw ;
extern uint16  ioa_FC12VVoltActRaw ; 

extern uint16  ioa_HVILVoltRaw ;
extern uint16  ioa_HVILVoltActRaw; 

extern uint16  ioa_FCCCVoltRaw;
extern uint16  ioa_FCCCVoltActRaw; 

extern uint16  ioa_SCCCVoltRaw;
extern uint16  ioa_SCCCVoltActRaw; 


extern uint16 ioa_gasVoltRaw;
extern uint16 ioa_gasPressureVoltRaw;


extern boolean ioa_12VOut;
extern boolean ioa_5VOut;
extern boolean ioa_PwrOut;

extern boolean ioa_SyncOut;

extern boolean ioa_RedLmpCtl;
extern boolean ioa_GrLmpCtl;

extern boolean ioa_Rly1FdBk;
extern boolean ioa_Rly2FdBk;

extern boolean ioa_OcIn1;
extern boolean ioa_OcIn2;

extern boolean ioa_T15SwtSts;

extern boolean ioa_pingSplyCtl;
extern boolean ioa_fastChrgSplyCtl;
extern boolean ioa_vehSplyCtl;


/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,IOA_CODE) Ioa_Init(void);
extern void IOA_CODE Ioa_Output(void);

extern void IOA_CODE Ioa_ReadAdValue(void);
extern void IOA_CODE Ioa_ReadDigValue(void);
extern void IOA_CODE Ioa_ToggleRedLamp(void);

//////////////////////////////////////////////////////////////////////////////////
//add 20150819
extern boolean ioa_RedLmpCtl;
extern boolean ioa_GrLmpCtl;
extern void IOA_CODE Ioa_Red_Open();
extern void IOA_CODE Ioa_Red_Close();
extern void IOA_CODE Ioa_Gr_Open();
extern void IOA_CODE Ioa_Gr_Close();
extern void IOA_CODE Ioa_ToggleRedLamp(void);
extern void IOA_CODE Ioa_ToggleGrLamp(void);   
  
extern void Ioa_Output_Other(void);



//add 20150819
//���������̵������� 
extern boolean ioa_FanRelayCtl;
extern boolean ioa_AirACRelayCtl;
extern boolean ioa_FCRelayCtl; 
extern boolean ioa_PTCRelayCtrl;
extern boolean ioa_AirPTCRelayCtl;

#endif /* #ifndef _IOA_H_ */
