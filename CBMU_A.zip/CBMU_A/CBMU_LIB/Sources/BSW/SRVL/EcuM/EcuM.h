/*******************************************************************************
*
*  FILE
*     TFT.h
*
*  DESCRIPTION
*     The Header file for EcuM module  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    0.01
*
*******************************************************************************/

#ifndef _ECUM_H_
#define _ECUM_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Platform_Types.h"
#include "Eep.h"
#include "Ioa.h"
#include "VFB.h"
#include "TrpR.h"
#include "Wdg.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
typedef uint8 EcuM_StateType;

extern uint8 ecum_State;

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

extern void ECUM_CODE EcuM_AppReturnNormalRun(void);
extern FUNC(void,ECUM_CODE) EcuM_Init(void);
extern FUNC(void,ECUM_CODE) EcuM_MainFunction(void);

extern FUNC(uint8, ECUM_CODE) EcuM_AppPostRun(void);
  

#endif /* #ifndef _ECUM_H_ */