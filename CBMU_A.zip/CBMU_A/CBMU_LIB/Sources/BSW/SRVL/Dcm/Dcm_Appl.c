/*******************************************************************************
*
*  FILE
*     Dcm_Appl.c
*
*  DESCRIPTION
*     Dcm Application Interface Source Code File  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.2.1
*
*  DATE: 2014-01-06  
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Dcm_Appl.h"

 


/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define PROGRAM_CONST 0xcd3e89fd

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

//const uint8 Dcm_AppSwVersion[12]= {68,70,95,66,77,83,32,67,72,73,78,65};   /* DF_BMS CHINA */
//const uint8 Dcm_SerialNum[12]= {56,56,56,56,56,56,56,56,56,56,56,56};      /* ���кţ�888888888888*/
//const uint8 Dcm_BootSwVersion[12]= {49,46,48,48,48,48,48,48,48,48,48,48};  /* 1.0000000000*/
//const uint8 Dcm_BSWVersion[6]={86,48,49,46,48,55};                         /*���綨�������汾��,V01.07*/
//const uint8 Dcm_BSWDate[6]={49,48,48,56,51,49};                            /*��������:10-08-31*/
//const uint8 Dcm_BSWPartNumber[14]={'Z',1,1,0,0,3,0,'J','-','H',0,1,0,0} ;    /*ECU Part Number*/
//const uint8 Dcm_BSW_VIN[17]={'z'} ;                                  /*VIN:����ʶ�����*/
//const uint8 Dcm_BSW_HardwareNumber[5]={49,48,48,56,51};              /*ECU Hardware Number*/
//const uint8 Dcm_BSW_AppSwNumber[5]={49,48,48,56,51};                 /*ECU Application Software Number*/
//const uint8 Dcm_BSW_CalibrationSwNumber[5]={49,48,48,56,51};         /*ECU Calibration Software Number*/



/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
uint16 AirSplyPRaw;
uint16 CluActrPosnActRaw;
uint8  Dem_DTCSetVailed ;

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ uint8 dcm_SeedForRandSeed;
_STATIC_ uint8 dcm_RandSeed[4];
_STATIC_ uint32 dcm_CalKey;

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ FUNC(uint8,DCM_CODE) Dcm_ApplGetDataFromLocalID \
(Dcm_LocalIdType id,uint8* ptr,uint8 max_length);


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Dcm_ApplStartDefaultSession
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplStartDefaultSession(Dcm_MsgContextType* pMsgContext)
{
	uint8 Dcm_DefaultSessionEnable = DCM_DEFAULT_SESSION_SVR_ENTRY; 
	pMsgContext->resDataLen = 4 ;
  Dcm_ProcessingDone();
}

/*******************************************************************************
* NAME:             Dcm_ApplStartEOLSession
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplStartEOLSession(Dcm_MsgContextType* pMsgContext)
{
  Dcm_ProcessingDone();
}

/*******************************************************************************
* NAME:             Dcm_ApplStartProgSession
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplStartProgSession(Dcm_MsgContextType* pMsgContext)
{
  Dcm_ProcessingDone();
}

/*******************************************************************************
* NAME:             Dcm_ApplStartDevSession
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplStartDevSession(Dcm_MsgContextType* pMsgContext)
{
  Dcm_ProcessingDone();
}

/*******************************************************************************
* NAME:             Dcm_ApplResetPowerOn
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplResetPowerOn(Dcm_MsgContextType* pMsgContext)
{
  Dcm_ProcessingDone();
  /* Jump to reset vector */
  COP_RST_CTL = 2 ;
  COP_RST_ADR = 0x12;      //add zuo ,2013-12-06  
}

/*******************************************************************************
* NAME:             Dcm_ApplClearFaultMemory
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplClearFaultMemory(Dcm_MsgContextType* pMsgContext)
{
  uint16 Id ;
  Id = (*(uint16*)(&pMsgContext->reqData[0]));
  
  if(Id == 0xFFFF)
    {
       Dem_FaultMemClearAll(); 
       pMsgContext->resDataLen = 2 ;
       pMsgContext->resData[0] = 0xFF ;
       pMsgContext->resData[1] = 0xFF ; 
    }else
    {
      // Dcm_SetNegResponse(DCM_E_SUBFUNCTIONNOTSUPPORTED);
       Dcm_SetNegResponse(DCM_E_REQUESTOUTOFRANGE); 
    }
  Dcm_ProcessingDone();
}

/*******************************************************************************
* NAME:             Dcm_ApplReadStatusOfDTC
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplReadStatusOfDTC(Dcm_MsgContextType* pMsgContext)
{
  Dem_EventIdType eventId;
  Dcm_MsgLenType length;
  
  eventId = (Dem_EventIdType)(*(uint16*)(&pMsgContext->reqData[0]));
  
  length = Dem_GetErrorStatus(eventId,&pMsgContext->resData[0]);
  if (length != 0)
  {
    pMsgContext->resDataLen = length;
  }else
  {
    Dcm_SetNegResponse(DCM_E_REQUESTOUTOFRANGE);
  }
  Dcm_ProcessingDone();
}
/*******************************************************************************
* NAME:             Dcm_ApplReadInactiveDTC
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/

/***
FUNC(void,DCM_CODE) Dcm_ApplReadInactiveDTC(Dcm_MsgContextType* pMsgContext)
{
   pMsgContext->resDataLen = Dem_DtcAssembly(&pMsgContext->resData[0],INACTIVE_DTC);
   Dcm_ProcessingDone();
}
***/


/*******************************************************************************
* NAME:             Dcm_ApplReportNumberOfDTC
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
/*
FUNC(void,DCM_CODE) Dcm_ApplReportNumberOfDTC(Dcm_MsgContextType* pMsgContext)
{
  Dem_EventIdType eventId;
  Dcm_MsgLenType length;
  
  eventId = (Dem_EventIdType)(*(uint16*)(&pMsgContext->reqData[0]));
  
  length = Dem_GetErrorStatus(eventId,&pMsgContext->resData[0]);
  if (length != 0)
  {
    pMsgContext->resDataLen = length;
  }else
  {
    Dcm_SetNegResponse(DCM_E_REQUESTOUTOFRANGE);
  }
  Dcm_ProcessingDone();
}
*/

/*******************************************************************************
* NAME:             Dcm_ApplReadActiveDTC
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
/***
FUNC(void,DCM_CODE) Dcm_ApplReadActiveDTC(Dcm_MsgContextType* pMsgContext)
{
  pMsgContext->resDataLen = Dem_DtcAssembly(&pMsgContext->resData[0],ACTIVE_DTC);
  Dcm_ProcessingDone();
}
***/


/*******************************************************************************
* NAME:             Dcm_ApplReportDTC
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplReportDTC(Dcm_MsgContextType* pMsgContext)
{
 // pMsgContext->resDataLen =  Dem_GetDTCTargetStatus(pMsgContext);
  Dem_DtcAssembly(&pMsgContext->resData[0],ACTIVE_DTC); //2103-12-16
  Dcm_ProcessingDone();
}

/*******************************************************************************
* NAME:             Dcm_ApplReadAllDTC
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/

FUNC(void,DCM_CODE) Dcm_ApplReadAllDTC(Dcm_MsgContextType* pMsgContext)
{
  pMsgContext->resDataLen = Dem_DtcAssembly(&pMsgContext->resData[0],REPORT_DTC_STATE);
  Dcm_ProcessingDone();
}


/*******************************************************************************
* NAME:             Dcm_ApplReportDTCSnapshotID
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplReportDTCSnapshotID(Dcm_MsgContextType* pMsgContext)
{
  
  Dcm_ProcessingDone();
}
/*******************************************************************************
* NAME:             Dcm_ApplReadECUId
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplReadECUId(Dcm_MsgContextType* pMsgContext)
{
  switch (pMsgContext->reqData[0])
  {
    uint8 index;
    
    case DCM_READ_ECU_ID_SERIAL_NUM:
    {
      for (index =0;index<sizeof(Dcm_SerialNum);index++)
      {
        pMsgContext->reqData[index]=Dcm_SerialNum[index];   
      }
      pMsgContext->resDataLen = sizeof(Dcm_SerialNum); 
    }
    break;
    
    case DCM_READ_ECU_ID_APPSW_VERSION:
    {
      for (index =0;index<sizeof(Dcm_AppSwVersion);index++)
      {
        pMsgContext->reqData[index]=Dcm_AppSwVersion[index];   
      }
      pMsgContext->resDataLen = sizeof(Dcm_AppSwVersion);
    }
    break;
    
    case DCM_READ_ECU_ID_BOOTSW_VERSION:
    {
      for (index =0;index<sizeof(Dcm_BootSwVersion);index++)
      {
        pMsgContext->reqData[index]=Dcm_BootSwVersion[index];   
      }
      pMsgContext->resDataLen = sizeof(Dcm_BootSwVersion);
    }
    break;     

    case DCM_READ_ECU_ID_BSW_VERSION:
    {
      for (index =0;index<sizeof(Dcm_BSWVersion);index++)
      {
        pMsgContext->reqData[index]=Dcm_BSWVersion[index];   
      }
      pMsgContext->resDataLen = sizeof(Dcm_BSWVersion);
    }
    break; 
    
    case DCM_READ_ECU_ID_BSW_DATE:
    {
      for (index =0;index<sizeof(Dcm_BSWDate);index++)
      {
        pMsgContext->reqData[index]=Dcm_BSWDate[index];   
      }
      pMsgContext->resDataLen = sizeof(Dcm_BSWDate);
    }
    break;     
        
    default:
    {
      Dcm_SetNegResponse(DCM_E_REQUESTOUTOFRANGE);
    }
    break;     
  }
  Dcm_ProcessingDone();
}
/*******************************************************************************
* NAME:             Dcm_ApplReadDataByLocalID
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplReadDataByLocalID(Dcm_MsgContextType* pMsgContext)
{
  uint16 localId;
  
  localId = pMsgContext->reqData[0];
  localId <<= 8;
  localId += pMsgContext->reqData[1];
  
  if(localId < 0xFFFF)
  {
    pMsgContext->resDataLen = Dcm_ApplGetDataFromLocalID(localId,&pMsgContext->resData[0],100);
    if (pMsgContext->resDataLen == 0)
    {
      Dcm_SetNegResponse(DCM_E_REQUESTOUTOFRANGE);  
    }
  
  }
  else
  {
    /* Request contains invalid data - send negative response! */
    Dcm_SetNegResponse(DCM_E_REQUESTOUTOFRANGE);
  }
  Dcm_ProcessingDone();
}
/*******************************************************************************
* NAME:             Dcm_ApplReadMemoryByAddr
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplReadMemoryByAddr(Dcm_MsgContextType* pMsgContext)
{
  uint8 length;
  uint16 memAddr;
  
  length = pMsgContext->reqData[3];

  memAddr = *(uint16 *)(&pMsgContext->reqData[1]);
  
  if ((length != 0)&&(length<=DCM_BUFFER_LENGTH)&&(memAddr >= 0x2000)&&((memAddr+length)<=0x4000))
  {    
	  uint8 idx;
	  uint8* dataPtr;

	  dataPtr = (uint16 *) memAddr;

	  for (idx = 0; idx < length; idx++) { 
		  pMsgContext->resData[idx] = *dataPtr;
		  dataPtr++;     
	  }   
	  pMsgContext->resDataLen    =   length;    
  }   
  else    {
	  Dcm_SetNegResponse(DCM_E_REQUESTOUTOFRANGE);
  } 
  Dcm_ProcessingDone(); 
}

/*******************************************************************************
* NAME:             Dcm_ApplReqSeedLvl1
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplReqSeedLvl1(Dcm_MsgContextType* pMsgContext)
{
  dcm_SeedForRandSeed++;
  srand(dcm_SeedForRandSeed);
  dcm_RandSeed[0] = (uint8) (rand()&0xff);
  if( dcm_RandSeed[0] == 0x00 )
      dcm_RandSeed[0] = 0xea;
  dcm_SeedForRandSeed++;
  srand(dcm_SeedForRandSeed);
  dcm_RandSeed[1] = (uint8) (rand()&0xff);
  dcm_SeedForRandSeed++;
  srand(dcm_SeedForRandSeed);
  dcm_RandSeed[2] = (uint8) (rand()&0xff);
  dcm_SeedForRandSeed++;
  srand(dcm_SeedForRandSeed);
  dcm_RandSeed[3] = (uint8) (rand()&0xff);
  
  pMsgContext->resData[0] = dcm_RandSeed[0];
  pMsgContext->resData[1] = dcm_RandSeed[1];
  pMsgContext->resData[2] = dcm_RandSeed[2];
  pMsgContext->resData[3] = dcm_RandSeed[3];
  /* Always set the correct length of the response data. */
  pMsgContext->resDataLen = 4;
  
  Dcm_ProcessingDone();
}
/*******************************************************************************
* NAME:             Dcm_ApplSendKeyLvl1
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplSendKeyLvl1(Dcm_MsgContextType* pMsgContext)
{
  uint32 revKey;
  uint32 calKey;
  
  revKey = *(uint32*)(&(pMsgContext->reqData[0]));

  dcm_CalKey = ~(*(uint32*)(&dcm_RandSeed[0]));
  dcm_CalKey &= PROGRAM_CONST;
  dcm_CalKey += 0x88;
  
  if(revKey != dcm_CalKey)
  {
    Dcm_SetNegResponse(DCM_E_INVALIDKEY);
  }
  Dcm_ProcessingDone();
}

/*******************************************************************************
* NAME:             Dcm_ApplMainFunction
* CALLED BY:        Scheduler
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_ApplMainFunction(void)
{

}


/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Dcm_ApplResetPowerOn
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_LocalIdType id: Local ID number
*                   uint8* ptr: ptr to data buffer
*                   uint8 max_length: max length of data buffer
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/


_STATIC_ FUNC(uint8,DCM_CODE) Dcm_ApplGetDataFromLocalID \
 (Dcm_LocalIdType id,uint8* ptr,uint8 max_length)
{
   return(App_DCM_Handle(id,ptr,max_length));
}



//!<
//!< 
//!<

/*******************************************************************************
* NAME:             Dcm_ControlDTCSetting
* CALLED BY:        Dcm
* PRECONDITIONS:
* INPUT PARAMETERS: Dcm_MsgContextType* pMsgContext: Message Context
* RETURN VALUES:    Void
* DESCRIPTION:      
*******************************************************************************/
FUNC(void,DCM_CODE) Dcm_DTCControlSetON(Dcm_MsgContextType* pMsgContext)
{
  Dem_DTCSetVailed = TRUE ;    // Turn on DTC setting
  Dcm_ProcessingDone();
}


void DCM_CODE  Dcm_DTCControlSetOFF(Dcm_MsgContextType* pMsgContext)
{
  Dem_DTCSetVailed = FALSE ;   // Turn off DTC setting
  Dcm_ProcessingDone();
}


/*******************************************************************************
* NAME:             Dcm_ApplRequestDownload
* CALLED BY:        Dcm
* PRECONDITIONS:     
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      The requestDownload service is used by the client to initiate 
*                   a data transfer from the client to the server (download). After
*                   the server has received the requestDownload request message the
*                   ECU shall take all necessary actions to receive data before it 
*                   sends a positive response message. 
*******************************************************************************/
void DCM_CODE Dcm_ApplRequestDownload(Dcm_MsgContextType *pMsgContext)
  {
    Dcm_ProcessingDone();
  }

/*******************************************************************************
* NAME:             Dcm_ApplTransferData
* CALLED BY:        Dcm
* PRECONDITIONS:     
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      The transferData service is used by the client to transfer data 
*                   either from the client to the server (download) or from the server
*                   to the client (upload).The data transfer direction is defined by 
*                   the preceding requestDownload or requestUpload service. 
*******************************************************************************/
void DCM_CODE Dcm_ApplTransferData(Dcm_MsgContextType *pMsgContext)
  {
    Dcm_ProcessingDone();
  }

/*******************************************************************************
* NAME:             Dcm_ApplRequestTransferExit
* CALLED BY:        Dcm
* PRECONDITIONS:     
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      This service is used by the client to terminate a data transfer
*                   between client and server. 
*******************************************************************************/
void DCM_CODE Dcm_ApplRequestTransferExit(Dcm_MsgContextType *pMsgContext)
  {
    Dcm_ProcessingDone();
  }

