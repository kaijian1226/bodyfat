#define MEMMAP_ERROR 

/* CODE NEAR */

#if defined MCU_START_SEC_CODE_NEAR
  #undef MCU_START_SEC_CODE_NEAR
  #define START_SECTION_CODE_NEAR

#elif defined MCU_STOP_SEC_CODE_NEAR
  #undef MCU_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR
  
#elif defined CAN_START_SEC_CODE_NEAR
  #undef CAN_START_SEC_CODE_NEAR
  #define START_SECTION_CODE_NEAR

#elif defined CAN_STOP_SEC_CODE_NEAR
  #undef CAN_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR   

#elif defined ADC_START_SEC_CODE_NEAR
  #undef ADC_START_SEC_CODE_NEAR
  #define START_SECTION_CODE_NEAR

#elif defined ADC_STOP_SEC_CODE_NEAR
  #undef ADC_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR   

#elif defined GPT_START_SEC_CODE_NEAR
  #undef GPT_START_SEC_CODE_NEAR
  #define START_SECTION_CODE_NEAR

#elif defined PBS_START_SEC_CODE_NEAR
  #undef PBS_START_SEC_CODE_NEAR  
  #define START_SECTION_CODE_NEAR
  
#elif defined PBS_STOP_SEC_CODE_NEAR
  #undef PBS_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR
  
#elif defined GPT_STOP_SEC_CODE_NEAR
  #undef GPT_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR 
  
#elif defined PWM_START_SEC_CODE_NEAR
  #undef PWM_START_SEC_CODE_NEAR
  #define START_SECTION_CODE_NEAR

#elif defined PWM_STOP_SEC_CODE_NEAR
  #undef PWM_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR   
    
#elif defined OS_START_SEC_CODE_NEAR
  #undef OS_START_SEC_CODE_NEAR
  #define START_SECTION_CODE_NEAR

#elif defined OS_STOP_SEC_CODE_NEAR
  #undef OS_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR  

#elif defined ICU_START_SEC_CODE_NEAR
  #undef ICU_START_SEC_CODE_NEAR
  #define START_SECTION_CODE_NEAR

#elif defined ICU_STOP_SEC_CODE_NEAR
  #undef ICU_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR  

#elif defined IOA_START_SEC_CODE_NEAR
  #undef IOA_START_SEC_CODE_NEAR
  #define START_SECTION_CODE_NEAR

#elif defined IOA_STOP_SEC_CODE_NEAR
  #undef IOA_STOP_SEC_CODE_NEAR
  #define STOP_SECTION_CODE_NEAR  
      
/* VECTOR TABLE */
#elif defined OS_START_SEC_VECT_TBL
  #undef OS_START_SEC_VECT_TBL
  #define START_SEC_VECT_TBL 
  
#elif defined OS_STOP_SEC_VECT_TBL
  #undef OS_STOP_SEC_VECT_TBL
  #define STOP_SEC_VECT_TBL

/* XGATE CODE */
#elif defined XGATE_START_SEC_CODE
  #undef XGATE_START_SEC_CODE
  #define START_SEC_XGATE_CODE
  
#elif defined XGATE_STOP_SEC_CODE
  #undef XGATE_STOP_SEC_CODE
  #define STOP_SEC_XGATE_CODE

#elif defined ICU_START_SEC_XGATE_CODE
  #undef ICU_START_SEC_XGATE_CODE
  #define START_SEC_XGATE_CODE
  
#elif defined ICU_STOP_SEC_XGATE_CODE
  #undef ICU_STOP_SEC_XGATE_CODE
  #define STOP_SEC_XGATE_CODE
  
/* XGATE LOCAL VAR */
#elif defined XGATE_START_SEC_LOCAL_VAR
  #undef XGATE_START_SEC_LOCAL_VAR
  #define START_SEC_XGATE_LOCAL_VAR
  
#elif defined XGATE_STOP_SEC_LOCAL_VAR
  #undef XGATE_STOP_SEC_LOCAL_VAR
  #define STOP_SEC_XGATE_LOCAL_VAR 
  
#elif defined ICU_START_SEC_XGATE_LOCAL_VAR
  #undef ICU_START_SEC_XGATE_LOCAL_VAR
  #define START_SEC_XGATE_LOCAL_VAR
  
#elif defined ICU_STOP_SEC_XGATE_LOCAL_VAR
  #undef ICU_STOP_SEC_XGATE_LOCAL_VAR
  #define STOP_SEC_XGATE_LOCAL_VAR    
  
/* XGATE SHARED VAR */
#elif defined XGATE_START_SEC_SHARED_VAR
  #undef XGATE_START_SEC_SHARED_VAR
  #define START_SEC_XGATE_SHARED_VAR
  
#elif defined XGATE_STOP_SEC_SHARED_VAR
  #undef XGATE_STOP_SEC_SHARED_VAR
  #define STOP_SEC_XGATE_SHARED_VAR  

#elif defined ICU_START_SEC_XGATE_SHARED_VAR
  #undef ICU_START_SEC_XGATE_SHARED_VAR
  #define START_SEC_XGATE_SHARED_VAR
  
#elif defined ICU_STOP_SEC_XGATE_SHARED_VAR
  #undef ICU_STOP_SEC_XGATE_SHARED_VAR
  #define STOP_SEC_XGATE_SHARED_VAR  
  
/* XGATE VECTOR TABLE  */
#elif defined XGATE_START_SEC_VECT_TBL
  #undef XGATE_START_SEC_VECT_TBL
  #define START_SEC_XGATE_VECT_TBL
  
#elif defined XGATE_STOP_SEC_VECT_TBL
  #undef XGATE_STOP_SEC_VECT_TBL
  #define STOP_SEC_XGATE_VECT_TBL  
  
  
/* JUMP TABLE */
#elif defined OS_START_SEC_JUMP_TBL
  #undef OS_START_SEC_JUMP_TBL
  #define START_SEC_JUMP_TBL  
    
#elif defined OS_STOP_SEC_JUMP_TBL
  #undef OS_STOP_SEC_JUMP_TBL
  #define STOP_SEC_JUMP_TBL  
  
/* FAULT ROM */
#elif defined DEM_START_SEC_FAULT_ROM
  #undef DEM_START_SEC_FAULT_ROM
  #define START_SEC_FAULT_ROM
  
#elif defined DEM_STOP_SEC_FAULT_ROM
  #undef DEM_STOP_SEC_FAULT_ROM
  #define STOP_SEC_FAULT_ROM

/* CAL RAM */
#elif defined XCP_START_SEC_CAL_RAM
  #undef XCP_START_SEC_CAL_RAM
  #define START_SEC_CAL_RAM
  
#elif defined XCP_STOP_SEC_CAL_RAM
  #undef XCP_STOP_SEC_CAL_RAM
  #define STOP_SEC_CAL_RAM 
  
/* CAL ROM */
#elif defined SWC_START_SEC_CAL_ROM
  #undef SWC_START_SEC_CAL_ROM
  #define START_SEC_CAL_ROM
  
#elif defined SWC_STOP_SEC_CAL_ROM
  #undef SWC_STOP_SEC_CAL_ROM
  #define STOP_SEC_CAL_ROM    
  
/* FAR RAM - PAGED RAM */
#elif defined XCP_START_SEC_DAQ_BUFFER
  #undef XCP_START_SEC_DAQ_BUFFER
  #define START_SEC_DAQ_BUFFER
  
#elif defined XCP_STOP_SEC_DAQ_BUFFER
  #undef XCP_STOP_SEC_DAQ_BUFFER
  #define STOP_SEC_DAQ_BUFFER    

#endif

/**********************************************************************
  Actual Configuration
**********************************************************************/

/* NEAR CODE */
#if defined START_SECTION_CODE_NEAR
  #pragma CODE_SEG __NEAR_SEG NON_BANKED
  #undef START_SECTION_CODE_NEAR
  #undef MEMMAP_ERROR

#elif defined STOP_SECTION_CODE_NEAR
  #pragma CODE_SEG DEFAULT
  #undef STOP_SECTION_CODE_NEAR
  #undef MEMMAP_ERROR

/* XGATE CODE */
#elif defined START_SEC_XGATE_CODE
  #pragma CODE_SEG XGATE_CODE
  #undef START_SEC_XGATE_CODE
  #undef MEMMAP_ERROR

#elif defined STOP_SEC_XGATE_CODE
  #pragma CODE_SEG DEFAULT
  #undef STOP_SEC_XGATE_CODE
  #undef MEMMAP_ERROR

/* XGATE VECTOR TABLE */
#elif defined START_SEC_XGATE_VECT_TBL
  #pragma CONST_SEG __GPAGE_SEG XGATE_VECTORS
  #undef START_SEC_XGATE_VECT_TBL
  #undef MEMMAP_ERROR

#elif defined STOP_SEC_XGATE_VECT_TBL
  #pragma CONST_SEG DEFAULT
  #undef STOP_SEC_XGATE_VECT_TBL
  #undef MEMMAP_ERROR

/* XGATE LOCAL VAR */
#elif defined START_SEC_XGATE_LOCAL_VAR
  #pragma DATA_SEG XGATE_DATA
  #undef START_SEC_XGATE_LOCAL_VAR
  #undef MEMMAP_ERROR

#elif defined STOP_SEC_XGATE_LOCAL_VAR
  #pragma DATA_SEG DEFAULT
  #undef STOP_SEC_XGATE_LOCAL_VAR
  #undef MEMMAP_ERROR

/* XGATE SHARED VAR */
#elif defined START_SEC_XGATE_SHARED_VAR
  #pragma DATA_SEG SHARED_DATA
  #undef START_SEC_XGATE_SHARED_VAR
  #undef MEMMAP_ERROR

#elif defined STOP_SEC_XGATE_SHARED_VAR
  #pragma DATA_SEG DEFAULT
  #undef STOP_SEC_XGATE_SHARED_VAR
  #undef MEMMAP_ERROR
  
/* VECTOR TABLE */  
#elif defined START_SEC_VECT_TBL
  #pragma CONST_SEG BOOT_VECTOR
  #undef START_SEC_VECT_TBLE
  #undef MEMMAP_ERROR

#elif defined STOP_SEC_VECT_TBL
  #pragma CONST_SEG DEFAULT
  #undef STOP_SEC_VECT_TBL
  #undef MEMMAP_ERROR  

/* JUMP TABLE */   
#elif defined START_SEC_JUMP_TBL
  #pragma CONST_SEG APP_VECTOR
  #undef START_SEC_JUMP_TBL
  #undef MEMMAP_ERROR 
  
#elif defined STOP_SEC_JUMP_TBL
  #pragma CONST_SEG DEFAULT
  #undef STOP_SEC_JUMP_TBL
  #undef MEMMAP_ERROR 
  
/* FAULT ROM */
#elif defined START_SEC_FAULT_ROM
  #pragma DATA_SEG FAULT_ROM
  #undef START_SEC_FAULT_ROM
  #undef MEMMAP_ERROR 
  
#elif defined STOP_SEC_FAULT_ROM
  #pragma DATA_SEG DEFAULT
  #undef STOP_SEC_FAULT_ROM
  #undef MEMMAP_ERROR 
  
/* CAL RAM */
#elif defined START_SEC_CAL_RAM
  #pragma DATA_SEG CAL_DATA_RAM
  #undef START_SEC_CAL_RAM
  #undef MEMMAP_ERROR 
  
#elif defined STOP_SEC_CAL_RAM
  #pragma DATA_SEG DEFAULT
  #undef STOP_SEC_CAL_RAM
  #undef MEMMAP_ERROR   
  
/* CAL ROM */
#elif defined START_SEC_CAL_ROM
  #pragma CONST_SEG CAL_DATA_ROM
  #undef START_SEC_CAL_ROM
  #undef MEMMAP_ERROR 
  
#elif defined STOP_SEC_CAL_ROM
  #pragma CONST_SEG DEFAULT
  #undef STOP_SEC_CAL_ROM
  #undef MEMMAP_ERROR     

/* FAR RAM - PAGED RAM */
#elif defined START_SEC_DAQ_BUFFER
  #pragma DATA_SEG DAQ_BUFFER
  #undef START_SEC_DAQ_BUFFER
  #undef MEMMAP_ERROR 
  
#elif defined STOP_SEC_DAQ_BUFFER
  #pragma DATA_SEG DEFAULT
  #undef STOP_SEC_DAQ_BUFFER
  #undef MEMMAP_ERROR             

#elif defined START_SEC_FAR_RAM
  #pragma DATA_SEG PAGED_RAM
  #undef START_SEC_FAR_RAM
  #undef MEMMAP_ERROR 
  
#elif defined STOP_SEC_FAR_RAM
  #pragma DATA_SEG DEFAULT
  #undef STOP_SEC_FAR_RAM
  #undef MEMMAP_ERROR             
/*
additional statements for switching the project sections
*/
#endif

#ifdef MEMMAP_ERROR
  #error "MemMap.h, wrong pragma command"
#endif
