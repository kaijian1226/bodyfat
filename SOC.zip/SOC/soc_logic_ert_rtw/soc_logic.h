/*******************************************************************************
 *  Real-Time Workshop code generated for Simulink model < soc_logic >
 *
 *  File: soc_logic.h
 *  File Creation Date: 30-Aug-2016
 *  Code generated on : Tue Aug 30 18:03:34 2016
 *  Abstraction:
 *  Notes:
 *
 *  Model Information:
 *  Model Name: soc_logic
 *  Model Version: 1.137
 *  Model Description:
 *  Creation date:	Thu Nov 06 11:14:33 2014
 *  Last Saved Modification:   Tue Aug 30 18:01:52 2016
 *
 *  (c)Copyright 2008-2014��Wuhan Eureka Control System Co., Ltd.
 *******************************************************************************/
/******************************************************************************
 *  Include files
 ******************************************************************************/
#ifndef RTW_HEADER_soc_logic_h_
#define RTW_HEADER_soc_logic_h_
#include <stddef.h>
#ifndef soc_logic_COMMON_INCLUDES_
# define soc_logic_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* soc_logic_COMMON_INCLUDES_ */

#include "soc_logic_types.h"

/* Includes for objects with custom storage classes. */
#include "soc_logic_Data.h"

/*****************************************************************************
 *  Defines
 *****************************************************************************/

/* Macros for accessing real-time model data structure */

/*****************************************************************************
 *  Data Types
 *****************************************************************************/

/*****************************************************************************
 *  Definitions
 *****************************************************************************/

/*****************************************************************************
 *  Declarations
 *****************************************************************************/

/* Model entry point functions */
extern void soc_logic_initialize(void);
extern void soc_logic_step(void);

/*****************************************************************************
 *  Global Function Declaration
 *****************************************************************************/

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'soc_logic'
 * '<S1>'   : 'soc_logic/Soc'
 * '<S2>'   : 'soc_logic/Soc/Soc_Calculation'
 * '<S3>'   : 'soc_logic/Soc/Soc_Calculation/Soc_calculation'
 * '<S4>'   : 'soc_logic/Soc/Soc_Calculation/Soc_fac_cal'
 */
#endif                                 /* RTW_HEADER_soc_logic_h_ */

/*======================== TOOL VERSION INFORMATION ==========================*
 * MATLAB 8.5 (R2015a)09-Feb-2015                                             *
 * Simulink 8.5 (R2015a)09-Feb-2015                                           *
 * Simulink Coder 8.8 (R2015a)09-Feb-2015                                     *
 * Embedded Coder 6.8 (R2015a)09-Feb-2015                                     *
 * Stateflow 8.5 (R2015a)09-Feb-2015                                          *
 * Fixed-Point Designer 5.0 (R2015a)09-Feb-2015                               *
 *============================================================================*/

/*======================= LICENSE IN USE INFORMATION =========================*
 * fixed_point_toolbox                                                        *
 * matlab                                                                     *
 * matlab_coder                                                               *
 * real-time_workshop                                                         *
 * rtw_embedded_coder                                                         *
 * simulink                                                                   *
 *============================================================================*/
