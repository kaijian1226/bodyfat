/*
 * File: SocMon.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SocMon.h"

/* Include model header file for global data */
#include "BMS_MON.h"
#include "BMS_MON_private.h"

/* Named constants for Chart: '<S343>/SRC_Check' */
#define BMS_MON_IN_Defect_o            ((uint8_T)1U)
#define BMS_MON_IN_NO_ACTIVE_CHILD_h0  ((uint8_T)0U)
#define BMS_MON_IN_NO_Defect_jk        ((uint8_T)2U)
#define BMS_MON_IN_SRC_High_Confimed_l ((uint8_T)1U)
#define BMS_MON_IN_SRC_High_Healing_gm ((uint8_T)3U)
#define BMS_MON_IN_SRC_Low_Confimed_cx ((uint8_T)4U)
#define BMS_MON_IN_SRC_Low_Healing_p   ((uint8_T)6U)
#define BMS_MO_IN_SRC_Low_Debouncing_dr ((uint8_T)5U)
#define BMS_M_IN_SRC_High_Debouncing_ek ((uint8_T)2U)

/*
 * Initial conditions for atomic system:
 *    '<S342>/SRC_Check'
 *    '<S351>/SRC_Check'
 */
void BMS_MON_SRC_Check_o_Init(rtB_SRC_Check_BMS_MON_lw *localB,
  rtDW_SRC_Check_BMS_MON_pd *localDW)
{
  /* InitializeConditions for Chart: '<S343>/SRC_Check' */
  localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
  localDW->bitsForTID0.is_active_c19_BMS_MON = 0U;
  localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
  localDW->local_Timer = 0U;
  localB->SRC_Def_Status = 0U;
  localB->SRC_Tmp_Def_Flag = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S342>/SRC_Check'
 *    '<S351>/SRC_Check'
 */
void BMS_MON_SRC_Check_c(boolean_T rtu_Clear_Def_Flag, t_Soc1 rtu_Sig_Volt,
  t_Soc1 rtu_Par_SRC_H_Threshold, t_Soc1 rtu_Par_SRC_L_Threshold, uint16_T
  rtu_Par_SRC_H_PosDeb, uint16_T rtu_Par_SRC_H_NegDeb, uint16_T
  rtu_Par_SRC_L_PosDeb, uint16_T rtu_Par_SRC_L_NegDeb, uint8_T
  rtu_Par_SampleTime, rtB_SRC_Check_BMS_MON_lw *localB,
  rtDW_SRC_Check_BMS_MON_pd *localDW)
{
  /* Chart: '<S343>/SRC_Check' */
  /* Gateway: Task_100ms/HVCU/HVCU_Mon/SocMon/Enabled Subsystem/SOC_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  /* During: Task_100ms/HVCU/HVCU_Mon/SocMon/Enabled Subsystem/SOC_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
  if (localDW->bitsForTID0.is_active_c19_BMS_MON == 0U) {
    /* Entry: Task_100ms/HVCU/HVCU_Mon/SocMon/Enabled Subsystem/SOC_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    localDW->bitsForTID0.is_active_c19_BMS_MON = 1U;

    /* Entry Internal: Task_100ms/HVCU/HVCU_Mon/SocMon/Enabled Subsystem/SOC_SRC_Check1/BatVolt_SRC_Check/SRCCheck/Signal_SRC/SRC_Check/SRC_Check */
    /* Transition: '<S344>:9' */
    localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_NO_Defect_jk;

    /* Entry 'NO_Defect': '<S344>:1' */
    localB->SRC_Def_Status = SRC_NON_DEF;
  } else if (localDW->bitsForTID0.is_c19_BMS_MON == BMS_MON_IN_Defect_o) {
    /* During 'Defect': '<S344>:8' */
    if (rtu_Clear_Def_Flag) {
      /* Transition: '<S344>:22' */
      /* Exit Internal 'Defect': '<S344>:8' */
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_M_IN_SRC_High_Debouncing_ek:
        /* Exit 'SRC_High_Debouncing': '<S344>:4' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
        break;

       case BMS_MO_IN_SRC_Low_Debouncing_dr:
        /* Exit 'SRC_Low_Debouncing': '<S344>:3' */
        localB->SRC_Tmp_Def_Flag = 0U;
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
        break;

       default:
        localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
        break;
      }

      localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_NO_Defect_jk;

      /* Entry 'NO_Defect': '<S344>:1' */
      localB->SRC_Def_Status = SRC_NON_DEF;
    } else {
      switch (localDW->bitsForTID0.is_Defect) {
       case BMS_MON_IN_SRC_High_Confimed_l:
        /* During 'SRC_High_Confimed': '<S344>:5' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S344>:13' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Healing_gm;

          /* Entry 'SRC_High_Healing': '<S344>:2' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_M_IN_SRC_High_Debouncing_ek:
        /* During 'SRC_High_Debouncing': '<S344>:4' */
        if (rtu_Sig_Volt <= rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S344>:12' */
          /* Exit 'SRC_High_Debouncing': '<S344>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
          localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_NO_Defect_jk;

          /* Entry 'NO_Defect': '<S344>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_H_PosDeb) {
          /* Transition: '<S344>:14' */
          /* Exit 'SRC_High_Debouncing': '<S344>:4' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_l;

          /* Entry 'SRC_High_Confimed': '<S344>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_High_Healing_gm:
        /* During 'SRC_High_Healing': '<S344>:2' */
        if (localDW->local_Timer > rtu_Par_SRC_H_NegDeb) {
          /* Transition: '<S344>:15' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
          localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_NO_Defect_jk;

          /* Entry 'NO_Defect': '<S344>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) {
          /* Transition: '<S344>:17' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_High_Confimed_l;

          /* Entry 'SRC_High_Confimed': '<S344>:5' */
          localB->SRC_Def_Status = SRC_HIGH_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       case BMS_MON_IN_SRC_Low_Confimed_cx:
        /* During 'SRC_Low_Confimed': '<S344>:6' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S344>:18' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Healing_p;

          /* Entry 'SRC_Low_Healing': '<S344>:7' */
          localDW->local_Timer = rtu_Par_SampleTime;
        }
        break;

       case BMS_MO_IN_SRC_Low_Debouncing_dr:
        /* During 'SRC_Low_Debouncing': '<S344>:3' */
        if (rtu_Sig_Volt >= rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S344>:21' */
          /* Exit 'SRC_Low_Debouncing': '<S344>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
          localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_NO_Defect_jk;

          /* Entry 'NO_Defect': '<S344>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (localDW->local_Timer > rtu_Par_SRC_L_PosDeb) {
          /* Transition: '<S344>:16' */
          /* Exit 'SRC_Low_Debouncing': '<S344>:3' */
          localB->SRC_Tmp_Def_Flag = 0U;
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_cx;

          /* Entry 'SRC_Low_Confimed': '<S344>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;

       default:
        /* During 'SRC_Low_Healing': '<S344>:7' */
        if (localDW->local_Timer > rtu_Par_SRC_L_NegDeb) {
          /* Transition: '<S344>:20' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_NO_ACTIVE_CHILD_h0;
          localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_NO_Defect_jk;

          /* Entry 'NO_Defect': '<S344>:1' */
          localB->SRC_Def_Status = SRC_NON_DEF;
        } else if (rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) {
          /* Transition: '<S344>:19' */
          localDW->bitsForTID0.is_Defect = BMS_MON_IN_SRC_Low_Confimed_cx;

          /* Entry 'SRC_Low_Confimed': '<S344>:6' */
          localB->SRC_Def_Status = SRC_LOW_DEF;
        } else {
          localDW->local_Timer += rtu_Par_SampleTime;
        }
        break;
      }
    }
  } else {
    /* During 'NO_Defect': '<S344>:1' */
    if ((rtu_Sig_Volt > rtu_Par_SRC_H_Threshold) && (!rtu_Clear_Def_Flag)) {
      /* Transition: '<S344>:10' */
      localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_Defect_o;
      localDW->bitsForTID0.is_Defect = BMS_M_IN_SRC_High_Debouncing_ek;

      /* Entry 'SRC_High_Debouncing': '<S344>:4' */
      localDW->local_Timer = rtu_Par_SampleTime;
      localB->SRC_Tmp_Def_Flag = 1U;
    } else {
      if ((rtu_Sig_Volt < rtu_Par_SRC_L_Threshold) && (!rtu_Clear_Def_Flag)) {
        /* Transition: '<S344>:11' */
        localDW->bitsForTID0.is_c19_BMS_MON = BMS_MON_IN_Defect_o;
        localDW->bitsForTID0.is_Defect = BMS_MO_IN_SRC_Low_Debouncing_dr;

        /* Entry 'SRC_Low_Debouncing': '<S344>:3' */
        localDW->local_Timer = rtu_Par_SampleTime;
        localB->SRC_Tmp_Def_Flag = 1U;
      }
    }
  }

  /* End of Chart: '<S343>/SRC_Check' */
}

/*
 * Output and update for action system:
 *    '<S335>/If Abnormal Action Subsystem'
 *    '<S335>/If Normal Action Subsystem'
 */
void BMS_IfAbnormalActionSubsystem_o(boolean_T rtu_In1, t_Soc1 rtu_In2, uint8_T
  rtu_In3, boolean_T *rty_Out1, t_Soc1 *rty_Out2, uint8_T *rty_Out3)
{
  /* Inport: '<S338>/In1' */
  *rty_Out1 = rtu_In1;

  /* Inport: '<S338>/In2' */
  *rty_Out2 = rtu_In2;

  /* Inport: '<S338>/In3' */
  *rty_Out3 = rtu_In3;
}

/* Start for atomic system: '<S227>/SocMon' */
void BMS_MON_SocMon_Start(void)
{
  /* InitializeConditions for Enabled SubSystem: '<S235>/Enabled Subsystem' */

  /* InitializeConditions for Atomic SubSystem: '<S342>/SRC_Check' */
  BMS_MON_SRC_Check_o_Init(&BMS_MON_B.SRC_Check_cx, &BMS_MON_DWork.SRC_Check_cx);

  /* End of InitializeConditions for SubSystem: '<S342>/SRC_Check' */

  /* InitializeConditions for Atomic SubSystem: '<S351>/SRC_Check' */
  BMS_MON_SRC_Check_o_Init(&BMS_MON_B.SRC_Check_mw, &BMS_MON_DWork.SRC_Check_mw);

  /* End of InitializeConditions for SubSystem: '<S351>/SRC_Check' */

  /* End of InitializeConditions for SubSystem: '<S235>/Enabled Subsystem' */
}

/* Output and update for atomic system: '<S227>/SocMon' */
void BMS_MON_SocMon(void)
{
  boolean_T rtb_LogicalOperator1;
  uint8_T rtb_Switch;
  uint8_T rtb_Switch_mb;
  boolean_T rtb_Merge;
  t_Soc1 rtb_Merge1_a;

  /* Outputs for Enabled SubSystem: '<S235>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S334>/Enable'
   */
  /* RelationalOperator: '<S235>/Relational Operator' incorporates:
   *  Constant: '<S342>/Constant1'
   *  Constant: '<S342>/Constant2'
   *  Constant: '<S342>/Constant3'
   *  Constant: '<S342>/Constant4'
   *  Constant: '<S342>/Constant5'
   *  Constant: '<S342>/Constant6'
   *  Constant: '<S342>/Constant7'
   *  Constant: '<S342>/Constant8'
   *  Constant: '<S351>/Constant1'
   *  Constant: '<S351>/Constant2'
   *  Constant: '<S351>/Constant3'
   *  Constant: '<S351>/Constant4'
   *  Constant: '<S351>/Constant5'
   *  Constant: '<S351>/Constant6'
   *  Constant: '<S351>/Constant7'
   *  Constant: '<S351>/Constant8'
   *  Inport: '<Root>/com_SOC'
   */
  if (com_SOC <= 250) {
    /* Outputs for Atomic SubSystem: '<S342>/SRC_Check' */
    BMS_MON_SRC_Check_c(false, com_SOC, SocSigASRCHigh, SocSigASRCLow,
                        BmsSigASRCHighPosDeb, BmsSigASRCHighNegDeb,
                        BmsSigASRCLowPosDeb, BmsSigASRCLowNegDeb, StepTim,
                        &BMS_MON_B.SRC_Check_cx, &BMS_MON_DWork.SRC_Check_cx);

    /* End of Outputs for SubSystem: '<S342>/SRC_Check' */

    /* Logic: '<S341>/Logical Operator1' incorporates:
     *  Constant: '<S342>/Constant1'
     *  Constant: '<S342>/Constant2'
     *  Constant: '<S342>/Constant3'
     *  Constant: '<S342>/Constant4'
     *  Constant: '<S342>/Constant5'
     *  Constant: '<S342>/Constant6'
     *  Constant: '<S342>/Constant7'
     *  Constant: '<S342>/Constant8'
     *  DataStoreRead: '<S341>/Data Store Read'
     *  Logic: '<S341>/Logical Operator4'
     */
    rtb_LogicalOperator1 = ((BMS_MON_B.SRC_Check_cx.SRC_Tmp_Def_Flag != 0) &&
      (!(BMS_MON_DWork.Dem_stClear != 0)));

    /* Switch: '<S337>/Switch2' incorporates:
     *  Constant: '<S337>/Constant4'
     *  DataStoreRead: '<S337>/Data Store Read1'
     *  Logic: '<S337>/Logical Operator3'
     */
    if (!(BMS_MON_DWork.Dem_stClear != 0)) {
      rtb_Switch = BMS_MON_B.SRC_Check_cx.SRC_Def_Status;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S337>/Switch2' */

    /* Switch: '<S337>/Switch' incorporates:
     *  Constant: '<S337>/Constant4'
     *  RelationalOperator: '<S337>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch_mb = BMS_MON_B.SRC_Check_cx.SRC_Def_Status;
    } else {
      rtb_Switch_mb = SRC_NON_DEF;
    }

    /* End of Switch: '<S337>/Switch' */

    /* Outputs for Atomic SubSystem: '<S351>/SRC_Check' */
    BMS_MON_SRC_Check_c(false, com_SOC, SocSigASRCTooHigh, SocSigASRCTooLow,
                        BmsSigASRCHighPosDeb, BmsSigASRCHighNegDeb,
                        BmsSigASRCLowPosDeb, BmsSigASRCLowNegDeb, StepTim,
                        &BMS_MON_B.SRC_Check_mw, &BMS_MON_DWork.SRC_Check_mw);

    /* End of Outputs for SubSystem: '<S351>/SRC_Check' */

    /* SwitchCase: '<S345>/Switch Case' incorporates:
     *  Constant: '<S345>/Constant1'
     *  Constant: '<S345>/Constant2'
     *  Constant: '<S345>/Constant4'
     *  Constant: '<S351>/Constant1'
     *  Constant: '<S351>/Constant2'
     *  Constant: '<S351>/Constant3'
     *  Constant: '<S351>/Constant4'
     *  Constant: '<S351>/Constant5'
     *  Constant: '<S351>/Constant6'
     *  Constant: '<S351>/Constant7'
     *  Constant: '<S351>/Constant8'
     */
    switch ((int32_T)BMS_MON_B.SRC_Check_mw.SRC_Def_Status) {
     case 0L:
      /* Outputs for IfAction SubSystem: '<S345>/Switch Case Action Subsystem' incorporates:
       *  ActionPort: '<S348>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_NON_DEF, &BMS_MON_B.Merge);

      /* End of Outputs for SubSystem: '<S345>/Switch Case Action Subsystem' */
      break;

     case 1L:
      /* Outputs for IfAction SubSystem: '<S345>/Switch Case Action Subsystem1' incorporates:
       *  ActionPort: '<S349>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_HIGH_DEF, &BMS_MON_B.Merge);

      /* End of Outputs for SubSystem: '<S345>/Switch Case Action Subsystem1' */
      break;

     case 2L:
      /* Outputs for IfAction SubSystem: '<S345>/Switch Case Action Subsystem2' incorporates:
       *  ActionPort: '<S350>/Action Port'
       */
      BMS_M_SwitchCaseActionSubsystem(SRC_TOO_LOW_DEF, &BMS_MON_B.Merge);

      /* End of Outputs for SubSystem: '<S345>/Switch Case Action Subsystem2' */
      break;
    }

    /* End of SwitchCase: '<S345>/Switch Case' */

    /* Switch: '<S336>/Switch2' incorporates:
     *  Constant: '<S336>/Constant4'
     *  DataStoreRead: '<S336>/Data Store Read1'
     *  Logic: '<S336>/Logical Operator3'
     */
    if (!(BMS_MON_DWork.Dem_stClear_b != 0)) {
      rtb_Switch = BMS_MON_B.Merge;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S336>/Switch2' */

    /* Switch: '<S336>/Switch' incorporates:
     *  Constant: '<S336>/Constant4'
     *  RelationalOperator: '<S336>/Relational Operator1'
     */
    if (rtb_Switch != SRC_NON_DEF) {
      rtb_Switch = BMS_MON_B.Merge;
    } else {
      rtb_Switch = SRC_NON_DEF;
    }

    /* End of Switch: '<S336>/Switch' */

    /* If: '<S335>/If Abnormal' incorporates:
     *  DataStoreRead: '<S347>/Data Store Read'
     *  Logic: '<S347>/Logical Operator1'
     *  Logic: '<S347>/Logical Operator4'
     */
    if (rtb_Switch != 0) {
      /* Outputs for IfAction SubSystem: '<S335>/If Abnormal Action Subsystem' incorporates:
       *  ActionPort: '<S338>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_o((BMS_MON_B.SRC_Check_mw.SRC_Tmp_Def_Flag
        != 0) && (!(BMS_MON_DWork.Dem_stClear_b != 0)), com_SOC, rtb_Switch,
        &rtb_Merge, &rtb_Merge1_a, &Soc_St);

      /* End of Outputs for SubSystem: '<S335>/If Abnormal Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S335>/If Normal Action Subsystem' incorporates:
       *  ActionPort: '<S339>/Action Port'
       */
      BMS_IfAbnormalActionSubsystem_o(rtb_LogicalOperator1, com_SOC,
        rtb_Switch_mb, &rtb_Merge, &rtb_Merge1_a, &Soc_St);

      /* End of Outputs for SubSystem: '<S335>/If Normal Action Subsystem' */
    }

    /* End of If: '<S335>/If Abnormal' */
  }

  /* End of RelationalOperator: '<S235>/Relational Operator' */
  /* End of Outputs for SubSystem: '<S235>/Enabled Subsystem' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
