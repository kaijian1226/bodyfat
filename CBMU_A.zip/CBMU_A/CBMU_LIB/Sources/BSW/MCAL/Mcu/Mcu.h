/*******************************************************************************
*
*  FILE
*     Mcu.h
*
*  DESCRIPTION
*      mcu module header file 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.2
*
*******************************************************************************/

#ifndef _MCU_H_
#define _MCU_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Mcu_Types.h"
#include "Mcu_Cfg.h"
#include "Det.h"

#if (MCU_SUPPORT_OSEK_OS == STD_ON)
  #include "osek.h"
#endif  

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* Vendor ID. */
#define MCU_VENDOR_ID         6666

/* Module ID  */
#define MCU_MODULE_ID         101

/* Version number of the module */
#define MCU_SW_MAJOR_VERSION    1
#define MCU_SW_MINOR_VERSION    0
#define MCU_SW_PATCH_VERSION    0


#define MCU_INSTATNCE_ID        1

#define MCU_API_INITCLK_ID      1
#define MCU_API_SUSPENDINT_ID   2
#define MCU_API_RESUMEINT_ID   3

#define MCU_E_WRONG_PARAM         1
#define MCU_E_INT_CNT_TOO_BIG     2
#define MCU_E_INT_CNT_NOT_CORRECT 3


#define MCU_SYNR_SYNDIV0_MASK               1
#define MCU_SYNR_SYNDIV1_MASK               2
#define MCU_SYNR_SYNDIV2_MASK               4
#define MCU_SYNR_SYNDIV3_MASK               8
#define MCU_SYNR_SYNDIV4_MASK               16
#define MCU_SYNR_SYNDIV5_MASK               32
#define MCU_SYNR_VCOFRQ0_MASK               64
#define MCU_SYNR_VCOFRQ1_MASK               128
#define MCU_SYNR_SYNDIV_MASK                63
#define MCU_SYNR_SYNDIV_BITNUM              0
#define MCU_SYNR_VCOFRQ_MASK                192
#define MCU_SYNR_VCOFRQ_BITNUM              6

#define MCU_REFDV_REFDIV0_MASK              1
#define MCU_REFDV_REFDIV1_MASK              2
#define MCU_REFDV_REFDIV2_MASK              4
#define MCU_REFDV_REFDIV3_MASK              8
#define MCU_REFDV_REFDIV4_MASK              16
#define MCU_REFDV_REFDIV5_MASK              32
#define MCU_REFDV_REFFRQ0_MASK              64
#define MCU_REFDV_REFFRQ1_MASK              128
#define MCU_REFDV_REFDIV_MASK               63
#define MCU_REFDV_REFDIV_BITNUM             0
#define MCU_REFDV_REFFRQ_MASK               192
#define MCU_REFDV_REFFRQ_BITNUM             6

#define MCU_POSTDIV_POSTDIV0_MASK           1
#define MCU_POSTDIV_POSTDIV1_MASK           2
#define MCU_POSTDIV_POSTDIV2_MASK           4
#define MCU_POSTDIV_POSTDIV3_MASK           8
#define MCU_POSTDIV_POSTDIV4_MASK           16
#define MCU_POSTDIV_POSTDIV_MASK            31
#define MCU_POSTDIV_POSTDIV_BITNUM          0

#define MCU_CRGFLG_SCM_MASK                 1
#define MCU_CRGFLG_SCMIF_MASK               2
#define MCU_CRGFLG_ILAF_MASK                4
#define MCU_CRGFLG_LOCK_MASK                8
#define MCU_CRGFLG_LOCKIF_MASK              16
#define MCU_CRGFLG_LVRF_MASK                32
#define MCU_CRGFLG_PORF_MASK                64
#define MCU_CRGFLG_RTIF_MASK                128

#define MCU_CRGINT_SCMIE_MASK               2
#define MCU_CRGINT_LOCKIE_MASK              16
#define MCU_CRGINT_RTIE_MASK                128

#define MCU_CLKSEL_COPWAI_MASK              1
#define MCU_CLKSEL_RTIWAI_MASK              2
#define MCU_CLKSEL_PLLWAI_MASK              8
#define MCU_CLKSEL_XCLKS_MASK               32
#define MCU_CLKSEL_PSTP_MASK                64
#define MCU_CLKSEL_PLLSEL_MASK              128

#define MCU_DIRECT  (*(volatile uint8*) 0x00000011)

#define MCU_SYNR    (*(volatile uint8*) 0x00000034)
#define MCU_REFDV   (*(volatile uint8*) 0x00000035)
#define MCU_POSTDIV (*(volatile uint8*) 0x00000036)
#define MCU_CRGFLG  (*(volatile uint8*) 0x00000037)
#define MCU_CRGINT  (*(volatile uint8*) 0x00000038)
#define MCU_CLKSEL  (*(volatile uint8*) 0x00000039)  

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern VAR(boolean,MCU_VAR) mcu_ClkInitError;
extern VAR(uint8,MCU_VAR) mcu_SavedGlbIntBit;
extern VAR(uint8,MCU_VAR) mcu_SavedGlbIntBitNested;
extern VAR(uint8,MCU_VAR) mcu_GlbIntDisableCnt;

/*******************************************************************************
* Macros                                                                
*******************************************************************************/
#define Mcu_DisableAllInterrupt()   asm sei

#define Mcu_EnableAllInterrupt()    asm cli


#define Mcu_SaveDisableAllInterrupt()   \
  { asm psha;                           \
    asm tfr ccr,a;                      \
    asm sei;                            \
    asm staa mcu_SavedGlbIntBit;        \
    asm pula; }

#define Mcu_RestoreEnableAllInterrupt()   \
  { asm psha;                             \
    asm ldaa  mcu_SavedGlbIntBit;         \
    asm tfr a,ccr;                        \
    asm pula; }    
   


/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
#define MCU_START_SEC_CODE_NEAR
#include "MemMap.h"

extern FUNC(void,MCU_CODE_NEAR) Mcu_SuspendAllInterrupt(void);
extern FUNC(void,MCU_CODE_NEAR) Mcu_ResumeAllInterrupt(void);  

#define MCU_STOP_SEC_CODE_NEAR
#include "MemMap.h"

extern FUNC(void,MCU_CODE) Mcu_Init(void);
extern FUNC(void,MCU_CODE) Mcu_GetVersionInfo(Std_VersionInfoType* versioninfo);


#if (MCU_SUPPORT_OSEK_OS == STD_OFF)

  #define DisableAllInterrupts()   Mcu_SaveDisableAllInterrupt()
  #define EnableAllInterrupts()    Mcu_RestoreEnableAllInterrupt()
  #define SuspendAllInterrupts()   Mcu_SuspendAllInterrupt() //��ͣ�ж�
  #define ResumeAllInterrupts()    Mcu_ResumeAllInterrupt() //�ָ������ж�    
  
#endif

#endif /* #ifndef _MCU_H_ */




