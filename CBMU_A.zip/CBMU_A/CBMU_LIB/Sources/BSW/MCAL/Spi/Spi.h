/*******************************************************************************
*
*  FILE
*     SPI.h
*
*  DESCRIPTION
*     The Header file for 9S12HY64 SPI Driver   
*      
*       
*  COPYRIGHT
*     (c)Copyright 2012, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*     Gu Bin
*
*  VERSION
*    1.0.0
*
*******************************************************************************/
#ifndef __SPI_H__
#define __SPI_H__

/*******************************************************************************
* include files
*******************************************************************************/
#include "Std_Types.h"
#include "SPI_Cfg.h"

/*******************************************************************************
* Defines
*******************************************************************************/
extern uint16 spi_loopCnt;

/*******************************************************************************
* Macros
*******************************************************************************/

/* Register Definition */
#define SPI_REG_MODRR          (*(volatile uint8*) 0x00000257)

#define SPI_REG_SPI0CR1        (*(volatile uint8*) 0x000000D8)    /* SPI 0 Control Register; 0x000000D8 */
#define SPI_REG_SPI0CR2        (*(volatile uint8*) 0x000000D9)    /* SPI 0 Control Register 2; 0x000000D9 */
#define SPI_REG_SPI0BR         (*(volatile uint8*) 0x000000DA)    /* SPI 0 Baud Rate Register; 0x000000DA */
#define SPI_REG_SPI0SR         (*(volatile uint8*) 0x000000DB)    /* SPI 0 Status Register; 0x000000DB */
#define SPI_REG_SPI0DR         (*(volatile uint16*)0x000000DC)    /* SPI 0 Data Register; 0x000000DD */
#define SPI_REG_SPI0DRL        (*(volatile uint8*)0x000000DD)     /* SPI 0 Data Register; 0x000000DD */

/* SPI 1 */
#define SPI_REG_SPI1CR1        (*(volatile uint8*) 0x000000F0)
#define SPI_REG_SPI1CR2        (*(volatile uint8*) 0x000000F1)
#define SPI_REG_SPI1BR         (*(volatile uint8*) 0x000000F2)
#define SPI_REG_SPI1SR         (*(volatile uint8*) 0x000000F3)
#define SPI_REG_SPI1DRH        (*(volatile uint8*) 0x000000F4)
#define SPI_REG_SPI1DRL        (*(volatile uint8*) 0x000000F5)
#define SPI_REG_SPI1DR         (*(volatile uint16*)0x000000F4)

/* SPI 2 */
#define SPI_REG_SPI2CR1        (*(volatile uint8*) 0x000000F8)
#define SPI_REG_SPI2CR2        (*(volatile uint8*) 0x000000F9)
#define SPI_REG_SPI2BR         (*(volatile uint8*) 0x000000FA)
#define SPI_REG_SPI2SR         (*(volatile uint8*) 0x000000FB)
#define SPI_REG_SPI2DRH        (*(volatile uint8*) 0x000000FC)
#define SPI_REG_SPI2DRL        (*(volatile uint8*) 0x000000FD)
#define SPI_REG_SPI2DR         (*(volatile uint16*)0x000000FC)

#define SPI_SPTEF_MASK         0x20
#define SPI_SPIF_MASK          0x80

/* Bit mask in MODRR register */
#define SPI_SPI0_MASK_PM       0x10
#define SPI_SPI1_MASK_PH0      0x20
#define SPI_SPI2_MASK_PH4      0x40  

#define SPI_SPI0_NMASK_PM      (~SPI_SPI0_MASK_PM)


 
/*******************************************************************************
* Global Variables declaration
*******************************************************************************/

/*******************************************************************************
* Global functions declaration
*******************************************************************************/
extern void Spi_Init(uint8 spiCh);
extern Std_ReturnType Spi_SendByte(uint8 spiCh,uint8 data);
extern Std_ReturnType Spi_SendWord(uint8 spiCh,uint16 data);
extern Std_ReturnType Spi_ReadByte(uint8 spiCh,uint8* dataPtr);
extern Std_ReturnType Spi_ReadWord(uint8 spiCh,uint16* dataPtr);
extern Std_ReturnType Spi_RWByte(uint8 spiCh,uint8 data,uint8* dataPtr);
extern Std_ReturnType Spi_RWWord(uint8 spiCh,uint16 data, uint16* dataPtr);

#endif /* #ifndef __SPI_H__ */
