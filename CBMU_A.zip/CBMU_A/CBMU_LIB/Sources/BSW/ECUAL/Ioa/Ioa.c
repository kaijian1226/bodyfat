/*******************************************************************************
*
*  FILE
*     Ioa.c
*
*  DESCRIPTION
*     Source File for IO abstraction   IO����
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Ioa.h"
#include "VFB.h"  
#include "Com.h"


/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/
boolean ioa_DisChMRelayCtl;    
boolean ioa_PreChargeRelayCtl; //add 20151027Ԥ��̵���
boolean Relay_CZ;//add 20150819�̵ܼ���״̬
boolean ioa_ChMRelayCtl;
boolean ioa_NegativeRelayCtl;
boolean ioa_Resvd1RelayCtl;
boolean ioa_Resvd2RelayCtl;
boolean ioa_DCRelayCtl;



boolean ioa_slowChrgEnaCtl;
boolean ioa_lowSide1Ctl;
boolean ioa_lowSide2Ctl;
boolean ioa_lowSide3Ctl;

uint16 ioa_T15VoltRaw;
uint16 ioa_T15VoltActRaw;
uint16 ioa_chrgVoltRaw;
uint16 ioa_chrgVoltActRaw;
uint16 ioa_battVoltRaw;
uint16 ioa_battVoltActRaw;
uint16 ioa_vccVoltRaw;
uint16 ioa_vccVoltActRaw;
uint16 ioa_sensorSplyVoltRaw;
uint16 ioa_sensorSplyVoltActRaw;
//new added for B sample 
uint16 ioa_12VOutVoltRaw;
uint16 ioa_12VOutVoltActRaw;
//new added for B sample 

/* 2013-09-18, Add for C Sample */
uint16  ioa_FC12VVoltRaw ;
uint16  ioa_FC12VVoltActRaw ; 

uint16  ioa_HVILVoltRaw ;
uint16  ioa_HVILVoltActRaw; 

uint16  ioa_FCCCVoltRaw;
uint16  ioa_FCCCVoltActRaw; 

uint16  ioa_SCCCVoltRaw;
uint16  ioa_SCCCVoltActRaw; 




uint16 ioa_gasVoltRaw;
uint16 ioa_gasPressureVoltRaw;

boolean ioa_12VOut;
boolean ioa_5VOut;
boolean ioa_PwrOut;

boolean ioa_SyncOut;

boolean ioa_RedLmpCtl;
boolean ioa_GrLmpCtl;

boolean ioa_Rly1FdBk;
boolean ioa_Rly2FdBk;

boolean ioa_OcIn1;
boolean ioa_OcIn2;

boolean ioa_T15SwtSts;

boolean ioa_pingSplyCtl;
boolean ioa_fastChrgSplyCtl;
boolean ioa_vehSplyCtl;

//�����̵������� AAA 9.19
boolean ioa_FanRelayCtl;
boolean ioa_AirACRelayCtl;
boolean ioa_FCRelayCtl;   
boolean ioa_PTCRelayCtrl;
boolean ioa_AirPTCRelayCtl;

uint8 FCRelayCtrlIO = 0xff;	//���̵�����������
uint8 FanRelayCtrlIO = 0xff;	//���ȼ̵�����������
uint8 AirACRelayCtrlIO = 0xff;	//�յ�AC�̵�����������
uint8 AirPTCRelayCtrlIO = 0xff;	//�յ�PTC�̵�����������
uint8 PTCRelayCtrlIO = 0xff;	//��ؼ��ȼ̵�����������

uint8 DisChMRelayCtrlIO = 0xff;	//�ŵ����̵�����������
uint8 ChMRelayCtrlIO = 0xff;		//������̵�����������
uint8 PreChargeRelayCtrlIO = 0xff;	//�ŵ�Ԥ��̵�����������
uint8 NegativeRelayCtrlIO = 0xff;	//�����̵�����������

uint8 DisChMRelayStateIO;	//�ŵ����̵����ؼ�����
uint8 ChMRelayStateIO;		//������̵����ؼ�����

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ uint8 ioa_T15OnCnt;
_STATIC_ uint8 ioa_T15OffCnt;

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/
/*******************************************************************************
* NAME:             Ioa_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize the IO abstraction   
*******************************************************************************/
void IOA_CODE Ioa_Init(void)
{
  Mcu_Init(); 
  Adc_Init(); 
  
  Dio_WriteChannelDir(IOA_DI_OC_IN1_DIR,IOA_DI_OC_IN1_CH,DIO_DIR_INPUT);
  Dio_WriteChannelDir(IOA_DI_OC_IN2_DIR,IOA_DI_OC_IN2_CH,DIO_DIR_INPUT);
  Dio_WriteChannelDir(IOA_DI_RELAY1_FDBK_DIR,IOA_DI_RELAY1_FDBK_CH,DIO_DIR_INPUT);
  Dio_WriteChannelDir(IOA_DI_RELAY2_FDBK_DIR,IOA_DI_RELAY2_FDBK_CH,DIO_DIR_INPUT);  
  
  Dio_WriteChannelDir(IOA_DO_5V_CTL_DIR,IOA_DO_5V_CTL_CH,DIO_DIR_OUTPUT);
  Dio_WriteChannelDir(IOA_DO_12V_CTL_DIR,IOA_DO_12V_CTL_CH,DIO_DIR_OUTPUT);
  Dio_WriteChannelDir(IOA_DO_PWR_CTL_DIR,IOA_DO_PWR_CTL_CH,DIO_DIR_OUTPUT);
  Dio_WriteChannelDir(IOA_DO_RED_LMP_CTL_DIR,IOA_DO_RED_LMP_CTL_CH,DIO_DIR_OUTPUT);
  Dio_WriteChannelDir(IOA_DO_GR_LMP_CTL_DIR,IOA_DO_GR_LMP_CTL_CH,DIO_DIR_OUTPUT);
  Dio_WriteChannelDir(IOA_DO_SYNC_CTL_DIR,IOA_DO_SYNC_CTL_CH,DIO_DIR_OUTPUT);

  Dio_WriteChannelDir(IOA_DO_PING_SPLY_CTL_DIR,IOA_DO_PING_SPLY_CTL_CH,DIO_DIR_OUTPUT);
  Dio_WriteChannelDir(IOA_DO_FC_SPLY_CTL_DIR,IOA_DO_FC_SPLY_CTL_CH,DIO_DIR_OUTPUT);
  Dio_WriteChannelDir(IOA_DO_VEH_SPLY_CTL_DIR,IOA_DO_VEH_SPLY_CTL_CH,DIO_DIR_OUTPUT);

  ioa_pingSplyCtl = FALSE;
  ioa_fastChrgSplyCtl = FALSE;
  ioa_vehSplyCtl = FALSE;

}

void IOA_CODE Ioa_Output(void)   //$$$�������̵�������
{
	uint8 chSts;

	  //chSts = (ioa_DisChMRelayCtl<<4)|(ioa_ChMRelayCtl<<5)|(ioa_PreChargeRelayCtl<<6);
	  //chSts = (ioa_DisChMRelayCtl<<4)|(ioa_ChMRelayCtl<<5)|(ioa_NegativeRelayCtl<<6);
	chSts = ((DisChMRelayCtrlIO == 0xff)? 0 : (ioa_DisChMRelayCtl << DisChMRelayCtrlIO))
			| ((ChMRelayCtrlIO == 0xff)? 0 : (ioa_ChMRelayCtl << ChMRelayCtrlIO))
			| ((PreChargeRelayCtrlIO == 0xff)? 0 : (ioa_PreChargeRelayCtl << PreChargeRelayCtrlIO))
			| ((NegativeRelayCtrlIO == 0xff)? 0 : (ioa_NegativeRelayCtl << NegativeRelayCtrlIO));
	
	Tle8104_Output(1,chSts);

/*  // not used in B Sample 
  chSts = (ioa_PTCRelayCtl<<4)|(ioa_DCRelayCtl<<5)|(ioa_Resvd1RelayCtl<<6)|(ioa_Resvd2RelayCtl<<7);
  
  Tle8104_Output(2,chSts);
  
  chSts = (ioa_lowSide1Ctl<<4)|(ioa_lowSide2Ctl<<5)|(ioa_lowSide3Ctl<<6)|(ioa_slowChrgEnaCtl<<7);
  
  Tle8104_Output(0,chSts);    
*/
  BM_ST_Precharge_Relay = ioa_PreChargeRelayCtl;
  
  if (ioa_5VOut == TRUE)
  {
    Dio_WriteChannel(IOA_DO_5V_CTL_PORT,IOA_DO_5V_CTL_CH,STD_HIGH);  
  }else
  {
    Dio_WriteChannel(IOA_DO_5V_CTL_PORT,IOA_DO_5V_CTL_CH,STD_LOW); 
  }

  if (ioa_12VOut == TRUE)
  {
    Dio_WriteChannel(IOA_DO_12V_CTL_PORT,IOA_DO_12V_CTL_CH,STD_HIGH);  
  }else
  {
    Dio_WriteChannel(IOA_DO_12V_CTL_PORT,IOA_DO_12V_CTL_CH,STD_LOW); 
  }
  
  if (ioa_PwrOut == TRUE)
  {
    Dio_WriteChannel(IOA_DO_PWR_CTL_PORT,IOA_DO_PWR_CTL_CH,STD_HIGH);  
  }else
  {
    Dio_WriteChannel(IOA_DO_PWR_CTL_PORT,IOA_DO_PWR_CTL_CH,STD_LOW); 
  } 


  if (ioa_SyncOut == TRUE)
  {
    Dio_WriteChannel(IOA_DO_SYNC_CTL_PORT,IOA_DO_SYNC_CTL_CH,STD_HIGH);  
  }else
  {
    Dio_WriteChannel(IOA_DO_SYNC_CTL_PORT,IOA_DO_SYNC_CTL_CH,STD_LOW); 
  } 

  if (canif_RxFlag == TRUE)
  {
    ioa_GrLmpCtl = TRUE;
    canif_RxFlag = FALSE;   
  }else
  {
    ioa_GrLmpCtl = FALSE;
  } 
  
  if (ioa_GrLmpCtl == TRUE)
  {
    Dio_WriteChannel(IOA_DO_GR_LMP_CTL_PORT,IOA_DO_GR_LMP_CTL_CH,STD_LOW);  
  }else
  {
    Dio_WriteChannel(IOA_DO_GR_LMP_CTL_PORT,IOA_DO_GR_LMP_CTL_CH,STD_HIGH); 
  }
 
  if (ioa_pingSplyCtl == TRUE)
  {
    Dio_WriteChannel(IOA_DO_PING_SPLY_CTL_PORT,IOA_DO_PING_SPLY_CTL_CH,STD_HIGH);  
  }else
  {
    Dio_WriteChannel(IOA_DO_PING_SPLY_CTL_PORT,IOA_DO_PING_SPLY_CTL_CH,STD_LOW); 
  }

  if (ioa_fastChrgSplyCtl == TRUE)
  {
    Dio_WriteChannel(IOA_DO_FC_SPLY_CTL_PORT,IOA_DO_FC_SPLY_CTL_CH,STD_HIGH);  
  }else
  {
    Dio_WriteChannel(IOA_DO_FC_SPLY_CTL_PORT,IOA_DO_FC_SPLY_CTL_CH,STD_LOW); 
  }
  
  if (ioa_vehSplyCtl == TRUE)
  {
    Dio_WriteChannel(IOA_DO_VEH_SPLY_CTL_PORT,IOA_DO_VEH_SPLY_CTL_CH,STD_HIGH);  
  }else
  {
    Dio_WriteChannel(IOA_DO_VEH_SPLY_CTL_PORT,IOA_DO_VEH_SPLY_CTL_CH,STD_LOW); 
  }  
  
}

void IOA_CODE Ioa_ReadAdValue(void)
{
  ioa_T15VoltRaw = Adc_Read(IOA_AD_T15_CH);
  ioa_T15VoltActRaw =  ioa_T15VoltRaw * IOA_AD_12V_GAIN;
  
  ioa_battVoltRaw = Adc_Read(IOA_AD_BATT_VOLT_CH);
  ioa_battVoltActRaw =  ioa_battVoltRaw * IOA_AD_12V_GAIN;  
  //ioa_battVoltActRaw =  ioa_battVoltActRaw >>1;  
  //ioa_battVoltActRaw =  ioa_battVoltActRaw *5; //�ϵ�minibusӲ�����,�µ���Ҫע�͵�!!!!!!20151019
  
  ioa_chrgVoltRaw = Adc_Read(IOA_AD_CHRG_CH);
  ioa_chrgVoltActRaw =  ioa_chrgVoltRaw * IOA_AD_12V_GAIN;
  
  ioa_vccVoltRaw = Adc_Read(IOA_AD_VCC_CH);
  ioa_vccVoltActRaw =  ioa_vccVoltRaw * IOA_AD_5V_GAIN;

  ioa_sensorSplyVoltRaw = Adc_Read(IOA_AD_SUPPLY_5V_CH);
  ioa_sensorSplyVoltActRaw =  ioa_sensorSplyVoltRaw * IOA_AD_5V_GAIN;
  
  ioa_gasVoltRaw = Adc_Read(IOA_AD_GAS_CH);
  
  ioa_gasPressureVoltRaw = Adc_Read(IOA_AD_GAS_PRESS_CH);
 
  ioa_12VOutVoltRaw = Adc_Read(IOA_AD_12VOUT_CH);
  ioa_12VOutVoltActRaw =  ioa_12VOutVoltRaw * IOA_AD_12V_GAIN; 
  
  //���12V��ѹAD��ؿ� AAA 10.27
  ioa_FC12VVoltRaw = Adc_Read(IOA_AD_FC12V_CH);
  ioa_FC12VVoltActRaw =  ioa_FC12VVoltRaw * IOA_AD_12V_GAIN;  //2015-07-31, LZY
  

  ioa_HVILVoltRaw = Adc_Read(IOA_AD_HVIL_CH);
  ioa_HVILVoltActRaw =  ioa_HVILVoltRaw ; 

  ioa_FCCCVoltRaw = Adc_Read(IOA_AD_FCCC_CH);
  ioa_FCCCVoltActRaw =  ioa_FCCCVoltRaw; 

  ioa_SCCCVoltRaw = Adc_Read(IOA_AD_SCCC_CH);
  ioa_SCCCVoltActRaw =  ioa_SCCCVoltRaw; 
  

  if (ioa_T15VoltActRaw >= IOA_T15_ON_THRESHOLD)
  {
    ioa_T15OffCnt = 0;
    if (ioa_T15OnCnt >= IOA_T15_ON_CNT)
    {
      ioa_T15SwtSts = TRUE;
      
    }else
    {
      ioa_T15OnCnt++;
    }   
  }
else if (ioa_T15VoltActRaw <= IOA_T15_OFF_THRESHOLD)
  {
    ioa_T15OnCnt = 0;
    if (ioa_T15OffCnt >= IOA_T15_OFF_CNT)
    {
      ioa_T15SwtSts = FALSE;
      
    }else
    {
      ioa_T15OffCnt++;
    } 
  }
  
         
}

void IOA_CODE Ioa_ReadDigValue(void)
{
  ioa_Rly1FdBk = Dio_ReadChannel(IOA_DI_RELAY1_FDBK_PORT,IOA_DI_RELAY1_FDBK_CH);
  ioa_Rly2FdBk = Dio_ReadChannel(IOA_DI_RELAY2_FDBK_PORT,IOA_DI_RELAY2_FDBK_CH);
  ioa_OcIn1 = Dio_ReadChannel(IOA_DI_OC_IN1_PORT,IOA_DI_OC_IN1_CH);
  ioa_OcIn2 = Dio_ReadChannel(IOA_DI_OC_IN2_PORT,IOA_DI_OC_IN2_CH);  
}

void IOA_CODE Ioa_ToggleRedLamp(void)
{
  if (ioa_RedLmpCtl == CTL_ON)
  {
    ioa_RedLmpCtl = CTL_OFF;  
  }else
  {
    ioa_RedLmpCtl = CTL_ON;
  }

  if (ioa_RedLmpCtl == TRUE)
  {
    Dio_WriteChannel(IOA_DO_RED_LMP_CTL_PORT,IOA_DO_RED_LMP_CTL_CH,STD_LOW);  
  }else
  {
    Dio_WriteChannel(IOA_DO_RED_LMP_CTL_PORT,IOA_DO_RED_LMP_CTL_CH,STD_HIGH); 
  }  
}


//add 20150819
void Ioa_ToggleGrLamp(void)
{
   if (ioa_GrLmpCtl == CTL_ON)
  {
    ioa_GrLmpCtl = CTL_OFF;  
  }
  else
  {
    ioa_GrLmpCtl = CTL_ON;
  }

  if (ioa_GrLmpCtl == TRUE)
  {
    Dio_WriteChannel(IOA_DO_GR_LMP_CTL_PORT,IOA_DO_GR_LMP_CTL_CH,STD_LOW);  
  }else
  {
    Dio_WriteChannel(IOA_DO_GR_LMP_CTL_PORT,IOA_DO_GR_LMP_CTL_CH,STD_HIGH); 
  }      
}

//red Led
void IOA_CODE Red_Lemp_Ctl(boolean action)
 {
    ioa_RedLmpCtl = action;
    
    if (ioa_RedLmpCtl == CTL_ON)
    {
        Dio_WriteChannel(IOA_DO_RED_LMP_CTL_PORT,IOA_DO_RED_LMP_CTL_CH,STD_LOW);
    } 
    
    if (ioa_RedLmpCtl == CTL_OFF)
    {
        Dio_WriteChannel(IOA_DO_RED_LMP_CTL_PORT,IOA_DO_RED_LMP_CTL_CH,STD_HIGH);        
    }
 }
 
 void IOA_CODE Ioa_Red_Open(void)
 {
     Red_Lemp_Ctl((boolean)CTL_ON);  
 }
 
 void IOA_CODE Ioa_Red_Close(void)
 {
     Red_Lemp_Ctl((boolean)CTL_OFF); 
 }
  
 //green led
  void IOA_CODE Gr_Lemp_Ctl(boolean action)
 {
    ioa_RedLmpCtl = action;
    
    if (ioa_GrLmpCtl == CTL_ON)
    {
        Dio_WriteChannel(IOA_DO_GR_LMP_CTL_PORT,IOA_DO_GR_LMP_CTL_CH,STD_LOW);
    } 
    
    if (ioa_GrLmpCtl == CTL_OFF)
    {
        Dio_WriteChannel(IOA_DO_GR_LMP_CTL_PORT,IOA_DO_GR_LMP_CTL_CH,STD_HIGH);        
    }
 } 
 
  void IOA_CODE Ioa_Gr_Open(void)
 {
     Gr_Lemp_Ctl((boolean)CTL_ON);  
 }
 
 void IOA_CODE Ioa_Gr_Close(void)
 {
     Gr_Lemp_Ctl((boolean)CTL_OFF); 
 }
 
 ////////////////////////////////////////////////////////////////////////////////
 //ADD BY AAA 9.17
void IOA_CODE Ioa_Output_Other(void)   //���̵���
{
	uint8 chSts;
   //chSts = (ioa_AirACRelayCtl<<4)|(ioa_FCRelayCtl<<6)|(ioa_FanRelayCtl<<7);            
   //chSts = (ioa_FanRelayCtl<<4)|(ioa_FCRelayCtl<<6)|(ioa_AirACRelayCtl<<7);   //20151116   
   //chSts = (ioa_FanRelayCtl<<4)|(ioa_AirACRelayCtl<<5)|(ioa_FCRelayCtl<<6)|(ioa_Resvd1RelayCtl<<7);   //20151116                  
   //chSts = (ioa_PTCRelayCtrl<<4)|(ioa_AirACRelayCtl<<5)|(ioa_AirPTCRelayCtl<<7);   //20151116 
	chSts = ((FCRelayCtrlIO == 0xff)? 0 : (ioa_FCRelayCtl << FCRelayCtrlIO))
			| ((FanRelayCtrlIO == 0xff)? 0 : (ioa_FanRelayCtl << FanRelayCtrlIO))
			| ((AirACRelayCtrlIO == 0xff)? 0 : (ioa_AirACRelayCtl << AirACRelayCtrlIO))
			| ((AirPTCRelayCtrlIO == 0xff)? 0 : (ioa_AirPTCRelayCtl << AirPTCRelayCtrlIO))
			| ((PTCRelayCtrlIO == 0xff)? 0 : (ioa_PTCRelayCtrl << PTCRelayCtrlIO));
   
	Tle8104_Output(2,chSts);             
}
//DCDC    ��Ӧ�̵���      K4
//FC      ��Ӧ�̵���      K6
//MOTOR   ��Ӧ�̵���      K5

//PTC  K4   ioa_AirACRelayCtl
//���� K5   ioa_FanRelayCtl
//DCDC����������


/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

