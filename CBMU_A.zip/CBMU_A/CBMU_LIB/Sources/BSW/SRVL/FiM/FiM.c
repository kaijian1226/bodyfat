/*******************************************************************************
*
*  FILE
*     FiM.c
*
*  DESCRIPTION
*     Source File for FiM Module  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "FiM.h"
#include "Dem.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ VAR(boolean,FIM_VAR) fim_Initialized;
_STATIC_ VAR(uint8,FIM_VAR) fim_FidCounter[FIM_FID_NUM]; 
 
/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             FiM_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void 
* DESCRIPTION:      Initialize Fim  
*******************************************************************************/
FUNC(void,FIM_CODE) FiM_Init(void)
{
  fim_Initialized = TRUE;
}


/*******************************************************************************
* NAME:             FiM_GetFunctionPermission
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: FiM_FunctionIdType FID: Fid Number
*                   boolean* Permission: 
*                         - TRUE: FID has permission to run
*                         - FALSE: FID has no permission to run
* RETURN VALUES:    Std_ReturnType : 
*                         - E_OK: the request is accepted
*                         - E_NOT_OK; the request is not accepted. 
* DESCRIPTION:      Report the permission state to the functionality   
*******************************************************************************/
FUNC(Std_ReturnType,FIM_CODE) FiM_GetFunctionPermission(FiM_FunctionIdType FID,boolean* Permission)
{
  if (fim_Initialized == FALSE)
  {    
    return (E_NOT_OK);
  }
  
  if (fim_FidCounter[FID] != 0)
  {
    *Permission = FALSE;
  }
  else 
  {
    *Permission = TRUE;
  }
  return (E_OK);
}

/*******************************************************************************
* NAME:             FiM_DemTriggerOnEventStatus
* CALLED BY:        Dem
* PRECONDITIONS:
* INPUT PARAMETERS: Dem_EventIdType EventId:
*                   uint8 EventStatus
* RETURN VALUES:    Void
* DESCRIPTION:      Calculate the inhitation   
*******************************************************************************/
FUNC(void,FIM_CODE) FiM_DemTriggerOnEventStatus(Dem_EventIdType EventId, uint8 EventStatus)//û���ô�
{   
  uint8 idx;
  FiM_FunctionIdType fid;
  
	for (idx=0; idx < FIM_ERR_MEM_FID_NUM; idx++)
	{
		fid = FiM_ErrFidCfg_C[EventId][idx];
		
		if (fid != FIM_FID_EMPTY)
		{
			if (EventStatus == DEM_ERR_ACTIVE)
			{
			  fim_FidCounter[fid]++;
			}
			else if ((EventStatus == DEM_ERR_PASSIVE) && (fim_FidCounter[fid]!=0))
			{	
			  fim_FidCounter[fid]--;
			}
		}		
	}	
}

/****************************************************************************
* NAME:             FiM_GetVersionInfo
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Std_VersionInfoType *versioninfo
* RETURN VALUES:    void
* DESCRIPTION:      Service to get version information     
****************************************************************************/
FUNC(void,FIM_CODE) FiM_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
  versioninfo->vendorID = FIM_VENDOR_ID;
  versioninfo->moduleID = FIM_MODULE_ID;
  versioninfo->sw_major_version = FIM_SW_MAJOR_VERSION;
  versioninfo->sw_minor_version = FIM_SW_MINOR_VERSION;
  versioninfo->sw_patch_version = FIM_SW_PATCH_VERSION;
} 


/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/
