/*******************************************************************************
*
*  FILE
*     CanIf_Cfg.c
*
*  DESCRIPTION
*     Can interface configuration   ���ͽ��ձ��Ļ�������
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*                         
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "CanIf.h"

#include "CanTp_Cbk.h"
#include "Xcp_CanIf_Cbk.h"
#include "Com_Cbk.h"
#include "J1939Tp_Cbk.h" //2015-07-07 xyl
#include "J1939Tp_Cfg.h"


/*******************************************************************************
* External Call out Function                                                                
*******************************************************************************/

/*******************************************************************************
* Defines                                                                
*******************************************************************************/


/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*****************************************************************
* Transmission
*****************************************************************/
#if (CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS != 0)
CONST(CanIf_StaticPduTxCfgType,TYPEDEF) CanIf_StaticPduTxCfg_C[CANIF_INIT_NUMBER_OF_STATIC_CANTXPDUIDS] =
{
  {  //0
    MK_STDID(0x380),0,Com_TxConfirmation,
  },
  { //1
    MK_STDID(0x370),0,Com_TxConfirmation,  //TD ʱ�䷢�͵�ַ0x6F0 ��Ϊ 0x370  20151008
  },  
  {
    MK_STDID(0x7F1),0,Com_TxConfirmation,
  },  
  {
    MK_STDID(0x7F2),0,Com_TxConfirmation,
  },      
  {
    MK_STDID(0x7F3),0,Com_TxConfirmation,
  },		
  {
    MK_EXTID(0x18FF20F4),1,Com_TxConfirmation,
  },         
  {  //6
    MK_EXTID(0x18FF21F4),1,Com_TxConfirmation,
  },
  {
    MK_EXTID(0x18FF22F4),1,Com_TxConfirmation,
  },
  {
    MK_EXTID(0x18FF23F4),1,Com_TxConfirmation,
  },
  {   //
    MK_EXTID(0x18FF24F4),1,Com_TxConfirmation,
  },
  {   //
    MK_EXTID(0x13CC16B2),2,Com_TxConfirmation,
  }, 
  {  //11
    MK_EXTID(0x104C1991),2,Com_TxConfirmation,
  }, 
  {
    MK_EXTID(0x104C1992),2,Com_TxConfirmation,
  }, 
  {
    MK_EXTID(0x104C1993),2,Com_TxConfirmation,
  },         
  {
    MK_EXTID(0x1CFFF3F4),1,Com_TxConfirmation,      //2013-07-03
  },         
  {
    MK_STDID(0x7D3),0,Xcp_CanIfTxConfirmation,
  },            
  {
    MK_EXTID(0x18DAF1F4),2,CanTp_TxConfirmation,//2015-07-03 XYL
    //MK_STDID(0x7FB),1,CanTp_TxConfirmation,     //2013-08-01
  },
  
  
      
  {//TP.CM   17
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    //MK_EXTID(0x1CEC56F4),2,J1939Tp_TxConfirmation,
    MK_EXTID(0x1CEC56F4),2,NULL_PTR,//20151127
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    MK_EXTID(0x1CECF456),2,J1939Tp_TxConfirmation,//2015-07-06 xyl  CHARGER
    #endif
  },    
  {//TP.DT 18//�������ϵͳ��������ѹ  ����  ��������Ϣ
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    //MK_EXTID(0x1CEB56F4),2,J1939Tp_TxConfirmation, 
    MK_EXTID(0x1CEB56F4),2,NULL_PTR,//20151127
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    MK_EXTID(0x1CEBF456),2,J1939Tp_TxConfirmation,//2015-07-06 xyl  CHARGER
    #endif
  },
      
  { //DM1 19
    MK_EXTID(0x1CFECAF4),2,Com_TxConfirmation,
  },        
    
//add by xql for fast charge Tx Msg,20150708
  { //20  BRM
    MK_EXTID(0x180256F4),2,Com_TxConfirmation,
  },  
  { //21  BCP ���
    MK_EXTID(0x180656F4),2,Com_TxConfirmation,
  },
  { //22  BRO
    MK_EXTID(0x100956F4),2,Com_TxConfirmation,
  },
  { //23  BCL
    MK_EXTID(0x181056F4),2,Com_TxConfirmation,
  },
  { //24  BCS ��� ����???
    MK_EXTID(0x181156F4),2,Com_TxConfirmation,
  },
  { //25  BSM
    MK_EXTID(0x181356F4),2,Com_TxConfirmation,
  },
  { //26  BST
    MK_EXTID(0x101956F4),2,Com_TxConfirmation,
  },
  { //27  BSD
    MK_EXTID(0x181C56F4),2,Com_TxConfirmation,
  },
  { //28  BEM
    MK_EXTID(0x081E56F4),2,Com_TxConfirmation,
  },
 //FC Tx Msg End  
 //add 20150805 ����5��MINIBUS
  {//ST_BMS_1    29
    MK_EXTID(0x18FF200F), 1, Com_TxConfirmation,//��IDΪ��չ��
  },   
  {//ST_BMS_2    30
    MK_EXTID(0x18FF210F), 1, Com_TxConfirmation,
  }, 
  {//ST_BMS_3    31
    MK_EXTID(0x18FF220F), 1, Com_TxConfirmation,
  },   
  {//ST_BMS_4    32
    MK_EXTID(0x18FF230F), 1, Com_TxConfirmation,
  },  
    
};
#endif

#if (CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS != 0)
CONST(CanIf_DynamicPduTxCfgType,TYPEDEF) CanIf_DynamicPduTxCfg_C[CANIF_INIT_NUMBER_OF_DYNAMIC_CANTXPDUIDS] = 
{
  {
    0,CAN_EXT_ID,CanTp_TxConfirmation,
  },
};
#endif

/*****************************************************************
* Reception
*****************************************************************/

/*********************************
* Reception objects 
**********************************/
#if (CANIF_INIT_NUMBER_OF_CANRXPDUIDS != 0)  

CONST(CanIf_PduRxCfgType,TYPEDEF) CanIf_PduRxCfg_C[CANIF_INIT_NUMBER_OF_CANRXPDUIDS] =
{
  //Inner CAN        0~16   38~61  17+23
  { //HVA1             //0
    MK_STDID(0x300),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //HVM1 
    MK_STDID(0x610),// 1
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {
    MK_STDID(0x788),// 2 
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },  
///////////////////////////////////////////////  
  //BMU1
  { //CMT  3
    MK_STDID(0x620),  //3
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //4
    MK_STDID(0x625),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2                       //5
    MK_STDID(0x626),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  {                              //6
    MK_STDID(0x630),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {                               //7
    MK_STDID(0x635),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  {                              //8
    MK_STDID(0x636),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },                            //9
  {
    MK_STDID(0x640),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {                             //10
    MK_STDID(0x645),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  {
    MK_STDID(0x646),             //11
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {
    MK_STDID(0x650),            //12
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {
    MK_STDID(0x655),            //13
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  {
    MK_STDID(0x656),             //14
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },  
///////////////////////////////////////////////  add 20150805 38~61
  //BMU5
  { //CMT  3
    MK_STDID(0x660),  //15
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x665),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //
    MK_STDID(0x666),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU6
  { //CMT  3
    MK_STDID(0x670),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x675),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //20
    MK_STDID(0x676),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU7
  { //CMT  3
    MK_STDID(0x680),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x685),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //
    MK_STDID(0x686),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU8
  { //CMT  3
    MK_STDID(0x690),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //25
    MK_STDID(0x695),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //
    MK_STDID(0x696),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU9
  { //CMT  3
    MK_STDID(0x6A0),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x6A5),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //
    MK_STDID(0x6A6),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU10
  { //CMT  3
    MK_STDID(0x6B0),  //30
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x6B5),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //
    MK_STDID(0x6B6),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU11
  { //CMT  3
    MK_STDID(0x6C0),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x6C5),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //35
    MK_STDID(0x6C6),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU12
  { //CMT  3
    MK_STDID(0x6D0),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x6D5),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x6D6),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU13
  { //CMT  3
    MK_STDID(0x6E0),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x6E5),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x6E6),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU14
  { //CMT  3
    MK_STDID(0x6F0),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x6F5),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x6F6),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU15
  { //CMT  3
    MK_STDID(0x700),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x705),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x706),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU16
  { //CMT  3
    MK_STDID(0x710),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x715),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x716),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU17
  { //CMT  3
    MK_STDID(0x720),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x725),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x726),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU18
  { //CMT  3
    MK_STDID(0x730),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x735),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x736),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU19
  { //CMT  3
    MK_STDID(0x740),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x745),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x746),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU20
  { //CMT  3
    MK_STDID(0x750),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x755),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x756),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU21
  { //CMT  3
    MK_STDID(0x760),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x765),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x766),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU22
  { //CMT  3
    MK_STDID(0x770),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x775),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x776),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU23
  { //CMT  3
    MK_STDID(0x780),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x785),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x786),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU24
  { //CMT  3
    MK_STDID(0x790),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x795),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //38
    MK_STDID(0x796),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  //BMU25
  { //CMT  3
    MK_STDID(0x7A0),  //
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  { //STS1            //
    MK_STDID(0x7A5),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //STS2            //77
    MK_STDID(0x7A6),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  
  { //M1CV1            //78   20151210
    MK_STDID(0x621),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //M1CV2            //79
    MK_STDID(0x622),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //M1CV3            //80
    MK_STDID(0x623),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //M1CV4            //81
    MK_STDID(0x624),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  { //M2CV1            //
    MK_STDID(0x631),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x632),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //M2CV3            //
    MK_STDID(0x633),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //M2CV4            //
    MK_STDID(0x634),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },  
  { //M3CV1            //
    MK_STDID(0x641),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x642),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x643),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //
    MK_STDID(0x644),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },        
  { //M4CV1            //
    MK_STDID(0x651),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x652),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x653),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //
    MK_STDID(0x654),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  { //M5CV1            //
    MK_STDID(0x661),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x662),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x663),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //
    MK_STDID(0x664),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  { //M6CV1            //
    MK_STDID(0x671),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x672),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x673),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //
    MK_STDID(0x674),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  { //M7CV1            //
    MK_STDID(0x681),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x682),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x683),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //
    MK_STDID(0x684),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  { //M8CV1            //
    MK_STDID(0x691),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x692),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x693),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //
    MK_STDID(0x694),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  { //M9CV1            //
    MK_STDID(0x6A1),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x6A2),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x6A3),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //
    MK_STDID(0x6A4),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  { //M10CV1            //
    MK_STDID(0x6B1),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x6B2),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x6B3),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //
    MK_STDID(0x6B4),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //M11CV1            //
    MK_STDID(0x6C1),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV2            //
    MK_STDID(0x6C2),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV3            //
    MK_STDID(0x6C3),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  { //MCV4            //77+44  121
    MK_STDID(0x6C4),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
    
	{ //M12CV1			  //
	  MK_STDID(0x6D1),
	  Com_RxIndication,
	  CANIF_INVALID_SW_FILTER  
	}, 
	{ //MCV2			//
	  MK_STDID(0x6D2),
	  Com_RxIndication,
	  CANIF_INVALID_SW_FILTER  
	}, 
	{ //MCV3			//
	  MK_STDID(0x6D3),
	  Com_RxIndication,
	  CANIF_INVALID_SW_FILTER  
	}, 
	{ //MCV4			//77+48  125
	  MK_STDID(0x6D4),
	  Com_RxIndication,
	  CANIF_INVALID_SW_FILTER  
	},	 
  
  {
    MK_STDID(0x7C1),              //126
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {
    MK_STDID(0x7D2),              //127
    Xcp_CanIfRxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  	//�ڲ�CAN�ŵ�̵������Խ��ձ���
	{
	  MK_STDID(0x7CC),				//128
	  Com_RxIndication,
	  CANIF_INVALID_SW_FILTER  
	},
	//Reserve1
	{
	  MK_STDID(0x7E1),				//129
	  Com_RxIndication,
	  CANIF_INVALID_SW_FILTER  
	},
  //Inner CAN
  
  //Vehicle CAN                    //130
  {
    MK_EXTID(0x18FF80E5),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {                                //130
    MK_EXTID(0x18FF10EF),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {                               //131
    MK_EXTID(0x18FF12EF),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {                               //132
    MK_EXTID(0x18FF3117),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {//VMS_3    add 20150805      //85
    MK_EXTID(0x18FF132F),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },     
  {//MCU_2    add 20151205      //86
    MK_EXTID(0x18FF011F),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  {//VMS_7    add 20151205      //135
    MK_EXTID(0x18FF172F),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },  
	{//CMU_5	
	  MK_EXTID(0x18FEE017),
	  Com_RxIndication,
	  CANIF_INVALID_SW_FILTER  
	},	
  //Vehicle CAN

  //FC CAN                         //137
  {
    MK_EXTID(0x13D01721),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {                                //138
    MK_EXTID(0x13D016B7),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },     
//add by xql for fast charge,20150709  only for test
//CRM 
  {                                  //90
    MK_EXTID(0x1801F456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
//CTS  140 
  {
    MK_EXTID(0x1807F456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
//CML 141 
  {
    MK_EXTID(0x1808F456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
//CRO                        
  {
    MK_EXTID(0x100AF456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
//CCS        
  {
    MK_EXTID(0x1812F456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
//CST  
  {
    MK_EXTID(0x101AF456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
//CSD  
  {
    MK_EXTID(0x181DF456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
//CEM   146
  {
    MK_EXTID(0x081FF456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },        
  //FC CAN
  
 //147 2015-7-21 for test   
  {
    MK_EXTID(0x181DF456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  }, 
  {
    MK_EXTID(0x081FF456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },   
  {
    MK_EXTID(0x081FF456),
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  
  {                       //150
    MK_EXTID(0x18DAF4F1),          
    //MK_STDID(0x7F3),         //2013-08-01
    CanTp_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
              

  {//TP.CM  60                          
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    MK_EXTID(0x1CECF456),        //2015-07-06 xyl BMS
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    MK_EXTID(0x1CEC56F4),        //2015-07-14 xyl CHARGER
    #endif    
    J1939Tp_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  {//TP.DT  61                            
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    MK_EXTID(0x1CEBF456),      //2015-07-06 xyl BMS
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    MK_EXTID(0x1CEB56F4),      //2015-07-14 xyl   CHARGER
    #endif
    J1939Tp_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  
  {//DM1    153                          
    #if (J1939TP_SEND_RECV_SELECT==J1939TP_SEND) 
    MK_EXTID(0x18FECAF4),      //2015-07-06 xyl BMS
    #elif (J1939TP_SEND_RECV_SELECT==J1939TP_RECV)
    MK_EXTID(0x18FECA56),      //2015-07-14 xyl   CHARGER
    #endif
    Com_RxIndication,
    CANIF_INVALID_SW_FILTER  
  },
  
};

//add 20150805       
CONST(PduIdType,CANIF_CONST)CanIf_RxStrtIdx_C[CAN_USED_NUM_OF_CHANNEL+1] =
//3·CAN�����Ľ��ձ������� 
{
  0, //InnerCAN START INDEX
  130,//VEHCAN START INDEX 
  138,//FCCAN START INDEX 
  CANIF_INIT_NUMBER_OF_CANRXPDUIDS,//�ڲ����ձ������� modified by xyl
};
#endif

/*********************************
* Software Filter
**********************************/
#if (CANIF_INIT_NUMBER_OF_SW_FILTER != 0)

CONST(CanIf_SwFltType,CANIF_CONST) CanIf_SwFlt_C[CANIF_INIT_NUMBER_OF_SW_FILTER]=
{
  {
    MK_RX_RANGE_CODE(0x00), 
    MK_RX_RANGE_MASK(0x1FFFFFFF), 
  }  
};

#endif



/*********************************
* CHECK
**********************************/
CONST(boolean,CANIF_CONST)CanIf_IdChkOrNot_C[CAN_USED_NUM_OF_CHANNEL] = 
{
  TRUE,
  TRUE, 
  TRUE,  
};

CONST(Can_IdRngType,CANIF_CONST)CanIf_CntrlIdType_C[CAN_USED_NUM_OF_CHANNEL] = 
{
  CAN_STD_ID, 
  CAN_EXT_ID, 
  CAN_EXT_ID, 
};
/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/


/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/


/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/



/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/
