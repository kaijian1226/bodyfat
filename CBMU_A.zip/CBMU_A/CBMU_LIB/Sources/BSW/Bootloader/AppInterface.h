#ifndef __APP_INTERFACE_H__
#define __APP_INTERFACE_H__


#define JmpCode             0x06        //MCU operate-code of JMP
#define AppRegisterAddress  0xEFF0      //The AppRegisterData will be saved here
#define kAppMainVersion     0x0010      //should be defined by appl.
#define kAppSubVersion      0x0101      //should be defined by appl.
#define kAppYear            0x2008      //should be defined by appl. year bcd
#define kAppMonthDay        0x0926      //should be defined by appl.month, day bcd


typedef struct
{
  unsigned char opcode;
  void near (*near const JumpAddress)(void);
} AppJumpTable;

typedef struct
{
   void near (* near const AppStartup)( void );  //2bytes, _Startup of appl.
   unsigned int uiAppMainVersion;                //should be filled by appl.
   unsigned int uiAppSubVersion;                 //should be filled by appl.
   unsigned int uiAppYear;                       //should be filled by appl. year bcd
   unsigned int uiAppMonthDay;                   //should be filled by appl.month, day bcd
   unsigned int uiConfirmWord1;                  //2bytes, filled by EFa
   unsigned int uiConfirmWord2;                  //2bytes, filled by EFa
   unsigned int uiChecksum;                      //2bytes, calculated and filled by EFa
} AppRegisterData;

#pragma CONST_SEG APPREG_DATA
extern volatile const AppRegisterData AppRegisterTable;
#pragma CONST_SEG DEFAULT

#define JumpToEXB()    {COPCTL = 0; asm jmp	0xFE00;}

#endif

