/*******************************************************************************
*
*  FILE
*     Dcm_Cfg.h
*
*  DESCRIPTION
*     The Configuration Header file for Dcm  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/

#ifndef _DCM_CFG_H_
#define _DCM_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Dcm_Types.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define DCM_DEV_ERROR_DETECT    STD_ON

/* Unit: Bytes */
#define DCM_BUFFER_LENGTH       88

/* Unit: ms */
#define DCM_CALL_CYCLE          10

#define DCM_P2_TIME             300
#define DCM_P3MAX_TIME          4000
#define DCM_S1_TIME             5000

/* Normally the transition number bigger than 1 if more than 1 state group */
#define DCM_STATE_NO_TRANSITION       5

/* The biggest hexadecimal digit as a SID configured for this ECU. */
#define DCM_MAX_REQ_SID               0x85

/* Service Header table size. */
//#define DCM_SVC_HEAD_ITEMS_NUM        11
#define DCM_SVC_HEAD_ITEMS_NUM          16/* 2013-12-16 */

/* Service Instance table size. */
//#define DCM_SVC_INSTANCE_ITEMS_NUM    16 
#define DCM_SVC_INSTANCE_ITEMS_NUM      23/* add $85, has 2 subfunction */

/* SvcInstHeadEx table size. */
//#define DCM_SVC_HEAD_EXT_ITEMS_NUM    9 
#define DCM_SVC_HEAD_EXT_ITEMS_NUM     19 /* add $85, has 2 subfunction */


/*******************************************************************************
* Macros                                                                
*******************************************************************************/
#define DCM_P2_TICKS            (DCM_P2_TIME/DCM_CALL_CYCLE - 1)

#define DCM_P3MAX_TICKS         (DCM_P3MAX_TIME/DCM_CALL_CYCLE - 1)

#define DCM_S1_TICKS            (DCM_S1_TIME/DCM_CALL_CYCLE)

/* The size of the index search table. */
#if (DCM_MAX_REQ_SID > 0x40)  
  #define DCM_SID_MAP_SIZE              (DCM_MAX_REQ_SID - 0x3F)
#else 
  #define DCM_SID_MAP_SIZE              (DCM_MAX_REQ_SID + 1)
#endif

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

/*******************************************************************************
* Global Constant declaration                         
*******************************************************************************/
extern CONST(Dcm_StateInfoType,DCM_CONST) Dcm_StateGroupTransition_C[DCM_STATE_NO_TRANSITION][2];
extern CONST(Dcm_MsgItemType,DCM_CONST) Dcm_SidMap_C[DCM_SID_MAP_SIZE];
extern CONST(Dcm_SvcHeadType,DCM_CONST) Dcm_SvcHead_C[DCM_SVC_HEAD_ITEMS_NUM];
extern CONST(Dcm_SvcInstType,DCM_CONST) Dcm_SvcInst_C[DCM_SVC_INSTANCE_ITEMS_NUM];
extern CONST(Dcm_MsgItemType,DCM_CONST) Dcm_SvcInstHeadExt_C[DCM_SVC_HEAD_EXT_ITEMS_NUM];



#endif /* #ifndef _DCM_CFG_H_ */











