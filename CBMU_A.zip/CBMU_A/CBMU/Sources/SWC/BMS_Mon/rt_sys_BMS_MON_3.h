/*
 * File: rt_sys_BMS_MON_3.h
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rt_sys_BMS_MON_3_h_
#define RTW_HEADER_rt_sys_BMS_MON_3_h_
#ifndef BMS_MON_COMMON_INCLUDES_
# define BMS_MON_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "SetErr.h"
#endif                                 /* BMS_MON_COMMON_INCLUDES_ */

#include "BMS_MON_types.h"

extern void BMS_M_SwitchCaseActionSubsystem(uint8_T rtu_In1, uint8_T *rty_Out1);

#endif                                 /* RTW_HEADER_rt_sys_BMS_MON_3_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
