/*
 * File: BMS_MON_private.h
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BMS_MON_private_h_
#define RTW_HEADER_BMS_MON_private_h_
#include "rtwtypes.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFU) ) || ( INT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFUL) ) || ( LONG_MAX != (0x7FFFFFFFL) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/* Imported (extern) block signals */
extern uint8_T PackCurMode;            /* '<Root>/PackCurMode' */
extern t_Voltage3 SWC_CellVoltMax;     /* '<Root>/com_CellVoltMax' */
extern t_Voltage3 SWC_CellVoltMin;     /* '<Root>/com_CellVoltMin' */
extern t_Temp1 SWC_CellTempAvrg;       /* '<Root>/com_CellTempAvrg' */
extern t_Temp1 SWC_CellTempMax;        /* '<Root>/com_CellTempMax' */
extern t_Temp1 SWC_CellTempMin;        /* '<Root>/com_CellTempMin' */
extern t_Soc1 com_SOC;                 /* '<Root>/com_SOC' */
extern t_Voltage4 com_BattVolt;        /* '<Root>/com_BattVolt' */
extern t_Current1 com_BattCurr;        /* '<Root>/com_BattCurr' */
extern uint16_T com_Resistance;        /* '<Root>/com_Resistance' */

/* Imported (extern) states */
extern uint8_T com_BPSSelfChkSts;      /* '<S5>/Data Store Memory' */
extern t_Temp1 FcTempTooLow;           /* '<S156>/Data Store Memory5' */

/* Imported (extern) block parameters */
extern t_Current1 FcCurLimit;          /* Variable: FcCurLimit
                                        * Referenced by: '<S284>/Constant2'
                                        */
extern void BMS_MON_High1(uint8_T rtu_H1, uint8_T rtu_H2, uint8_T *rty_H1_St,
  uint8_T *rty_H2_St);
extern void BMS_MON_High3(uint8_T rtu_H1, uint8_T *rty_H1_St, uint8_T *rty_H2_St);
extern void BMS_MON_Low1(uint8_T rtu_L1, uint8_T rtu_L2, uint8_T *rty_L1_St,
  uint8_T *rty_L2_St);
extern void BMS_MON_Low3(uint8_T rtu_L1, uint8_T *rty_L1_St, uint8_T *rty_L2_St);
extern void BMS_MON_SCStartCheck(uint8_T rtu_In1, uint8_T rtu_In2, uint8_T
  *rty_Out1, uint8_T *rty_Out2);

#endif                                 /* RTW_HEADER_BMS_MON_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
