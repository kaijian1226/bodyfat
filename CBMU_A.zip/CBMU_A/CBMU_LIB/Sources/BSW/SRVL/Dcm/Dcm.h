/*******************************************************************************
*
*  FILE
*     Dcm_Cbk.h
*
*  DESCRIPTION
*     The Call back Header file for Dcm  
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/

#ifndef _DCM_H_
#define _DCM_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"
#include "Dcm_Types.h"
#include "Dcm_Cfg.h"
#include "Dcm_Cbk.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
/* Vendor ID. */
#define DCM_VENDOR_ID           6666

/* Module ID  */
#define DCM_MODULE_ID                 53

/* Version number of the module */
#define DCM_SW_MAJOR_VERSION    1
#define DCM_SW_MINOR_VERSION    0
#define DCM_SW_PATCH_VERSION    0




#define DCM_INSTANCE_ID               0

#define DCM_API_CHKTBLCONSSIST_ID             0
#define DCM_API_PROCESSDONE_ID                1
#define DCM_API_SET_SECURITY_STATE_ID         2
#define DCM_API_SET_SESSION_STATE_ID          3  

#define DCM_E_INVALID_INDEX           0
#define DCM_E_SID_CNT                 1
#define DCM_E_SVRHEAD                 2
#define DCM_E_SVRHEAD_DUMMY           3
#define DCM_E_HANDLE                  4           
#define DCM_E_NOT_ACTIVE              5 
#define DCM_E_STATE_ZERO              6
#define DCM_E_INVALID_RCP_USE         7


#define DCM_EXT_NRC_NONE                            (0x00)

/*  Post handler status masks  */
#define DCM_POST_HANDLE_STATE_OK                    (0x01)
#define DCM_POST_HANDLE_STATE_NR_SENT               (0x02)
#define DCM_POST_HANDLE_STATE_TX_FAILED             (0x04)

/* Context specific activity states */      

#define DCM_CONTEXT_IDLE                ((uint8)0x00)
#define DCM_CONTEXT_ACTIVE_RX_BEGIN     ((uint8)0x01)
#define DCM_CONTEXT_ACTIVE_RX_END       ((uint8)0x02)
#define DCM_CONTEXT_ACTIVE_PROCESS      ((uint8)0x04)
#define DCM_CONTEXT_ACTIVE_PROCESS_END  ((uint8)0x08)                              
#define DCM_CONTEXT_ACTIVE_TX_READY     ((uint8)0x10)
#define DCM_CONTEXT_ACTIVE_TX           ((uint8)0x20)                           
#define DCM_CONTEXT_ACTIVE_POST_PROCESS ((uint8)0x40)

/* (starts default session) */
#define DCM_DEFAULT_SESSION_SVR_ENTRY             0

/*  Positive response service ID offset */
#define DCM_POS_RES_ID_OFFSET                     (0x40)

/*  Length of negative response message */
#define DCM_NEG_RES_LENGTH                        (3)

/*  Negative response service ID */
#define DCM_NEG_RES_ID                            (0x7F)

#define DCM_INVALID_SVC_HANDLE                    (DCM_SVC_HEAD_ITEMS_NUM)
#define DCM_INVALID_SVC_INST_HANDLE               (DCM_SVC_INSTANCE_ITEMS_NUM)

#define DCM_INVALID_HANDLE                        (0xFF)

#define DCM_USED_HANDLE                            (0x00)

/* Default setting for "response on request" (1 - yes,) */
#define DCM_DEFAULT_RES_ON_REQ                     0x01
   

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern VAR(Dcm_MsgContextType,DCM_VAR)     dcm_MsgContext;

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/
extern FUNC(void,DCM_CODE)  Dcm_Init(void);
extern FUNC(void,DCM_CODE)  Dcm_Task(void);
extern FUNC(void,DCM_CODE) Dcm_SetNegResponse(Dcm_NRCType errorCode);
extern FUNC(void,DCM_CODE) Dcm_SetExtNegResponse(Dcm_NRCType errorCode, Dcm_ExtNRCType  extErrorCode);
extern FUNC(void,DCM_CODE) Dcm_DcmTesterPresent(Dcm_MsgContextType *pMsgContext);
extern FUNC(void,DCM_CODE) Dcm_GetVersionInfo(Std_VersionInfoType* versioninfo);
extern FUNC(void,DCM_CODE) Dcm_ProcessingDone(void);

#endif /* #ifndef _DCM_H_ */





