/*******************************************************************************
*
*  FILE
*     OSTimer.h
*
*  DESCRIPTION
*     OSTimer module header file
*      
*       
*  COPYRIGHT
*     (c)Copyright 2008, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*    Gu Bin
*
*  VERSION
*    1.00
*
*******************************************************************************/

/*******************************************************************************
*                      Revision  History 
*                              
*   V1.00   18.11.2008  Gu Bin:  Initial version
*******************************************************************************/

#ifndef _OSTIMER_H_
#define _OSTIMER_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "OSTimer_Cfg.h"
#include "OSTimer_Types.h"
#include "OSTimer_Cbk.h"
/*******************************************************************************
* definition                                                
*******************************************************************************/
#define OSMS   1000000UL

#define MS2NS(a)  (a*OSMS) 

#define OsTimer_GetMinutes()  (OsTimer_GetSeconds()/60)
#define OsTimer_GetHours()    (OsTimer_GetMinutes()/60)
#define OsTimer_GetDays()     ((uint16)(OsTimer_GetHours()/24))

/*******************************************************************************
* Macro                                                 
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                                                
*******************************************************************************/

#define OS_START_SEC_CODE_NEAR
#include "MemMap.h"

extern FUNC(osTimer_MSecondType, OS_CODE_NEAR) OsTimer_GetMSeconds(void);
extern FUNC(osTimer_SecondType, OS_CODE_NEAR) OsTimer_GetSeconds(void);
extern FUNC(boolean, OS_CODE_NEAR) OsTimer_CheckTimeOut(osTime_MSecTickType timeStart,osTime_MSecTickType timeNow,osTime_MSecTickType timeOut);
extern FUNC(void, OS_CODE_NEAR) OsTimer_Increment(osTimer_MSecondType msec);
extern FUNC(osTime_MSecTickType, OS_CODE_NEAR) OsTimer_GetMSecondsTick(void);
extern FUNC(void, OS_CODE_NEAR) OsTimer_Init(void);
extern FUNC(OsTimer_StopWatchTickType, OS_CODE_NEAR) OsTimer_GetStopWatch(void);

#define OS_STOP_SEC_CODE_NEAR
#include "MemMap.h"

#endif  /* #ifndef _OSTIMER_H_ */
