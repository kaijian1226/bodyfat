/*******************************************************************************
*
*  FILE
*     Xcp.c
*
*  DESCRIPTION
*     Xcp Protocol Implementation       
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.2.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Xcp.h"
#include "Det.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define XCP_DRIVER_VERSION                        0x01  /* version 0.1 */

/* status of pending tasks */
#define XCP_NO_PENDING                            0x00
#define XCP_PENDING_UPLOAD_INFO                   0x01
#define XCP_PENDING_EVENT                         0x02

/* status of seed (required for seeds larger than 1 XCP packet) */
#define XCP_SEED_INCOMPLETE                       0
#define XCP_SEED_COMPLETE                         1

/* status of DAQ pointer */
#define XCP_DAQ_PTR_INVALID                       0
#define XCP_DAQ_PTR_VALID                         1

/* status of event channels concerning assignment of DAQ lists */
#define XCP_EVENT_CHANNEL_NO_DAQ_ASSIGNED         0
#define XCP_EVENT_CHANNEL_DAQ_ASSIGNED            1

/* status of non-volatile memory programming */
#define XCP_PGM_STATUS_INACTIVE                   0x00
#define XCP_PGM_STATUS_ACTIVE                     0x01
#define XCP_PGM_STATUS_PREPARED                   0x02
#define XCP_PGM_STATUS_STARTED                    0x03
/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/
_STATIC_ VAR(Xcp_ServiceType,XCP_VAR) xcp_ServiceInfo;

#if (XCP_DAQ_LST_BUFFER_NEAR == STD_ON)

#else
  #define XCP_START_SEC_DAQ_BUFFER
  #include "MemMap.h"
#endif
/* DAQ buffer for dynamic DAQ list configuration */
_STATIC_ Xcp_DaqBuffType xcp_daq_buffer[XCP_DAQ_BUFFER_SIZE];

#if (XCP_DAQ_LST_BUFFER_NEAR == STD_ON)

#else
  #define XCP_STOP_SEC_DAQ_BUFFER
  #include "MemMap.h"
#endif
/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_CmdProcessor(uint8 *cmd_cto); 
_STATIC_ FUNC(void,XCP_CODE) Xcp_ServiceInit(void);
_STATIC_ FUNC(void,XCP_CODE) Xcp_SetMTA( uint32 address, uint8 extension);
_STATIC_ FUNC(void,XCP_CODE) Xcp_Upload( uint8 *destination_address, uint8 no_of_elements);
_STATIC_ FUNC(void,XCP_CODE) Xcp_BlockUpload(void);
_STATIC_ FUNC(void,XCP_CODE) Xcp_Download( uint8 *source_address, uint8 no_of_elements);
_STATIC_ FUNC(void,XCP_CODE) Xcp_DaqSetup(void);
_STATIC_ FUNC(void,XCP_CODE) Xcp_DaqInit(void);
_STATIC_ FUNC(void,XCP_CODE) Xcp_ClearDaqLst( uint16 daq);
_STATIC_ FUNC(void,XCP_CODE) Xcp_StartDaqLst( uint16 daq);
_STATIC_ FUNC(void,XCP_CODE) Xcp_StartSelectedDaqLst(void);
_STATIC_ FUNC(void,XCP_CODE) Xcp_StopDaqLst( uint16 daq);
_STATIC_ FUNC(void,XCP_CODE) Xcp_StopAllDaqLst(void);
_STATIC_ FUNC(void,XCP_CODE) Xcp_StopSelectedDaqLst(void);
_STATIC_ FUNC(void,XCP_CODE) Xcp_SelectDaqLst( uint16 daq);
_STATIC_ FUNC(void,XCP_CODE) Xcp_InsertDaqLstToEventChannel( uint16 event_channel, uint16 daq);
_STATIC_ FUNC(void,XCP_CODE) Xcp_RemoveDaqLstFromEventChannel( uint16 event_channel, uint16 daq);
_STATIC_ FUNC(void,XCP_CODE) Xcp_CheckDaqRunningMode(void);
_STATIC_ FUNC(Std_ReturnType,XCP_CODE) Xcp_CheckDaqBufferOverflow(void);
_STATIC_ FUNC(uint32,XCP_CODE) Xcp_BuildChecksum(Xcp_MtaPtrType ptr, uint32 size);

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Xcp_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize Xcp Service  
*******************************************************************************/
FUNC(void,XCP_CODE) Xcp_Init(void)
{

  /* initialize external resources needed by the  XCP service */
  Xcp_ApplInit();

  /* initialize the protocol layer (without DAQ resource) */
  Xcp_ServiceInit();

  /* initialize the transport layer */
  Xcp_CanIfInit();

  /* setup fixed attributes of DAQ resource */
  Xcp_DaqSetup();

  /* initialize the DAQ resource */
  Xcp_DaqInit();

}

/*******************************************************************************
* NAME:             Xcp_Background
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Background function of Xcp Service  
*******************************************************************************/
FUNC(void,XCP_CODE) Xcp_Background(void)
{
  /* receive XCP packets in the background */
  uint8  *rx_ptr;

  /* try to get pointer to a new XCP packet of receive buffer */
  rx_ptr = Xcp_CanIfGetReceivePtr();

  /* check if a new XCP packet has been received */
  if (rx_ptr != NULL_PTR)
  {
    /* a CMD packet has been received, call CMD processor */
    Xcp_CmdProcessor( rx_ptr);
  }
  else
  {
    /* check if a block upload is pending */
    if (xcp_ServiceInfo.no_of_sbm_bytes_remaining > 0)
    {
      Xcp_BlockUpload();
    }
  }
}

/*******************************************************************************
* NAME:             Xcp_Service
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: uint16 event_channel
* RETURN VALUES:    Void
* DESCRIPTION:      foreground function of Xcp Service  
*******************************************************************************/
FUNC(void,XCP_CODE) Xcp_Service(uint16 event_channel)
{
  if (event_channel < XCP_MAX_EVENT_CHANNEL)
  {
    /* check if DAQ is active */
    if (xcp_ServiceInfo.session_status & XCP_SESSION_STATUS_DAQ_RUNNING)
    {
      /* check if at least one DAQ list has been assigned to this event channel */
      if (xcp_ServiceInfo.event_channel[event_channel].status == XCP_EVENT_CHANNEL_DAQ_ASSIGNED)
      {
        Xcp_DaqLstType * XCP_VAR_DAQ_LST daq_list_ptr;
        uint16         daq;
        uint16         next_daq;

        next_daq = xcp_ServiceInfo.event_channel[event_channel].first_daq;

        /* iterate over all DAQ lists which are assigned to this event channel */
        do
        {
          daq = next_daq;
          daq_list_ptr = &xcp_ServiceInfo.daq_list[daq];

          /* check if DAQ list is started */
          if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_RUNNING)
          {

          /* data acquisition */
            uint8 * XCP_VAR data_ptr;
            Xcp_OdtEntryType * XCP_VAR_DAQ_LST entry_ptr;
            Xcp_MtaPtrType address_ptr;
            uint16        dto_length;
            uint8         odt;
            uint8         pid;

            /* set entry pointer to first ODT entry of DAQ list */
            entry_ptr = &xcp_ServiceInfo.odt_entry[daq_list_ptr->first_odt_entry];

            pid = (uint8)daq_list_ptr->first_odt;

            /* iterate over all ODTs */
            for (odt = 0; odt < daq_list_ptr->no_of_configured_odts; odt++)
            {
              SuspendAllInterrupts();

              /* try to get pointer to free buffer element of DAQ DTO buffer */
              data_ptr = Xcp_CanIfGetDaqDtoPtr();

              if (data_ptr  == NULL_PTR)
              {
                 /* do nothing */
              }
              else
              {
                /* DAQ DTO buffer is not full, copy data */
                uint8 odt_entry;
                uint8 no_of_odt_entries;

                /* copy PID, increase data pointer */
                *data_ptr = pid;
                data_ptr++;
                dto_length = 1;
                odt_entry = 0;

                no_of_odt_entries = xcp_ServiceInfo.odt[daq_list_ptr->first_odt + odt].no_of_odt_entries;

                /*
                * iterate over all ODT entries
                * if current entry is not configured, continue with next ODT
                */
                while ((odt_entry < no_of_odt_entries) && (entry_ptr->size > 0) && (entry_ptr->size <= (XCP_MAX_DTO - dto_length)))
                {
                  address_ptr = entry_ptr->address_ptr;

                  /* check if current ODT entry represents a bit */
                  if (entry_ptr->bit_offset <= 0x07)
                  {
                    /* yes, copy bit value */
                    *data_ptr = (*address_ptr >> entry_ptr->bit_offset) & 0x1;

                    /* increase data pointer */
                    data_ptr++;
                  }
                  else
                  {
                    /* no bit access, distinguish size of ODT entry */
                    switch (entry_ptr->size)
                    {
                      case 8:
                        *data_ptr++ = *address_ptr++;
                        *data_ptr++ = *address_ptr++;
                        *data_ptr++ = *address_ptr++;
                        *data_ptr++ = *address_ptr++;
                      case 4:
                        *data_ptr++ = *address_ptr++;
                        *data_ptr++ = *address_ptr++;
                      case 2:
                        *data_ptr++ = *address_ptr++;
                      case 1:
                        *data_ptr++ = *address_ptr;
                        break;
                      default:
                        break;
                    }
                  }
                  dto_length += entry_ptr->size;
                  entry_ptr++;
                  odt_entry++;
                }

                /* set entry pointer to first entry of next ODT */
                entry_ptr += (no_of_odt_entries - odt_entry);

                /* send DAQ DTO */
                Xcp_CanIfSendDaqDto(dto_length);
              } /* if ((data_ptr == NULL_PTR) */
              pid++;

              ResumeAllInterrupts();
            }/* for (odt = 0; odt < daq_list_ptr->no_of_configured_odts; odt++) */
          }/* if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_RUNNING) */

          /* continue with next DAQ list */
          next_daq = daq_list_ptr->next_daq;
        }while (daq != next_daq);
        
      }/* if (xcp_ServiceInfo.event_channel[event_channel].status == XCP_EVENT_CHANNEL_DAQ_ASSIGNED) */
    }/* if (xcp_ServiceInfo.session_status & XCP_SESSION_STATUS_DAQ_RUNNING) */
  }else
  {
#if (XCP_DEV_ERROR_DETECT == STD_ON)
    Det_ReportError(XCP_MODULE_ID,XCP_INSTATNCE_ID,XCP_API_SERVICE,XCP_E_EVENT_CH_NA);
#endif    
  }
}

/****************************************************************************
* NAME:             Xcp_GetVersionInfo
* CALLED BY:        Application
* PRECONDITIONS:    
* INPUT PARAMETERS: Std_VersionInfoType *versioninfo
* RETURN VALUES:    void
* DESCRIPTION:      Service to get version information     
****************************************************************************/
FUNC(void,XCP_CODE) Xcp_GetVersionInfo(Std_VersionInfoType* versioninfo)
{
  versioninfo->vendorID = XCP_VENDOR_ID;
  versioninfo->moduleID = XCP_MODULE_ID;
  versioninfo->sw_major_version = XCP_SW_MAJOR_VERSION;
  versioninfo->sw_minor_version = XCP_SW_MINOR_VERSION;
  versioninfo->sw_patch_version = XCP_SW_PATCH_VERSION;
} 

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             Xcp_ServiceInit
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      initializes the protocol layer of the  XCP service.   
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_ServiceInit(void)
{
  /* set session status to state "disconnected" */
  xcp_ServiceInfo.session_status = XCP_SESSION_STATUS_DISCONNECTED;

  /* reset pending status */
  xcp_ServiceInfo.pending_status = XCP_NO_PENDING;

  /* set protection status to default */
  xcp_ServiceInfo.protection_status = XCP_RESOURCE_PROTECTION_DEFAULT;

  /* reset resource, which is requested to be unlocked */
  xcp_ServiceInfo.resource_to_unlock = 0;

  /* reset seed flag */
  xcp_ServiceInfo.seed_flag = XCP_SEED_INCOMPLETE;

  /* reset number of remaining bytes for seed&key */
  xcp_ServiceInfo.no_of_seed_key_bytes_remaining = 0;

  /* reset number of remaining bytes in slave block mode */
  xcp_ServiceInfo.no_of_sbm_bytes_remaining = 0;

  /* reset number of remaining bytes for uploading slave id or event channel name */
  xcp_ServiceInfo.no_of_upload_info_bytes_remaining = 0;

  /* reset number of remaining bytes in master block mode */
  xcp_ServiceInfo.no_of_mbm_bytes_remaining = 0;

}

/*******************************************************************************
* NAME:             Xcp_CmdProcessor
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      It processes the given CMD CTO packet and composes an 
*                   appropriate RES CTO packet  
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_CmdProcessor(uint8* cmd_cto)
{
  Xcp_CmdCto_Type *cmd_cto_ptr;
  Xcp_CmdResCtoType *res_cto_ptr;
  uint8_least        res_cto_length;

  res_cto_length = 0; /* set default length of RES CTO packet to 0 */

  cmd_cto_ptr = (Xcp_CmdCto_Type *)cmd_cto;

  /* try to get pointer to free buffer element of RES CTO buffer */
  if ((res_cto_ptr = (Xcp_CmdResCtoType *)Xcp_CanIfGetResCtoPtr()) != NULL_PTR)
  {
    /* set default PID of RES CTO packet to 0xFF (positive response) */
    res_cto_ptr->pid = XCP_PID_RES;

/**** CONNECT *****************************************************************/
    if (cmd_cto_ptr->pid == XCP_CMD_CODE_CONNECT)
    {
      uint8 mode;

      mode = cmd_cto_ptr->connect.mode;

      if (mode > 1)
      {
        /* send error packet */
        res_cto_ptr->pid        = XCP_PID_ERR;
        res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
        res_cto_length = 2;
      }
      else
      {

        /* set session status to state "connected" */
        xcp_ServiceInfo.session_status |= XCP_SESSION_STATUS_CONNECTED;

        /* send command response packet */
        res_cto_ptr->connect.resource          = XCP_RESOURCE;
        res_cto_ptr->connect.comm_mode_basic   = XCP_COMM_MODE_BASIC;
        res_cto_ptr->connect.max_cto           = XCP_MAX_CTO;
        res_cto_ptr->connect.max_dto           = XCP_MAX_DTO;
        res_cto_ptr->connect.protocol_version  = XCP_PROTOCOL_LAYER_VERSION;
        res_cto_ptr->connect.transport_version = XCP_TRANSPORT_LAYER_VERSION;
        res_cto_length = 8;
      }
    }
    else
    {
      /* the following commands may be executed in connected state only */
      if (xcp_ServiceInfo.session_status & XCP_SESSION_STATUS_CONNECTED)
      {
        /* check if current command belongs to a protected resource */
        uint16 protected_flag;

        protected_flag = 0; /* default: resource is unprotected */

        if (xcp_ServiceInfo.protection_status == 0)
        {
          protected_flag = 0;
        }
#if (XCP_RESOURCE_PROTECTION_CAL_PAG == STD_ON)
        else if ((cmd_cto_ptr->pid <= XCP_CMD_CODE_DOWNLOAD) && (cmd_cto_ptr->pid >= XCP_CMD_CODE_COPY_CAL_PAGE))
        {
          if (xcp_ServiceInfo.protection_status & XCP_RESOURCE_CAL_PAG)
          {
            protected_flag = 1;
          }
        }
#endif /* #if (XCP_RESOURCE_PROTECTION_CAL_PAG == STD_ON) */  

#if (XCP_RESOURCE_PROTECTION_DAQ == STD_ON)
        else if ((cmd_cto_ptr->pid <= XCP_CMD_CODE_CLEAR_DAQ_LIST) && (cmd_cto_ptr->pid >= XCP_CMD_CODE_ALLOC_ODT_ENTRY))
        {
          if (xcp_ServiceInfo.protection_status & XCP_RESOURCE_DAQ)
          {
            protected_flag = 1;
          }
        }
#endif /* #if (XCP_RESOURCE_PROTECTION_DAQ == STD_ON) */    
        if (protected_flag == 1)
        {
          /* send error packet */
          res_cto_ptr->pid        = XCP_PID_ERR;
          res_cto_ptr->error.code = XCP_ERR_ACCESS_LOCKED;
          res_cto_length = 2;
        }
        else /* current command is not protected */
        {
          switch(cmd_cto_ptr->pid)
          {
/**** DISCONNECT **************************************************************/
            case XCP_CMD_CODE_DISCONNECT:
            {
              
              /* re-initialize the protocol layer (without DAQ resource) */
              Xcp_ServiceInit();

              /* re-initialize the transport layer */
              Xcp_CanIfInit();

              /* re-initialize the DAQ resource */
              Xcp_DaqInit();

              /* send command response packet */
              res_cto_length = 1;
            }
            break;

/**** GET_STATUS **************************************************************/
            case XCP_CMD_CODE_GET_STATUS:
            {
              /* send command response packet */
              res_cto_ptr->get_status.session_status    = xcp_ServiceInfo.session_status;
              res_cto_ptr->get_status.protection_status = xcp_ServiceInfo.protection_status;
              res_cto_ptr->get_status.session_id        = 0;
              res_cto_length = 6;   
            }
            break;

/**** SYNCH *******************************************************************/
            case XCP_CMD_CODE_SYNCH:
            {
              /* send error packet */
              res_cto_ptr->pid        = XCP_PID_ERR;
              res_cto_ptr->error.code = XCP_ERR_CMD_SYNCH;
              res_cto_length = 2;
            }
            break;

/**** GET_COMM_MODE_INFO ******************************************************/
            case XCP_CMD_CODE_GET_COMM_MODE_INFO:
            {
              /* send command response packet */
              res_cto_ptr->get_comm_mode_info.optional       = XCP_COMM_MODE_OPTIONAL;
              res_cto_ptr->get_comm_mode_info.max_bs         = XCP_MAX_BS;
              res_cto_ptr->get_comm_mode_info.min_st         = XCP_MIN_ST;
              res_cto_ptr->get_comm_mode_info.queue_size     = 0; /* interleaved mode is not implemented */
              res_cto_ptr->get_comm_mode_info.driver_version = XCP_DRIVER_VERSION;
              res_cto_length = 8;
            }
            break;


/**** GET_SEED ****************************************************************/
            case XCP_CMD_CODE_GET_SEED:
            {
              uint8 mode;

              mode = cmd_cto_ptr->get_seed.mode;

              /* check parameters */
              if (mode > 1)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                res_cto_length = 2;
              }
              else
              {
                uint8 resource;
                uint8 length;

                resource = cmd_cto_ptr->get_seed.resource & (XCP_RESOURCE_CAL_PAG | XCP_RESOURCE_DAQ | XCP_RESOURCE_STIM | XCP_RESOURCE_PGM);

                if ((mode == 0) && ((resource != XCP_RESOURCE_CAL_PAG) &&
                                    (resource != XCP_RESOURCE_DAQ)     &&
                                    (resource != XCP_RESOURCE_STIM)    &&
                                    (resource != XCP_RESOURCE_PGM)))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else if ((mode == 1) && (xcp_ServiceInfo.seed_flag == XCP_SEED_COMPLETE))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                  res_cto_length = 2;
                }
                else /* parameters are correct */
                {
                  uint8 i;

                  if (mode == 0)
                  {
                    /* get seed for current resource */
                    length = Xcp_ApplGetSeed(xcp_ServiceInfo.seed, resource);

                    xcp_ServiceInfo.resource_to_unlock = resource;
                    xcp_ServiceInfo.seed_flag          = XCP_SEED_INCOMPLETE;
                    xcp_ServiceInfo.seed_key_index     = 0;
                  }
                  else /* mode == 1 */
                  {
                    length = xcp_ServiceInfo.no_of_seed_key_bytes_remaining;
                  }

                  i = 0;

                  /* copy seed to RES CTO */
                  while ((i < length) && (i < (XCP_MAX_CTO - 2)))
                  {
                    res_cto_ptr->get_seed.seed[i] = xcp_ServiceInfo.seed[xcp_ServiceInfo.seed_key_index + i];
                    i++;
                  }

                  xcp_ServiceInfo.no_of_seed_key_bytes_remaining = length - i;

                  if (xcp_ServiceInfo.no_of_seed_key_bytes_remaining == 0)
                  {
                    xcp_ServiceInfo.seed_flag = XCP_SEED_COMPLETE;
                  }
                  else
                  {
                    xcp_ServiceInfo.seed_key_index += i;
                  }

                  /* send command response packet */
                  res_cto_ptr->get_seed.length = length;
                  res_cto_length = i + 2;
                }
              }
            }
            break;

/**** UNLOCK ******************************************************************/
            case XCP_CMD_CODE_UNLOCK:
            {
              uint8 length;

              length = cmd_cto_ptr->unlock.length;

              /* check parameters */
              if ((length == 0) || (length > XCP_MAX_KEY_SIZE))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else if ((xcp_ServiceInfo.seed_flag == XCP_SEED_INCOMPLETE) ||
                       ((xcp_ServiceInfo.no_of_seed_key_bytes_remaining > 0) &&
                        (xcp_ServiceInfo.no_of_seed_key_bytes_remaining != length)))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else /* parameters are correct */
              {
                uint8 i;

                /* reset Seed&Key index in case of a new unlock sequence */
                if (xcp_ServiceInfo.no_of_seed_key_bytes_remaining == 0)
                {
                  xcp_ServiceInfo.seed_key_index = 0;
                }

                i = 0;

                /* copy key from CMD CTO */
                while ((i < length) && (i < (XCP_MAX_CTO - 2)))
                {
                  xcp_ServiceInfo.key[xcp_ServiceInfo.seed_key_index + i] = cmd_cto_ptr->unlock.key[i];
                  i++;
                }

                xcp_ServiceInfo.no_of_seed_key_bytes_remaining = length - i;
                xcp_ServiceInfo.seed_key_index += i;

                /* check if unlock sequence has finished */
                if (xcp_ServiceInfo.no_of_seed_key_bytes_remaining == 0)
                {
                  /* check if key is correct */
                  if (Xcp_ApplUnlock(xcp_ServiceInfo.seed, xcp_ServiceInfo.key, xcp_ServiceInfo.resource_to_unlock) == E_OK)
                  {
                    /* key is correct, clear protected flag of resource */
                    xcp_ServiceInfo.protection_status &= ~xcp_ServiceInfo.resource_to_unlock;

                    /* send command response packet */
                    res_cto_ptr->unlock.protection_status = xcp_ServiceInfo.protection_status;
                    res_cto_length = 2;
                  }
                  else /* key is not correct, go to disconnected state */
                  {
                    /* re-initialize the protocol layer (without DAQ resource) */
                    Xcp_ServiceInit();

                    /* re-initialize the transport layer */
                    Xcp_CanIfInit();

                    /* re-initialize the DAQ resource */
                    Xcp_DaqInit();

                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_ACCESS_LOCKED;
                    res_cto_length = 2;
                  }
                }
                else
                {
                  /* send command response packet */
                  res_cto_ptr->unlock.protection_status = xcp_ServiceInfo.protection_status;
                  res_cto_length = 2;
                }
              }
            }
            break;

/**** SET_MTA *****************************************************************/
            case XCP_CMD_CODE_SET_MTA:
            {
              /* set MTA */
              Xcp_SetMTA( cmd_cto_ptr->set_mta.address, cmd_cto_ptr->set_mta.extension);

              /* reset pending upload info flag */
              xcp_ServiceInfo.pending_status &= ~XCP_PENDING_UPLOAD_INFO;

              /* send command response packet */
              res_cto_length = 1;
            }
            break;

/**** UPLOAD ******************************************************************/
            case XCP_CMD_CODE_UPLOAD:
            {
              uint8 no_of_elements;

              no_of_elements = cmd_cto_ptr->upload.no_of_elements;

              /* check address only if no upload of service information is pending */
              if (!(xcp_ServiceInfo.pending_status & XCP_PENDING_UPLOAD_INFO) &&
                   (Xcp_ApplMemAccessChk(xcp_ServiceInfo.mta_info.address, xcp_ServiceInfo.mta_info.extension, no_of_elements, XCP_MEMORY_ACCESS_TYPE_READ) == E_NOT_OK))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                res_cto_length = 2;
              }
              else
              {
                /* check number of elements if upload of service information is pending */
                if ((xcp_ServiceInfo.pending_status & XCP_PENDING_UPLOAD_INFO) && (no_of_elements > xcp_ServiceInfo.no_of_upload_info_bytes_remaining))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
                {
                  if (no_of_elements > (XCP_MAX_CTO - 1))
                  {
                    /* negative response, if upload data doesn't fit into RES packet when SBM is disabled */
                    
                    /* upload data from MTA */
                    Xcp_Upload( res_cto_ptr->upload.data, XCP_MAX_CTO - 1);
                    xcp_ServiceInfo.no_of_sbm_bytes_remaining = no_of_elements - (XCP_MAX_CTO - 1);

                    /* send command response packet */
                    res_cto_length = XCP_MAX_CTO;
                  }
                  else
                  {
                    /* upload data from MTA */
                    Xcp_Upload( res_cto_ptr->upload.data, no_of_elements);

                    /* send command response packet */
                    res_cto_length = no_of_elements + 1;
                  }

                  if (xcp_ServiceInfo.pending_status & XCP_PENDING_UPLOAD_INFO)
                  {
                    if (no_of_elements > (XCP_MAX_CTO - 1))
                    {
                      xcp_ServiceInfo.no_of_upload_info_bytes_remaining -= (XCP_MAX_CTO - 1);
                    }
                    else
                    {
                      xcp_ServiceInfo.no_of_upload_info_bytes_remaining -= no_of_elements;
                    }

                    if (xcp_ServiceInfo.no_of_upload_info_bytes_remaining == 0)
                    {
                      xcp_ServiceInfo.pending_status &= ~XCP_PENDING_UPLOAD_INFO;
                    }
                  }
                }
              }
            }
            break;

/**** SHORT_UPLOAD ************************************************************/
            case XCP_CMD_CODE_SHORT_UPLOAD:
            {
              uint8 no_of_elements;

              no_of_elements = cmd_cto_ptr->short_upload.no_of_elements;

              /* negative response, if upload data doesn't fit into RES packet */
              if (no_of_elements > (XCP_MAX_CTO - 1))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else
              {
                uint32 address;
                uint8  extension;

                address   = cmd_cto_ptr->short_upload.address;
                extension = cmd_cto_ptr->short_upload.extension;

                if (Xcp_ApplMemAccessChk(address, extension, no_of_elements, XCP_MEMORY_ACCESS_TYPE_READ) == E_NOT_OK)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
                {
                  /* set MTA */
                  Xcp_SetMTA( address, extension);

                  /* upload data from MTA */
                  Xcp_Upload( res_cto_ptr->short_upload.data, no_of_elements);

                  /* send command response packet */
                  res_cto_length = no_of_elements + 1;
                }
              }
            }
            break;

/**** BUILD_CHECKSUM **********************************************************/
            case XCP_CMD_CODE_BUILD_CHECKSUM:
            {
              uint32 block_size;

              block_size = cmd_cto_ptr->build_checksum.block_size;

              if (block_size > XCP_MAX_CHECKSUM_BLOCKSIZE)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                *((uint32 *)&res_cto_ptr->error.info[2]) = XCP_MAX_CHECKSUM_BLOCKSIZE;
                res_cto_length = 8;
              }
              else
              {
                if (Xcp_ApplMemAccessChk(xcp_ServiceInfo.mta_info.address, xcp_ServiceInfo.mta_info.extension, block_size, XCP_MEMORY_ACCESS_TYPE_READ) == E_NOT_OK)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
                {
                  /* send command response packet */
                  res_cto_ptr->build_checksum.type     = XCP_ADD_14;
                  res_cto_ptr->build_checksum.checksum = Xcp_BuildChecksum(xcp_ServiceInfo.mta_ptr, block_size);
                  res_cto_length = 8;

                  /* post-increment MTA */
                  xcp_ServiceInfo.mta_ptr += block_size;
                  xcp_ServiceInfo.mta_info.address += block_size;
                }
              }
            }
            break;


/**** DOWNLOAD ****************************************************************/
            case XCP_CMD_CODE_DOWNLOAD:
            {
              uint8 no_of_elements;

              no_of_elements = cmd_cto_ptr->download.no_of_elements;

              if (Xcp_ApplMemAccessChk(xcp_ServiceInfo.mta_info.address, xcp_ServiceInfo.mta_info.extension, no_of_elements,XCP_MEMORY_ACCESS_TYPE_WRITE) == E_NOT_OK)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                res_cto_length = 2;
              }
              else
              {
                if (no_of_elements > (XCP_MAX_CTO - 2))
                {
                  /* download data to MTA */
                  Xcp_Download( cmd_cto_ptr->download.data, XCP_MAX_CTO - 2);
                  xcp_ServiceInfo.no_of_mbm_bytes_remaining = no_of_elements - (XCP_MAX_CTO - 2);
                }
                else
                {
                  /* download data to MTA */
                  Xcp_Download( cmd_cto_ptr->download.data, no_of_elements);

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
            }
            break;

/**** DOWNLOAD_NEXT ***********************************************************/
            case XCP_CMD_CODE_DOWNLOAD_NEXT:
            {
              
              if (cmd_cto_ptr->download_next.no_of_elements != xcp_ServiceInfo.no_of_mbm_bytes_remaining) /* check consistency */
              {
                /* send error packet */
                res_cto_ptr->pid           = XCP_PID_ERR;
                res_cto_ptr->error.code    = XCP_ERR_SEQUENCE;
                res_cto_ptr->error.info[0] = xcp_ServiceInfo.no_of_mbm_bytes_remaining;
                res_cto_length = 3;
              }
              else
              {
                uint8 no_of_elements;

                no_of_elements = cmd_cto_ptr->download_next.no_of_elements;

                if (no_of_elements > (XCP_MAX_CTO - 2))
                {
                  /* download data to MTA */
                  Xcp_Download( cmd_cto_ptr->download_next.data, XCP_MAX_CTO - 2);
                  xcp_ServiceInfo.no_of_mbm_bytes_remaining = no_of_elements - (XCP_MAX_CTO - 2);
                }
                else
                {
                  /* download data to MTA */
                  Xcp_Download( cmd_cto_ptr->download_next.data, no_of_elements);
                  xcp_ServiceInfo.no_of_mbm_bytes_remaining = 0;

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
            }
            break;

/**** DOWNLOAD_MAX ************************************************************/
            case XCP_CMD_CODE_DOWNLOAD_MAX: 
            {
              if (Xcp_ApplMemAccessChk(xcp_ServiceInfo.mta_info.address, xcp_ServiceInfo.mta_info.extension, XCP_MAX_CTO - 1, XCP_MEMORY_ACCESS_TYPE_WRITE) == E_NOT_OK)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                res_cto_length = 2;
              }
              else
              {
                /* download data to MTA */
                Xcp_Download( cmd_cto_ptr->download_max.data, XCP_MAX_CTO - 1);

                /* send command response packet */
                res_cto_length = 1;
              }
            }
            break;

/**** MODIFY_BITS *************************************************************/
            case XCP_CMD_CODE_MODIFY_BITS:
            {
              if (cmd_cto_ptr->modify_bits.shift_value > 16)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                res_cto_length = 2;
              }
              else
              {
                if (Xcp_ApplMemAccessChk(xcp_ServiceInfo.mta_info.address, xcp_ServiceInfo.mta_info.extension, 4, XCP_MEMORY_ACCESS_TYPE_WRITE) == E_NOT_OK)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
                {
                  uint32 temp = 0;

                  /* read 32 bit value at MTA */
                  ((uint8 *)&temp)[0] = xcp_ServiceInfo.mta_ptr[0];
                  ((uint8 *)&temp)[1] = xcp_ServiceInfo.mta_ptr[1];
                  ((uint8 *)&temp)[2] = xcp_ServiceInfo.mta_ptr[2];
                  ((uint8 *)&temp)[3] = xcp_ServiceInfo.mta_ptr[3];

                  /* modify bits */
                  temp = (temp & ((~((uint32)(((uint32)((uint16)~cmd_cto_ptr->modify_bits.and_mask)) << cmd_cto_ptr->modify_bits.shift_value)))) ^ ((uint32)(((uint32)cmd_cto_ptr->modify_bits.xor_mask) << cmd_cto_ptr->modify_bits.shift_value)));

                  /* write 32 bit value to MTA */
                  xcp_ServiceInfo.mta_ptr[0] = ((uint8 *)&temp)[0];
                  xcp_ServiceInfo.mta_ptr[1] = ((uint8 *)&temp)[1];
                  xcp_ServiceInfo.mta_ptr[2] = ((uint8 *)&temp)[2];
                  xcp_ServiceInfo.mta_ptr[3] = ((uint8 *)&temp)[3];

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
            }
            break;

/**** SET_CAL_PAGE ************************************************************/
            case XCP_CMD_CODE_SET_CAL_PAGE:
            {
              uint8 segment;
              uint8 page;
              uint8 mode;

              segment = cmd_cto_ptr->set_cal_page.segment;
              page    = cmd_cto_ptr->set_cal_page.page;
              mode    = cmd_cto_ptr->set_cal_page.mode;

              if (segment >= XCP_MAX_SEGMENT)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                res_cto_length = 2;
              }
              else if (page >= XCP_MAX_PAGES)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_PAGE_NOT_VALID;
                res_cto_length = 2;
              }
              else
              {
                if (Xcp_ApplSetCalPage(segment, page, mode) == E_OK)
                {
                  /* send command response packet */
                  res_cto_length = 1;
                }
                else
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_MODE_NOT_VALID;
                  res_cto_length = 2;
                }
              }
            }
            break;

/**** GET_CAL_PAGE ************************************************************/
            case XCP_CMD_CODE_GET_CAL_PAGE:
            {
              uint8 segment;
              uint8 mode;

              segment = cmd_cto_ptr->get_cal_page.segment;
              mode    = cmd_cto_ptr->get_cal_page.mode;

              if (segment >= XCP_MAX_SEGMENT)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                res_cto_length = 2;
              }
              else if (mode > 2)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_MODE_NOT_VALID;
                res_cto_length = 2;
              }
              else
              {
                /* send command response packet */

                res_cto_ptr->get_cal_page.page = Xcp_ApplGetCalPage(segment, mode);
                res_cto_length = 4;
              }
            }
            break;

/**** CLEAR_DAQ_LIST **********************************************************/
            case XCP_CMD_CODE_CLEAR_DAQ_LIST:
            {
              uint16 daq;
              daq = cmd_cto_ptr->clear_daq_list.daq;

              if (daq >= xcp_ServiceInfo.max_daq)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else
              {
                /*
                 * If DAQ list has been assigned to an event channel, it has
                 * to be removed from the event channel before it is cleared.
                 */
                if (xcp_ServiceInfo.daq_list[daq].mode & XCP_DAQ_LIST_MODE_CONFIGURED)
                {
                  Xcp_RemoveDaqLstFromEventChannel( xcp_ServiceInfo.daq_list[daq].event_channel, daq);
                }
                Xcp_ClearDaqLst( daq);

                /* send command response packet */
                res_cto_length = 1;
              }
            }
            break;

/**** SET_DAQ_PTR *************************************************************/
            case XCP_CMD_CODE_SET_DAQ_PTR:
            {
              uint16 daq;
              uint8  odt;
              uint8  odt_entry;

              daq       = cmd_cto_ptr->set_daq_ptr.daq;
              odt       = cmd_cto_ptr->set_daq_ptr.odt;
              odt_entry = cmd_cto_ptr->set_daq_ptr.odt_entry;

              if (daq >= xcp_ServiceInfo.max_daq)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else
              {
                uint16 abs_odt;
                uint8  no_of_odts;
                uint8  no_of_odt_entries;

                abs_odt    = xcp_ServiceInfo.daq_list[daq].first_odt + odt;
                no_of_odts = xcp_ServiceInfo.daq_list[daq].no_of_odts;

                no_of_odt_entries = xcp_ServiceInfo.odt[abs_odt].no_of_odt_entries;

                if ((odt >= no_of_odts) || (odt_entry >= no_of_odt_entries))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
                {
                  uint16 abs_odt_entry;

          
                  abs_odt_entry = xcp_ServiceInfo.odt[abs_odt].first_odt_entry + odt_entry;

                  /* set DAQ list pointer */
                  xcp_ServiceInfo.daq_ptr.daq           = daq;
                  xcp_ServiceInfo.daq_ptr.abs_odt       = abs_odt;
                  xcp_ServiceInfo.daq_ptr.abs_odt_entry = abs_odt_entry;
                  xcp_ServiceInfo.daq_ptr.rel_odt       = odt;
                  xcp_ServiceInfo.daq_ptr.rel_odt_entry = odt_entry;
                  xcp_ServiceInfo.daq_ptr.valid_flag    = XCP_DAQ_PTR_VALID;

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
            }
            break;

/**** WRITE_DAQ ***************************************************************/
            case XCP_CMD_CODE_WRITE_DAQ:
            {              
              if ((xcp_ServiceInfo.daq_ptr.valid_flag == XCP_DAQ_PTR_INVALID) ||
                  (xcp_ServiceInfo.daq_ptr.daq < XCP_MIN_DAQ))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_WRITE_PROTECTED;
                res_cto_length = 2;
              }
              else
              {
                uint8  size;
                uint8  bit_offset;

                size = cmd_cto_ptr->write_daq.size;
                bit_offset = cmd_cto_ptr->write_daq.bit_offset;

                if (((bit_offset == 0xFF) &&((size == 1) || (size == 2) || (size == 4) || (size == 8)) && (size <= XCP_MAX_ODT_ENTRY_SIZE_DAQ)) ||\
                    ((bit_offset <= 0x07) && (size == XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ)))
                {
                  uint32 address;
                  uint8  extension;

                  address = cmd_cto_ptr->write_daq.address;
                  extension = cmd_cto_ptr->write_daq.extension;

                  if (Xcp_ApplMemAccessChk(address, extension, size, XCP_MEMORY_ACCESS_TYPE_DAQ_STIM) == E_NOT_OK)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                    res_cto_length = 2;
                  }
                  else
                  {
                    uint16 abs_odt_entry;

                    abs_odt_entry = xcp_ServiceInfo.daq_ptr.abs_odt_entry;

                    /* configure ODT entry */
                    xcp_ServiceInfo.odt_entry[abs_odt_entry].bit_offset  = bit_offset;
                    xcp_ServiceInfo.odt_entry[abs_odt_entry].size        = size;
                    xcp_ServiceInfo.odt_entry[abs_odt_entry].extension   = extension;
                    xcp_ServiceInfo.odt_entry[abs_odt_entry].address_ptr = Xcp_ApplGetAddressPtr(address, extension);

                    /* move DAQ pointer to next ODT entry */
                    xcp_ServiceInfo.daq_ptr.abs_odt_entry++;
                    xcp_ServiceInfo.daq_ptr.rel_odt_entry++;

                    /* check if next ODT entry is available */
                      if (xcp_ServiceInfo.daq_ptr.rel_odt_entry == xcp_ServiceInfo.odt[xcp_ServiceInfo.daq_ptr.abs_odt].no_of_odt_entries)
                      {
                        xcp_ServiceInfo.daq_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                      }


                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
                else
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                  res_cto_length = 2;
                }
              }
            }
            break;

/**** SET_DAQ_LIST_MODE *******************************************************/
            case XCP_CMD_CODE_SET_DAQ_LIST_MODE:
            {
              uint16 daq;
              uint16 event_channel;
              uint8  mode;

              mode          = cmd_cto_ptr->set_daq_list_mode.mode;
              daq           = cmd_cto_ptr->set_daq_list_mode.daq;
              event_channel = cmd_cto_ptr->set_daq_list_mode.event_channel;

              if ((daq >= xcp_ServiceInfo.max_daq)    ||
                    (mode & XCP_DAQ_LIST_MODE_DIRECTION)     ||
                    (mode & XCP_DAQ_LIST_MODE_TIMESTAMP)     ||
                    (mode & XCP_DAQ_LIST_MODE_PID_OFF)       ||   
                    (event_channel >= XCP_MAX_EVENT_CHANNEL))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else
              {
                if ((mode & XCP_DAQ_LIST_MODE_DIRECTION) && (xcp_ServiceInfo.protection_status & XCP_RESOURCE_STIM))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_LOCKED;
                  res_cto_length = 2;
                }
                else
                {
                  if (xcp_ServiceInfo.daq_list[daq].mode & XCP_DAQ_LIST_MODE_RUNNING)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_DAQ_ACTIVE;
                    res_cto_length = 2;
                  }
                  else
                  {
                    Xcp_DaqLstType * XCP_VAR_DAQ_LST daq_list_ptr;

                    daq_list_ptr = &xcp_ServiceInfo.daq_list[daq];

                    daq_list_ptr->mode &= ~(XCP_DAQ_LIST_MODE_DIRECTION | XCP_DAQ_LIST_MODE_TIMESTAMP | XCP_DAQ_LIST_MODE_PID_OFF);
                    daq_list_ptr->mode |= (mode & (XCP_DAQ_LIST_MODE_DIRECTION | XCP_DAQ_LIST_MODE_TIMESTAMP | XCP_DAQ_LIST_MODE_PID_OFF));

                    daq_list_ptr->priority = cmd_cto_ptr->set_daq_list_mode.priority;

                    /* check if DAQ list has already been configured before */
                    if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_CONFIGURED)
                    {
                      /*
                       * If DAQ list has been assigned to another event channel,
                       * remove it and assign it to the new event channel.
                       */
                      Xcp_RemoveDaqLstFromEventChannel( daq_list_ptr->event_channel, daq);
                      daq_list_ptr->event_channel = event_channel;
                      Xcp_InsertDaqLstToEventChannel( event_channel, daq);
                    }
                    else
                    {
                      daq_list_ptr->event_channel = event_channel;
                      Xcp_InsertDaqLstToEventChannel( event_channel, daq);
                      daq_list_ptr->mode |= XCP_DAQ_LIST_MODE_CONFIGURED;
                    }

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
            }
            break;

/**** GET_DAQ_LIST_MODE *******************************************************/
            case XCP_CMD_CODE_GET_DAQ_LIST_MODE:
            {
              uint16 daq;

              daq = cmd_cto_ptr->get_daq_list_mode.daq;

              if (daq >= xcp_ServiceInfo.max_daq)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else
              {
                Xcp_DaqLstType * XCP_VAR_DAQ_LST daq_list_ptr;

                daq_list_ptr = &xcp_ServiceInfo.daq_list[daq];

                /* send command response packet */
                res_cto_ptr->get_daq_list_mode.mode          = daq_list_ptr->mode;
                res_cto_ptr->get_daq_list_mode.event_channel = daq_list_ptr->event_channel;
                res_cto_ptr->get_daq_list_mode.prescaler     = 1;
                res_cto_ptr->get_daq_list_mode.priority      = daq_list_ptr->priority;
                res_cto_length = 8;
              }
            }
            break;

/**** START_STOP_DAQ_LIST *****************************************************/
            case XCP_CMD_CODE_START_STOP_DAQ_LIST:
            {
              uint16 daq;
              uint8  mode;

              daq  = cmd_cto_ptr->start_stop_daq_list.daq;
              mode = cmd_cto_ptr->start_stop_daq_list.mode;

              if (daq >= xcp_ServiceInfo.max_daq)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else if (cmd_cto_ptr->start_stop_daq_list.mode > 2)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                res_cto_length = 8;
              }
              else
              {
                if (mode == 0)      /* stop */
                {
                  Xcp_StopDaqLst( daq);
                  Xcp_CheckDaqRunningMode();
                }
                else if (mode == 1) /* start */
                {
                  Xcp_StartDaqLst( daq);
                }
                else if (mode == 2) /* select */
                {
                  Xcp_SelectDaqLst( daq);
                }

                /* send command response packet */
                res_cto_ptr->start_stop_daq_list.first_pid = (uint8)xcp_ServiceInfo.daq_list[daq].first_odt;
                res_cto_length = 2;
              }
            }
            break;

/**** START_STOP_SYNCH ********************************************************/
            case XCP_CMD_CODE_START_STOP_SYNCH:
            {
              uint8 mode;

              mode = cmd_cto_ptr->start_stop_synch.mode;

              if (mode > 2)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                res_cto_length = 2;
              }
              else
              {
                if (mode == 0)      /* stop all */
                {
                  Xcp_StopAllDaqLst();
                }
                else if (mode == 1) /* start selected */
                {
                  Xcp_StartSelectedDaqLst();
                }
                else  /* (mode == 2) stop selected */
                {
                  Xcp_StopSelectedDaqLst();
                  Xcp_CheckDaqRunningMode();
                }

                /* send command response packet */
                res_cto_length = 1;
              }
            }
            break;


/**** READ_DAQ ****************************************************************/
            case XCP_CMD_CODE_READ_DAQ:
            {
              if (xcp_ServiceInfo.daq_ptr.valid_flag == XCP_DAQ_PTR_INVALID)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_WRITE_PROTECTED;
                res_cto_length = 2;
              }
              else
              {
                uint16 abs_odt_entry;

                abs_odt_entry = xcp_ServiceInfo.daq_ptr.abs_odt_entry;

                res_cto_ptr->read_daq.bit_offset = xcp_ServiceInfo.odt_entry[abs_odt_entry].bit_offset;
                res_cto_ptr->read_daq.size       = xcp_ServiceInfo.odt_entry[abs_odt_entry].size;
                res_cto_ptr->read_daq.extension  = xcp_ServiceInfo.odt_entry[abs_odt_entry].extension;
                res_cto_ptr->read_daq.address    = (uint32)xcp_ServiceInfo.odt_entry[abs_odt_entry].address_ptr;

                /* move DAQ pointer to next ODT entry */
                xcp_ServiceInfo.daq_ptr.abs_odt_entry++;
                xcp_ServiceInfo.daq_ptr.rel_odt_entry++;

                /* check if next ODT entry is available */
                  if (xcp_ServiceInfo.daq_ptr.rel_odt_entry == xcp_ServiceInfo.odt[xcp_ServiceInfo.daq_ptr.abs_odt].no_of_odt_entries)
                  {
                    xcp_ServiceInfo.daq_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                  }
                /* send command response packet */
                res_cto_length = 8;
              }
            }
            break;

/**** GET_DAQ_PROCESSOR_INFO **************************************************/
            case XCP_CMD_CODE_GET_DAQ_PROCESSOR_INFO:
            {
              /* send command response packet */
              res_cto_ptr->get_daq_processor_info.properties        = XCP_DAQ_PROPERTIES_0;
              res_cto_ptr->get_daq_processor_info.max_daq           = xcp_ServiceInfo.max_daq;
              res_cto_ptr->get_daq_processor_info.max_event_channel = XCP_MAX_EVENT_CHANNEL;
              res_cto_ptr->get_daq_processor_info.min_daq           = XCP_MIN_DAQ;
              res_cto_ptr->get_daq_processor_info.key_byte          = XCP_DAQ_KEY_BYTE;
              res_cto_length = 8;
            }
            break;

/**** GET_DAQ_RESOLUTION_INFO *************************************************/
            case XCP_CMD_CODE_GET_DAQ_RESOLUTION_INFO:
            {
              /* send command response packet */
              res_cto_ptr->get_daq_resolution_info.granularity_daq  = XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ;
              res_cto_ptr->get_daq_resolution_info.max_daq          = XCP_MAX_ODT_ENTRY_SIZE_DAQ;
              res_cto_ptr->get_daq_resolution_info.granularity_stim = 0;
              res_cto_ptr->get_daq_resolution_info.max_stim         = 0;
              res_cto_ptr->get_daq_resolution_info.timestamp_mode   = 0;
              res_cto_ptr->get_daq_resolution_info.timestamp_ticks  = 0;
              res_cto_length = 8;
            }
            break;

/**** GET_DAQ_LIST_INFO *******************************************************/
            case XCP_CMD_CODE_GET_DAQ_LIST_INFO:
            {
              uint16 daq;

              daq = cmd_cto_ptr->get_daq_list_info.daq;


              if (daq >= xcp_ServiceInfo.max_daq)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else
              {
                Xcp_DaqLstType * XCP_VAR_DAQ_LST daq_list_ptr;

                daq_list_ptr = &xcp_ServiceInfo.daq_list[daq];

                /* send command response packet */
                res_cto_ptr->get_daq_list_info.properties      = daq_list_ptr->properties;
                res_cto_ptr->get_daq_list_info.max_odt         = daq_list_ptr->no_of_odts;
                res_cto_ptr->get_daq_list_info.max_odt_entries = daq_list_ptr->no_of_odt_entries;
                res_cto_ptr->get_daq_list_info.fixed_event     = 0; /* no fixed event channel */
                res_cto_length = 6;
              }
            }
            break;

/**** GET_DAQ_EVENT_INFO ******************************************************/
            case XCP_CMD_CODE_GET_DAQ_EVENT_INFO:
            {
              uint16 event_channel;

              event_channel = cmd_cto_ptr->get_daq_event_info.event_channel;

              if (event_channel >= XCP_MAX_EVENT_CHANNEL)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                res_cto_length = 2;
              }
              else
              {
                xcp_ServiceInfo.mta_ptr = (Xcp_MtaPtrType)Xcp_EventInfo_C[event_channel].name;
                xcp_ServiceInfo.pending_status |= XCP_PENDING_UPLOAD_INFO;
                xcp_ServiceInfo.no_of_upload_info_bytes_remaining = Xcp_EventInfo_C[event_channel].name_length;

                /* send command response packet */
                res_cto_ptr->get_daq_event_info.properties   = Xcp_EventInfo_C[event_channel].properties;
                res_cto_ptr->get_daq_event_info.max_daq_list = Xcp_EventInfo_C[event_channel].max_daq;
                res_cto_ptr->get_daq_event_info.name_length  = Xcp_EventInfo_C[event_channel].name_length;
                res_cto_ptr->get_daq_event_info.time_cycle   = Xcp_EventInfo_C[event_channel].time_cycle;
                res_cto_ptr->get_daq_event_info.time_unit    = Xcp_EventInfo_C[event_channel].time_unit;
                res_cto_ptr->get_daq_event_info.priority     = Xcp_EventInfo_C[event_channel].priority;
                res_cto_length = 7;
              }
            }
            break;

/**** FREE_DAQ ****************************************************************/
            case XCP_CMD_CODE_FREE_DAQ:
            {
              Xcp_DaqInit();
              /* send command response packet */
              res_cto_length = 1;
            }
            break;

/**** ALLOC_DAQ ***************************************************************/
            case XCP_CMD_CODE_ALLOC_DAQ:
            {
              if ((xcp_ServiceInfo.odt_count > 0) || (xcp_ServiceInfo.odt_entries_count > 0))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
              {
                uint16 daq_count;

                daq_count = cmd_cto_ptr->alloc_daq.daq_count;

                xcp_ServiceInfo.max_daq = daq_count;

                if (Xcp_CheckDaqBufferOverflow() == E_NOT_OK)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_MEMORY_OVERFLOW;
                  res_cto_length = 2;
                }
                else
                {
                  /* set ODT pointer behind last DAQ list */

                    xcp_ServiceInfo.odt = (Xcp_DynDaqOdtType * XCP_VAR_DAQ_LST)&xcp_daq_buffer[daq_count * sizeof(Xcp_DaqLstType)];


                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
            }
            break;

/**** ALLOC_ODT ***************************************************************/
            case XCP_CMD_CODE_ALLOC_ODT:
            {
              if ((xcp_ServiceInfo.max_daq == 0) || (xcp_ServiceInfo.odt_entries_count > 0))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
              {
                uint16 daq;

                daq = cmd_cto_ptr->alloc_odt.daq;

                if (daq >= xcp_ServiceInfo.max_daq)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
                {
                  uint8 odt_count;

                  odt_count = cmd_cto_ptr->alloc_odt.odt_count;

                  xcp_ServiceInfo.daq_list[daq].first_odt  = xcp_ServiceInfo.odt_count;
                  xcp_ServiceInfo.daq_list[daq].no_of_odts = odt_count;
                  xcp_ServiceInfo.odt_count += odt_count;

                  if ((xcp_ServiceInfo.odt_count > 0xFB) ||
                      (Xcp_CheckDaqBufferOverflow() == E_NOT_OK))
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_MEMORY_OVERFLOW;
                    res_cto_length = 2;
                  }
                  else
                  {
                    /* set ODT entry pointer behind last ODT */
                      xcp_ServiceInfo.odt_entry   = (Xcp_OdtEntryType * XCP_VAR_DAQ_LST)&xcp_daq_buffer[(xcp_ServiceInfo.max_daq * sizeof(Xcp_DaqLstType)) + (xcp_ServiceInfo.odt_count * sizeof(Xcp_DynDaqOdtType))];

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
            }
            break;

/**** ALLOC_ODT_ENTRY *********************************************************/
            case XCP_CMD_CODE_ALLOC_ODT_ENTRY:
            {
              if ((xcp_ServiceInfo.max_daq == 0) || (xcp_ServiceInfo.odt_count == 0))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
              {
                uint16 daq;
                uint8  odt;

                daq = cmd_cto_ptr->alloc_odt_entry.daq;
                odt = cmd_cto_ptr->alloc_odt_entry.odt;

                if ((daq >= xcp_ServiceInfo.max_daq) || (odt >= xcp_ServiceInfo.daq_list[daq].no_of_odts))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
                {
                  uint16 abs_odt;
                  uint8  odt_entries_count;

                  odt_entries_count = cmd_cto_ptr->alloc_odt_entry.odt_entries_count;

                  if (odt == 0)
                  {
                    xcp_ServiceInfo.daq_list[daq].first_odt_entry = xcp_ServiceInfo.odt_entries_count;
                  }

                  abs_odt = xcp_ServiceInfo.daq_list[daq].first_odt + odt;

                  xcp_ServiceInfo.odt[abs_odt].first_odt_entry   = xcp_ServiceInfo.odt_entries_count;
                  xcp_ServiceInfo.odt[abs_odt].no_of_odt_entries = odt_entries_count;
                  xcp_ServiceInfo.odt_entries_count += odt_entries_count;

                  if (Xcp_CheckDaqBufferOverflow() == E_NOT_OK)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_MEMORY_OVERFLOW;
                    res_cto_length = 2;
                  }
                  else
                  {
                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
            }
            break;

            default: 
            {
              
              /* send error packet */
              res_cto_ptr->pid        = XCP_PID_ERR;
              res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
              res_cto_length = 2;   
            }
            break;
          }
        }
      }
    }
  }

  /* check if a response packet needs to be sent */
  if (res_cto_length > 0)
  {
    /* send RES CTO */
    Xcp_CanIfSendResCto( res_cto_length);
  }
}

/*******************************************************************************
* NAME:             Xcp_SetMTA
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint32 address
*                   uint8 extension
* RETURN VALUES:    Void
* DESCRIPTION:      sets the MTA to the given address and extension 
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_SetMTA(uint32 address, uint8 extension)
{
  xcp_ServiceInfo.mta_info.address   = address;
  xcp_ServiceInfo.mta_info.extension = extension;
  xcp_ServiceInfo.mta_ptr            = Xcp_ApplGetAddressPtr(address, extension);
}

/*******************************************************************************
* NAME:             Xcp_Upload
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint8* destination_address
*                   uint8 no_of_elements
* RETURN VALUES:    Void
* DESCRIPTION:      sets the MTA to the given address and extension 
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_Upload(uint8* destination_address, uint8 no_of_elements)
{
  SuspendAllInterrupts();
  /* copy data from MTA to destination address */
  while (no_of_elements > 0)
  {
    *destination_address = *xcp_ServiceInfo.mta_ptr;
    destination_address++;
    xcp_ServiceInfo.mta_ptr++;
    no_of_elements--;
  }

  /* post-increment MTA by number of elements */
  xcp_ServiceInfo.mta_info.address += no_of_elements;
  
  ResumeAllInterrupts();
}

/*******************************************************************************
* NAME:             Xcp_BlockUpload
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      called if a slave block mode is pending.
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_BlockUpload(void)
{
  Xcp_CmdResCtoType *res_cto_ptr;

  /* try to get pointer to free buffer element of RES CTO buffer */
  if ((res_cto_ptr = (Xcp_CmdResCtoType *)Xcp_CanIfGetResCtoPtr()) != NULL_PTR)
  {
    uint8 no_of_elements;

    if (xcp_ServiceInfo.no_of_sbm_bytes_remaining > (XCP_MAX_CTO - 1))
    {
      no_of_elements = XCP_MAX_CTO - 1;
    }
    else
    {
      no_of_elements = xcp_ServiceInfo.no_of_sbm_bytes_remaining;
    }

    /* upload data from MTA */
    Xcp_Upload( res_cto_ptr->upload.data, no_of_elements);
    xcp_ServiceInfo.no_of_sbm_bytes_remaining -= no_of_elements;

    if (xcp_ServiceInfo.pending_status & XCP_PENDING_UPLOAD_INFO)
    {
      xcp_ServiceInfo.no_of_upload_info_bytes_remaining -= no_of_elements;
      if (xcp_ServiceInfo.no_of_upload_info_bytes_remaining == 0)
      {
        xcp_ServiceInfo.pending_status &= ~XCP_PENDING_UPLOAD_INFO;
      }
    }

    /* send command response packet */
    res_cto_ptr->pid = XCP_PID_RES;

    /* send RES CTO */
    Xcp_CanIfSendResCto( no_of_elements + 1);
  }
}

/*******************************************************************************
* NAME:             Xcp_Download
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint8* source_address
*                   uint8 no_of_elements
* RETURN VALUES:    Void
* DESCRIPTION:      downloads the given number of element
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_Download(uint8* source_address, uint8 no_of_elements)
{
  /* copy data from source address to MTA */
  SuspendAllInterrupts();
  
  while (no_of_elements > 0)
  {
    *xcp_ServiceInfo.mta_ptr = *source_address;
    xcp_ServiceInfo.mta_ptr++;
    source_address++;
    no_of_elements--;
  }

  /* post-increment MTA by number of elements */
  xcp_ServiceInfo.mta_info.address += no_of_elements;
  
  ResumeAllInterrupts();
}

/*******************************************************************************
* NAME:             Xcp_BuildChecksum
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Xcp_MtaPtrType ptr
*                   uint32 size
* RETURN VALUES:    uint32: Checksum 
* DESCRIPTION:      calculates the checksum of the memory range
*******************************************************************************/
_STATIC_ FUNC(uint32,XCP_CODE) Xcp_BuildChecksum(Xcp_MtaPtrType ptr, uint32 size)
{
  uint32 checksum;
  checksum = 0;

  while (size-- > 0)
  {
    checksum += *(ptr++);
  }
  return ((uint32)checksum);
}

/*******************************************************************************
* NAME:             Xcp_DaqSetup
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      sets up all fixed structures and properties of DAQ
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_DaqSetup(void)
{
  /* set DAQ list pointer to beginning of DAQ buffer */
  xcp_ServiceInfo.daq_list = (Xcp_DaqLstType * XCP_VAR_DAQ_LST)&xcp_daq_buffer[0];

}

/*******************************************************************************
* NAME:             Xcp_DaqInit
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      initializes all DAQ lists.
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_DaqInit(void)
{
  uint16_least idx;

  /* reset DAQ flag of session status */
  xcp_ServiceInfo.session_status &= ~XCP_SESSION_STATUS_DAQ_RUNNING;

  /* reset DAQ buffer for dynamic DAQ list configuration */
  for (idx = 0; idx < XCP_DAQ_BUFFER_SIZE; idx++)
  {
    xcp_daq_buffer[idx] = 0;
  }

  /* reset counters for dynamic DAQ list configuration */
  xcp_ServiceInfo.max_daq           = 0;
  xcp_ServiceInfo.odt_count         = 0;
  xcp_ServiceInfo.odt_entries_count = 0;



  xcp_ServiceInfo.daq_ptr.valid_flag     = XCP_DAQ_PTR_INVALID;

  /* reset status of all event channels */
  for (idx = 0; idx < XCP_MAX_EVENT_CHANNEL; idx++)
  {
    xcp_ServiceInfo.event_channel[idx].first_daq = 0;
    xcp_ServiceInfo.event_channel[idx].status    = XCP_EVENT_CHANNEL_NO_DAQ_ASSIGNED;
  }
    
}

/*******************************************************************************
* NAME:             Xcp_ClearDaqLst
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint16 daq
* RETURN VALUES:    Void
* DESCRIPTION:      clears a DAQ list.
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_ClearDaqLst(uint16 daq)
{
  Xcp_DaqLstType * XCP_VAR_DAQ_LST daq_list_ptr;
  Xcp_OdtEntryType    *odt_entry_ptr;
  uint16         no_of_odt_entries;
  uint16         odt_entry;
  uint8 odt;
  
  daq_list_ptr = &xcp_ServiceInfo.daq_list[daq];

  daq_list_ptr->mode = 0;

  /* if DAQ list is configurable, clear all ODT entries */
  if (daq >= XCP_MIN_DAQ)
  {
    /* odt_entry_ptr points to first ODT entry of first ODT of DAQ list */
    odt_entry_ptr = &xcp_ServiceInfo.odt_entry[daq_list_ptr->first_odt_entry];

    /* determine the total number of ODT entries of DAQ list */
    no_of_odt_entries = 0;

    for (odt = 0; odt < daq_list_ptr->no_of_odts; odt++)
    {
      no_of_odt_entries += xcp_ServiceInfo.odt[daq_list_ptr->first_odt + odt].no_of_odt_entries;
    }

    /* clear all ODT entries */
    for (odt_entry = 0; odt_entry < no_of_odt_entries; odt_entry++)
    {
      odt_entry_ptr->address_ptr = 0;
      odt_entry_ptr->extension   = 0;
      odt_entry_ptr->size        = 0;
      odt_entry_ptr->bit_offset  = 0xFF;
      odt_entry_ptr++;
    }
  }
}

/*******************************************************************************
* NAME:             Xcp_StartDaqLst
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint16 daq
* RETURN VALUES:    Void
* DESCRIPTION:      starts a DAQ list
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_StartDaqLst(uint16 daq)
{
  Xcp_DaqLstType * XCP_VAR_DAQ_LST daq_list_ptr;

  daq_list_ptr = &xcp_ServiceInfo.daq_list[daq];

  if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_CONFIGURED)
  {
    uint8  odt;
    uint8  no_of_configured_odts;
    uint16 entry_offset;

    entry_offset          = 0;
    no_of_configured_odts = 0;

    /* determine number of configured ODTs */
    entry_offset = xcp_ServiceInfo.odt[daq_list_ptr->first_odt].first_odt_entry;

    for (odt = 0; odt < daq_list_ptr->no_of_odts; odt++)
    {
      if (xcp_ServiceInfo.odt_entry[entry_offset].size == 0)
      {
        break;
      }
      else
      {
        no_of_configured_odts++;
        entry_offset += xcp_ServiceInfo.odt[daq_list_ptr->first_odt + odt].no_of_odt_entries;
      }
    }
    
    daq_list_ptr->no_of_configured_odts = no_of_configured_odts;
    daq_list_ptr->mode &= ~XCP_DAQ_LIST_MODE_SELECTED;
    daq_list_ptr->mode |= XCP_DAQ_LIST_MODE_RUNNING;

    /* set session status to state "DAQ running" */
    xcp_ServiceInfo.session_status |= XCP_SESSION_STATUS_DAQ_RUNNING;
  }
}

/*******************************************************************************
* NAME:             Xcp_StartSelectedDaqLst
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      starts all selected DAQ lists.
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_StartSelectedDaqLst(void)
{
  uint16 daq;

  for (daq = 0; daq < xcp_ServiceInfo.max_daq; daq++)
  {
    if (xcp_ServiceInfo.daq_list[daq].mode & XCP_DAQ_LIST_MODE_SELECTED)
    {
      Xcp_StartDaqLst( daq);
    }
  }
}

/*******************************************************************************
* NAME:             Xcp_StopDaqLst
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint16 daq
* RETURN VALUES:    Void
* DESCRIPTION:      stops a DAQ list
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_StopDaqLst( uint16 daq)
{
  xcp_ServiceInfo.daq_list[daq].mode &= ~(XCP_DAQ_LIST_MODE_SELECTED | XCP_DAQ_LIST_MODE_RUNNING);
}

/*******************************************************************************
* NAME:             Xcp_StopSelectedDaqLst
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      stops all selected DAQ lists.
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_StopSelectedDaqLst(void)
{
  uint16 daq;

  for (daq = 0; daq < xcp_ServiceInfo.max_daq; daq++)
  {
    if (xcp_ServiceInfo.daq_list[daq].mode & XCP_DAQ_LIST_MODE_SELECTED)
    {
      Xcp_StopDaqLst(daq);
    }
  }
}

/*******************************************************************************
* NAME:             Xcp_StopAllDaqLst
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      stops all DAQ lists.
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_StopAllDaqLst(void)
{
  uint16 daq;

  for (daq = 0; daq < xcp_ServiceInfo.max_daq; daq++)
  {
    Xcp_StopDaqLst( daq);
  }

  xcp_ServiceInfo.session_status &= ~XCP_SESSION_STATUS_DAQ_RUNNING;
}

/*******************************************************************************
* NAME:             Xcp_SelectDaqLst
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      selects a DAQ list
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_SelectDaqLst( uint16 daq)
{
  xcp_ServiceInfo.daq_list[daq].mode |= XCP_DAQ_LIST_MODE_SELECTED;
}

/*******************************************************************************
* NAME:             Xcp_InsertDaqLstToEventChannel
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint16 event_channel
*                   uint16 daq
* RETURN VALUES:    Void
* DESCRIPTION:      adds a DAQ list to the list of DAQ lists of an event channel
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_InsertDaqLstToEventChannel(uint16 event_channel, uint16 daq)
{
  Xcp_DaqLstType * XCP_VAR_DAQ_LST daq_list_ptr;

  daq_list_ptr = &xcp_ServiceInfo.daq_list[daq];

  /* if no DAQ list has been assigned to the event channel, the DAQ list
     is assigned as the first one */
  if (xcp_ServiceInfo.event_channel[event_channel].status == XCP_EVENT_CHANNEL_NO_DAQ_ASSIGNED)
  {
    daq_list_ptr->next_daq = daq;
    xcp_ServiceInfo.event_channel[event_channel].first_daq = daq;
    xcp_ServiceInfo.event_channel[event_channel].status    = XCP_EVENT_CHANNEL_DAQ_ASSIGNED;
  }
  /* another DAQ list has already been assigned to the event channel; the DAQ list
     is assigned to the event channel according its priority */
  else
  {
    uint16 first_daq;

    first_daq = xcp_ServiceInfo.event_channel[event_channel].first_daq;

    /* if the priority of the DAQ list is higher than the first DAQ list of the
       event channel, the DAQ list is assigned as the first one */
    if (daq_list_ptr->priority > xcp_ServiceInfo.daq_list[first_daq].priority)
    {
      daq_list_ptr->next_daq = first_daq;
      xcp_ServiceInfo.event_channel[event_channel].first_daq = daq;
    }
    else
    {
      uint16 current_daq;
      uint16 next_daq;

      current_daq = first_daq;
      next_daq    = xcp_ServiceInfo.daq_list[current_daq].next_daq;

      /* insert the DAQ list before a DAQ list with a lower priority */
      while (current_daq != next_daq)
      {
        if (daq_list_ptr->priority > xcp_ServiceInfo.daq_list[next_daq].priority)
        {
          daq_list_ptr->next_daq = next_daq;
          xcp_ServiceInfo.daq_list[current_daq].next_daq = daq;
          break;
        }

        current_daq = next_daq;
        next_daq    = xcp_ServiceInfo.daq_list[current_daq].next_daq;
      }

      if (current_daq == next_daq)
      {
        daq_list_ptr->next_daq = daq;
        xcp_ServiceInfo.daq_list[next_daq].next_daq = daq;
      }
    }
  }
}

/*******************************************************************************
* NAME:             Xcp_RemoveDaqLstFromEventChannel
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: uint16 event_channel
*                   uint16 daq
* RETURN VALUES:    Void
* DESCRIPTION:      removes a DAQ list to the list of DAQ lists of an event channel
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_RemoveDaqLstFromEventChannel(uint16 event_channel, uint16 daq)
{
  uint16 next_daq;

  next_daq = xcp_ServiceInfo.event_channel[event_channel].first_daq;

  /* check if there is only one DAQ list assigned to the event channel */
  if (next_daq == xcp_ServiceInfo.daq_list[next_daq].next_daq)
  {
    xcp_ServiceInfo.event_channel[event_channel].status = XCP_EVENT_CHANNEL_NO_DAQ_ASSIGNED;
  }
  else
  {
    uint16 first_daq;

    first_daq = xcp_ServiceInfo.event_channel[event_channel].first_daq;

    if (first_daq == daq)
    {
      xcp_ServiceInfo.event_channel[event_channel].first_daq = xcp_ServiceInfo.daq_list[first_daq].next_daq;
    }
    else
    {
      uint16 current_daq;

      current_daq = first_daq;
      next_daq    = xcp_ServiceInfo.daq_list[current_daq].next_daq;

      /* insert the DAQ list before a DAQ list with a lower priority */
      while (current_daq != next_daq)
      {
        if (daq == next_daq)
        {
          if (xcp_ServiceInfo.daq_list[next_daq].next_daq == next_daq)
          {
            xcp_ServiceInfo.daq_list[current_daq].next_daq = current_daq;
          }
          else
          {
            xcp_ServiceInfo.daq_list[current_daq].next_daq = xcp_ServiceInfo.daq_list[next_daq].next_daq;
          }
          break;
        }

        current_daq = next_daq;
        next_daq    = xcp_ServiceInfo.daq_list[current_daq].next_daq;
      }
    }
  }
}

/*******************************************************************************
* NAME:             Xcp_CheckDaqRunningMode
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      checks if at least one DAQ list is still started after
*                   stopping one or more DAQ lists.
*******************************************************************************/
_STATIC_ FUNC(void,XCP_CODE) Xcp_CheckDaqRunningMode(void)
{
  uint16 daq;

  /* iterate over all DAQ lists */
  for (daq = 0; daq < xcp_ServiceInfo.max_daq; daq++)
  {
    /* check if current DAQ list is started */
    if (xcp_ServiceInfo.daq_list[daq].mode & XCP_DAQ_LIST_MODE_RUNNING)
    {
      return;
    }
  }
  /* no DAQ list is started, reset DAQ flag of session status */
  xcp_ServiceInfo.session_status &= ~XCP_SESSION_STATUS_DAQ_RUNNING;
}

/*******************************************************************************
* NAME:             Xcp_CheckDaqBufferOverflow
* CALLED BY:        Xcp
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    E_OK : no memory overflow
*                   E_NOT_OK: 
* DESCRIPTION:      checks for a memory overflow in case of dynamic DAQ configuration
*******************************************************************************/
_STATIC_ FUNC(Std_ReturnType,XCP_CODE) Xcp_CheckDaqBufferOverflow(void)
{
  uint32 size;

  /* determine the required size for the current DAQ configuration */
  size = (xcp_ServiceInfo.max_daq           * sizeof(Xcp_DaqLstType))       +
         (xcp_ServiceInfo.odt_count         * sizeof(Xcp_DynDaqOdtType))    +
         (xcp_ServiceInfo.odt_entries_count * sizeof(Xcp_OdtEntryType));

  /* check if required size exceeds DAQ buffer size */
  if (size > XCP_DAQ_BUFFER_SIZE)
  {
    /* reset number of DAQ lists */
    xcp_ServiceInfo.max_daq = 0;

    return (E_NOT_OK);
  }
  else
  {
    return (E_OK);
  }
}

