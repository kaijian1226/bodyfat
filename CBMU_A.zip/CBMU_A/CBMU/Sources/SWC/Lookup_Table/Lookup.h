/*
 * File: Lookup.h
 *
 * Code generated for Simulink model 'Lookup'.
 *
 * Model version                  : 1.488
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Wed Jun 22 13:54:32 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Lookup_h_
#define RTW_HEADER_Lookup_h_
#include <stddef.h>
#include <string.h>
#ifndef Lookup_COMMON_INCLUDES_
# define Lookup_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* Lookup_COMMON_INCLUDES_ */

#include "Lookup_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  uint32_T m_bpIndex[2];               /* '<S2>/2-D Lookup Table' */
  uint32_T m_bpIndex_b[2];             /* '<S1>/2-D Lookup Table' */
} D_Work_Lookup;

/* Constant parameters (auto storage) */
typedef struct {
  /* Computed Parameter: DLookupTable_maxIndex
   * Referenced by: '<S2>/2-D Lookup Table'
   */
  uint32_T DLookupTable_maxIndex[2];

  /* Computed Parameter: DLookupTable_maxInd_d
   * Referenced by: '<S3>/2-D Lookup Table'
   */
  uint32_T DLookupTable_maxInd_d[2];

  /* Computed Parameter: DLookupTable_maxInd_l
   * Referenced by: '<S1>/2-D Lookup Table'
   */
  uint32_T DLookupTable_maxInd_l[2];

  /* Computed Parameter: DLookupTable_tableD
   * Referenced by: '<S2>/2-D Lookup Table'
   */
  uint16_T DLookupTable_tableD[140];

  /* Computed Parameter: DLookupTable_tableDa
   * Referenced by: '<S3>/2-D Lookup Table'
   */
  uint16_T DLookupTable_tableDa[25];

  /* Computed Parameter: DLookupTable_bp02Dat
   * Referenced by: '<S2>/2-D Lookup Table'
   */
  t_Voltage3 DLookupTable_bp02Dat[14];

  /* Computed Parameter: DLookupTable_bp01Data
   * Referenced by: '<S3>/2-D Lookup Table'
   */
  uint8_T DLookupTable_bp01Data[5];

  /* Computed Parameter: DLookupTable_bp01Da_d
   * Referenced by: '<S1>/2-D Lookup Table'
   */
  uint8_T DLookupTable_bp01Da_d[2];

  /* Computed Parameter: DLookupTable_bp02Data
   * Referenced by: '<S1>/2-D Lookup Table'
   */
  uint8_T DLookupTable_bp02Data[3];

  /* Computed Parameter: DLookupTable_bp01Dat
   * Referenced by: '<S2>/2-D Lookup Table'
   */
  t_Temp1 DLookupTable_bp01Dat[10];

  /* Computed Parameter: DLookupTable_bp02Da_c
   * Referenced by: '<S3>/2-D Lookup Table'
   */
  t_Temp1 DLookupTable_bp02Da_c[5];

  /* Computed Parameter: DLookupTable_tableDat
   * Referenced by: '<S1>/2-D Lookup Table'
   */
  t_Temp1 DLookupTable_tableDat[6];
} ConstParam_Lookup;

/* Real-time Model Data Structure */
struct tag_RTM_Lookup {
  const char_T * volatile errorStatus;
};

/* Block states (auto storage) */
extern D_Work_Lookup Lookup_DWork;

/* Constant parameters (auto storage) */
extern const ConstParam_Lookup Lookup_ConstP;

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  Code generation will declare the memory for
 * these signals and export their symbols.
 *
 */
extern uint8_T BM_Battery_SOC;         /* '<Root>/BM_Battery_SOC' */
extern uint8_T HeatingSt;              /* '<Root>/HeatingSt' */
extern uint8_T HeatingEnable;          /* '<Root>/HeatingEnable' */
extern uint16_T LPC_CUR;               /* '<S1>/Product' */
extern uint16_T LPEC_CUR;              /* '<S3>/2-D Lookup Table' */
extern t_Temp1 FcTempTooLow;           /* '<S1>/2-D Lookup Table' */

/* Model entry point functions */
extern void Lookup_initialize(void);
extern void Lookup_step(void);
extern void Lookup_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Lookup *const Lookup_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Lookup'
 * '<S1>'   : 'Lookup/Subsystem2'
 * '<S2>'   : 'Lookup/Subsystem2/Subsystem'
 * '<S3>'   : 'Lookup/Subsystem2/Subsystem1'
 */
#endif                                 /* RTW_HEADER_Lookup_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
