/*******************************************************************************
*
*  FILE
*     IIC.c
*
*  DESCRIPTION
*     The Driver for freescale IIC
*      
*       
*  COPYRIGHT
*     (c)Copyright 2011, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*    Gu Bin
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

/*******************************************************************************
* include files
*******************************************************************************/
#include "IIC.h"
         
/*******************************************************************************
* Defines
*******************************************************************************/

/*******************************************************************************
* Macros
*******************************************************************************/

/*******************************************************************************
* Global Variables definition
*******************************************************************************/

/*******************************************************************************
* Local Variables definition
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes
*******************************************************************************/


/*******************************************************************************
* Functions
*******************************************************************************/     

/*******************************************************************************
* NAME:             IIC_ReceiveOneByte
* CALLED BY:
* PRECONDITIONS:
* INPUT PARAMETERS: slaver_addr: this is slaver address .
                    operation_addr: this address is the internal address in the salver.
                    iic_rx:  this vaule be from IIC bus.
* RETURN VALUES:    fault or success
* DESCRIPTION:      mcu read one byte data from IIC bus.  
*******************************************************************************/
Std_ReturnType IIC_ReceiveOneByte(IIC_ADDR_TYPE slaver_addr, uint8 operation_addr ,uint8 *iic_rx)
{
  uint8 index; 
  
  /* send ACK signal */
  IIC_IBCR &= ~IIC_IBCR_TXAK_MASK;
  /* send mode */
  IIC_IBCR |= IIC_IBCR_TX_RX_MASK;
  /* produce start signal */      
  IIC_IBCR |= IIC_IBCR_MS_SL_MASK;        
  /* send salver address , R/W=0 , write mode */
  IIC_IBDR = slaver_addr & 0xfe;    
    
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)                 
  {
    return E_NOT_OK;           
  }
  
  /* send operation address */
  IIC_IBDR = operation_addr;         
   
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)             
  {
    return E_NOT_OK;  
  }
    
  /* send Repeat Start signal */
  IIC_IBCR |= IIC_IBCR_RSTA_MASK;    
  /* send salver address agine, R/W=1 , read mode */            
  IIC_IBDR = slaver_addr | 0x01;     
   
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)           
  {  
    return E_NOT_OK;            
  }    
    
  
  /* receive mode */
   IIC_IBCR &= ~IIC_IBCR_TX_RX_MASK;
  /* NO ACK */
  IIC_IBCR |= IIC_IBCR_TXAK_MASK; 
  /* read iic data register */               
  *iic_rx = IIC_IBDR;           
       
  /* wait transmit success */  
  if (IIC_WaitTransmit() == E_NOT_OK)        
  {
    return E_NOT_OK;              
  }
  /* send stop signal */  
  IIC_IBCR &= ~IIC_IBCR_MS_SL_MASK; 
  for (index = 0; index<IIC_STOP_DELAY; index++ )
  {
  }
      
  /* read iic data register again */    
  *iic_rx = IIC_IBDR;  
  
  /* reutrn receive success */       
  return E_OK;               
}

/*******************************************************************************
* NAME:             IIC_WriteOneByte
* CALLED BY:
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    fault or success
* DESCRIPTION:      MCU write one byte to IIC bus.   
*******************************************************************************/
Std_ReturnType IIC_SendOneByte(IIC_ADDR_TYPE slaver_addr, uint8 operation_addr ,uint8 iic_tx)
{
  uint8 index; 
  
  /* send ACK signal */
  IIC_IBCR &= ~IIC_IBCR_TXAK_MASK;
  /* send mode */
  IIC_IBCR |= IIC_IBCR_TX_RX_MASK;
  /* produce start signal */      
  IIC_IBCR |= IIC_IBCR_MS_SL_MASK; ;        
  /* send salver address , R/W=0 , write mode */
  IIC_IBDR = slaver_addr & 0xfe;    
    
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)                 
  {
    return E_NOT_OK;           
  }           
    
  /* send operation address */
  IIC_IBDR = operation_addr;         
   
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)             
  {
    return E_NOT_OK;           
  } 
     
  /* data send to iic data regsiter */ 
  IIC_IBDR = iic_tx;           
  
  /* wait transmit success ,and wait ACK signal */ 
  if (IIC_Wait() == E_NOT_OK)             
  {
    return E_NOT_OK;           
  }            
  
  /* send stop signal */  
  IIC_IBCR &= ~IIC_IBCR_MS_SL_MASK; 
  for (index = 0; index<IIC_STOP_DELAY; index++ )
  {
  }
  /* reutrn send success */       
  return E_OK;               
}

/*******************************************************************************
* NAME:             IIC_ReadMulByte
* CALLED BY:
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    fault or success
* DESCRIPTION:      mcu read multi byte data from IIC bus.  
*******************************************************************************/
Std_ReturnType IIC_ReceiveMulByte(IIC_ADDR_TYPE slaver_addr, uint8 operation_addr ,uint8 length, uint8 *iic_rx)
{
  uint8 index;
  
  /* send ACK signal */
  IIC_IBCR &= ~IIC_IBCR_TXAK_MASK;
  /* send mode */
  IIC_IBCR |= IIC_IBCR_TX_RX_MASK;
  /* produce start signal */      
  IIC_IBCR |= IIC_IBCR_MS_SL_MASK; ;        
  /* send salver address , R/W=0 , write mode */
  IIC_IBDR = slaver_addr & 0xfe;    
    
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)             
  {
    return E_NOT_OK;           
  }                
    
  /* send operation address */
  IIC_IBDR = operation_addr;         
   
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)             
  {
    return E_NOT_OK;           
  }             
  
    
  /* send Repeat Start signal */
  IIC_IBCR |= IIC_IBCR_RSTA_MASK;    
  /* send salver address agine, R/W=1 , read mode */            
  IIC_IBDR = slaver_addr | 0x01;     
   
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)             
  {
    return E_NOT_OK;           
  }         
    
  
  /* receive mode */
  IIC_IBCR &= ~IIC_IBCR_TX_RX_MASK;
  /* dummy read */
  index = IIC_IBDR;
  
  for(index=0;index<(length-1);index++)
  {           
    /* wait transmit success */  
    if (IIC_WaitTransmit() == E_NOT_OK)        
    return E_NOT_OK; 
    
    /* read iic data register */               
    *iic_rx++ = IIC_IBDR;    
  }
  
  /* send NO ACK signal */
  IIC_IBCR |= IIC_IBCR_TXAK_MASK;
  /* wait transmit success */  
  if (IIC_WaitTransmit() == E_NOT_OK)        
  {  
    return E_NOT_OK; 
  }
    
  /* send stop signal */  
  IIC_IBCR &= ~IIC_IBCR_MS_SL_MASK; 
  for (index = 0; index<IIC_STOP_DELAY; index++)
  {
  }
    
  /* read iic data register again */ 
  *iic_rx = IIC_IBDR; 
  
  /* reutrn receive success */       
  return E_OK; 
}

/*******************************************************************************
* NAME:             IIC_WriteMulByte
* CALLED BY:
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    fault or success
* DESCRIPTION:      mcu write multi byte data from IIC bus.  
*******************************************************************************/
Std_ReturnType IIC_SendMulByte(IIC_ADDR_TYPE slaver_addr, uint8 operation_addr ,uint8 length, uint8 *iic_tx)
{
  uint8 index;
  
  /* send ACK signal */
  IIC_IBCR &= ~IIC_IBCR_TXAK_MASK;
  /* send mode */
  IIC_IBCR |= IIC_IBCR_TX_RX_MASK;
  /* produce start signal */      
  IIC_IBCR |= IIC_IBCR_MS_SL_MASK; ;        
  /* send salver address , R/W=0 , write mode */
  IIC_IBDR = slaver_addr & 0xfe;    
    
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)             
  {
    return E_NOT_OK;           
  }           
    
  /* send operation address */
  IIC_IBDR = operation_addr;         
   
  /* wait transmit success ,and wait ACK signal */
  if (IIC_Wait() == E_NOT_OK)             
  {
    return E_NOT_OK;           
  }            
  
  for(index=0;index<length;index++)
  {    
    /* data send to iic data regsiter */ 
    IIC_IBDR = *iic_tx++;           
  
    /* wait transmit success ,and wait ACK signal */ 
    if (IIC_Wait() == E_NOT_OK)             
    {
      return E_NOT_OK;           
    }              
  }
  /* send stop signal */  
  IIC_IBCR &= ~IIC_IBCR_MS_SL_MASK; 
  for (index = 0; index<IIC_STOP_DELAY; index++)
  {
  }

  /* reutrn send success */       
  return E_OK;  
}

/*******************************************************************************
* NAME:             IIC_init
* CALLED BY:
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize IIC   
*******************************************************************************/
void IIC_Init(void)
{ 
  IIC_Routing();
  
  /* setting baudrate */
  IIC_IBFD = IIC_BAUDRATE;
  
  /* address mode , 7bit or 10bit */
  IIC_IBCR2 &= ~IIC_IBCR2_ADTYPE_MASK;
  /* setting slaver address */    
  IIC_IBAD = IIC_SLAVE_ADDR;
  /* enable iic bus */
  IIC_IBCR |= IIC_IBCR_IBEN_MASK;
  /* slaver mode */
  IIC_IBCR &= ~IIC_IBCR_MS_SL_MASK;
  /* send mode */
  IIC_IBCR &= ~IIC_IBCR_TX_RX_MASK;
  /* disable iic inttrup */
  IIC_IBCR &= ~IIC_IBCR_IBIE_MASK;
  
  /* disable General Call */
  IIC_IBCR2 &= ~IIC_IBCR2_GCEN_MASK;   

}

Std_ReturnType IIC_WaitTransmit(void)
{
  uint16 index;
  
  for (index = 0;index < IIC_WAIT_MAX;index++)
  {   
    if ((IIC_IBSR & IIC_IBSR_IBIF_MASK) != 0)    
    {
      /* write 1 to clear IBIF bit */
      IIC_IBSR |= IIC_IBSR_IBIF_MASK;   
      return E_OK;   
    }       
  }
  
   /* 2015-07-01, lzy, we should send stop signal here */  
  IIC_IBCR &= ~IIC_IBCR_MS_SL_MASK; 
  for (index = 0; index<IIC_STOP_DELAY; index++)
  {
  }
 
  return E_NOT_OK;  
}



Std_ReturnType IIC_Wait(void)
{
  uint16 index;
  
  index =0;

  do
  {
  }while (((IIC_IBSR & IIC_IBSR_IBIF_MASK) == 0) && (index++ < IIC_WAIT_MAX));
  
  if (index >= IIC_WAIT_MAX)
  {
     /* 2015-07-14, lzy, we should send stop signal here */  
    IIC_IBCR &= ~IIC_IBCR_MS_SL_MASK; 
    for (index = 0; index<IIC_STOP_DELAY; index++)
    {
    }
  
    return E_NOT_OK; 
  }
  
  /* write 1 to clear IBIF bit */
  IIC_IBSR |= IIC_IBSR_IBIF_MASK;   
  
  index =0;
      
  do
  {
  }while (((IIC_IBSR & IIC_IBSR_RXAK_MASK) != 0) && (index++ < IIC_WAIT_MAX));
  
  if (index >= IIC_WAIT_MAX)
  {
  
     /* 2015-07-01, lzy, we should send stop signal here */  
    IIC_IBCR &= ~IIC_IBCR_MS_SL_MASK; 
    for (index = 0; index<IIC_STOP_DELAY; index++)
    {
    }
 
  
  
    return E_NOT_OK; 
  }
     
  return E_OK;  
}








