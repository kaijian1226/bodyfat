/*******************************************************************************
*
*  FILE
*     Can_Types.h
*
*  DESCRIPTION
*     CAN data type  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.1
*
*******************************************************************************/
#ifndef _CAN_TYPES_H_
#define _CAN_TYPES_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "ComStack_Types.h"

/*******************************************************************************
* Type Definition                                                                
*******************************************************************************/

/* 
This is the type of the external data structure containing the overall initialization
data for the CAN driver and SFR settings affecting all controllers.
*/
typedef struct 
{
  uint8 CanInitCTL0;       /* Control Register 0         */
  uint8 CanInitCTL1;       /* Control Register 1         */
  uint8 CanInitCBTR0;      /* Bus Timing 0               */
  uint8 CanInitCBTR1;      /* Bus Timing 1               */
  uint8 CanInitCIDAC;      /* Acceptance Control Register  */
  uint8 CanInitCIDAR0;     /* ID acceptance register     */
  uint8 CanInitCIDAR1;     /* ID acceptance register     */
  uint8 CanInitCIDAR2;     /* ID acceptance register     */
  uint8 CanInitCIDAR3;     /* ID acceptance register     */
  uint8 CanInitCIDMR0;     /* ID mask register           */
  uint8 CanInitCIDMR1;     /* ID mask register           */
  uint8 CanInitCIDMR2;     /* ID mask register           */
  uint8 CanInitCIDMR3;     /* ID mask register           */
  uint8 CanInitCIDAR4;     /* ID acceptance register     */
  uint8 CanInitCIDAR5;     /* ID acceptance register     */
  uint8 CanInitCIDAR6;     /* ID acceptance register     */  
  uint8 CanInitCIDAR7;     /* ID acceptance register     */
  uint8 CanInitCIDMR4;     /* ID mask register           */
  uint8 CanInitCIDMR5;     /* ID mask register           */
  uint8 CanInitCIDMR6;     /* ID mask register           */
  uint8 CanInitCIDMR7;     /* ID mask register           */
}Can_ConfigType;

/*
configuration dependent
uint16: if only Standard IDs are used
uint32: if also Extended IDs are used
*/
typedef uint32 Can_IdType;

typedef uint8 Can_CntrlType;

typedef uint8 Can_DlcType;

typedef uint8 Can_HwHandleType;


typedef enum
{
  CAN_STD_ID = 0,
  CAN_EXT_ID = 1,
}Can_IdRngType;


typedef volatile struct
{
  Can_IdType Id;         /* complete ID                                     */
  uint8  DataFld[8];     /* Data 0 .. 7                                     */
  uint8  Dlc;            /* Data length reg.:  X X X X DLC3 DLC2 DLC1 DLC0  */
  uint8  Prio;           /* TxBuf priority reg.                             */
  uint8  Unused[2];
}Can_MsgObjType;

typedef struct
{
  Can_DlcType length;
  Can_IdType id;
  uint8* sdu;
}Can_PduType;

typedef volatile struct
{
  uint8      CanCTL0;         /* RXFRM RXACT  CSWAI   SYNCH   TIME    WUPE    SLPRQ  INITRQ  */
  uint8      CanCTL1;         /* CANE  CLKSRC LOOPB   LISTEN  0       WUPM    SLPAK  INITAK  */
  uint8      CanCBTR0;        /* SJW1  SJW0   BRP5    BRP4    BRP3    BRP2    BRP1   BRP0    */
  uint8      CanCBTR1;        /* SAMP  TSEG22 TSEG21  TSEG20  TSEG13  TSEG12  TSEG11 TSEG10  */
  uint8      CanCRFLG;        /* WUPIF CSCIF  RSTAT1  RSTAT0  TSTAT1  TSTAT0  OVRIF  RXF     */
  uint8      CanCRIER;        /* WUPIE CSCIF  RSTATE1 RSTATE0 TSTATE1 TSTATE0 OVRIE  RXE     */
  uint8      CanCTFLG;        /* 0     0     0       0       0       TXE2    TXE1   TXE0     */
  uint8      CanCTIER;        /* 0     0     0       0       0       TXEIE2  TXEIE1 TXEIE0   */
  uint8      CanCTARQ;        /* 0     0     0       0       0       ABTRQ2  ABTRQ1 ABTRQ0   */
  uint8      CanCTAAK;        /* 0     0     0       0       0       ABTAK2  ABTAK1 ABTAK0   */
  uint8      CanCTBSEL;       /* 0     0     0       0       0       TXE2    TXE1   TXE0     */
  uint8      CanCIDAC;        /* 0     0     IDAM1   IDAM0   0       0       IDHIT1 IDHIT0   */
  uint8      Reserved1;
  uint8      CanCMISC;        /* 0     0     0       0       0       0       0      BOHOLD   */
  uint8      CanCRXERR;       /* RXERR7 ... RXERR0                          */
  uint8      CanCTXERR;       /* TXERR7 ... TXERR0                          */
  uint8      CanCIDAR0;       /* Filter Masks 0..3                          */
  uint8      CanCIDAR1;
  uint8      CanCIDAR2;
  uint8      CanCIDAR3;
  uint8      CanCIDMR0;
  uint8      CanCIDMR1;
  uint8      CanCIDMR2;
  uint8      CanCIDMR3;
  uint8      CanCIDAR4;       /* Filter Masks 4..7 */
  uint8      CanCIDAR5;
  uint8      CanCIDAR6;
  uint8      CanCIDAR7;
  uint8      CanCIDMR4;
  uint8      CanCIDMR5;
  uint8      CanCIDMR6;
  uint8      CanCIDMR7;
  Can_MsgObjType  CanRxBuf;        /* Rx-Msg Object */
  Can_MsgObjType  CanTxBuf;        /* Tx-Msg Objects */
}Can_CtrlRegType;

typedef volatile struct
{
  uint8 oldCanCRIER;
  uint8 oldCanCTIER;  
}Can_IrqRegType;

typedef struct 
{
  volatile uint8* pChipMsgObj;
  volatile uint8* pChipData;
}Can_RxInfoType;

typedef enum{
  CAN_OK     = 0,
  CAN_NOT_OK = 1,
  CAN_BUSY   = 2,
  CAN_WAKEUP = 3
}Can_ReturnType;

typedef enum{
  CAN_T_START     = 0,
  CAN_T_STOP      = 1,
  CAN_T_SLEEP     = 2,
  CAN_T_WAKEUP    = 3
}Can_StateTransitionType;


/*******************************************************************************
* Define                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/



#endif /* #ifndef _CAN_TYPES_H_ */