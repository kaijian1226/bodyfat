#ifndef _VFB_H_
#define _VFB_H_

#include "Std_Types.h"
#include "Variant_Cfg.h"
#include "Dem_Cfg.h"  
//#include "Com.h"
                              

typedef struct	     
{	
	uint32 mTotalDistance;
	uint8  mStartSOC;    
	uint8  mEndSOC;
	uint16 mStartPackVoltage;
	uint16 mEndPackVoltage;
	uint8  mPackTempMin;
	uint8  mPackTempMax;                        
	uint8  mStartCellVoltageMin;
	uint8  mEndCellVoltageMin;
	uint8  mStartCellVoltageMax;                 
	uint8  mEndCellVoltageAcerage;
	uint8  mStartCellVoltage;
	uint8  mEndCellVoltageAverage;
	uint8  mBMU1AMBCounter;
	uint8  mBMU2AMBCounter;
	uint8  mBMU3AMBCounter;
	uint8  mBMU4AMBCounter;
	uint16 mPackCurrentMax;
	uint16 mACBCounter;
}VehPowerDownDataStr;	

typedef struct	
{	
	uint32 mTotalDistance;
	uint8  mStartSOC;
	uint8  mEndSOC;
	uint8  mChargedAH;
	uint16 mStartPackVoltage;
	uint16 mEndPackVoltage;
	uint8  mChargeSeconds;
	uint8  mStartPackTempMin;
	uint8  mEndPackTempMin;
	uint8  mStartPackTempMax;
	uint8  mEndPackTempMax;
	uint8  mStartPackTempAverage;
	uint8  mEndPackTempAverage;
	uint8  mStartCellVoltageMin;
	uint8  mEndCellVoltageMin;
	uint8  mStartCellVoltageMax;
	uint8  mEndCellVoltageMax;
	uint8  mStartCellVoltageAverage;
	uint8  mEndCellVoltageAverage;
	uint16 mChargeCounter;
	uint16 mPackCurrentMax;
	uint8  mBMU1AMBCounter;
	uint8  mBMU2AMBCounter;
	uint8  mBMU3AMBCounter;
	uint8  mBMU4AMBCounter;
	uint16 mACBCounter;
}ChrgPowerDownDataStr;

#pragma DATA_SEG TRIP_RECORD
extern VehPowerDownDataStr TRPR_VAR_FAR trpr_PwrDwnData[100];
extern ChrgPowerDownDataStr TRPR_VAR_FAR trpr_SlwChrgDwnData[20];
extern ChrgPowerDownDataStr TRPR_VAR_FAR trpr_FstChrgDwnData[2];

extern uint8 TRPR_VAR_FAR trpr_PwrDwnDataIdx;
extern uint8 TRPR_VAR_FAR trpr_SlwChrgDwnDataIdx;
extern uint8 TRPR_VAR_FAR trpr_FstChrgDwnDataIdx;

#pragma DATA_SEG DEFAULT			

extern boolean trpr_tripRcdDataValid;
extern uint8 PackCurMode;

/***************************************************************************
*                        From SWC                                          
***************************************************************************/
// To Inner Bus, Cmd Message
extern uint8 com_BalEnable[25];
extern uint8 com_CurrentSet;
extern uint8 com_ShutDown;
extern uint8 com_chrgCmd;
extern uint8 com_chrgCellNum;
extern uint8 com_chrgDuration;

// To Vehicle Bus
extern uint16 com_BPVP1BattVolt;
extern uint16 com_BPVP1MaxCellVolt;
extern uint16 com_BPVP1MinCellVolt;
extern uint16 com_BPVP1AvrgCellVolt;
extern uint16 com_BPVP1MaxCellNum;
extern uint16 com_BPVP1MinCellNum;

extern uint8 com_BPTP1MaxCellNum;
extern uint8 com_BPTP1MinCellNum;
extern uint8 com_BPTP1MinCellTemp;
extern uint8 com_BPTP1MaxCellTemp;
extern uint8 com_BPTP1AvrgCellTemp;

extern uint16 com_BPC1MinDchrgVolt;
extern uint8 com_BPC1CurrChrgVol;
extern uint16 com_BPC1MaxDchrgCurrent;

extern boolean com_BPC2ChrgrACInput;
extern boolean com_BPC2ChrgEnable;
extern uint8   com_BPC2ChrgSts;
extern uint16 com_BPC2MaxChrgVolt;
extern uint16 com_BPC2MaxChrgCurrent;


extern uint8   com_BPSSelfChkSts;
extern uint8   com_BPSDisChMRelaySts;
extern uint8   com_BPSChMRelaySts;
extern uint8   com_BPSFCContactSts; //add 20150819 
extern uint8   com_BPSHighVoltSts;
extern boolean com_BPSBattVoltLowAlarm;
extern boolean com_BPSBattTempHighAlarm;
extern boolean com_BPSBattLeakAlarm;
extern boolean com_BPSCellVoltLowAlarm;
extern boolean com_BPSVolumLowAlarm;
extern boolean com_BPSBattMaintenanceAlarm;
extern boolean com_BPSOverCurrAlarm;
extern uint8  com_BPSSOC;
extern uint16 com_BPSCurrent;
extern uint16 com_BPSInsulationResistance;         

/* to fast charger */
extern uint16 com_CPMaxChrgVolt;
extern uint16 com_CPCmdChrgCurr;
extern uint8  com_CPCtl;
extern uint8  com_CPModuleNum;

extern uint16 com_SP1BattVolt;
extern uint16 com_SP1BattCurr;
extern uint16 com_SP1Soc;
extern uint16 com_SP1CellAlarmUpVolt;

extern uint16 com_SP2CellShutUpVolt;
extern uint16 com_SP2CellAlarmLwrVolt;
extern uint16 com_SP2CellShutLwrVolt;
extern uint16 com_SP2CellDiffAlarm;

extern uint16 com_SP3TempAlarmUpVal;
extern uint16 com_SP3MaxChrgCurr;
extern uint16 com_SP3MaxDchrgCurr;
extern uint16 com_SP3Volum;

// Comm Control Label.
extern boolean com_VehBusRxEna;
extern boolean com_InnerBusRxEna;
extern boolean com_SlowChrgrRxEna;
extern boolean com_FastChrgrRxEna;

extern boolean com_VehBusTxEna;
extern boolean com_InnerBusTxEna;
extern boolean com_SlowChrgrTxEna;
extern boolean com_FastChrgrTxEna;

// Relay Control
extern boolean ioa_DisChMRelayCtl;  
extern boolean ioa_PreChargeRelayCtl; //add 20151027Ԥ��̵���
extern boolean Relay_CZ;//add 20150819
extern boolean ioa_ChMRelayCtl;
extern boolean ioa_NegativeRelayCtl;
extern boolean ioa_Resvd1RelayCtl;
extern boolean ioa_Resvd2RelayCtl;
extern boolean ioa_DCRelayCtl;


//�����̵������� 20150925
extern boolean ioa_FanRelayCtl;
extern boolean ioa_AirACRelayCtl;
extern boolean ioa_FCRelayCtl;
extern boolean ioa_PTCRelayCtrl;
extern boolean ioa_AirPTCRelayCtl;
                                  

extern uint8 COM_FM1St; 
extern uint8 COM_FM2St;  
extern uint8 COM_FM3St;  


extern uint8 BMU_NoActive[25];//BMU��������� ����Ϊ0 ��ʧΪ1  20150905
extern boolean com_RelayTimeoutFlag; //������������ʧ�ź� 20151029 
 
extern uint16 BM_VMS_Mil;//������������������  20151205
extern uint8 DCVolt_Reach;//2151205


// Low side Switch Control
extern boolean ioa_slowChrgEnaCtl;
extern boolean ioa_lowSide1Ctl;
extern boolean ioa_lowSide2Ctl;
extern boolean ioa_lowSide3Ctl;

//Power Control                     
extern boolean ioa_12VOut;
extern boolean ioa_5VOut;
extern boolean ioa_PwrOut;

/***************************************************************************
*                       To SWC                                          
***************************************************************************/
//BMU from Inner Bus 
extern uint8 Cell_Module_Num;	//���ģ����
extern uint8 Temp_Number;		//ÿ�����¶ȴ�������Ŀ
extern uint16 Total_CellNumber;	//�ܵ�о��Ŀ
extern uint8 Module_CellNumber[25];	//ÿ���ص�о��Ŀ

extern uint8  com_CellTemp[25][5];

//CV
extern uint16  com_CellVoltCur[25][12];   //��ǰģ�鵥о��ѹ 20151210
extern uint16  com_CellVoltBef[25][12];   //��ǰģ�鵥о��ѹ 
extern uint16  com_CellVoltCgeCnt[25];  //��о��ѹ�仯����ֵ

extern uint8  com_BalanceSts[25];
extern uint8  com_CellTempAvrg[25];
extern uint8  com_CellTempMax[25];
extern uint8  com_CellTempMin[25];
extern uint8  com_CellTempMaxNum[25];
extern uint8  com_CellTempMinNum[25];
extern uint8  com_CurSet[25];
extern uint8  com_ModuleStatus[25];
extern uint8  com_CellAlarm[25];

extern uint16  com_CellVoltAvrg[25];
extern uint16  com_CellVoltMax[25];
extern uint16  com_CellVoltMin[25];
extern uint8  com_CellVoltMaxNum[25];
extern uint8  com_CellVoltMinNum[25];

//HVCU from Inner Bus 
extern uint16 com_BattVoltOrg;
extern uint16 com_BattCurr;
extern uint16 com_Resistance;
extern uint16 com_ResistancePos;
extern uint16 com_ResistanceNeg;
extern uint8  com_SOC;

//HVCU HVA1
extern uint32 com_hva1Alarm;
extern uint8 com_hva1ModuleSts;
extern uint16 com_hva1FaultCode;


// From Vehicle Bus, Chrgr
extern uint8  com_CCP1HwFault;
extern uint8  com_CCP1ACConnect;
extern uint8  com_CCP1TempSts;
extern uint8  com_CCP1CommSts;
extern uint8  com_CCP1ACRange;
extern uint8  com_CCP1ChrgrTemp;
extern uint8  com_CCP1ChrgrPreReadySts;
extern uint16 com_CCP1ChrgCurrOut;
extern uint16 com_CCP1ChrgVolt;

//From Motor, Vehicle Bus.
extern uint8 com_MSP3MotorTrq;
extern uint16 com_MSP3MotorSpd;

extern uint16 com_MSP1MotorDcVolt;
extern uint16 com_MSP1MotorDcCurr;

//From Dashboard, Vehicle Bus
extern uint32 com_VDTotalOdometer;
extern uint32 com_VDTripOdometer;

// From Fast Charger, Fast Charger Bus
extern uint16 com_CSOutVolt;
extern uint16 com_CSOutCurrent;
extern uint16  com_CSStatus1;
extern uint16  com_CSStatus2;

extern uint16 com_CCMaxChrgVolt;
extern uint16 com_CCMaxChrgCurr;
extern uint8  com_CCChrgSts;

// From AD HW
extern uint16 ioa_T15VoltActRaw;
extern uint16 ioa_chrgVoltActRaw;
extern uint16 ioa_battVoltActRaw;
extern uint16 ioa_vccVoltActRaw;
extern uint16 ioa_sensorSplyVoltActRaw;
extern uint16 ioa_gasVoltRaw;
extern uint16 ioa_gasPressureVoltRaw;
extern uint16 ioa_12VOutVoltActRaw;
// add for C Sample 
extern uint16 ioa_FC12VVoltActRaw ;  // need multiply 11 
extern uint16 ioa_HVILVoltActRaw  ;
extern uint16 ioa_FCCCVoltActRaw  ;
extern uint16 ioa_SCCCVoltActRaw  ;

// From Ping Bus
extern boolean pbs_PingBusHeart;
extern uint8   pbs_PingBusCode[25]; 


extern boolean SID_m_st_ChMRelay;
extern boolean SID_m_st_DisChMRelay;

extern boolean ioa_T15SwtSts;
extern uint8   TTT; 

extern uint8 AirconCtrlOrder;		//�յ���������
extern uint8 AirPTCConCtrlOrder;		//�յ�AC��������

extern uint8 DebugMode;	//����ģʽ��־λ:0-δ����;1-�������ģʽ���ɶ����м̵������е�������
extern uint8 FCRelayCtrlIO;	//���̵�����������
extern uint8 FanRelayCtrlIO;	//���ȼ̵�����������
extern uint8 AirACRelayCtrlIO;	//�յ�AC�̵�����������
extern uint8 AirPTCRelayCtrlIO;	//�յ�PTC�̵�����������
extern uint8 PTCRelayCtrlIO;	//��ؼ��ȼ̵�����������
extern uint8 DisChMRelayCtrlIO;	//�ŵ����̵�����������
extern uint8 ChMRelayCtrlIO;		//������̵�����������
extern uint8 PreChargeRelayCtrlIO;	//�ŵ�Ԥ��̵�����������
extern uint8 NegativeRelayCtrlIO;	//�����̵�����������

extern uint8 DisChMRelayStateIO;	//�ŵ����̵����ؼ�����
extern uint8 ChMRelayStateIO;		//������̵����ؼ�����

extern uint8 O_S_FCCC;  

extern uint8 HeatingSt;	//��ؼ���״̬:0δ���ȣ�1������ɣ�2������

/***************************************************************************
*                       Constant                                         
***************************************************************************/

/****************** DTC Index **************************/
/*
#define DTC_IDX_CT_HIGH               0
#define DTC_IDX_CV_HIGH              (DTC_IDX_CT_HIGH +1)          
#define DTC_IDX_CT_LOW               (DTC_IDX_CV_HIGH +1)         
#define DTC_IDX_CV_LOW               (DTC_IDX_CT_LOW  +1)        
#define DTC_IDX_CHG_CURR_HIGH        (DTC_IDX_CV_LOW  +1)      
#define DTC_IDX_DISCHG_CURR_HIGH     (DTC_IDX_CHG_CURR_HIGH+1)     
#define DTC_IDX_PV_HIGH              (DTC_IDX_DISCHG_CURR_HIGH+1)  
#define DTC_IDX_PV_LOW               (DTC_IDX_PV_HIGH +1)     
#define DTC_IDX_ISO_LOW              (DTC_IDX_PV_LOW  +1)     
#define DTC_IDX_CT_DIFF_HIGH         (DTC_IDX_ISO_LOW +1)        
#define DTC_IDX_POWER_CAP_LOW        (DTC_IDX_CT_DIFF_HIGH+1)      
#define DTC_IDX_CV_DIFF_HIGH         (DTC_IDX_POWER_CAP_LOW+1)     
#define DTC_IDX_HVCU_COMERR          (DTC_IDX_CV_DIFF_HIGH +1)     
#define DTC_IDX_BMU1_COMERR          (DTC_IDX_HVCU_COMERR +1)      
#define DTC_IDX_BMU2_COMERR          (DTC_IDX_BMU1_COMERR +1)      
#define DTC_IDX_BMU3_COMERR          (DTC_IDX_BMU2_COMERR +1)      
#define DTC_IDX_BMU4_COMERR          (DTC_IDX_BMU3_COMERR +1)      
#define DTC_IDX_CAN6_COMERR          (DTC_IDX_BMU4_COMERR +1)      
#define DTC_IDX_VEH_COMERR           (DTC_IDX_CAN6_COMERR +1)      
#define DTC_IDX_FCHG_COMERR          (DTC_IDX_VEH_COMERR  +1)      
#define DTC_IDX_MOUDL_EERR           (DTC_IDX_FCHG_COMERR +1)      
#define DTC_IDX_EXTERN_UINT_ERR      (DTC_IDX_MOUDL_EERR  +1)      
#define DTC_IDX_HV_INTERLOCK_ERR     (DTC_IDX_EXTERN_UINT_ERR +1)  
#define DTC_IDX_CRASH_SW_ERR         (DTC_IDX_HV_INTERLOCK_ERR+1)  
#define DTC_IDX_RLY_STICKY_FAULT     (DTC_IDX_CRASH_SW_ERR+1) 
#define DTC_IDX_HARDWARE_FAULT       (DTC_IDX_RLY_STICKY_FAULT +1)    
*/

/* Event Id */
/*#define HVA1_TIME_OUT                  DTC_IDX_HVCU_COMERR
#define HVM1_TIME_OUT                  DTC_IDX_HVCU_COMERR
#define M1CMT_TIME_OUT                 DTC_IDX_BMU1_COMERR
#define M1STS1_TIME_OUT                DTC_IDX_BMU1_COMERR
#define M1STS2_TIME_OUT                DTC_IDX_BMU1_COMERR //
#define M2CMT_TIME_OUT                 DTC_IDX_BMU2_COMERR
#define M2STS1_TIME_OUT                DTC_IDX_BMU2_COMERR
#define M2STS2_TIME_OUT                DTC_IDX_BMU2_COMERR 
#define M3CMT_TIME_OUT                 DTC_IDX_BMU3_COMERR
#define M3STS1_TIME_OUT                DTC_IDX_BMU3_COMERR
#define M3STS2_TIME_OUT                DTC_IDX_BMU3_COMERR 
#define M4CMT_TIME_OUT                 DTC_IDX_BMU4_COMERR
#define M4STS1_TIME_OUT                DTC_IDX_BMU4_COMERR
#define M4STS2_TIME_OUT                DTC_IDX_BMU4_COMERR
#define CCP1_TIME_OUT                  DTC_IDX_VEH_COMERR
#define MSP1_TIME_OUT                  DTC_IDX_VEH_COMERR
#define MSP3_TIME_OUT                  DTC_IDX_VEH_COMERR
#define VD_TIME_OUT                    DTC_IDX_VEH_COMERR
#define CS_TIME_OUT                    DTC_IDX_FCHG_COMERR
#define CC_TIME_OUT                    DTC_IDX_FCHG_COMERR
#define INN_CAN_BUS_OFF                DTC_IDX_INNER_COMERR
#define VEH_CAN_BUS_OFF                DTC_IDX_VEH_COMERR
#define CHRG_CAN_BUS_OFF               DTC_IDX_FCHG_COMERR*/
#define INN_CAN_BUS_OFF                97
#define VEH_CAN_BUS_OFF                95
#define CHRG_CAN_BUS_OFF               96

#define EEPROM_ERR                     98
#define TLE8104_INIT_ERR1              98
#define TLE8104_INIT_ERR2              98
#define TLE8104_INIT_ERR3              98
#define TLE8104_SPI_ERR1               98
#define TLE8104_SPI_ERR2               98
#define TLE8104_SPI_ERR3               98
#define CLK_ERR                        98


/***************************************************************************
*                       Function Prototype                                       
***************************************************************************/
extern FUNC(uint8,ECUM_CODE) EcuM_AppPostRun(void);
extern FUNC(Std_ReturnType,EEP_CODE) Eep_ChkSaveIfFinish(void);
extern FUNC(Std_ReturnType,DEM_CODE)  Dem_SetError(uint8 EventId, uint8 EventStatus);
extern FUNC(uint8,DEM_CODE) Dem_GetError(uint8 EventId);

extern void Swc_Init(); 
extern void Swc_Task10ms();  

#endif
