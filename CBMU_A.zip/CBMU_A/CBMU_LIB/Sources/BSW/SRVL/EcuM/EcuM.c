/*******************************************************************************
*
*  FILE
*     EcuM.c
*
*  DESCRIPTION
*     Ecu State Manager  ���µ�����״̬������δʹ��
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.0.0
*

Updata Records:

2014-01-17, lzy, fix EEP error
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "EcuM.h"
#include "OSTimer.h"
#include "VFB.h"
#include "dem.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/
uint8 retVal;

uint8 ecum_State;

uint8 EcuM_m_st_SaveDataRequest;

uint16 ecum_StartTimeToShutOff;

#define ECUM_STATE_STARTUP            0x0
#define ECUM_STATE_APP_RUN            0x1
#define ECUM_STATE_APP_POSTRUN        0x2
#define ECUM_STATE_APP_POSTRUN_FINI   0x3
#define ECUM_STATE_OFF                0x4

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/

/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/
/*******************************************************************************
* NAME:             EcuM_Init
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Initialize Ecu State Manger  
*******************************************************************************/
FUNC(void,ECUM_CODE) EcuM_Init(void)  
{
  ioa_5VOut = TRUE;
  
  //com_VehBusRxEna = 1;
  com_InnerBusRxEna = 1;
  //com_SlowChrgrRxEna = 1;
  com_FastChrgrRxEna = 1;

  com_VehBusTxEna = 1;
  com_InnerBusTxEna = 1;
  com_SlowChrgrTxEna = 1;
  com_FastChrgrTxEna = 1;
  
  ecum_State = ECUM_STATE_APP_RUN;  
  
  ioa_T15SwtSts = TRUE;
  
}
/*******************************************************************************
* NAME:             EcuM_MainFunction
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Main function of Ecu State Manager  
*******************************************************************************/
FUNC(void,ECUM_CODE) EcuM_MainFunction(void)
{
  
    switch( ecum_State )
    {
        case ECUM_STATE_STARTUP:
        {
            EcuM_m_st_SaveDataRequest = 1;
            ecum_StartTimeToShutOff = 0;

            ecum_State = ECUM_STATE_APP_RUN;
            break;
        }
        case ECUM_STATE_APP_RUN:
        {
            ioa_PwrOut = TRUE;
            ioa_12VOut = TRUE;
            if (ioa_T15SwtSts == FALSE)
            {
              if( EcuM_AppPostRun() == 1 )
              {
                ecum_State = ECUM_STATE_APP_POSTRUN;
                com_ShutDown = TRUE;
              }
              else
              {
                 ecum_StartTimeToShutOff++;
                 if(ecum_StartTimeToShutOff > 200)
                 {
                   ecum_State = ECUM_STATE_APP_POSTRUN;
                   com_ShutDown = TRUE;
                   ecum_StartTimeToShutOff = 0;
                 }
              }
            }
            break;
        }
        case ECUM_STATE_APP_POSTRUN: 
        {
            if (ioa_T15SwtSts == TRUE)
            {
            ecum_State = ECUM_STATE_APP_RUN; 
            com_ShutDown = FALSE;
            EcuM_AppReturnNormalRun();
            }else if (ecum_StartTimeToShutOff++ >= 100)
            {
            ecum_StartTimeToShutOff = 0;
            ecum_State = ECUM_STATE_APP_POSTRUN_FINI;
            }
            break;
        }

        case ECUM_STATE_APP_POSTRUN_FINI: 
        {
            if (ioa_T15SwtSts == TRUE)
            {
            ecum_State = ECUM_STATE_APP_RUN; 
            com_ShutDown = FALSE;
            EcuM_AppReturnNormalRun();
            }else if (ecum_StartTimeToShutOff++ >= 100)
            {
            ecum_State = ECUM_STATE_OFF;           
            } 
            break; 
        }
        case ECUM_STATE_OFF: 
        {  
            if (ioa_T15SwtSts == TRUE)
            {
            ecum_State = ECUM_STATE_APP_RUN; 
            com_ShutDown = FALSE;
            EcuM_AppReturnNormalRun();
            }else
            {
                ioa_PwrOut = FALSE; 
                ioa_12VOut = FALSE; 
            }
            break;
        } 
        default:
        {
            ecum_State = ECUM_STATE_APP_RUN; 
            break;
        }
    }
}

/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/

/*******************************************************************************
* NAME:             EcuM_AppPostRun
* CALLED BY:        Application
* PRECONDITIONS:
* INPUT PARAMETERS: Void
* RETURN VALUES:    Void
* DESCRIPTION:      Request post Run 
*******************************************************************************/
FUNC(uint8,ECUM_CODE) EcuM_AppPostRun(void) //$$$����
{
  if( EcuM_m_st_SaveDataRequest == 1)
  {
    EcuM_m_st_SaveDataRequest = 0;
    TrpR_DataSave();
    Dem_AfterRunChkSum();
  
    Mcu_SuspendAllInterrupt();
    retVal = Eep_EnableEEE();
    if( retVal == E_OK )
    {
      if(E_OK == Eep_ChkSaveIfFinish() )
      {
         retVal = Eep_DisableEEE();
         Mcu_ResumeAllInterrupt();
         return 1;
      }
      else
      {
        Mcu_ResumeAllInterrupt();
        return 0;
      }
        // Wdg_Trigger() ;     //2014-01-17, lzy, fix EEP error
        //2015-06-29, lzy, May stay here forever, we need to fix this bug
        
    }
  }
  else
  {
    Mcu_SuspendAllInterrupt();
    if(E_OK == Eep_ChkSaveIfFinish() )
    {
         retVal = Eep_DisableEEE();
         Mcu_ResumeAllInterrupt();
         return 1;
    }
    else
    {
      Mcu_ResumeAllInterrupt();
        return 0;
    }
  }
  
  return 0;
}

void ECUM_CODE EcuM_AppReturnNormalRun(void)
{
  Eep_DisableEEE();
}