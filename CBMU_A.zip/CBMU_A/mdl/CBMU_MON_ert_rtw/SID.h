/*
 * File: SID.h
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SID_h_
#define RTW_HEADER_SID_h_
#ifndef CBMU_MON_COMMON_INCLUDES_
# define CBMU_MON_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "SetErr.h"
#endif                                 /* CBMU_MON_COMMON_INCLUDES_ */

#include "CBMU_MON_types.h"

/* Block signals for system '<S52>/Chart' */
typedef struct {
  struct {
    uint_T O_S_CC_Swt:1;               /* '<S52>/Chart' */
  } bitsForTID0;
} rtB_Chart_CBMU_MON;

/* Block signals for system '<S65>/Swtich_Debouncing' */
typedef struct {
  struct {
    uint_T swtDeb:1;                   /* '<S66>/Switch_Debouncing' */
  } bitsForTID0;
} rtB_Swtich_Debouncing_CBMU_MON;

/* Block states (auto storage) for system '<S65>/Swtich_Debouncing' */
typedef struct {
  uint16_T localTimer;                 /* '<S66>/Switch_Debouncing' */
  struct {
    uint_T is_c47_CBMU_MON:3;          /* '<S66>/Switch_Debouncing' */
    uint_T is_active_c47_CBMU_MON:1;   /* '<S66>/Switch_Debouncing' */
  } bitsForTID0;
} rtDW_Swtich_Debouncing_CBMU_MON;

/* Block signals for system '<S52>/O_SW_HVIL_Swt' */
typedef struct {
  rtB_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S65>/Swtich_Debouncing' */
} rtB_O_SW_HVIL_Swt_CBMU_MON;

/* Block states (auto storage) for system '<S52>/O_SW_HVIL_Swt' */
typedef struct {
  rtDW_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S65>/Swtich_Debouncing' */
} rtDW_O_SW_HVIL_Swt_CBMU_MON;

/* Block signals for system '<S53>/O_SW_HVIL_Swt' */
typedef struct {
  rtB_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S69>/Swtich_Debouncing' */
} rtB_O_SW_HVIL_Swt_CBMU_MON_i;

/* Block states (auto storage) for system '<S53>/O_SW_HVIL_Swt' */
typedef struct {
  rtDW_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S69>/Swtich_Debouncing' */
} rtDW_O_SW_HVIL_Swt_CBMU_MON_e;

/* Block signals for system '<S7>/O_SW_HVIL_Swt' */
typedef struct {
  rtB_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S59>/Swtich_Debouncing' */
} rtB_O_SW_HVIL_Swt_CBMU_MON_d;

/* Block states (auto storage) for system '<S7>/O_SW_HVIL_Swt' */
typedef struct {
  rtDW_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S59>/Swtich_Debouncing' */
} rtDW_O_SW_HVIL_Swt_CBMU_MON_p;

/* Block signals for system '<S60>/O_SW_HVIL_Swt' */
typedef struct {
  rtB_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S75>/Swtich_Debouncing' */
} rtB_O_SW_HVIL_Swt_CBMU_MON_m;

/* Block states (auto storage) for system '<S60>/O_SW_HVIL_Swt' */
typedef struct {
  rtDW_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S75>/Swtich_Debouncing' */
} rtDW_O_SW_HVIL_Swt_CBMU_MON_k;

/* Block signals for system '<S60>/O_SW_HVIL_Swt1' */
typedef struct {
  rtB_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S76>/Swtich_Debouncing' */
} rtB_O_SW_HVIL_Swt1_CBMU_MON;

/* Block states (auto storage) for system '<S60>/O_SW_HVIL_Swt1' */
typedef struct {
  rtDW_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S76>/Swtich_Debouncing' */
} rtDW_O_SW_HVIL_Swt1_CBMU_MON;

/* Block signals for system '<S60>/O_SW_NegRlyCtl_Swt' */
typedef struct {
  rtB_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S77>/Swtich_Debouncing' */
} rtB_O_SW_NegRlyCtl_Swt_CBMU_MON;

/* Block states (auto storage) for system '<S60>/O_SW_NegRlyCtl_Swt' */
typedef struct {
  rtDW_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S77>/Swtich_Debouncing' */
} rtDW_O_SW_NegRlyCtl_Swt_CBMU_MO;

/* Block signals for system '<S60>/O_SW_PosRlyCtl_Swt' */
typedef struct {
  rtB_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S78>/Swtich_Debouncing' */
} rtB_O_SW_PosRlyCtl_Swt_CBMU_MON;

/* Block states (auto storage) for system '<S60>/O_SW_PosRlyCtl_Swt' */
typedef struct {
  rtDW_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S78>/Swtich_Debouncing' */
} rtDW_O_SW_PosRlyCtl_Swt_CBMU_MO;

/* Block signals for system '<S61>/O_SW_HVIL_Swt' */
typedef struct {
  rtB_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S91>/Swtich_Debouncing' */
} rtB_O_SW_HVIL_Swt_CBMU_MON_ii;

/* Block states (auto storage) for system '<S61>/O_SW_HVIL_Swt' */
typedef struct {
  rtDW_Swtich_Debouncing_CBMU_MON Swtich_Debouncing;/* '<S91>/Swtich_Debouncing' */
} rtDW_O_SW_HVIL_Swt_CBMU_MON_d;

/* Block signals for system '<S104>/SRC_Check' */
typedef struct {
  uint8_T SRC_Def_Status;              /* '<S105>/SRC_Check' */
} rtB_SRC_Check_CBMU_MON;

/* Block states (auto storage) for system '<S104>/SRC_Check' */
typedef struct {
  uint16_T local_Timer;                /* '<S105>/SRC_Check' */
  struct {
    uint_T is_Defect:3;                /* '<S105>/SRC_Check' */
    uint_T is_c33_CBMU_MON:2;          /* '<S105>/SRC_Check' */
    uint_T is_active_c33_CBMU_MON:1;   /* '<S105>/SRC_Check' */
  } bitsForTID0;
} rtDW_SRC_Check_CBMU_MON;

/* Extern declarations of internal data for system '<S52>/O_SW_HVIL_Swt' */
extern rtB_O_SW_HVIL_Swt_CBMU_MON CBMU_MON_O_SW_HVIL_Swt_B;
extern rtDW_O_SW_HVIL_Swt_CBMU_MON CBMU_MON_O_SW_HVIL_Swt_DW;

/* Extern declarations of internal data for system '<S53>/O_SW_HVIL_Swt' */
extern rtB_O_SW_HVIL_Swt_CBMU_MON_i CBMU_MON_O_SW_HVIL_Swt_B_h;
extern rtDW_O_SW_HVIL_Swt_CBMU_MON_e CBMU_MON_O_SW_HVIL_Swt_DW_d;

/* Extern declarations of internal data for system '<S7>/O_SW_HVIL_Swt' */
extern rtB_O_SW_HVIL_Swt_CBMU_MON_d CBMU_MON_O_SW_HVIL_Swt_B_e;
extern rtDW_O_SW_HVIL_Swt_CBMU_MON_p CBMU_MON_O_SW_HVIL_Swt_DW_c;

/* Extern declarations of internal data for system '<S60>/O_SW_HVIL_Swt' */
extern rtB_O_SW_HVIL_Swt_CBMU_MON_m CBMU_MON_O_SW_HVIL_Swt_B_g;
extern rtDW_O_SW_HVIL_Swt_CBMU_MON_k CBMU_MON_O_SW_HVIL_Swt_DW_o;

/* Extern declarations of internal data for system '<S60>/O_SW_HVIL_Swt1' */
extern rtB_O_SW_HVIL_Swt1_CBMU_MON CBMU_MON_O_SW_HVIL_Swt1_B;
extern rtDW_O_SW_HVIL_Swt1_CBMU_MON CBMU_MON_O_SW_HVIL_Swt1_DW;

/* Extern declarations of internal data for system '<S60>/O_SW_NegRlyCtl_Swt' */
extern rtB_O_SW_NegRlyCtl_Swt_CBMU_MON CBMU_MON_O_SW_NegRlyCtl_Swt_B;
extern rtDW_O_SW_NegRlyCtl_Swt_CBMU_MO CBMU_MON_O_SW_NegRlyCtl_Swt_DW;

/* Extern declarations of internal data for system '<S60>/O_SW_PosRlyCtl_Swt' */
extern rtB_O_SW_PosRlyCtl_Swt_CBMU_MON CBMU_MON_O_SW_PosRlyCtl_Swt_B;
extern rtDW_O_SW_PosRlyCtl_Swt_CBMU_MO CBMU_MON_O_SW_PosRlyCtl_Swt_DW;

/* Extern declarations of internal data for system '<S61>/O_SW_HVIL_Swt' */
extern rtB_O_SW_HVIL_Swt_CBMU_MON_ii CBMU_MON_O_SW_HVIL_Swt_B_hk;
extern rtDW_O_SW_HVIL_Swt_CBMU_MON_d CBMU_MON_O_SW_HVIL_Swt_DW_b;
extern void CBMU_M_O_SW_HVIL_Swt_initialize(void);
extern void CBMU_O_SW_HVIL_Swt_h_initialize(void);
extern void CBMU_O_SW_HVIL_Swt_l_initialize(void);
extern void CBMU_O_SW_HVIL_Swt_p_initialize(void);
extern void CBMU__O_SW_HVIL_Swt1_initialize(void);
extern void C_O_SW_NegRlyCtl_Swt_initialize(void);
extern void C_O_SW_PosRlyCtl_Swt_initialize(void);
extern void CBMU_O_SW_HVIL_Swt_k_initialize(void);
extern void CBMU_MON_Chart_Init(rtB_Chart_CBMU_MON *localB);
extern void CBMU_MON_Chart(t_Voltage1 rtu_CCVolt, t_Voltage1 rtu_CC_VoltHigh,
  t_Voltage1 rtu_CC_VoltLow, rtB_Chart_CBMU_MON *localB);
extern void CBMU_MON_Swtich_Debouncing_Init(rtB_Swtich_Debouncing_CBMU_MON
  *localB, rtDW_Swtich_Debouncing_CBMU_MON *localDW);
extern void CBMU_MON_Swtich_Debouncing(boolean_T rtu_swtRaw, uint16_T
  rtu_Par_SwtOffDebTime, uint16_T rtu_Par_SwtOnDebTime, uint8_T
  rtu_Par_SampleTime, rtB_Swtich_Debouncing_CBMU_MON *localB,
  rtDW_Swtich_Debouncing_CBMU_MON *localDW);
extern void CBMU_MON_SRC_Check_Init(rtB_SRC_Check_CBMU_MON *localB,
  rtDW_SRC_Check_CBMU_MON *localDW);
extern void CBMU_MON_SRC_Check(boolean_T rtu_Clear_Def_Flag, t_Voltage1
  rtu_Sig_Volt, t_Voltage1 rtu_Par_SRC_H_Threshold, t_Voltage1
  rtu_Par_SRC_L_Threshold, uint16_T rtu_Par_SRC_H_PosDeb, uint16_T
  rtu_Par_SRC_H_NegDeb, uint16_T rtu_Par_SRC_L_PosDeb, uint16_T
  rtu_Par_SRC_L_NegDeb, uint8_T rtu_Par_SampleTime, rtB_SRC_Check_CBMU_MON
  *localB, rtDW_SRC_Check_CBMU_MON *localDW);
extern void CBMU_MON_O_SW_HVIL_Swt_Init(void);
extern void CBMU_MON_O_SW_HVIL_Swt(void);
extern void CBMU_MON_O_SW_HVIL_Swt_j_Init(void);
extern void CBMU_MON_O_SW_HVIL_Swt_e(void);
extern void CBMU_MON_O_SW_HVIL_Swt_o_Init(void);
extern void CBMU_MON_O_SW_HVIL_Swt_k(void);
extern void CBMU_MON_O_SW_HVIL_Swt_d_Init(void);
extern void CBMU_MON_O_SW_HVIL_Swt_l(void);
extern void CBMU_MON_O_SW_HVIL_Swt1_Init(void);
extern void CBMU_MON_O_SW_HVIL_Swt1(void);
extern void CBMU_MO_O_SW_NegRlyCtl_Swt_Init(void);
extern void CBMU_MON_O_SW_NegRlyCtl_Swt(void);
extern void CBMU_MO_O_SW_PosRlyCtl_Swt_Init(void);
extern void CBMU_MON_O_SW_PosRlyCtl_Swt(void);
extern void CBMU_MON_O_SW_HVIL_Swt_e_Init(void);
extern void CBMU_MON_O_SW_HVIL_Swt_p(void);
extern void CBMU_MON_SID_Init(void);
extern void CBMU_MON_SID(void);

#endif                                 /* RTW_HEADER_SID_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
