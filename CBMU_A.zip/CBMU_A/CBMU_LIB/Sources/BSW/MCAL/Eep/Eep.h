/*******************************************************************************
*
*  FILE
*     Eep.h
*
*  DESCRIPTION
*      Eep module header file 
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.0.2
*
*******************************************************************************/
#ifndef _EEP_H_
#define _EEP_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Eep_Cfg.h"
#include "Eep_Types.h"


/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/* Vendor ID. */
#define EEP_VENDOR_ID           6666

/* Module ID */
#define EEP_MODULE_ID           90

/* Version number of the module */
#define EEP_SW_MAJOR_VERSION    1
#define EEP_SW_MINOR_VERSION    0
#define EEP_SW_PATCH_VERSION    0

/* Instance ID */
#define EEP_INSTATNCE_ID              1

#define EEP_API_CMD_COMPLETE_ID       1

#define EEP_E_PARAM_LOOP_TO         15

/* Register */
#define EEP_REG_FSTAT    (*(volatile uint8*) 0x00000106)
#define EEP_REG_FCLKDIV  (*(volatile uint8*) 0x00000100)
#define EEP_REG_FCCOBIX  (*(volatile uint8*) 0x00000102)
#define EEP_REG_FCCOBHI  (*(volatile uint8*) 0x0000010A)
#define EEP_REG_FCCOB    (*(volatile uint16*) 0x0000010A)
#define EEP_REG_ETAG     (*(volatile uint16*) 0x0000010C)


#define EEP_FSTAT_MGBUSY_MASK               8
#define EEP_FSTAT_ACCERR_MASK               32
#define EEP_FSTAT_CCIF_MASK                 128

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/
extern boolean eep_Status;
/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/

extern FUNC(Eep_ErrType,EEP_CODE) Eep_EnableEEE(void);
extern FUNC(Eep_ErrType,EEP_CODE) Eep_DisableEEE(void);
extern FUNC(Std_ReturnType,EEP_CODE) Eep_ChkSaveIfFinish(void);
extern FUNC(void,EEP_CODE)  Eep_Init(void);


#endif /* #ifndef _EEP_H_ */