/*
 * File: SID_data.c
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "CBMU_MON.h"
#include "CBMU_MON_private.h"

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
