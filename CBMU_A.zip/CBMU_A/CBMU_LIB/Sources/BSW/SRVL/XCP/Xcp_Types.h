/*******************************************************************************
*
*  FILE
*     Xcp_Types.h
*
*  DESCRIPTION
*     The Data Type Header file for Xcp Module 
*      
*       
*  COPYRIGHT
*      
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.2.0
*
*******************************************************************************/
#ifndef _XCP_TYPES_H_
#define _XCP_TYPES_H_
/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Xcp_Cfg.h"
/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#if (XCP_DAQ_LST_BUFFER_NEAR == STD_ON)
  #define XCP_VAR_DAQ_LST  XCP_VAR
#else  
  #define XCP_VAR_DAQ_LST  XCP_VAR_FAR  
#endif

/* type definition of the MTA pointer */
typedef uint8* XCP_VAR_FAR Xcp_MtaPtrType;

typedef uint8 XCP_VAR_DAQ_LST Xcp_DaqBuffType;

/* structure of an XCP CMD CTO packet */
typedef union
{
  uint8 pid;
  uint8 data[1];

  /*********************************************************************
  * command CONNECT
  * position:     type:   description:
  * 0             BYTE    command code = 0xFF
  * 1             BYTE    mode
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
  } connect;

  /*********************************************************************
  * command DISCONNECT
  * position:     type:   description:
  * 0             BYTE    command code = 0xFE
  **********************************************************************/
  struct
  {
    uint8   pid;
  } disconnect;

  /*********************************************************************
  * command GET_STATUS:
  * position:     type:   description:
  * 0             BYTE    command code = 0xFD
  **********************************************************************/
  struct
  {
    uint8   pid;
  } get_status;

  /*********************************************************************
  * command SYNCH
  * position:     type:   description:
  * 0             BYTE    command code = 0xFC
  **********************************************************************/
  struct
  {
    uint8   pid;
  } synch;

  /*********************************************************************
  * command GET_COMM_MODE_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xFB
  **********************************************************************/
  struct
  {
    uint8   pid;
  } get_comm_mode_info;

  /*********************************************************************
  * command GET_ID
  * position:     type:   description:
  * 0             BYTE    command code = 0xFA
  * 1             BYTE    requested identification type
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   type;
  } get_id;

  /*********************************************************************
  * command SET_REQUEST:
  * position:     type:   description:
  * 0             BYTE    command code = 0xF9
  * 1             BYTE    mode
  * 2,3           WORD    session configuration id
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint16  id;
  } set_request;

  /*********************************************************************
  * command GET_SEED
  * position:     type:   description:
  * 0             BYTE    command code = 0xF8
  * 1             BYTE    mode
  * 2             BYTE    resource
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint8   resource;
  } get_seed;

  /*********************************************************************
  * command UNLOCK
  * position:     type:   description:
  * 0             BYTE    command code = 0xF7
  * 1             BYTE    (remaining) length of key
  * 2..MAX_CTO-1  BYTE    key
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   length;
    uint8   key[1];
  } unlock;

  /*********************************************************************
  * command SET_MTA
  * position:     type:   description:
  * 0             BYTE    command code = 0xF6
  * 1,2           BYTE    reserved
  * 3             BYTE    address extension
  * 4..7          DWORD   address
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved1;
    uint8   reserved2;
    uint8   extension;
    uint32  address;
  } set_mta;

  /*********************************************************************
  * command UPLOAD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF5
  * 1             BYTE    number of data elements
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   no_of_elements;
  } upload;

  /*********************************************************************
  * command SHORT_UPLOAD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF4
  * 1             BYTE    number of data elements
  * 2             BYTE    reserved
  * 3             BYTE    address extension
  * 4..7          DWORD   address
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   no_of_elements;
    uint8   reserved;
    uint8   extension;
    uint32  address;
  } short_upload;

  /*********************************************************************
  * command BUILD_CHECKSUM
  * position:     type:   description:
  * 0             BYTE    command code = 0xF3
  * 1..3          BYTE    reserved
  * 4..7          DWORD   block size
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved1;
    uint8   reserved2;
    uint8   reserved3;
    uint32  block_size;
  } build_checksum;

  /*********************************************************************
  * command TRANSPORT_LAYER_CMD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF2
  * 1             BYTE    sub command code
  * 2...          BYTE    parameters
  **********************************************************************/
  struct
  {
    uint8 pid;
    uint8 sub_pid;
    uint8 data[1];
  } transport_layer_cmd;

  /*********************************************************************
  * command USER_CMD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code
  * 2..           BYTE    parameters
  **********************************************************************/
  struct
  {
    uint8 pid;
    uint8 sub_pid;
    uint8 data[1];
  } user_cmd;

  /*********************************************************************
  * command GET_BYP_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   sub_code;
  } get_byp_info;

  /*********************************************************************
  * command SET_DAQ_LIST_BYP_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xFE
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    mode
  * 5             BYTE    DAQ list timeout cycle
  * 6             BYTE    DAQ list timeout unit
  * 7             BYTE    failure_limit
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   sub_code;
    uint16  daq;
    uint8   mode;
    uint8   timeout_cycle;
    uint8   timeout_unit;
    uint8   failure_limit;
  } set_daq_list_byp_mode;

  /*********************************************************************
  * command GET_DAQ_LIST_BYP_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xFD
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   sub_code;
    uint16  daq;
  } get_daq_list_byp_mode;

  /*********************************************************************
  * command SET_FAILSAFE_DATA_PTR
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xFA
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    ODT_NUMBER
  * 5             BYTE    ODT_ENTRY_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   sub_code;
    uint16  daq;
    uint8   odt;
    uint8   odt_entry;
  } set_failsafe_data_ptr;

  /*********************************************************************
  * command WRITE_FAILSAFE_DATA
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xF9
  * 2             BYTE    size
  * 3             BYTE    qword_nibble
  * 4..7          BYTE    data
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   sub_code;
    uint8   size;
    uint8   qword_nibble;
    uint8   data[4];
  } write_failsafe_data;

  /*********************************************************************
  * command DOWNLOAD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF0
  * 1             BYTE    number of data elements
  * 2..MAX_CTO-1  ELEMENT data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   no_of_elements;
    uint8   data[1];
  } download;

  /*********************************************************************
  * command DOWNLOAD_NEXT
  * position:     type:   description:
  * 0             BYTE    command code = 0xEF
  * 1             BYTE    number of data elements
  * 2..MAX_CTO-1  ELEMENT data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   no_of_elements;
    uint8   data[1];
  } download_next;

  /*********************************************************************
  * command DOWNLOAD_MAX
  * position:     type:   description:
  * 0             BYTE    command code = 0xEE
  * 2..MAX_CTO-1  BYTE    data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   data[1];
  } download_max;

  /*********************************************************************
  * command SHORT_DOWNLOAD (not usable with XCP on CAN)
  * position:     type:   description:
  * 0             BYTE    command code = 0xED
  * 1             BYTE    number of data elements
  * 2             BYTE    reserved
  * 3             BYTE    address extension
  * 4..7          DWORD   address
  * 8..MAX-CTO-1  BYTE    data elements
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   no_of_elements;
    uint8   reserved;
    uint8   extension;
    uint32  address;
    uint8   data[1];
  } short_download;

  /*********************************************************************
  * command MODIFY_BITS
  * position:     type:   description:
  * 0             BYTE    command code = 0xEC
  * 1             BYTE    shift value
  * 2,3           WORD    AND mask
  * 4,5           WORD    XOR mask
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   shift_value;
    uint16  and_mask;
    uint16  xor_mask;
  } modify_bits;

  /*********************************************************************
  * command SET_CAL_PAGE
  * position:     type:   description:
  * 0             BYTE    command code = 0xEB
  * 1             BYTE    mode
  * 2             BYTE    logical data segment number
  * 3             BYTE    logical data page number
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint8   segment;
    uint8   page;
  } set_cal_page;

  /*********************************************************************
  * command GET_CAL_PAGE
  * position:     type:   description:
  * 0             BYTE    command code = 0xEA
  * 1             BYTE    access mode
  * 2             BYTE    logical data segment number
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint8   segment;
  } get_cal_page;

  /*********************************************************************
  * command GET_PAG_PROCESSOR_INFO
  * position:     type:     description:
  * 0             BYTE    command code = 0xE9
  **********************************************************************/
  struct
  {
    uint8   pid;
  } get_pag_processor_info;

  /*********************************************************************
  * command GET_SEGMENT_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xE8
  * 1             BYTE    mode
  * 2             BYTE    SEGMENT_NUMBER
  * 3             BYTE    SEGMENT_INFO
  * 4             BYTE    MAPPING_INDEX
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint8   segment;
    uint8   info;
    uint8   index;
  } get_segment_info;

  /*********************************************************************
  * command GET_PAGE_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xE7
  * 1             BYTE    reserved
  * 2             BYTE    SEGMENT_NUMBER
  * 3             BYTE    PAGE_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint8   segment;
    uint8   page;
  } get_page_info;

  /*********************************************************************
  * command SET_SEGMENT_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xE6
  * 1             BYTE    mode
  * 2             BYTE    SEGMENT_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint8   segment;
  } set_segment_mode;

  /*********************************************************************
  * command GET_SEGMENT_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xE5
  * 1             BYTE    reserved
  * 2             BYTE    SEGMENT_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint8   segment;
  } get_segment_mode;

  /*********************************************************************
  * command COPY_CAL_PAGE
  * position:     type:   description:
  * 0             BYTE    command code = 0xE4
  * 2             BYTE    logical data segment number source
  * 3             BYTE    logical data page number source
  * 4             BYTE    logical data segment number destination
  * 5             BYTE    logical data page number destination
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   segment_source;
    uint8   page_source;
    uint8   segment_destination;
    uint8   page_destination;
  } copy_cal_page;

  /*********************************************************************
  * command CLEAR_DAQ_LIST
  * position:     type:   description:
  * 0             BYTE    command code = 0xE3
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  daq;
  } clear_daq_list;

  /*********************************************************************
  * command SET_DAQ_PTR
  * position:     type:   description:
  * 0             BYTE    command code = 0xE2
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    ODT_NUMBER
  * 5             BYTE    ODT_ENTRY_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  daq;
    uint8   odt;
    uint8   odt_entry;
  } set_daq_ptr;

  /*********************************************************************
  * command WRITE_DAQ
  * position:     type:   description:
  * 0             BYTE    command code = 0xE1
  * 1             BYTE    BIT_OFFSET
  * 2             BYTE    size of DAQ element
  * 3             BYTE    address extension of DAQ element
  * 4..7          DWORD   address of DAQ element
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   bit_offset;
    uint8   size;
    uint8   extension;
    uint32  address;
  } write_daq;

  /*********************************************************************
  * command SET_DAQ_LIST_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xE0
  * 1             BYTE    mode
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4,5           WORD    event channel number
  * 6             BYTE    transmission rate prescaler
  * 7             BYTE    DAQ list priority
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint16  daq;
    uint16  event_channel;
    uint8   prescaler;
    uint8   priority;
  } set_daq_list_mode;

  /*********************************************************************
  * GET_DAQ_LIST_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xDF
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  daq;
  } get_daq_list_mode;

  /*********************************************************************
  * command START_STOP_DAQ_LIST
  * position:     type:   description:
  * 0             BYTE    command code = 0xDE
  * 1             BYTE    mode
  * 2             WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint16  daq;
  } start_stop_daq_list;

  /*********************************************************************
  * command START_STOP_SYNCH
  * position:     type:   description:
  * 0             BYTE    command code = 0xDD
  * 1             BYTE    mode
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
  } start_stop_synch;

  /*********************************************************************
  * command GET_DAQ_CLOCK
  * position:     type:   description:
  * 0             BYTE    command code = 0xDC
  **********************************************************************/
  struct
  {
    uint8   pid;
  } get_daq_clock;

  /*********************************************************************
  * command READ_DAQ
  * position:     type:   description:
  * 0             BYTE    command code = 0xDB
  **********************************************************************/
  struct
  {
    uint8   pid;
  } read_daq;

  /*********************************************************************
  * command GET_DAQ_PROCESSOR_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xDA
  **********************************************************************/
  struct
  {
    uint8   pid;
  } get_daq_processor_info;

  /*********************************************************************
  * command GET_DAQ_RESOLUTION_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xD9
  **********************************************************************/
  struct
  {
    uint8   pid;
  } get_daq_resolution_info;

  /*********************************************************************
  * command GET_DAQ_LIST_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xD8
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  daq;
  } get_daq_list_info;

  /*********************************************************************
  * command GET_DAQ_EVENT_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xD7
  * 1             BYTE    reserved
  * 2,3           WORD    event channel number
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  event_channel;
  } get_daq_event_info;

  /*********************************************************************
  * command FREE_DAQ
  * position:     type:   description:
  * 0             BYTE    command code = 0xD6
  **********************************************************************/
  struct
  {
    uint8   pid;
  } free_daq;

  /*********************************************************************
  * command ALLOC_DAQ
  * position:     type:   description:
  * 0             BYTE    command code = D5
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_COUNT
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  daq_count;
  } alloc_daq;

  /*********************************************************************
  * command ALLOC_ODT
  * position:     type:   description:
  * 0             BYTE    command code = 0xD4
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    ODT_COUNT
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  daq;
    uint8   odt_count;
  } alloc_odt;

  /*********************************************************************
  * command ALLOC_ODT_ENTRY
  * position:     type:   description:
  * 0             BYTE    command code = 0xD3
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    ODT_NUMBER
  * 5             BYTE    ODT_ENTRIES_COUNT
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  daq;
    uint8   odt;
    uint8   odt_entries_count;
  } alloc_odt_entry;

  /*********************************************************************
  * command PROGRAM_START
  * position:     type:   description:
  * 0             BYTE    command code = 0xD2
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_start;

  /*********************************************************************
  * command PROGRAM_CLEAR
  * position:     type:   description:
  * 0             BYTE    command code = 0xD1
  * 1             BYTE    mode
  * 2,3           WORD    reserved
  * 4..7          DWORD   clear range
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint16  reserved;
    uint32  range;
  } program_clear;

  /*********************************************************************
  * command PROGRAM
  * position:     type:   description:
  * 0             BYTE    command code = 0xD0
  * 1             BYTE    number of data elements
  * 2..MAX_CTO-1  ELEMENT data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   no_of_elements;
    uint8   data[1];
  } program;

  /*********************************************************************
  * command PROGRAM_RESET
  * position:     type:   description:
  * 0             BYTE    command code = 0xCF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_reset;

  /*********************************************************************
  * command GET_PGM_PROCESSOR_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xCE
  **********************************************************************/
  struct
  {
    uint8   pid;
  } get_pgm_processor_info;

  /*********************************************************************
  * command GET_SECTOR_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xCD
  * 1             BYTE    mode
  * 2             BYTE    SECTOR_NUMBER
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint8   sector;
  } get_sector_info;

  /*********************************************************************
  * command PROGRAM_PREPARE
  * position:     type:   description:
  * 0             BYTE    command code = 0xCC
  * 1             BYTE    not used
  * 2,3           WORD    codesize
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint16  codesize;
  } program_prepare;

  /*********************************************************************
  * command PROGRAM_FORMAT
  * position:     type:   description:
  * 0             BYTE    command code = 0xCB
  * 1             BYTE    compression method
  * 2             BYTE    encryption method
  * 3             BYTE    programming method
  * 4             BYTE    access method
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   compression;
    uint8   encryption;
    uint8   programming;
    uint8   access;
  } program_format;

  /*********************************************************************
  * command PROGRAM_NEXT
  * position:     type:   description:
  * 0             BYTE    command code = 0xCA
  * 1             BYTE    number of data elements
  * 2..MAX_CTO-1  ELEMENT data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   no_of_elements;
    uint8   data[1];
  } program_next;

  /*********************************************************************
  * command PROGRAM_MAX
  * position:     type:   description:
  * 0             BYTE    command code = 0xC9
  * 1..MAX_CTO-1  ELEMENT data elements (+fill byte/word for alignment)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   data[1];
  } program_max;

  /*********************************************************************
  * command PROGRAM_VERIFY
  * position:     type:   description:
  * 0             BYTE    command code = 0xC8
  * 1             BYTE    verification mode
  * 2,3           WORD    verification type
  * 4..7          DWORD   verification value
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint8   type;
    uint32  value;
  } program_verify;
} Xcp_CmdCto_Type;


/* structure of an XCP RES/ERR/EV/SERV CTO packet */
typedef union
{
  uint8 pid;
  uint8 data[1];

  /*********************************************************************
  * error message
  * negative response:
  * position:       type:   description:
  * 0               BYTE    packet ID : 0xFE
  * 1               BYTE    error code
  * 2..             BYTE    additional information
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   code;
    uint8   info[1];
  } error;

  /*********************************************************************
  * error message
  * negative response:
  * position:     type:   description:
  * 0             BYTE    packet ID : 0xFE
  * 1             BYTE    error code
  * 2..           BYTE    additional information
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   code;
    uint8   info[1];
  } event;

  /*********************************************************************
  * command CONNECT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    RESOURCE
  * 2             BYTE    COMM_MODE_BASIC
  * 3             BYTE    MAX_CTO, maximum CTO size
  * 4,5           WORD    MAX_DTO, maximum DTO size
  * 6             BYTE    XCP protocol layer version number
  * 7             BYTE    XCP transport layer version number
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   resource;
    uint8   comm_mode_basic;
    uint8   max_cto;
    uint16  max_dto;
    uint8   protocol_version;
    uint8   transport_version;
  } connect;

  /*********************************************************************
  * command DISCONNECT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    command code = 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } disconnect;

  /*********************************************************************
  * command GET_STATUS:
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    current session status
  * 2             BYTE    current resource protection status
  * 3             BYTE    reserved
  * 4,5           WORD    session configuration id
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   session_status;
    uint8   protection_status;
    uint8   reserved;
    uint16  session_id;
  } get_status;

  /*********************************************************************
  * command SYNCH
  * positive response: none
  **********************************************************************/

  /*********************************************************************
  * command GET_COMM_MODE_INFO:
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    reserved
  * 2             BYTE    COMM_MODE_OPTIONAL
  * 3             BYTE    reserved
  * 4             BYTE    MAX_BS
  * 5             BYTE    MIN_ST
  * 6             BYTE    QUEUE_SIZE
  * 7             BYTE    XCP driver version number
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved1;
    uint8   optional;
    uint8   reserved2;
    uint8   max_bs;
    uint8   min_st;
    uint8   queue_size;
    uint8   driver_version;
  } get_comm_mode_info;

  /*********************************************************************
  * command GET_ID
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    mode
  * 2,3           WORD    reserved
  * 4,7           DWORD   length
  * 7..MAX_CTO-1  BYTE    identification
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint16  reserved;
    uint32  length;
  } get_id;

  /*********************************************************************
  * command SET_REQUEST:
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_request;

  /*********************************************************************
  * command GET_SEED
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    length of seed
  * 2..MAX_CTO-1  BYTE    seed
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   length;
    uint8   seed[1];
  } get_seed;

  /*********************************************************************
  * command UNLOCK
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    current resource protection status
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   protection_status;
  } unlock;

  /*********************************************************************
  * command SET_MTA
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_mta;

  /*********************************************************************
  * command UPLOAD
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..MAX_CTO-1  BYTE    data elements (+fill byte/word for alignment)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   data[1];
  } upload;

  /*********************************************************************
  * command SHORT_UPLOAD
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..MAX_CTO-1  BYTE    data elements (+fill byte/word for alignment)
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   data[1];
  } short_upload;

  /*********************************************************************
  * command BUILD_CHECKSUM
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    checksum type
  * 2,3           WORD    reserved
  * 4..7          DWORD   checksum
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   type;
    uint16  reserved;
    uint32  checksum;
  } build_checksum;

  /*********************************************************************
  * command GET_BYP_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID : 0xFF
  * 1             BYTE    BYP_PROPERTIES
  * 2             BYTE    0x44 (ASCII = D )
  * 3             BYTE    0x53 (ASCII = S )
  * 4             BYTE    0x58 (ASCII = X )
  * 5             BYTE    0x43 (ASCII = C )
  * 6             BYTE    0x50 (ASCII = P )
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   properties;
    uint8   d;
    uint8   s;
    uint8   x;
    uint8   c;
    uint8   p;
  } get_byp_info;

  /*********************************************************************
  * command SET_DAQ_LIST_BYP_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_daq_list_byp_mode;

  /*********************************************************************
  * command GET_DAQ_LIST_BYP_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    mode
  * 2             BYTE    DAQ list timeout cycle
  * 3             BYTE    DAQ list timeout unit
  * 4             BYTE    failure limit
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint8   timeout_cycle;
    uint8   timeout_unit;
    uint8   failure_limit;
  } get_daq_list_byp_mode;

  /*********************************************************************
  * command SET_FAILSAFE_DATA_PTR
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_failsafe_data_ptr;

  /*********************************************************************
  * command WRITE_FAILSAFE_DATA
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } write_failsafe_data;

  /*********************************************************************
  * command DOWNLOAD
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } download;

  /*********************************************************************
  * command DOWNLOAD_MAX
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } download_max;

  /*********************************************************************
  * command DOWNLOAD_NEXT
  * positive response: none
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } download_next;

  /*********************************************************************
  * command SHORT_DOWNLOAD
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } short_download;

  /*********************************************************************
  * command MODIFY_BITS
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } modify_bits;

  /*********************************************************************
  * command SET_CAL_PAGE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_cal_page;

  /*********************************************************************
  * command GET_CAL_PAGE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    reserved
  * 2             BYTE    reserved
  * 3             BYTE    logical data page number
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved1;
    uint8   reserved2;
    uint8   page;
  } get_cal_page;

  /*********************************************************************
  * command GET_PAG_PROCESSOR_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    MAX_SEGMENT
  * 2             BYTE    PAG_PROPERTIES
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   max_segment;
    uint8   properties;
  } get_pag_processor_info;

  /*********************************************************************
  * command GET_SEGMENT_INFO
  * positive response (mode 0):
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..3          BYTE    reserved
  * 4..7          DWORD   BASIC_INFO
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved1;
    uint8   reserved2;
    uint8   reserved3;
    uint32  basic_info;
  } get_segment_info_mode0;

  /*********************************************************************
  * command GET_SEGMENT_INFO
  * positive response (mode 1):
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    MAX_PAGES
  * 2             BYTE    ADDRESS_EXTENSION
  * 3             BYTE    MAX_MAPPING
  * 4             BYTE    compression method
  * 5             BYTE    encryption method
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   max_pages;
    uint8   extension;
    uint8   max_mapping;
    uint8   compression_method;
    uint8   encryption_method;
  } get_segment_info_mode1;

  /*********************************************************************
  * command GET_SEGMENT_INFO
  * positive response (mode 2):
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..3          BYTE    reserved
  * 4..7          DWORD   MAPPING_INFO
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved1;
    uint8   reserved2;
    uint8   reserved3;
    uint32  mapping_info;
  } get_segment_info_mode2;

  /*********************************************************************
  * command GET_PAGE_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    PAGE_PROPERTIES
  * 2             BYTE    INIT_SEGMENT
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   properties;
    uint8   init_segment;
  } get_page_info;

  /*********************************************************************
  * command SET_SEGMENT_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_segment_mode;

  /*********************************************************************
  * command GET_SEGMENT_MODE
  * positive response:
  * position:   type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    reserved
  * 2             BYTE    mode
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint8   mode;
  } get_segment_mode;

  /*********************************************************************
  * command COPY_CAL_PAGE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } copy_cal_page;

  /*********************************************************************
  * command CLEAR_DAQ_LIST
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } clear_daq_list;

  /*********************************************************************
  * command SET_DAQ_PTR
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_daq_ptr;

  /*********************************************************************
  * command WRITE_DAQ
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } write_daq;

  /*********************************************************************
  * command SET_DAQ_LIST_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } set_daq_list_mode;

  /*********************************************************************
  * GET_DAQ_LIST_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    current mode
  * 2,3           WORD    reserved
  * 4,5           WORD    current event channel number
  * 6             BYTE    current prescaler
  * 7             BYTE    current DAQ list priority
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   mode;
    uint16  reserved;
    uint16  event_channel;
    uint8   prescaler;
    uint8   priority;
  } get_daq_list_mode;

  /*********************************************************************
  * command START_STOP_DAQ_LIST
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    FIRST_PID
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   first_pid;
  } start_stop_daq_list;

  /*********************************************************************
  * command START_STOP_SYNCH
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } start_stop_synch;

  /*********************************************************************
  * command GET_DAQ_CLOCK
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..3          BYTE    reserved
  * 4..7          DWORD   receive timestamp
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved1;
    uint8   reserved2;
    uint8   reserved3;
    uint32  timestamp;
  } get_daq_clock;

  /*********************************************************************
  * command READ_DAQ
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    BIT_OFFSET
  * 2             BYTE    size of DAQ element
  * 3             BYTE    address extension of DAQ element
  * 4..7          DWORD   address of DAQ element
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   bit_offset;
    uint8   size;
    uint8   extension;
    uint32  address;
  } read_daq;

  /*********************************************************************
  * command GET_DAQ_PROCESSOR_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    DAQ_PROPERTIES
  * 2,3           WORD    MAX_DAQ
  * 4,5           WORD    MAX_EVENT_CHANNEL
  * 6             BYTE    MIN_DAQ
  * 7             BYTE    DAQ_KEY_BYTE
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   properties;
    uint16  max_daq;
    uint16  max_event_channel;
    uint8   min_daq;
    uint8   key_byte;
  } get_daq_processor_info;

  /*********************************************************************
  * command GET_DAQ_RESOLUTION_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    GRANULARITY_ODT_ENTRY_SIZE_DAQ
  * 2             BYTE    MAX_ODT_ENTRY_SIZE_DAQ
  * 3             BYTE    GRANULARITY_ODT_ENTRY_SIZE_STIM
  * 4             BYTE    MAX_ODT_ENTRY_SIZE_STIM
  * 5             BYTE    TIMESTAMP_MODE
  * 6,7           WORD    TIMESTAMP_TICKS
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   granularity_daq;
    uint8   max_daq;
    uint8   granularity_stim;
    uint8   max_stim;
    uint8   timestamp_mode;
    uint16  timestamp_ticks;
  } get_daq_resolution_info;

  /*********************************************************************
  * command GET_DAQ_LIST_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    DAQ_LIST_PROPERTIES
  * 2             BYTE    MAX_ODT
  * 3             BYTE    MAX_ODT_ENTRIES
  * 4,5           WORD    FIXED_EVENT
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   properties;
    uint8   max_odt;
    uint8   max_odt_entries;
    uint16  fixed_event;
  } get_daq_list_info;

  /*********************************************************************
  * command GET_DAQ_EVENT_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    DAQ_EVENT_PROPERTIES
  * 2             BYTE    MAX_DAQ_LIST
  * 3             BYTE    event channel name length
  * 4             BYTE    event channel time cycle
  * 5             BYTE    event channel time unit
  * 6             BYTE    event channel priority
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   properties;
    uint8   max_daq_list;
    uint8   name_length;
    uint8   time_cycle;
    uint8   time_unit;
    uint8   priority;
  } get_daq_event_info;

  /*********************************************************************
  * command FREE_DAQ
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } free_daq;

  /*********************************************************************
  * command ALLOC_DAQ
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } alloc_daq;

  /*********************************************************************
  * command ALLOC_ODT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } alloc_odt;

  /*********************************************************************
  * command ALLOC_ODT_ENTRY
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } alloc_odt_entry;

  /*********************************************************************
  * command PROGRAM_START
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    reserved
  * 2             BYTE    COMM_MODE_PGM
  * 3             BYTE    MAX_CTO_PGM
  * 4             BYTE    MAX_BS_PGM
  * 5             BYTE    MIN_ST_PGM
  * 6             BYTE    QUEUE_SIZE_PGM
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   reserved;
    uint8   comm_mode_pgm;
    uint8   max_cto_pgm;
    uint8   max_bs_pgm;
    uint8   min_st_pgm;
    uint8   queue_size_pgm;
  } program_start;

  /*********************************************************************
  * command PROGRAM_CLEAR
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_clear;

  /*********************************************************************
  * command PROGRAM
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program;

  /*********************************************************************
  * command PROGRAM_RESET
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_reset;

  /*********************************************************************
  * command GET_PGM_PROCESSOR_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    PGM_PROPERTIES
  * 2             BYTE    MAX_SECTOR
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   properties;
    uint8   max_sector;
  } get_pgm_processor_info;

  /*********************************************************************
  * command GET_SECTOR_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    clear sequence number
  * 2             BYTE    program sequence number
  * 3             BYTE    programming method
  * 4..7          DWORD   SECTOR_INFO
  **********************************************************************/
  struct
  {
    uint8   pid;
    uint8   clear_number;
    uint8   program_number;
    uint8   method;
    uint32  info;
  } get_sector_info;

  /*********************************************************************
  * command PROGRAM_PREPARE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_prepare;

  /*********************************************************************
  * command PROGRAM_FORMAT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_format;

  /*********************************************************************
  * command PROGRAM_NEXT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_next;

  /*********************************************************************
  * command PROGRAM_MAX
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_max;

  /*********************************************************************
  * command PROGRAM_VERIFY
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    uint8   pid;
  } program_verify;
} Xcp_CmdResCtoType;


/* structure of the memory transfer address (used for memory protection) */
typedef struct
{
  uint32 address;                     /* memory address */
  uint8  extension;                   /* memory address extension */
} Xcp_MtaInfoType;


/* structure of a memory page */
typedef struct
{
  uint8 properties;                   /* properties (write access etc.) */
  uint8 init_segment;                 /* init segment, which initializes this page */
} Xcp_PageInfoType;


/* structure of a memory segment */
typedef struct
{
  uint32 address;                     /* address of segment */
  uint32 length;                      /* segment length */
  uint8  extension;                   /* address extension */
  uint8  max_pages;                   /* number of pages */
  uint8  max_mapping;                 /* number of address ranges with address mapping */
  uint8  compression_method;          /* compression method */
  uint8  encryption_method;           /* encryption method */
} Xcp_SegmentInfoType;

/* structure of an ODT entry */
typedef struct
{
  Xcp_MtaPtrType address_ptr;          /* pointer to address of ECU variable */
  uint8 extension;                    /* address extension */
  uint8 size;                         /* size of ECU variable */
  uint8 bit_offset;                   /* bit offset */
  uint8 reserved;                     /* for alignment */
} Xcp_OdtEntryType;

/* structure of an ODT (only required for dynamic DAQ lists) */
typedef struct
{
  uint16 first_odt_entry;             /* first ODT entry of ODT in entry array (absolute) */
  uint8 no_of_odt_entries;            /* number of entries in ODT */
} Xcp_DynDaqOdtType;


/* structure of configuration data of a DAQ list */
typedef struct
{
  uint8  no_of_odts;                  /* number of ODTs */
  uint8  no_of_odt_entries;           /* number of entries in each odt */
  uint8  properties;                  /* properties (read only, STIM/DAQ etc.) */
} Xcp_DaqLstConfigType;


/* structure of a DAQ list */
typedef struct
{
  uint16 first_odt;                   /* first ODT of DAQ list (absolute), equals to first PID */
  uint16 first_odt_entry;             /* first ODT entry of DAQ list (absolute) */
  uint8  no_of_odts;                  /* number of ODTs */
  uint8  no_of_odt_entries;           /* number of ODT entries in each ODT */
  uint8  properties;                  /* properties (read only, STIM/DAQ etc.) */
  uint8  no_of_configured_odts;       /* number of configured ODTs */
  uint16 event_channel;               /* assigned event channel */
  uint16 next_daq;                    /* next DAQ list in same event channel */
  uint8  prescaler;                   /* transmission rate prescaler */
  uint8  cycle;                       /* current cycle */
  uint8  mode;                        /* mode (resume, direction, stopped, started etc.) */
  uint8  priority;                    /* priority of DAQ list */
} Xcp_DaqLstType;


/* structure of the DAQ pointer */
typedef struct
{
  uint16 daq;                         /* DAQ list index */
  uint16 abs_odt;                     /* ODT index (absolute) */
  uint16 abs_odt_entry;               /* ODT entry index (absolute) */
  uint8  rel_odt;                     /* ODT index (relative) */
  uint8  rel_odt_entry;               /* ODT entry index (relative) */
  uint8  valid_flag;                  /* flag, if reference to DAQ list is valid */
} Xcp_DaqPtrType;


/* structure of information data of an event channel */
typedef struct
{
  uint8 max_daq;                      /* maximum number of DAQ lists in event channel */
  uint8 properties;                   /* properties */
  uint8 time_cycle;                   /* time cycle */
  uint8 time_unit;                    /* time unit */
  uint8 priority;                     /* priority */
  uint8 name_length;                  /* length of event channel name */
  uint8* name;                        /* pointer to name of event channel */
} Xcp_EventChannelInfoType;


/* structure of an event channel */
typedef struct
{
  uint16 first_daq;                   /* first assigned DAQ list */
  uint8  status;                      /* status */
}Xcp_EventChannelType;


/* XCP service structure */
typedef struct
{
  Xcp_MtaPtrType       mta_ptr;                              /* memory transfer address pointer */
  Xcp_MtaInfoType      mta_info;                             /* MTA adress info (for memory protection) */
  uint8               session_status;                       /* session status */
  uint8               pending_status;                       /* pending status */
  uint8               event_code;                           /* code of EV packet */
  uint8               protection_status;                    /* protection status */
  uint8               resource_to_unlock;                   /* resource, which is requested to be unlocked */
  uint8               seed_flag;                            /* flag, if whole seed has been received */
  uint8               seed[XCP_MAX_SEED_SIZE];              /* current seed */
  uint8               key[XCP_MAX_KEY_SIZE];                /* current key */
  uint8               seed_key_index;                       /* index in current seed or key */
  uint8               no_of_seed_key_bytes_remaining;       /* number of remaining bytes for seeds and keys larger than 1 XCP packet */
  uint8               no_of_sbm_bytes_remaining;            /* number of remaining bytes in a block upload */
  uint32              no_of_upload_info_bytes_remaining; /* number of remaining bytes for uploading XCP service information */
  uint8               no_of_mbm_bytes_remaining;            /* number of remaining bytes in a block download */
  uint16              max_daq;                              /* number of predefined and configurable static DAQ lists or allocated dynamic DAQ lists */
  uint16              odt_count;                            /* number of allocated ODTs */
  uint16              odt_entries_count;                    /* number of allocated ODT entries */
  Xcp_DynDaqOdtType * XCP_VAR_DAQ_LST odt;                                 /* pointer to first ODT (absolute) */
  Xcp_DaqPtrType       daq_ptr;                              /* DAQ pointer */
  Xcp_DaqLstType * XCP_VAR_DAQ_LST  daq_list;                            /* pointer to first DAQ list (absolute) */
  Xcp_OdtEntryType  * XCP_VAR_DAQ_LST odt_entry;                           /* pointer to first ODT entry (absolute) */
  Xcp_EventChannelType event_channel[XCP_MAX_EVENT_CHANNEL]; /* status of event channels */
} Xcp_ServiceType;

typedef struct
{
  uint32 length;
  uint8  data[XCP_MAX_DTO];
} Xcp_DtoBufferType;

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/


#endif /* #ifndef _XCP_TYPES_H_ */