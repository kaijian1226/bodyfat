/*******************************************************************************
*
*  FILE
*     Mcu_Cfg.h
*
*  DESCRIPTION
*     The Header file for MCU Configuration  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*    
*
*  VERSION
*    1.1.2
*
*******************************************************************************/

#ifndef _MCU_CFG_H_
#define _MCU_CFG_H_

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/
#define MCU_DEV_ERROR_DETECT    STD_ON


#define MCU_SUPPORT_OSEK_OS     STD_OFF

#define MCU_OSC_FREQ_MHZ      4
#define MCU_OSC_FREQ_HZ       (MCU_OSC_FREQ_MHZ * 1000000)

#define MCU_BUS_FREQ_MHZ      40
#define MCU_BUS_FREQ_HZ       (MCU_BUS_FREQ_MHZ * 1000000)

#define MCU_CLOCK_PLL_40       1U
#define MCU_CLOCK_NO_PLL       0U

#if (MCU_BUS_FREQ_MHZ > MCU_OSC_FREQ_MHZ)
  #if (MCU_BUS_FREQ_MHZ == 40)
    #define MCU_CLOCK_SETTING  MCU_CLOCK_PLL_40
  #else
    #error "MCU_BUS_FREQ_MHZ setting not supported"
  #endif 
#else
  #define MCU_CLOCK_SETTING     MCU_CLOCK_NO_PLL
#endif 


/* The try num limit for PLL Setup */
#define MCU_PLL_SETUP_UPLIMIT   10

#define MCU_STOP_MODE_SUPPORT   STD_ON

/* the default setting for direct page is zero, which means the address 
  range 0x0 - 0xFF, if set to other value, compiler options need to be 
  specified. */
#define MCU_DIRECT_PAGE         0x0
/*******************************************************************************
* Macros                                                                
*******************************************************************************/


/*******************************************************************************
* Global Variables declaration                         
*******************************************************************************/

/*******************************************************************************
* Global functions declaration                         
*******************************************************************************/



#endif /* #ifndef _MCU_TYPES_H_ */