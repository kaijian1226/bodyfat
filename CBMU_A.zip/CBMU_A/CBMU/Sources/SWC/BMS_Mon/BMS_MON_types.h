/*
 * File: BMS_MON_types.h
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BMS_MON_types_h_
#define RTW_HEADER_BMS_MON_types_h_
#include "rtwtypes.h"
#ifndef _DEFINED_TYPEDEF_FOR_t_Voltage3_
#define _DEFINED_TYPEDEF_FOR_t_Voltage3_

typedef uint16_T t_Voltage3;
typedef cuint16_T ct_Voltage3;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Temp1_
#define _DEFINED_TYPEDEF_FOR_t_Temp1_

typedef uint8_T t_Temp1;
typedef cuint8_T ct_Temp1;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Soc1_
#define _DEFINED_TYPEDEF_FOR_t_Soc1_

typedef uint8_T t_Soc1;
typedef cuint8_T ct_Soc1;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Voltage4_
#define _DEFINED_TYPEDEF_FOR_t_Voltage4_

typedef uint16_T t_Voltage4;
typedef cuint16_T ct_Voltage4;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Current1_
#define _DEFINED_TYPEDEF_FOR_t_Current1_

typedef uint16_T t_Current1;
typedef cuint16_T ct_Current1;

#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_BMS_MON RT_MODEL_BMS_MON;

#endif                                 /* RTW_HEADER_BMS_MON_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
