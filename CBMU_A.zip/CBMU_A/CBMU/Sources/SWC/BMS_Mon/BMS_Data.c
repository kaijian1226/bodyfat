/*
 * File: BMS_Data.c
 *
 * Code generated for Simulink model 'BMS_MON'.
 *
 * Model version                  : 1.217
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Mon Jun 20 14:40:58 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtwtypes.h"
#include "BMS_MON_types.h"

/* Exported data definition */
const uint16_T BmsSigASRCHighNegDeb = 500U;
const uint16_T BmsSigASRCHighPosDeb = 500U;
const uint16_T BmsSigASRCLowNegDeb = 500U;
const uint16_T BmsSigASRCLowPosDeb = 500U;
const t_Voltage3 CellVoltDiffSigASRCHigh = 1638U;
const t_Voltage3 CellVoltDiffSigASRCLow = 0U;
const t_Voltage3 CellVoltSigASRCHigh = 11960U;
const t_Voltage3 CellVoltSigASRCLow = 9175U;
const t_Voltage3 CellVoltSigASRCTooHigh = 12452U;
const t_Voltage3 CellVoltSigASRCTooLow = 8192U;
const t_Temp1 DiffTempSigASRCHigh = 48U;
const t_Temp1 DiffTempSigASRCLow = 40U;
const t_Current1 DsgCurSigASRCHigh = 38912U;
const t_Current1 DsgCurSigASRCLow = 24512U;
const t_Current1 DsgCurSigASRCTooHigh = 39872U;
const t_Current1 DsgCurSigASRCTooLow = 23232U;
const t_Temp1 DsgTempSigASRCHigh = 90U;
const t_Temp1 DsgTempSigASRCLow = 25U;
const t_Temp1 DsgTempSigASRCTooHigh = 93U;
const t_Temp1 DsgTempSigASRCTooLow = 20U;
const t_Current1 FcCurSigASRCLow = 32512U;
const t_Current1 FcCurSigASRCTooHigh = 36352U;
const t_Current1 FcCurSigASRCTooLow = 32512U;
const t_Temp1 FcTempSigASRCHigh = 85U;
const t_Temp1 FcTempSigASRCLow = 32U;
const t_Temp1 FcTempSigASRCTooHigh = 85U;
const t_Temp1 FcTempSigASRCTooLow = 10U;
const uint16_T IsoSigASRCHigh = 6500U;
const uint16_T IsoSigASRCLow = 350U;
const uint16_T IsoSigASRCTooHigh = 6500U;
const uint16_T IsoSigASRCTooLow = 200U;
const t_Voltage3 LTCellVoltSigASRCHigh = 10486U;
const t_Voltage3 LTCellVoltSigASRCLow = 7537U;
const t_Voltage3 LTCellVoltSigASRCTooHigh = 11469U;
const t_Voltage3 LTCellVoltSigASRCTooLow = 6881U;
const t_Temp1 LT_TempPoint = 40U;
const t_Voltage4 PackVoltSigASRCHigh = 18688U;
const t_Voltage4 PackVoltSigASRCLow = 14336U;
const t_Voltage4 PackVoltSigASRCTooHigh = 19456U;
const t_Voltage4 PackVoltSigASRCTooHighHeal = 18944U;
const t_Voltage4 PackVoltSigASRCTooLow = 12800U;
const t_Voltage4 PackVoltSigASRCTooLowHeal = 13824U;
const t_Current1 ScCurSigASRCHigh = 33152U;
const t_Current1 ScCurSigASRCLow = 32512U;
const t_Current1 ScCurSigASRCTooHigh = 33280U;
const t_Current1 ScCurSigASRCTooLow = 32512U;
const t_Temp1 ScTempSigASRCHigh = 85U;
const t_Temp1 ScTempSigASRCLow = 32U;
const t_Temp1 ScTempSigASRCTooHigh = 85U;
const t_Temp1 ScTempSigASRCTooLow = 10U;
const t_Soc1 SocSigASRCHigh = 250U;
const t_Soc1 SocSigASRCLow = 50U;
const t_Soc1 SocSigASRCTooHigh = 250U;
const t_Soc1 SocSigASRCTooLow = 3U;

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
