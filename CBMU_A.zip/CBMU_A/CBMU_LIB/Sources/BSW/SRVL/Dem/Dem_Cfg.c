/*******************************************************************************
*
*  FILE
*     Dem_Cfg.c
*
*  DESCRIPTION
*     Configuration Source Code File for Dem Module  
*      
*       
*  COPYRIGHT
*     
*     All rights reserved.
*
*  AUTHOR
*   
*
*  VERSION
*    1.1.0
*
*******************************************************************************/

/*******************************************************************************
* include files                                                 
*******************************************************************************/
#include "Std_Types.h"
#include "Dem_Types.h"

/*******************************************************************************
* Defines                                                                
*******************************************************************************/

/*******************************************************************************
* Macros                                                                
*******************************************************************************/

/*******************************************************************************
* Global Constant definition                         
*******************************************************************************/
boolean  Dem_stClear_C = 0;

CONST(Dem_FaultCodeType,DEM_CONST) Dem_ErrJ1939FaultCode[DEM_EVENT_NUM] = 
/* SPN, FMI, ErrorClass, Healing Counter*/
/*   FidPar , 
     UsrDefDataPar */
{
  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========�ܵ�ѹ============
  //0
  {                                              
    168,  16, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                  
  },          
 //1
  {                                              
    168,  17, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },      
  },          
  //2
  {                                              
    168,  18, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //3
  {                                              
    168,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
            
  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========�����ѹ============
  //4
  {                                              
    169,  16, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                  
  },          
 //5
  {                                              
    169,  17, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },      
  },          
  //6
  {                                              
    169,  18, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //7
  {                                              
    169,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },          
  //8                
  {                                              
    169,  19, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },          

  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========���£�0�����£������ѹ============
  //9
  {                                              
    170,  18, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //10
  {                                              
    170,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
  
  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========SOC============
  //11
  {                                              
    171,  18, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //12
  {                                              
    171,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
            
  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========��ŵ����============
  //13
  {                                              
    172,  16, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //14
  {                                              
    172,  17, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
  //15
  {                                              
    172,  18, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //16
  {                                              
    172,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
  //17
  {                                              
    172,  20, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //18
  {                                              
    172,  21, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
  
  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========��Ե����============
  //19
  {                                              
    173,  17, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //20
  {                                              
    173,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
  
  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========(��о)�ŵ��¶�============
  //21
  {                                              
    174,  16, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //22
  {                                              
    174,  17, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
  //23
  {                                              
    174,  18, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //24
  {                                              
    174,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },

  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========(��о)�����¶�============
  //25   20150831
  {                                              
    175,  16, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //26
  {                                              
    175,  17, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
  //27
  {                                              
    175,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          

  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========(��о)����¶�============
  //28
  {                                              
    176,  16, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          
  //29
  {                                              
    176,  17, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                
  },
  //30
  {                                              
    176,  19, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },          

  /* SPN, FMI, ErrorClass, Healing Counter*/
  /* FidPar , 
     UsrDefDataPar */
  //===========(��о)�¶Ȳ�����1============
  //31
  {                                              
    177,  20, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },
  
	//32����ϵͳ�����ָ�Ϊһ������ ����ᾭ�����ϼ̵���  20150902
	{											   
	  178,	5, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//33  20150831 Ŀǰ��Ϊ1����ѹ����
	{											   
	  178,	22, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//34   20150831 Ŀǰ��Ϊ1�� ��ȫ����
	{											   
	  178,	22, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//35  ճ�͹���
	{											   
	  178,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//36  Ӳ������
	{											   
	  178,	22, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
  //37	���ص�ѹ����
  { 											 
  	179,  5, 1, 3,
  	{ DEM_NO_FID, DEM_NO_FID },
  	{ DEM_NO_PARAM },					
  },
  //38	���ص�ѹ����
  { 											 
  	179,  4, 1, 3,
  	{ DEM_NO_FID, DEM_NO_FID },
  	{ DEM_NO_PARAM },					
  },
  //39  20150831 ��ѹ�峬ʱ
  {                                              
    180,  23, 2, 3,
    { DEM_FID_RELAY_OFF, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },
  //40  ��BMU1ͨ�ų���
  {                                              
    180,  23, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },
  //41  ��BMU2ͨ�ų���
  {                                              
    180,  23, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },
  //42  ��BMU3ͨ�ų���
  {                                              
    180,  23, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },
  //43  ��BMU4ͨ�ų���
  {                                              
    180,  23, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },
	//44  ��BMU5ͨ�ų���
	{											   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	}, 
	//45  ��BMU6ͨ�ų���
	{											   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//46  ��BMU7ͨ�ų���
	{												
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//47  ��BMU8ͨ�ų���
	{											   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//48  ��BMU9ͨ�ų���
	{												
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//49  ��BMU10ͨ�ų���
	{												
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//50  ��BMU11ͨ�ų���
	{											   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//51  ��BMU12ͨ�ų���
	{												
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//52  ��BMU13ͨ�ų���
	{												 
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//53  ��BMU14ͨ�ų���
	{												 
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//54  ��BMU15ͨ�ų��� 
	{												   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},	
	//55  ��BMU16ͨ�ų���
	{												   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//56   ��BMU17ͨ�ų���
	{												 
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//57  ��BMU18ͨ�ų��� 
	{												   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},	
	//58  ��BMU19ͨ�ų���
	{												   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//59  ��BMU20ͨ�ų���
	{												 
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//60  ��BMU21ͨ�ų��� 
	{												   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},	
	//61  ��BMU22ͨ�ų���
	{												   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//62  ��BMU23ͨ�ų���
	{												 
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//63  ��BMU24ͨ�ų��� 
	{												   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},	
	//64  ��BMU25ͨ�ų���
	{												   
	  180,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 	
	},
	//65	���ͨ���쳣
	{											   
		180,	23, 1, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM }, 				  
	},
  //66		�ڲ�ͨѶ�쳣
  {                                              
    180,  23, 2, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },
  //67 ����ͨѶ�쳣
  {                                              
    180,  23, 1, 3,
    { DEM_NO_FID, DEM_NO_FID },
    { DEM_NO_PARAM },                   
  },
	//68 SOC�ɼ��쳣2��
	{											   
	  181,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//69 ��Ե����ɼ��쳣2��
	{											   
	  181,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	  //70 �ܵ����ɼ��쳣2��
	  { 											 
		181,  23, 1, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM },					
	  },
	  //71 �ܵ�ѹ�ɼ��쳣1��
	  { 											 
		181,  23, 1, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM },					
	  },
	//72 �ܵ�ѹ�ɼ��쳣2��
	{											   
	  181,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//73	��о��ѹ�����쳣1��
	{												   
	  181,	23, 1, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//74	��о��ѹ�����쳣2��
	{												   
	  181,	23, 2, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
  //75	�¶Ȳ����쳣1��
  { 												 
	182,  23, 1, 3,
	{ DEM_NO_FID, DEM_NO_FID },
	{ DEM_NO_PARAM },					
  },
  //76	�¶Ȳ����쳣2��
  { 												 
	182,  23, 2, 3,
	{ DEM_NO_FID, DEM_NO_FID },
	{ DEM_NO_PARAM },					
  },
	//77	��о��ѹ����3��
	{												   
	  183,	23, 3, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//78	��о��ѹ����3��
	{												   
	  183,	23, 3, 3,
	  { DEM_NO_FID, DEM_NO_FID },
	  { DEM_NO_PARAM }, 				  
	},
	//79	�ŵ��¶ȹ���3��
	{ 												 
		183,  23, 3, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM },					
	},
	//80	�ŵ��¶ȹ���3��
	{ 												 
		183,  23, 3, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM },					
	},
	//81	����¶ȹ���3��
	{												   
		183,	23, 3, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM }, 				  
	},
	//82	����¶ȹ���3��
	{												   
		183,	23, 3, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM }, 				  
	},
	//83	����ͨ�Ŷ�ʧ
	{ 												 
		183,  23, 3, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM },					
	},   
	//84 ��о��ѹ���� 20151210
	{ 												 
		183,  23, 3, 3,
		{ DEM_NO_FID, DEM_NO_FID },
		{ DEM_NO_PARAM },					
	},
         
};
/*******************************************************************************
* Local Constant definition                         
*******************************************************************************/

/*******************************************************************************
* Global Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Variables definition                         
*******************************************************************************/

/*******************************************************************************
* Local Functions prototypes                         
*******************************************************************************/


/*******************************************************************************
*  Global Functions Body                                   
*******************************************************************************/



/*******************************************************************************
*  Local Functions Body                                   
*******************************************************************************/





