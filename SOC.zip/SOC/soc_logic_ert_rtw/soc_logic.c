/*******************************************************************************
 *  Real-Time Workshop code generated for Simulink model < soc_logic >
 *
 *  File: soc_logic.c
 *  File Creation Date: 30-Aug-2016
 *  Code generated on : Tue Aug 30 18:03:34 2016
 *  Abstraction:
 *  Notes:
 *
 *  Model Information:
 *  Model Name: soc_logic
 *  Model Version: 1.137
 *  Model Description:
 *  Creation date:	Thu Nov 06 11:14:33 2014
 *  Last Saved Modification:   Tue Aug 30 18:01:52 2016
 *
 *  (c)Copyright 2008-2014��Wuhan Eureka Control System Co., Ltd.
 *******************************************************************************/
/******************************************************************************
 *   Include files
 ******************************************************************************/
#include "soc_logic.h"
#include "soc_logic_private.h"

/*****************************************************************************
 *  Defines
 *****************************************************************************/

/*****************************************************************************
 *   Data Types
 *****************************************************************************/

/*****************************************************************************
 *   Definitions
 *****************************************************************************/

/*****************************************************************************
 *    Declarations
 *****************************************************************************/

/******************************************************************************
 *   FILE SCOPE DATA
 ******************************************************************************/

/*****************************************************************************
 *   FUNCTIONS
 *****************************************************************************/

/* Lookup Binary Search Utility BINARYSEARCH_U16 */
void BINARYSEARCH_U16(uint16_T *piLeft, uint16_T *piRght, uint16_T u, const
                      uint16_T *pData, uint16_T iHi)
{
  /* Find the location of current input value in the data table. */
  *piLeft = 0U;
  *piRght = iHi;
  if (u <= pData[0] ) {
    /* Less than or equal to the smallest point in the table. */
    *piRght = 0U;
  } else if (u >= pData[iHi] ) {
    /* Greater than or equal to the largest point in the table. */
    *piLeft = iHi;
  } else {
    uint16_T i;

    /* Do a binary search. */
    while (( *piRght - *piLeft ) > 1U ) {
      /* Get the average of the left and right indices using to Floor rounding. */
      i = (*piLeft + *piRght) >> 1;

      /* Move either the right index or the left index so that */
      /*  LeftDataPoint <= CurrentValue < RightDataPoint */
      if (u < pData[i] ) {
        *piRght = i;
      } else {
        *piLeft = i;
      }
    }
  }
}

/* Lookup Binary Search Utility BINARYSEARCH_U8 */
void BINARYSEARCH_U8(uint16_T *piLeft, uint16_T *piRght, uint8_T u, const
                     uint8_T *pData, uint16_T iHi)
{
  /* Find the location of current input value in the data table. */
  *piLeft = 0U;
  *piRght = iHi;
  if (u <= pData[0] ) {
    /* Less than or equal to the smallest point in the table. */
    *piRght = 0U;
  } else if (u >= pData[iHi] ) {
    /* Greater than or equal to the largest point in the table. */
    *piLeft = iHi;
  } else {
    uint16_T i;

    /* Do a binary search. */
    while (( *piRght - *piLeft ) > 1U ) {
      /* Get the average of the left and right indices using to Floor rounding. */
      i = (*piLeft + *piRght) >> 1;

      /* Move either the right index or the left index so that */
      /*  LeftDataPoint <= CurrentValue < RightDataPoint */
      if (u < pData[i] ) {
        *piRght = i;
      } else {
        *piLeft = i;
      }
    }
  }
}

/* Lookup Interpolation INTERPOLATE_S16_U8 */
void INTERPOLATE_S16_U8(int16_T *pY, int16_T yL, int16_T yR, uint8_T x, uint8_T
  xL, uint8_T xR)
{
  int32_T bigProd;
  int16_T yDiff;
  uint8_T xNum;
  uint8_T xDen;
  *pY = yL;

  /* If x is not strictly between xR and xL
   * then an interpolation calculation is not necessary x == xL
   * or not valid.  The invalid situation is expected when the input
   * is beyond the left or right end of the table.  The design is
   * that yL holds the correct value for *pY
   * in invalid situations.
   */
  if ((xR > xL) && (x > xL) ) {
    xDen = xR;
    xDen = (uint8_T)((uint16_T)xDen - (uint16_T)xL);
    xNum = x;
    xNum = (uint8_T)((uint16_T)xNum - (uint16_T)xL);
    yDiff = yR;
    yDiff -= yL;
    bigProd = (int32_T)yDiff * (int32_T)xNum;
    yDiff = div_s16s32_floor(bigProd, (int32_T)xDen);
    *pY += yDiff;
  }
}

/* Lookup Interpolation INTERPOLATE_S16_U16 */
void INTERPOLATE_S16_U16(int16_T *pY, int16_T yL, int16_T yR, uint16_T x,
  uint16_T xL, uint16_T xR)
{
  int32_T bigProd;
  int16_T yDiff;
  uint16_T xNum;
  uint16_T xDen;
  *pY = yL;

  /* If x is not strictly between xR and xL
   * then an interpolation calculation is not necessary x == xL
   * or not valid.  The invalid situation is expected when the input
   * is beyond the left or right end of the table.  The design is
   * that yL holds the correct value for *pY
   * in invalid situations.
   */
  if ((xR > xL) && (x > xL) ) {
    xDen = xR;
    xDen -= xL;
    xNum = x;
    xNum -= xL;
    yDiff = yR;
    yDiff -= yL;
    bigProd = (int32_T)yDiff * (int32_T)xNum;
    yDiff = div_s16s32_floor(bigProd, (int32_T)xDen);
    *pY += yDiff;
  }
}

/* Lookup 2D Lookup Utility Look2D_S16_U16_U8 */
void Look2D_S16_U16_U8(int16_T *pY, const int16_T *pYData, uint16_T u0, const
  uint16_T *pU0Data, uint16_T iHiU0, uint8_T u1, const uint8_T *pU1Data,
  uint16_T iHiU1)
{
  uint16_T iLeftU0, iRghtU0, iLeftU1, iRghtU1;
  BINARYSEARCH_U16( &(iLeftU0), &(iRghtU0), u0, pU0Data, iHiU0);
  BINARYSEARCH_U8( &(iLeftU1), &(iRghtU1), u1, pU1Data, iHiU1);

  {
    uint16_T u0Left = pU0Data[iLeftU0];
    uint16_T u0Rght = pU0Data[iRghtU0];
    uint8_T u1Left = pU1Data[iLeftU1];
    uint8_T u1Rght = pU1Data[iRghtU1];
    int16_T yTemp;
    int16_T yLeftLeft;
    int16_T yLeftRght;
    int16_T yRghtLeft;
    int16_T yRghtRght;
    iHiU0++;
    iLeftU1 *= iHiU0;
    iRghtU1 *= iHiU0;
    yRghtLeft = pYData[(iRghtU0+iLeftU1)];
    yRghtRght = pYData[(iRghtU0+iRghtU1)];
    yLeftLeft = pYData[(iLeftU0+iLeftU1)];
    yLeftRght = pYData[(iLeftU0+iRghtU1)];

    /* Interpolate along U1 variable
     *    with the u0 variable locked on the left u0
     */
    INTERPOLATE_S16_U8( pY, yLeftLeft, yLeftRght, u1, u1Left, u1Rght);

    /* Interpolate along U1 variable
     *    with the u0 variable locked on the right u0
     */
    INTERPOLATE_S16_U8( (&(yTemp)), yRghtLeft, yRghtRght, u1, u1Left, u1Rght);

    /*
     * Interpolate along u0 variable
     *    with the u1 variable locked on its interpolated value
     */
    INTERPOLATE_S16_U16( pY, (*pY), yTemp, u0, u0Left, u0Rght);
  }
}

void mul_wide_s32(int32_T temp_in0, int32_T temp_in1, uint32_T
                  *temp_ptrOutBitsHi, uint32_T *temp_ptrOutBitsLo)
{
  uint32_T temp_absIn0;
  uint32_T temp_absIn1;
  uint32_T temp_in0Lo;
  uint32_T temp_in0Hi;
  uint32_T temp_in1Hi;
  uint32_T temp_productHiLo;
  uint32_T temp_productLoHi;
  temp_absIn0 = (uint32_T)(temp_in0 < 0L ? -temp_in0 : temp_in0);
  temp_absIn1 = (uint32_T)(temp_in1 < 0L ? -temp_in1 : temp_in1);
  temp_in0Hi = temp_absIn0 >> 16UL;
  temp_in0Lo = temp_absIn0 & 65535UL;
  temp_in1Hi = temp_absIn1 >> 16UL;
  temp_absIn0 = temp_absIn1 & 65535UL;
  temp_productHiLo = temp_in0Hi * temp_absIn0;
  temp_productLoHi = temp_in0Lo * temp_in1Hi;
  temp_absIn0 *= temp_in0Lo;
  temp_absIn1 = 0UL;
  temp_in0Lo = (temp_productLoHi << 16UL) + temp_absIn0;
  if (temp_in0Lo < temp_absIn0) {
    temp_absIn1 = 1UL;
  }

  temp_absIn0 = temp_in0Lo;
  temp_in0Lo += temp_productHiLo << 16UL;
  if (temp_in0Lo < temp_absIn0) {
    temp_absIn1++;
  }

  temp_absIn0 = (((temp_productLoHi >> 16UL) + (temp_productHiLo >> 16UL)) +
                 temp_in0Hi * temp_in1Hi) + temp_absIn1;
  if (!((temp_in0 == 0L) || ((temp_in1 == 0L) || ((temp_in0 > 0L) == (temp_in1 >
          0L))))) {
    temp_absIn0 = ~temp_absIn0;
    temp_in0Lo = ~temp_in0Lo;
    temp_in0Lo++;
    if (temp_in0Lo == 0UL) {
      temp_absIn0++;
    }
  }

  *temp_ptrOutBitsHi = temp_absIn0;
  *temp_ptrOutBitsLo = temp_in0Lo;
}

int32_T mul_s32_s32_s32_sr28_zero(int32_T temp_a, int32_T temp_b)
{
  uint32_T temp_u32_chi;
  uint32_T temp_u32_clo;
  mul_wide_s32(temp_a, temp_b, &temp_u32_chi, &temp_u32_clo);
  temp_u32_clo = (((int32_T)temp_u32_chi < 0L) && ((temp_u32_clo & 268435455UL)
    != 0UL)) + (temp_u32_chi << 4UL | temp_u32_clo >> 28UL);
  return (int32_T)temp_u32_clo;
}

int32_T mul_s32_s32_s32_sr14_zero(int32_T temp_a, int32_T temp_b)
{
  uint32_T temp_u32_chi;
  uint32_T temp_u32_clo;
  mul_wide_s32(temp_a, temp_b, &temp_u32_chi, &temp_u32_clo);
  temp_u32_clo = (((int32_T)temp_u32_chi < 0L) && ((temp_u32_clo & 16383UL) !=
    0UL)) + (temp_u32_chi << 18UL | temp_u32_clo >> 14UL);
  return (int32_T)temp_u32_clo;
}

int16_T div_repeat_s16s32(int32_T temp_numerator, int32_T temp_denominator,
  uint16_T temp_nRepeatSub)
{
  int16_T temp_quotient;
  uint32_T temp_tempAbsQuotient;
  if (temp_denominator == 0L) {
    temp_quotient = temp_numerator >= 0L ? MAX_int16_T : MIN_int16_T;

    /* Divide by zero handler */
  } else {
    temp_tempAbsQuotient = div_nzp_repeat_u32((uint32_T)(temp_numerator >= 0L ?
      temp_numerator : -temp_numerator), (uint32_T)(temp_denominator >= 0L ?
      temp_denominator : -temp_denominator), temp_nRepeatSub);
    temp_quotient = (temp_numerator < 0L) != (temp_denominator < 0L) ? (int16_T)
      -(int32_T)temp_tempAbsQuotient : (int16_T)temp_tempAbsQuotient;
  }

  return temp_quotient;
}

uint32_T div_nzp_repeat_u32(uint32_T temp_numerator, uint32_T temp_denominator,
  uint16_T temp_nRepeatSub)
{
  uint32_T temp_quotient;
  uint16_T temp_iRepeatSub;
  boolean_T temp_numeratorExtraBit;
  temp_quotient = temp_numerator / temp_denominator;
  temp_numerator %= temp_denominator;
  for (temp_iRepeatSub = 0U; temp_iRepeatSub < temp_nRepeatSub; temp_iRepeatSub
       ++) {
    temp_numeratorExtraBit = (temp_numerator >= 2147483648UL);
    temp_numerator <<= 1UL;
    temp_quotient <<= 1UL;
    if (temp_numeratorExtraBit || (temp_numerator >= temp_denominator)) {
      temp_quotient++;
      temp_numerator -= temp_denominator;
    }
  }

  return temp_quotient;
}

int32_T mul_s32_s32_s32_sr35(int32_T temp_a, int32_T temp_b)
{
  uint32_T temp_u32_chi;
  uint32_T temp_u32_clo;
  mul_wide_s32(temp_a, temp_b, &temp_u32_chi, &temp_u32_clo);
  return (int32_T)temp_u32_chi >> 3L;
}

int32_T mul_s32_s32_s32_sr10(int32_T temp_a, int32_T temp_b)
{
  uint32_T temp_u32_chi;
  uint32_T temp_u32_clo;
  mul_wide_s32(temp_a, temp_b, &temp_u32_chi, &temp_u32_clo);
  temp_u32_clo = temp_u32_chi << 22UL | temp_u32_clo >> 10UL;
  return (int32_T)temp_u32_clo;
}

int16_T div_s16s32_floor(int32_T temp_numerator, int32_T temp_denominator)
{
  int16_T temp_quotient;
  uint32_T temp_absNumerator;
  uint32_T temp_absDenominator;
  uint32_T temp_tempAbsQuotient;
  boolean_T temp_quotientNeedsNegation;
  if (temp_denominator == 0L) {
    temp_quotient = temp_numerator >= 0L ? MAX_int16_T : MIN_int16_T;

    /* Divide by zero handler */
  } else {
    temp_absNumerator = (uint32_T)(temp_numerator >= 0L ? temp_numerator :
      -temp_numerator);
    temp_absDenominator = (uint32_T)(temp_denominator >= 0L ? temp_denominator :
      -temp_denominator);
    temp_quotientNeedsNegation = ((temp_numerator < 0L) != (temp_denominator <
      0L));
    temp_tempAbsQuotient = temp_absNumerator / temp_absDenominator;
    if (temp_quotientNeedsNegation) {
      temp_absNumerator %= temp_absDenominator;
      if (temp_absNumerator > 0UL) {
        temp_tempAbsQuotient++;
      }
    }

    temp_quotient = temp_quotientNeedsNegation ? (int16_T)-(int32_T)
      temp_tempAbsQuotient : (int16_T)temp_tempAbsQuotient;
  }

  return temp_quotient;
}

int16_T look1_is16lu16n16ts16D_c5pSCY2v(int16_T temp_u0, const int16_T temp_bp0[],
  const int16_T temp_table[], uint32_T temp_maxIndex)
{
  int16_T temp_y;
  uint16_T temp_frac;
  uint32_T temp_iRght;
  uint32_T temp_iLeft;
  uint32_T temp_bpIdx;

  /* Lookup 1-D
     Canonical function name: look1_is16lu16n16ts16Ds32_binlcas
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  if (temp_u0 <= temp_bp0[0UL]) {
    temp_iLeft = 0UL;
    temp_frac = 0U;
  } else if (temp_u0 < temp_bp0[temp_maxIndex]) {
    /* Binary Search */
    temp_bpIdx = temp_maxIndex >> 1UL;
    temp_iLeft = 0UL;
    temp_iRght = temp_maxIndex;
    while (temp_iRght - temp_iLeft > 1UL) {
      if (temp_u0 < temp_bp0[temp_bpIdx]) {
        temp_iRght = temp_bpIdx;
      } else {
        temp_iLeft = temp_bpIdx;
      }

      temp_bpIdx = (temp_iRght + temp_iLeft) >> 1UL;
    }

    temp_frac = (uint16_T)(((uint32_T)((uint16_T)temp_u0 - temp_bp0[temp_iLeft])
      << 16) / ((uint16_T)temp_bp0[temp_iLeft + 1UL] - temp_bp0[temp_iLeft]));
  } else {
    temp_iLeft = temp_maxIndex;
    temp_frac = 0U;
  }

  /* Interpolation 1-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'on'
     Rounding mode: 'simplest'
     Overflow mode: 'wrapping'
   */
  if (temp_iLeft == temp_maxIndex) {
    temp_y = temp_table[temp_iLeft];
  } else {
    temp_y = (int16_T)(((int32_T)temp_table[temp_iLeft + 1UL] -
                        temp_table[temp_iLeft]) * temp_frac >> 16) +
      temp_table[temp_iLeft];
  }

  return temp_y;
}

int16_T look1_iu8lu16n16ts16Ds_FbqVATJM(uint8_T temp_u0, const uint8_T temp_bp0[],
  const int16_T temp_table[], uint32_T temp_maxIndex)
{
  int16_T temp_y;
  uint16_T temp_frac;
  uint32_T temp_iRght;
  uint32_T temp_iLeft;
  uint32_T temp_bpIdx;

  /* Lookup 1-D
     Canonical function name: look1_iu8lu16n16ts16Ds32_binlcas
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  if (temp_u0 <= temp_bp0[0UL]) {
    temp_iLeft = 0UL;
    temp_frac = 0U;
  } else if (temp_u0 < temp_bp0[temp_maxIndex]) {
    /* Binary Search */
    temp_bpIdx = temp_maxIndex >> 1UL;
    temp_iLeft = 0UL;
    temp_iRght = temp_maxIndex;
    while (temp_iRght - temp_iLeft > 1UL) {
      if (temp_u0 < temp_bp0[temp_bpIdx]) {
        temp_iRght = temp_bpIdx;
      } else {
        temp_iLeft = temp_bpIdx;
      }

      temp_bpIdx = (temp_iRght + temp_iLeft) >> 1UL;
    }

    temp_frac = (uint16_T)(((uint32_T)(uint8_T)((uint16_T)temp_u0 -
      temp_bp0[temp_iLeft]) << 16) / (uint8_T)((uint16_T)temp_bp0[temp_iLeft +
      1UL] - temp_bp0[temp_iLeft]));
  } else {
    temp_iLeft = temp_maxIndex;
    temp_frac = 0U;
  }

  /* Interpolation 1-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'on'
     Rounding mode: 'simplest'
     Overflow mode: 'wrapping'
   */
  if (temp_iLeft == temp_maxIndex) {
    temp_y = temp_table[temp_iLeft];
  } else {
    temp_y = (int16_T)(((int32_T)temp_table[temp_iLeft + 1UL] -
                        temp_table[temp_iLeft]) * temp_frac >> 16) +
      temp_table[temp_iLeft];
  }

  return temp_y;
}

int16_T look1_is32lu16n16ts16D_UEUZuoen(int32_T temp_u0, const int32_T temp_bp0[],
  const int16_T temp_table[], uint32_T temp_maxIndex)
{
  int16_T temp_y;
  uint16_T temp_frac;
  uint32_T temp_iRght;
  uint32_T temp_iLeft;
  uint32_T temp_bpIdx;

  /* Lookup 1-D
     Canonical function name: look1_is32lu16n16ts16Ds32_binlcas
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
     Rounding mode: 'simplest'
   */
  if (temp_u0 <= temp_bp0[0UL]) {
    temp_iLeft = 0UL;
    temp_frac = 0U;
  } else if (temp_u0 < temp_bp0[temp_maxIndex]) {
    /* Binary Search */
    temp_bpIdx = temp_maxIndex >> 1UL;
    temp_iLeft = 0UL;
    temp_iRght = temp_maxIndex;
    while (temp_iRght - temp_iLeft > 1UL) {
      if (temp_u0 < temp_bp0[temp_bpIdx]) {
        temp_iRght = temp_bpIdx;
      } else {
        temp_iLeft = temp_bpIdx;
      }

      temp_bpIdx = (temp_iRght + temp_iLeft) >> 1UL;
    }

    temp_frac = (uint16_T)div_nzp_repeat_u32((uint32_T)temp_u0 -
      temp_bp0[temp_iLeft], (uint32_T)temp_bp0[temp_iLeft + 1UL] -
      temp_bp0[temp_iLeft], 16U);
  } else {
    temp_iLeft = temp_maxIndex;
    temp_frac = 0U;
  }

  /* Interpolation 1-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'on'
     Rounding mode: 'simplest'
     Overflow mode: 'wrapping'
   */
  if (temp_iLeft == temp_maxIndex) {
    temp_y = temp_table[temp_iLeft];
  } else {
    temp_y = (int16_T)(((int32_T)temp_table[temp_iLeft + 1UL] -
                        temp_table[temp_iLeft]) * temp_frac >> 16) +
      temp_table[temp_iLeft];
  }

  return temp_y;
}

/* Model step function */
void soc_logic_step(void)
{
  t_Factor1 lbo_Soc_DisChargeDiffCurv;
  t_Percent1 lbo_Add_g;
  t_Capacity1 lbo_Add;

  /* Outputs for Atomic SubSystem: '<S1>/Soc_Calculation' */

  /* Lookup2D: '<S2>/OCV_Map'
   * About '<S2>/OCV_Map':
   * Input0  Data Type:  Fixed Point    U16  2^-2  FSlope 1.220704
   * Input1  Data Type:  Fixed Point    U8  Bias -40.0
   * Output0 Data Type:  Fixed Point    S16  2^-14  FSlope 1.6384
   * Lookup Method: Linear_Endpoint
   *
   * Row Data    parameter uses the same data type and scaling as Input0
   * Column Data parameter uses the same data type and scaling as Input1
   * Table Data  parameter uses the same data type and scaling as Output0
   */
  Look2D_S16_U16_U8( &(soc_ocvPercent), (&(soc_percent_MAP[0])), soc_ocv,
                    (&(soc_ocv_TBL[0])), 26U, soc_temp, (&(soc_temp_TBL[0])), 4U);

  /* Outputs for Atomic SubSystem: '<S2>/Soc_fac_cal' */
  /* Sum: '<S4>/Add' incorporates:
   *  Delay: '<S2>/Delay'
   */
  lbo_Add_g = soc_percent - soc_ocvPercent;

  /* Switch: '<S4>/Switch_FullCharg2' incorporates:
   *  Inport: '<Root>/soc_current'
   *  Logic: '<S4>/Logical Operator1'
   *  RelationalOperator: '<S4>/Relational Operator2'
   *  RelationalOperator: '<S4>/Relational Operator3'
   */
  if ((soc_current < -32) && (soc_ocvPercent < 3000)) {
    /* Lookup_n-D: '<S4>/Soc_DisChargeDiffCurv' */
    lbo_Soc_DisChargeDiffCurv = look1_is16lu16n16ts16D_c5pSCY2v(lbo_Add_g,
      (&(soc_soc_DisChargeDiffCurvX[0])), (&(soc_fac_DisChargeDiffCurv[0])), 8UL);
  } else {
    /* Lookup_n-D: '<S4>/Soc_DisChargeDiffCurv' incorporates:
     *  Constant: '<S4>/Constant5'
     */
    lbo_Soc_DisChargeDiffCurv = 1024;
  }

  /* End of Switch: '<S4>/Switch_FullCharg2' */

  /* Switch: '<S4>/Switch_FullCharg1' incorporates:
   *  Inport: '<Root>/soc_current'
   *  Logic: '<S4>/Logical Operator'
   *  RelationalOperator: '<S4>/Relational Operator'
   *  RelationalOperator: '<S4>/Relational Operator1'
   */
  if ((soc_ocvPercent > 9500) && (soc_current > 32)) {
    /* Lookup_n-D: '<S4>/Soc_ChargeDiffCurv' */
    lbo_Add_g = look1_is16lu16n16ts16D_c5pSCY2v(lbo_Add_g,
      (&(soc_soc_ChargeDiffCurvX[0])), (&(soc_fac_ChargeDiffCurv[0])), 8UL);
  } else {
    /* Lookup_n-D: '<S4>/Soc_ChargeDiffCurv' incorporates:
     *  Constant: '<S4>/Constant2'
     */
    lbo_Add_g = 1024;
  }

  /* End of Switch: '<S4>/Switch_FullCharg1' */

  /* Product: '<S4>/CurrentMulti' */
  soc_fac_Charging = (t_Factor1)((int32_T)lbo_Soc_DisChargeDiffCurv * lbo_Add_g >>
    10);

  /* Lookup_n-D: '<S4>/Soc_CurrentCurv' incorporates:
   *  Inport: '<Root>/soc_current'
   */
  soc_fac_Current = look1_is16lu16n16ts16D_c5pSCY2v(soc_current,
    (&(soc_i_CurrentCurvX[0])), (&(soc_fac_CurrentCurv[0])), 10UL);

  /* Lookup_n-D: '<S4>/Soc_TempCurv' incorporates:
   *  Inport: '<Root>/soc_temp'
   */
  soc_fac_BatteryTemp = look1_iu8lu16n16ts16Ds_FbqVATJM(soc_temp,
    (&(soc_t_TempCurvX[0])), (&(soc_fac_TempCurv[0])), 10UL);

  /* Lookup_n-D: '<S4>/Soc_SocCurv' incorporates:
   *  Inport: '<Root>/soc_lastCapacity'
   */
  soc_fac_CurrSoc = look1_is32lu16n16ts16D_UEUZuoen(soc_lastCapacity,
    (&(soc_r_SocCurvX[0])), (&(soc_fac_SocCurv[0])), 8UL);

  /* Product: '<S4>/CurrentCorFac' incorporates:
   *  Product: '<S4>/SocCorFac'
   *  Product: '<S4>/TempCorFac'
   */
  soc_fac_All = (t_Factor1)((int32_T)(int16_T)((int32_T)(int16_T)((int32_T)
    soc_fac_BatteryTemp * soc_fac_CurrSoc >> 10) * soc_fac_Current >> 10) *
    soc_fac_Charging >> 10);

  /* End of Outputs for SubSystem: '<S2>/Soc_fac_cal' */

  /* Outputs for Atomic SubSystem: '<S2>/Soc_calculation' */
  /* Product: '<S3>/CurrentMulti' incorporates:
   *  Constant: '<S3>/sampleTime'
   *  Inport: '<Root>/soc_current'
   */
  soc_capacityCharging = (int32_T)soc_current * SOC_ST >> 1;

  /* Product: '<S3>/CurrentCorFac' */
  soc_capacityChargeCorrect = mul_s32_s32_s32_sr10(soc_fac_All,
    soc_capacityCharging);

  /* Switch: '<S3>/Switch_FullCharg' incorporates:
   *  Inport: '<Root>/soc_fullCapacity'
   *  Inport: '<Root>/soc_fullChrgFlg'
   */
  if (soc_fullChrgFlg) {
    soc_capacity = soc_fullCapacity;
  } else {
    /* Sum: '<S3>/Add' incorporates:
     *  DataTypeConversion: '<S3>/Data Type Conversion'
     *  Inport: '<Root>/soc_lastCapacity'
     */
    lbo_Add = mul_s32_s32_s32_sr35(soc_capacityChargeCorrect, 1374389535L) +
      soc_lastCapacity;

    /* MinMax: '<S3>/MinMax1' incorporates:
     *  Constant: '<S3>/Capacity_zero'
     */
    if (0L >= lbo_Add) {
      lbo_Add = 0L;
    }

    /* End of MinMax: '<S3>/MinMax1' */

    /* MinMax: '<S3>/MinMax' incorporates:
     *  Inport: '<Root>/soc_fullCapacity'
     */
    if (lbo_Add <= soc_fullCapacity) {
      soc_capacity = lbo_Add;
    } else {
      soc_capacity = soc_fullCapacity;
    }

    /* End of MinMax: '<S3>/MinMax' */
  }

  /* End of Switch: '<S3>/Switch_FullCharg' */
  /* End of Outputs for SubSystem: '<S2>/Soc_calculation' */

  /* Product: '<S2>/Product1' incorporates:
   *  Inport: '<Root>/soc_fullCapacity'
   */
  lbo_Add = div_repeat_s16s32(soc_capacity, soc_fullCapacity, 13U) * 625L;
  lbo_Add_g = (t_Percent1)(((lbo_Add < 0L ? 511 : 0) + lbo_Add) >> 9);

  /* Product: '<S2>/Product2' incorporates:
   *  Inport: '<Root>/soc_fullCapacity'
   */
  soc_ocvCapacity = mul_s32_s32_s32_sr28_zero(mul_s32_s32_s32_sr14_zero
    (soc_ocvPercent, soc_fullCapacity), 439804651L);

  /* Saturate: '<S2>/Saturation' */
  if (lbo_Add_g > 9900) {
    soc_percent = 9900;
  } else if (lbo_Add_g < 0) {
    soc_percent = 0;
  } else {
    soc_percent = lbo_Add_g;
  }

  /* End of Saturate: '<S2>/Saturation' */
  /* End of Outputs for SubSystem: '<S1>/Soc_Calculation' */
}

/* Model initialize function */
void soc_logic_initialize(void)
{
  /* (no initialization code required) */
}

/*======================== TOOL VERSION INFORMATION ==========================*
 * MATLAB 8.5 (R2015a)09-Feb-2015                                             *
 * Simulink 8.5 (R2015a)09-Feb-2015                                           *
 * Simulink Coder 8.8 (R2015a)09-Feb-2015                                     *
 * Embedded Coder 6.8 (R2015a)09-Feb-2015                                     *
 * Stateflow 8.5 (R2015a)09-Feb-2015                                          *
 * Fixed-Point Designer 5.0 (R2015a)09-Feb-2015                               *
 *============================================================================*/

/*======================= LICENSE IN USE INFORMATION =========================*
 * fixed_point_toolbox                                                        *
 * matlab                                                                     *
 * matlab_coder                                                               *
 * real-time_workshop                                                         *
 * rtw_embedded_coder                                                         *
 * simulink                                                                   *
 *============================================================================*/
