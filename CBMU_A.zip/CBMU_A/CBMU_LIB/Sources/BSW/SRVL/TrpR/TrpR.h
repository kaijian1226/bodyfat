#include "Std_Types.h"
#include "Eep.h"
#include "VFB.h"


extern void TRPR_CODE TrpR_Init(void);
extern void TRPR_CODE TrpR_DataSave(void);

extern boolean trpr_status;


