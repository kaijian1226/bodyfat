/*******************************************************************************
*
*  FILE
*     IIC_Cfg.h
*
*  DESCRIPTION
*     The Header file for   
*      
*       
*  COPYRIGHT
*     (c)Copyright 2011, Wuhan Eureka Control System Co., Ltd. 
*     All rights reserved.
*
*  AUTHOR
*    Gu Bin
*
*  VERSION
*    1.0.0
*
*******************************************************************************/

#ifndef __IIC_Cfg_H__
#define __IIC_Cfg_H__

/*******************************************************************************
* include files
*******************************************************************************/


/*******************************************************************************
* Defines
*******************************************************************************/

/*******************************************************************************
* Macros
*******************************************************************************/    
/* bus frequency 40Mhz,

37 - 125K
25 - 416.667K

*/


#define IIC_BAUDRATE      0x40           ///0x40   /* bus frequency 2Mhz, baudrate 200Kb/s */ 19

/* determine IIC slaver address width, 7bit or 10bit */
#define IIC_ADDR_WIDTH    7U
#if (IIC_ADDR_WIDTH==7)
  typedef      uint8    IIC_ADDR_TYPE ;
#else
  typedef     uint16    IIC_ADDR_TYPE ;
#endif

#define IIC_WAIT_MAX        1000U

#define IIC_STOP_DELAY      200U  //2015-07-14, xyl, changed from 20

#define IIC_IBCR    IIC0_IBCR
#define IIC_IBDR    IIC0_IBDR
#define IIC_IBFD    IIC0_IBFD
#define IIC_IBCR2   IIC0_IBCR2
#define IIC_IBAD    IIC0_IBAD
#define IIC_IBSR    IIC0_IBSR

//SD2405 Address 
#define IIC_SLAVE_ADDR  0x65


/*******************************************************************************
* Global Variables declaration
*******************************************************************************/

/*******************************************************************************
* Global functions declaration
*******************************************************************************/


#endif /* #ifndef __IIC_Cfg_H__ */
