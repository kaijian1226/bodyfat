/*
 * File: CBMU_MON_private.h
 *
 * Code generated for Simulink model 'CBMU_MON'.
 *
 * Model version                  : 1.877
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Mon Nov 25 13:16:45 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->S12x
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_CBMU_MON_private_h_
#define RTW_HEADER_CBMU_MON_private_h_
#include "rtwtypes.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFU) ) || ( INT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFUL) ) || ( LONG_MAX != (0x7FFFFFFFL) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/* Imported (extern) block signals */
extern uint16_T com_BPC2MaxChrgCurrent;/* '<S1>/Merge10' */
extern uint16_T com_BPC2MaxChrgVolt;   /* '<S23>/Chart' */
extern uint16_T ChargeCUR;             /* '<S10>/Merge' */
extern uint16_T com_BCL_ReqCurrent;    /* '<S8>/Chart' */
extern uint16_T com_BCL_ReqVolt;       /* '<S8>/Chart' */
extern uint16_T com_BCP_MaxCellChgVolt;/* '<S8>/Chart' */
extern uint16_T com_BCP_MaxChgCurrent; /* '<S8>/Chart' */
extern uint16_T com_BCP_MaxPackChgVolt;/* '<S8>/Chart' */
extern uint16_T com_BCP_NominalEnergy; /* '<S8>/Chart' */
extern uint16_T com_BCS_ChgTimeRemain; /* '<S8>/Chart' */
extern uint16_T com_BCS_MaxCellVolt;   /* '<S8>/Chart' */
extern uint16_T com_BCS_MeasuredChgCurrent;/* '<S8>/Chart' */
extern uint16_T com_BCS_MeasuredChgVolt;/* '<S8>/Chart' */
extern uint16_T com_BRM_ProVersion;    /* '<S8>/Chart' */
extern uint16_T com_BRM_RatedCap;      /* '<S8>/Chart' */
extern uint16_T com_BRM_RatedVolt;     /* '<S8>/Chart' */
extern uint16_T com_BSD_MaxCellVolt;   /* '<S8>/Chart' */
extern uint16_T com_BSD_MinCellVolt;   /* '<S8>/Chart' */
extern uint8_T com_BPC2ChrgSts;        /* '<S1>/Merge3' */
extern uint8_T com_ShutDown;           /* '<S1>/Merge6' */
extern uint8_T com_BPSHighVoltSts;     /* '<S1>/Merge7' */
extern uint8_T com_BEM_RcvChgerCMLMsg; /* '<S1>/Merge15' */
extern uint8_T com_BEM_RcvChgerReadyMsg;/* '<S1>/Merge16' */
extern uint8_T com_BEM_RcvChgerRecMsg_AA;/* '<S1>/Merge18' */
extern uint8_T com_BEM_RcvChgerStateMsg;/* '<S1>/Merge19' */
extern uint8_T com_BEM_RcvChgerStopMsg;/* '<S1>/Merge20' */
extern uint8_T com_BEM_RcvChgerTotalMsg;/* '<S1>/Merge21' */
extern uint8_T com_BPSDisChMRelaySts;  /* '<S79>/Chart' */
extern uint8_T com_BPSChMRelaySts;     /* '<S74>/Chart' */
extern uint8_T com_BPSSelfChkSts;      /* '<S23>/Chart' */
extern uint8_T BMS_ChargerDCInput;     /* '<S23>/Chart' */
extern uint8_T PackCurMode;            /* '<S23>/Chart' */
extern uint8_T com_BEM_RcvChgerRecMsg_00;/* '<S23>/Chart' */
extern uint8_T com_BCL_ChgMode;        /* '<S8>/Chart' */
extern uint8_T com_BCP_MaxAllowedTemp; /* '<S8>/Chart' */
extern uint8_T com_BCS_CurSOC;         /* '<S8>/Chart' */
extern uint8_T com_BCS_MaxCVGroupNum;  /* '<S8>/Chart' */
extern uint8_T com_BRM_BatType;        /* '<S8>/Chart' */
extern uint8_T com_BRM_SubProVersion;  /* '<S8>/Chart' */
extern uint8_T com_BRO_BMSReady;       /* '<S8>/Chart' */
extern uint8_T com_BSD_EndSOC;         /* '<S8>/Chart' */
extern uint8_T com_BSD_MaxCellTemp;    /* '<S8>/Chart' */
extern uint8_T com_BSD_MinCellTemp;    /* '<S8>/Chart' */
extern uint8_T com_BSM_ChgAllowed;     /* '<S8>/Chart' */
extern uint8_T com_BSM_ChgCVSt;        /* '<S8>/Chart' */
extern uint8_T com_BSM_ChgCurrentSt;   /* '<S8>/Chart' */
extern uint8_T com_BSM_ChgSOCSt;       /* '<S8>/Chart' */
extern uint8_T com_BSM_ChgTempSt;      /* '<S8>/Chart' */
extern uint8_T com_BSM_ConnecterSt;    /* '<S8>/Chart' */
extern uint8_T com_BSM_ISOSt;          /* '<S8>/Chart' */
extern uint8_T com_BSM_MaxCTCellNum;   /* '<S8>/Chart' */
extern uint8_T com_BSM_MaxCVCellNum;   /* '<S8>/Chart' */
extern uint8_T com_BSM_MaxCellTemp;    /* '<S8>/Chart' */
extern uint8_T com_BSM_MinCTCellNum;   /* '<S8>/Chart' */
extern uint8_T com_BSM_MinCellTemp;    /* '<S8>/Chart' */
extern uint8_T com_BST_BatOverTempFault;/* '<S8>/Chart' */
extern uint8_T com_BST_CompOverTempFault;/* '<S8>/Chart' */
extern uint8_T com_BST_ConnOverTempFault;/* '<S8>/Chart' */
extern uint8_T com_BST_ConnecterFault; /* '<S8>/Chart' */
extern uint8_T com_BST_CurrentError;   /* '<S8>/Chart' */
extern uint8_T com_BST_ISOFault;       /* '<S8>/Chart' */
extern uint8_T com_BST_OtherFault;     /* '<S8>/Chart' */
extern uint8_T com_BST_SetCVReach;     /* '<S8>/Chart' */
extern uint8_T com_BST_SetPVReach;     /* '<S8>/Chart' */
extern uint8_T com_BST_SetSOCReach;    /* '<S8>/Chart' */
extern uint8_T com_BST_VoltError;      /* '<S8>/Chart' */
extern uint8_T HeatingSt;              /* '<S8>/Chart' */
extern boolean_T com_InnerBusTxEna;    /* '<S1>/Merge' */
extern boolean_T com_VehBusTxEna;      /* '<S1>/Merge1' */
extern boolean_T com_BPC2ChrgEnable;   /* '<S1>/Merge2' */
extern boolean_T com_SlowChrgrTxEna;   /* '<S1>/Merge4' */
extern boolean_T com_FastChrgrTxEna;   /* '<S1>/Merge5' */
extern boolean_T com_BCPTxEna;         /* '<S1>/Merge12' */
extern boolean_T com_BEMTxEna;         /* '<S1>/Merge14' */
extern boolean_T com_BRMTxEna;         /* '<S1>/Merge22' */
extern boolean_T com_BROTxEna;         /* '<S1>/Merge23' */
extern boolean_T com_BSDTxEna;         /* '<S1>/Merge24' */
extern boolean_T com_BSTTxEna;         /* '<S1>/Merge26' */
extern boolean_T com_BCLTxEna;         /* '<S1>/Merge11' */
extern boolean_T com_BCSTxEna;         /* '<S1>/Merge13' */
extern boolean_T com_BSMTxEna;         /* '<S1>/Merge25' */
extern boolean_T ioa_PreChargeRelayCtl;/* '<S5>/Merge1' */
extern boolean_T ioa_ChMRelayCtl;      /* '<S5>/Merge2' */
extern boolean_T ioa_NegativeRelayCtl; /* '<S5>/Merge3' */
extern boolean_T ioa_DisChMRelayCtl;   /* '<S5>/Merge8' */
extern boolean_T ioa_12VOut;           /* '<S23>/Chart' */
extern boolean_T ioa_5VOut;            /* '<S23>/Chart' */
extern boolean_T com_InnerBusRxEna;    /* '<S23>/Chart' */
extern boolean_T com_VehBusRxEna;      /* '<S23>/Chart' */
extern boolean_T com_SlowChrgrRxEna;   /* '<S23>/Chart' */
extern boolean_T com_FastChrgrRxEna;   /* '<S23>/Chart' */
extern boolean_T com_BPC2ChrgrACInput; /* '<S23>/Chart' */
extern boolean_T com_BPSBattMaintenanceAlarm;/* '<S23>/Chart' */
extern boolean_T ioa_PwrOut;           /* '<S23>/Chart' */
extern boolean_T ioa_PTCRelayCtrl;     /* '<S8>/Chart' */
extern t_Voltage1 ioa_T15VoltActRaw;   /* '<Root>/ioa_T15VoltActRaw' */
extern t_Voltage1 ioa_chrgVoltActRaw;  /* '<Root>/ioa_ScVoltActRaw' */
extern t_Voltage1 ioa_battVoltActRaw;  /* '<Root>/ioa_battVoltActRaw' */
extern t_Voltage1 ioa_vccVoltActRaw;   /* '<Root>/ioa_vccVoltActRaw' */
extern t_Voltage1 ioa_sensorSplyVoltActRaw;/* '<Root>/ioa_sensorSplyVoltActRaw' */
extern t_Voltage1 ioa_gasVoltRaw;      /* '<Root>/ioa_gasVoltRaw' */
extern t_Voltage1 ioa_12VOutVoltActRaw;/* '<Root>/ioa_12VOutVoltActRaw' */
extern t_Voltage1 ioa_FC12VVoltActRaw; /* '<Root>/ioa_FC12VVoltActRaw' */
extern t_Voltage1 ioa_HVILVoltActRaw;  /* '<Root>/ioa_HVILVoltActRaw ' */
extern t_Voltage1 ioa_FCCCVoltActRaw;  /* '<Root>/ioa_FCCCVoltActRaw' */
extern t_Voltage1 ioa_SCCCVoltActRaw;  /* '<Root>/ioa_SCCCVoltActRaw' */
extern uint8_T ect_CrashOccur;         /* '<Root>/ect_CrashOccur' */
extern uint16_T com_CCP1ChrgCurrOut;   /* '<Root>/com_CCP1ChrgCurrOut' */
extern uint16_T com_CCP1ChrgVolt;      /* '<Root>/com_CCP1ChrgVolt' */
extern t_Temp1 SWC_CellTempMax;        /* '<Root>/com_CellTempMax' */
extern t_Temp1 SWC_CellTempMin;        /* '<Root>/com_CellTempMin' */
extern uint16_T com_Resistance;        /* '<Root>/com_Resistance' */
extern boolean_T CBMU_FM2St;           /* '<Root>/BMS_FM2St' */
extern t_Soc1 com_SOC;                 /* '<Root>/com_SOC' */
extern uint8_T com_CCP1ACConnect;      /* '<Root>/com_CCP1ACConnect' */
extern uint8_T com_CCP1ACRange;        /* '<Root>/com_CCP1ACRange' */
extern uint8_T com_CCP1ChrgrPreReadySts;/* '<Root>/com_CCP1ChrgPreReadySts' */
extern uint8_T com_CCP1CommSts;        /* '<Root>/com_CCP1CommSts' */
extern uint8_T com_CCP1HwFault;        /* '<Root>/com_CCP1HwFault' */
extern uint8_T com_CCP1TempSts;        /* '<Root>/com_CCP1TempSts' */
extern boolean_T COMM_NA;              /* '<Root>/COMM_NA' */
extern boolean_T SC_NA;                /* '<Root>/SC_NA' */
extern uint8_T com_CRM_RecResult;      /* '<Root>/com_CRM_RecResult' */
extern uint16_T com_BCP_PackSOC;       /* '<Root>/com_BCP_PackSOC' */
extern uint16_T com_BCP_PackVolt;      /* '<Root>/com_BCP_PackVolt' */
extern uint16_T com_CML_MaxOutCurrent; /* '<Root>/com_CML_MaxOutCurrent' */
extern uint16_T com_CML_MaxOutVolt;    /* '<Root>/com_CML_MaxOutVolt' */
extern uint16_T com_CML_MinOutVolt;    /* '<Root>/com_CML_MinOutVolt' */
extern uint8_T com_CRO_ChgerReady;     /* '<Root>/com_CRO_ChgerReady' */
extern uint8_T tMax;                   /* '<Root>/com_CTMax' */
extern uint8_T tMaxNum;                /* '<Root>/com_CTMaxNum' */
extern uint8_T tMin;                   /* '<Root>/com_CTMin' */
extern uint8_T tMinNum;                /* '<Root>/com_CTMinNum' */
extern uint16_T uMax;                  /* '<Root>/com_CVMax' */
extern uint8_T uMaxNum;                /* '<Root>/com_CVMaxNum' */
extern uint16_T uMin;                  /* '<Root>/com_CVMin' */
extern boolean_T Relay_CZ;             /* '<Root>/Relay_CZ' */
extern uint8_T DCVolt_Reach;           /* '<Root>/DCVolt_Reach' */
extern uint8_T HeatingEnable;          /* '<Root>/HeatingEnable' */
extern uint8_T ContactorMode;          /* '<Root>/ContactorMode' */
extern uint8_T DebugMode;              /* '<Root>/DebugMode' */

/* Imported (extern) states */
extern uint32_T ChargedAH;             /* '<S6>/Data Store Memory5' */
extern uint16_T com_BattCurr;          /* '<Root>/Data Store Memory5' */
extern uint16_T com_BattVolt;          /* '<Root>/Data Store Memory6' */
extern uint16_T LPC_CUR;               /* '<S10>/Data Store Memory2' */
extern uint8_T PC_chrg_St;             /* '<Root>/Data Store Memory' */
extern uint8_T CV_St;                  /* '<Root>/Data Store Memory1' */
extern uint8_T FCCur_St;               /* '<Root>/Data Store Memory2' */
extern uint8_T CTMaxFc_St;             /* '<Root>/Data Store Memory3' */
extern uint8_T SOC_St;                 /* '<Root>/Data Store Memory4' */
extern uint8_T ISO_St;                 /* '<Root>/Data Store Memory7' */
extern uint8_T ect_count;              /* '<S7>/Data Store Memory1' */
extern uint8_T ect_AirbagNormal;       /* '<S7>/Data Store Memory4' */
extern boolean_T com_CMLTimeoutFlag;   /* '<S1>/Data Store Memory1' */
extern boolean_T com_CCSTimeoutFlag;   /* '<S1>/Data Store Memory2' */
extern boolean_T com_CSDTimeoutFlag;   /* '<S1>/Data Store Memory3' */
extern boolean_T com_CEMTimeoutFlag;   /* '<S1>/Data Store Memory4' */
extern boolean_T com_CROTimeoutFlag;   /* '<S1>/Data Store Memory5' */
extern boolean_T com_CSTTimeoutFlag;   /* '<S1>/Data Store Memory6' */
extern boolean_T com_CTSTimeoutFlag;   /* '<S1>/Data Store Memory7' */
extern boolean_T com_CRMTimeoutFlag;   /* '<S1>/Data Store Memory8' */
extern uint16_T look2_iu8lu32n31yu16tu_e4FyxcSB(uint8_T u0, uint8_T u1, const
  uint8_T bp0[], const uint8_T bp1[], const uint16_T table[], const uint32_T
  maxIndex[], uint32_T stride);
extern uint16_T div_usu16_sat(int16_T numerator, uint16_T denominator);
extern int16_T div_nzp_s16(int16_T numerator, int16_T denominator);
extern void mul_wide_su32(int32_T in0, uint32_T in1, uint32_T *ptrOutBitsHi,
  uint32_T *ptrOutBitsLo);
extern int32_T mul_ssu32_loSR(int32_T a, uint32_T b, uint32_T aShift);
extern uint32_T div_nzp_repeat_u32(uint32_T numerator, uint32_T denominator,
  uint16_T nRepeatSub);

#endif                                 /* RTW_HEADER_CBMU_MON_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
