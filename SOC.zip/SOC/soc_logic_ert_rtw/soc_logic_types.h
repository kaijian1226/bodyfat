/*******************************************************************************
 *  Real-Time Workshop code generated for Simulink model < soc_logic >
 *
 *  File: soc_logic_types.h
 *  File Creation Date: 30-Aug-2016
 *  Code generated on : Tue Aug 30 18:03:34 2016
 *  Abstraction:
 *  Notes:
 *
 *  Model Information:
 *  Model Name: soc_logic
 *  Model Version: 1.137
 *  Model Description:
 *  Creation date:	Thu Nov 06 11:14:33 2014
 *  Last Saved Modification:   Tue Aug 30 18:01:52 2016
 *
 *  (c)Copyright 2008-2014��Wuhan Eureka Control System Co., Ltd.
 *******************************************************************************/
/******************************************************************************
 *  Include files
 ******************************************************************************/
#ifndef RTW_HEADER_soc_logic_types_h_
#define RTW_HEADER_soc_logic_types_h_
#include "rtwtypes.h"

/*****************************************************************************
 *  Defines
 *****************************************************************************/

/*****************************************************************************
 *  Data Types
 *****************************************************************************/
#ifndef _DEFINED_TYPEDEF_FOR_t_Percent2_
#define _DEFINED_TYPEDEF_FOR_t_Percent2_

/* Name: Percent2
   Unit: %
   Offset: 0
   Factor: 0.01
   DataType: Uint8 */
typedef uint8_T t_Percent2;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Voltage1_
#define _DEFINED_TYPEDEF_FOR_t_Voltage1_

/* Name: t_Voltage1
   Unit: mV
   Offset: 0
   Factor: 0.305176
   DataType: Uint16 */
typedef uint16_T t_Voltage1;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Temp1_
#define _DEFINED_TYPEDEF_FOR_t_Temp1_

/* Name: Temp1
   Unit: degC
   Offset: -40
   Factor: 1
   DataType: Uint8 */
typedef uint8_T t_Temp1;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_Boolean_
#define _DEFINED_TYPEDEF_FOR_Boolean_

typedef boolean_T Boolean;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Current1_
#define _DEFINED_TYPEDEF_FOR_t_Current1_

/* Name: Current1
   Unit: A
   Offset: 0
   Factor: 0.03125
   DataType: sint16 */
typedef int16_T t_Current1;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Capacity1_
#define _DEFINED_TYPEDEF_FOR_t_Capacity1_

/* Name: Capcity1
   Unit: As
   Offset: 0
   Factor: 0.0078125
   DataType: Sint32 */
typedef int32_T t_Capacity1;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Percent1_
#define _DEFINED_TYPEDEF_FOR_t_Percent1_

/* Name: Percent1
   Unit: %
   Offset: 0
   Factor: 0.0001
   DataType: Sint16 */
typedef int16_T t_Percent1;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Capacity3_
#define _DEFINED_TYPEDEF_FOR_t_Capacity3_

/* Name: Capcity3
   Unit: As
   Offset: 0
   Factor: 0.0003125
   DataType: SInt32 */
typedef int32_T t_Capacity3;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Time_
#define _DEFINED_TYPEDEF_FOR_t_Time_

/* Name: Time
   Unit: s
   Offset: 0
   Factor: 0.005
   DataType: Uint8 */
typedef uint16_T t_Time;

#endif

#ifndef _DEFINED_TYPEDEF_FOR_t_Factor1_
#define _DEFINED_TYPEDEF_FOR_t_Factor1_

/* Name: t_Factor1
   Unit:
   Offset: 0
   Factor: 2^-10
   DataType: Sint16 */
typedef int16_T t_Factor1;

#endif

/*****************************************************************************
 *  Definitions
 *****************************************************************************/

/*****************************************************************************
 *  Declarations
 *****************************************************************************/

/*****************************************************************************
 *  Global Function Declaration
 *****************************************************************************/
#endif                                 /* RTW_HEADER_soc_logic_types_h_ */

/*======================== TOOL VERSION INFORMATION ==========================*
 * MATLAB 8.5 (R2015a)09-Feb-2015                                             *
 * Simulink 8.5 (R2015a)09-Feb-2015                                           *
 * Simulink Coder 8.8 (R2015a)09-Feb-2015                                     *
 * Embedded Coder 6.8 (R2015a)09-Feb-2015                                     *
 * Stateflow 8.5 (R2015a)09-Feb-2015                                          *
 * Fixed-Point Designer 5.0 (R2015a)09-Feb-2015                               *
 *============================================================================*/

/*======================= LICENSE IN USE INFORMATION =========================*
 * fixed_point_toolbox                                                        *
 * matlab                                                                     *
 * matlab_coder                                                               *
 * real-time_workshop                                                         *
 * rtw_embedded_coder                                                         *
 * simulink                                                                   *
 *============================================================================*/
